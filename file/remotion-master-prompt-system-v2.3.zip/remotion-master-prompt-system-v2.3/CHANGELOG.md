# CHANGELOG

## v2.3 — Web Photo Research

Storyboard-ভিত্তিক image search, original source ও প্রতি-asset license যাচাই, responsible download, factual accuracy, credit ও fallback workflow; ASSETS.md template যোগ।

## v2.2 — Professional Motion & Delivery

Design judgment override, storyboard, independent motion controls, SVG asset delivery, QA এবং GoFile upload workflow যোগ। পুরোনো font-loader ও aesthetic rule conflict-এর অগ্রাধিকার নির্ধারণ। GoFile availability বা render সফলতা দাবি নয়।


## v2.1 — "Footage + Captions" (2026-10-24)

দুটি নতুন চাহিদা থেকে:

**(১) শুধু ছবি নয় — ভিডিও ফুটেজ সংগ্রহ।** নতুন **Annex M**: fallback chain (ইউজারের ভিডিও → AI ভিডিও → স্টক ভিডিও → ছবি+camera move → ভেক্টর), ক্লিপ আইন (২–৬s, ≥1080p, স্টক অডিও বন্ধ), `<OffthreadVideo>` ব্যবহার, শট-টাইপ→টেক্সট ম্যাপিং, grade match, ৮-পয়েন্ট Video QA Gate, `ASSETS.md` ফরম্যাট।

**(২) নিচে দিয়ে ওঠা ক্যাপশন, প্রতিটির নিজের রং।** নতুন **Annex N**: SRT/TXT → caption ম্যাপিং (অক্ষর-ভারিত সময় ভাগ), **palette cycle** (পরপর দুটি ক্যাপশনের রং কখনো এক নয়, deterministic), ৩টি অনুমোদিত স্টাইল (A Color Cycle · B Word Highlight · C Two-Tone), contrast law (≥৪.৫:১, auto-lighten), safe area টেবিল (16:9/9:16/1:1), সম্পূর্ণ Remotion reference implementation, ৯-পয়েন্ট Caption QA Gate।

**পরিবর্তিত:** `MASTER-PROMPT.md` — নতুন নিয়ম ১৮ক/১৮খ, Quality Bar-এ নতুন সারি, ইনপুট ম্যাট্রিক্সে ভিডিও, ধাপ ৩-এ B-roll ও ক্যাপশন ম্যাপিং।

**সংশোধন (ক্যাপশন):** ডিফল্ট ক্যাপশন স্টাইল এখন **B — ওয়ার্ড হাইলাইট** (ইউজারের নিশ্চিত পছন্দ), স্টাইল B-এর জন্য আলাদা মোশন নিয়ম (Annex N §৪.১) যোগ, এবং **wrap gotcha** ঠিক — শব্দগুলো `nowrap` + margin হলে লাইন ডানে উপচে পড়ত; এখন `flex-wrap` + `column-gap`।

**ডেমো:** `demo/caption-demo.html` + `demo/storyboard.jpg` (এই ফোল্ডারের বাইরে, আলাদা ডেলিভারি)।

---


## v2.0.1 — "Render-Hardened" (2026-10-23)

v2.0 সিস্টেম দিয়ে একটি পূর্ণ ২০ সেকেন্ডের ডেমো আসলে রেন্ডার করা হয়েছে
(১৯২০×১০৮০ · ৩০fps · ২ CPU · ২ GB RAM)। রেন্ডারে যা যা ভেঙেছিল, তার
প্রতিটি এখন ডকুমেন্টে ঠিক করা — **এগুলো অনুমান নয়, মাঠে ধরা পড়া বাগ।**

**পরিসর:** ৪,১৬৫ → **৪,৫৩১ লাইন** · ১৯ ফাইল · ডেমো প্রজেক্ট যুক্ত

### 🐛 রেন্ডারে ধরা পড়া ও সংশোধিত

| সমস্যা | যেখানে ঠিক হলো |
|---|---|
| রেন্ডারের মাঝপথে ফন্ট লোড **hang** করে (`delayRender() … not cleared`) — `FontFace.load()`, `@remotion/fonts`, data URI, timeout-fallback — **চারটি পদ্ধতিই ব্যর্থ** | Annex B — এখন বিশুদ্ধ সিঙ্ক্রোনাস CSS `@font-face` + base64 data URI; কোনো async গেট নয়। চারটি ব্যর্থ পদ্ধতিই টেবিলে নথিভুক্ত |
| Google Fonts-এর woff2 **unicode-range দিয়ে subset-split** — বাংলা ও ল্যাটিন আলাদা ফাইলে | Annex B — `.ttf` নামিয়ে নিজে subset করার নির্দেশ + cmap যাচাইয়ের নিয়ম |
| ব্যাকগ্রাউন্ড orb-এ `blur(70–90px)` একাই ফ্রেম-টাইম **৩ গুণ** বাড়ায় | Annex E §১১.১ — multi-stop gradient দিয়ে প্রতিস্থাপন (৩.০ → ০.৯ s/frame) |
| ডিফল্ট ৩০s `delayRender` timeout ধীর মেশিনে ফেল করে | Annex E §১১.২ — দুই জায়গায় ১২০s সেট করার নির্দেশ |
| পরিষ্কার Linux-এ Chrome Headless Shell `libnss3.so` না পেয়ে ক্র্যাশ | Annex E §১১.৩ — `apt-get` এক-লাইন কমান্ড |
| `lerp()` শুধু ২-বিন্দু range নিত; ৩-বিন্দু flash লিখলে TS এরর | `templates/motion.ts` — এখন N-বিন্দু সাপোর্ট করে |
| grade-এর `tintOpacity: 0.18` গোটা ফ্রেম একরঙা করে ফেলত | `templates/theme.ts` — ০.০৬; surface token গুলোও নিউট্রাল করা |
| secondary টাইপ ১০৮০p ভিডিওতে পড়া যেত না | `templates/theme.ts` — label ১৯→২৮, caption ১৬→২২, eyebrow ২২→২৬ |

### 🆕 নতুন

- **Annex E §১১ — "রেন্ডার পারফরম্যান্স"**: মাপা ফ্রেম-টাইম বাজেট
  (≤১.০s আরামদায়ক · >২.৫s ঠিক করো) এবং বাজেট ছাড়ালে কী কাটতে হবে তার ক্রম।
- **`tools/render-chunked.sh` প্যাটার্ন**: কম-RAM মেশিনে চাঙ্কে ভিডিও +
  এক পাসে অডিও + ffmpeg mux। চাঙ্ক-সীমানায় অডিও ফাটল পড়ে না।

---

## v2.0 — "Cinematic Grade" (2026-10-23)

ব্যবহারকারীর চাহিদা: *ভিজ্যুয়াল ও অ্যানিমেশন যেন After Effects-এর মতো হাই-এন্ড হয়; ফটো জেনারেশন, সাউন্ড ডিজাইন, ইন্ট্রো অ্যানিমেশন ও SVG যেন প্রিমিয়াম ও টপ-টিয়ার হয়।*

**পরিসর:** ১,৩৩৪ → **৪,১৬৫ লাইন** (+২,৮৩১) · ১৪ → ১৯ ফাইল · ০ → ২টি চালানোর মতো কোড টুল

---

### 🆕 নতুন ফাইল

| ফাইল | কী |
|---|---|
| **`annexes/K-intro-signature-system.md`** | সিনেমাটিক ইন্ট্রো সিস্টেম — ফ্রেম-নির্দিষ্ট ৫-beat sheet · ৮টি archetype · সম্পূর্ণ reference implementation · intro audio law · bookend outro · QA gate |
| **`annexes/L-svg-vector-lab.md`** | প্রিমিয়াম SVG ল্যাব — flat→premium রূপান্তর নিয়ম · gradient সিস্টেম · ৬টি SVG filter (bloom/liquid/depth/halation/grain/goo) · trim-path · path ও blob morph · ৮টি generative form · mask/clipPath · ৩-স্তর premium icon |
| **`templates/motion.ts`** | AE মোশন ইঞ্জিন (কোড) — ৮টি easing · ৬টি spring · fps-ভিত্তিক timing scale · **deterministic noise/wiggle** · anticipation · camera rig + DOF · shutter blur · beat grid · **audio ducking** |
| **`tools/make-audio.mjs`** | চালানোর মতো সাউন্ড জেনারেটর — শূন্য dependency, Node-এ pure DSP (biquad filter · ADSR · Schroeder reverb · soft clip · LUFS মিটার)। ১৪টি SFX + ৪-mood মিউজিক বেড + `MIX-REPORT.json` |
| **`CHANGELOG.md`** | এই ফাইল |

### ♻️ নাম পরিবর্তন
- `annexes/I-sfx-recipes.md` → **`annexes/I-sound-design-system.md`** (সম্পূর্ণ পুনর্লিখিত)

---

### 🔄 নীতি পরিবর্তন (v1.0-এর সিদ্ধান্ত উল্টানো)

| বিষয় | v1.0 | v2.0 | কেন |
|---|---|---|---|
| **ব্যাকগ্রাউন্ড মিউজিক** | ❌ নিষিদ্ধ ("শুধু SFX") | ✅ **ডিফল্টে চালু** + ducking | প্রিমিয়াম অনুভূতির ~৫০% অডিও থেকে আসে |
| **ইন্ট্রো** | একটি সাধারণ "hook সিন" | **আলাদা বাধ্যতামূলক সিস্টেম** (Annex K) | প্রথম ২ সেকেন্ডেই দর্শক সিদ্ধান্ত নেয় |
| **AI ছবি** | উৎস ক্রমে ৩য় | **২য়** — পূর্ণ prompt architecture সহ | concept-নির্দিষ্ট ছবি stock-এ মেলে না |
| **Entrance প্রপার্টি** | ≥২টি | **≥৩টি** (opacity + transform + blur/mask) | ২টি এখনো ফ্ল্যাট লাগে |
| **Post stack** | ৬ স্তর | **৯ স্তর** (+ split-tone, halation, film bar) | ফিল্মি গভীরতা |
| **Shadow** | একটি `box-shadow` | **৩-স্তর elevation স্কেল** | একক shadow = ফ্ল্যাট |
| **Transition timing** | `linearTiming` | **`springTiming`** | linear = "টেমপ্লেট" ভাব |
| **Determinism** | উল্লেখ ছিল | **`Math.random()` স্পষ্টভাবে নিষিদ্ধ** + seeded noise API | preview ≠ render সমস্যা |
| **ফন্ট** | "offline bundle করবে" | **`delayRender`/`continueRender` বাধ্যতামূলক** + কোড | "প্রিভিউ ঠিক, রেন্ডার ভুল"-এর মূল কারণ |
| **কমান্ড সংখ্যা** | ৩টি | **৪টি** (অডিও জেনারেশন যুক্ত) | — |

---

### 📈 সম্প্রসারিত Annex

| Annex | v1.0 | v2.0 | প্রধান সংযোজন |
|---|---|---|---|
| **A** Style Library | ১৬ স্টাইল | **২৪ স্টাইল** | ৩টি Tier · প্রতিটিতে "Premium Requirement" কলাম · scene composition-এর ৪ নিয়ম (focal point, ৩ স্তর depth, breathing, asymmetric balance) · grid সিস্টেম |
| **B** Text Animation | ২২ প্রিসেট (spec-only) | **৩৬ প্রিসেট + কোড** | AE Text Animator → Range Selector ম্যাপিং · `WordCascade`/`DepthExtrude`/`LightWipe` পূর্ণ implementation · ফন্ট loading কোড · বাংলা সেফটি ৮ → ৯ নিয়ম (mask-এ কার কাটার সতর্কতা, বর্ধিত টেস্ট স্ট্রিং) |
| **C** Icon System | বেসিক | stroke hierarchy (2.5/1.5/0.75) · "একটিই লাইব্রেরি" নিয়ম · ২টি নতুন animation pattern · optical sizing · QA |
| **D** Photo Pipeline | ১৫ treatment | **২৪ treatment** | **রেজোলিউশন আইন** (টেবিল) · **AI prompt architecture** (৬-ব্লক, ৭টি locked preset, negative prompt, ৭টি anti-AI-look নিয়ম) · পূর্ণ `PremiumPhoto` কোড (mask + halation + light wrap + DOF) · **৮-গেট Masterpiece Gate** |
| **E** Transitions/Post | ১২ ট্রানজিশন, ৬-স্তর | **২২ ট্রানজিশন, ৯-স্তর** | ৩টি Tier · Tier 3-এর কোড (LumaWipe, DisplaceOut, DollyThrough, LightStreak) · পূর্ণ `PostStack` কোড · dark/light টিউনিং টেবিল · **elevation সিস্টেম** · ৮টি background ধরন |
| **F** Motion | নীতি-তালিকা | সাউন্ড সরানো হয়েছে (→ I) · **১২ নীতি সংখ্যায়** · **velocity thinking** ডায়াগনস্টিক টেবিল · `CameraRig` কোড · depth/parallax স্কেল · **pacing টেবিল** |
| **G** Tutorial | ভালো ছিল | **§৭ premium polish** — বেসিক vs প্রিমিয়াম টেবিল · arc-সহ cursor physics · tutorial audio ম্যাপ (মিউজিক −4dB) |
| **H** Recipes | ২০ রেসিপি | **৪০ রেসিপি** · ৭টি গ্রুপ · `GlassCard`/`BrowserMockup`/`ProgressRing`/`Counter`/`Highlight` পূর্ণ কোড · **১৪-সারির GOTCHA তালিকা** |
| **I** Sound | ৫৬ লাইন SFX রেসিপি | **সম্পূর্ণ সিস্টেম** — ১৪টি SFX · মিউজিক উৎস ক্রম · **LUFS টার্গেট** · gain staging · **frequency slotting** · ducking কোড · sync law ডায়াগ্রাম · beat grid · রিপোর্ট-ভিত্তিক QA |
| **J** QA | ৯ বিভাগ | **১২ বিভাগ** + 🏆 **১২-পয়েন্ট Premium Gate** (ব্যর্থ = ডেলিভারি আটকায়) |

---

### 🎯 MASTER-PROMPT.md পরিবর্তন

- **§০.৫ Quality Bar** (নতুন) — ১৭-সারির "❌ বেসিক vs ✅ প্রিমিয়াম" টেবিল; প্রতিটি সিদ্ধান্তের মানদণ্ড
- **§১ নিয়ম** ২০ → **৩৩টি**, ৬টি বিভাগে সংগঠিত (কনটেন্ট সততা · মোশন · ভিজ্যুয়াল · টাইপোগ্রাফি · ইন্ট্রো-অডিও · যাচাই)
- **§৭ ইন্ট্রো সিস্টেম** (নতুন বিভাগ)
- **§১৩ ধাপ ৬ — Polish Pass** (নতুন, বাধ্যতামূলক): প্রথম build শেষে Quality Bar-এর বাঁ কলাম ধরে ধরে খুঁজে ঠিক করা
- ভূমিকায় Colorist · Sound Designer · Vector Illustrator যুক্ত
- Annex তালিকা A–J → **A–L**

---

### ✅ যাচাইকৃত

`tools/make-audio.mjs` Node.js v20.20.2-এ চালিয়ে পরীক্ষা করা হয়েছে:
- ১৪টি SFX + মিউজিক বেড সফলভাবে তৈরি (~৪ সেকেন্ডে)
- সব ফাইল ভ্যালিড 48kHz / 16-bit / stereo WAV (Python `wave` দিয়ে যাচাই)
- **Determinism নিশ্চিত** — একই আর্গুমেন্টে দুইবার চালিয়ে বিট-বাই-বিট অভিন্ন (SHA-256 মিল)
- চারটি mood (`cinematic`/`calm`/`tech`/`uplifting`) পরীক্ষিত
- কোনো clipping নেই; সব peak টার্গেটের মধ্যে

---

## v1.0 (প্রাথমিক সংস্করণ)

MASTER-PROMPT + Annex A–J + `templates/theme.ts` + `templates/project-structure.md`। ১,৩৩৪ লাইন।
