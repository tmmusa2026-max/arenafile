# Annex L — Premium Vector & SVG Lab (নতুন, v2.0)

> **কেন এই Annex:** Annex C আইকন*ব্যবস্থাপনা* শেখায়। এই Annex শেখায় কীভাবে vector গ্রাফিক্স **টপ-টিয়ার** দেখায় — gradient, filter, depth, morph, trim-path, generative form।
>
> **মূল নীতি:** ফ্ল্যাট একরঙা SVG = বেসিক। প্রিমিয়াম SVG-তে সবসময় থাকে — **gradient fill + depth shadow + একটি specular highlight + একটি motion property**।

---

## ১. Flat → Premium: রূপান্তর নিয়ম

| বেসিক (নিষিদ্ধ) | প্রিমিয়াম (বাধ্যতামূলক) |
|---|---|
| `fill="#10B981"` | `fill="url(#heroGrad)"` — ২–৩ স্টপ, কোণ ১৩৫° |
| shadow নেই | `filter: drop-shadow()` ২ স্তরে (ambient + contact) |
| একই stroke-width সর্বত্র | hierarchy: মূল form 2.5px · detail 1.5px · hairline 0.75px |
| pure black/white | কখনো `#000`/`#FFF` নয় — `theme.colors.bg` / `.text` |
| স্থির shape | অন্তত একটি: trim-path draw · gradient drift · micro-rotate |
| ধারালো কোণ | `strokeLinejoin="round"` + corner radius |
| একক স্তর | ≥২ স্তর: form + highlight overlay (opacity 0.1–0.2) |

---

## ২. Gradient সিস্টেম (`<defs>` একবার, পুরো প্রজেক্টে পুনর্ব্যবহার)

```tsx
// src/components/svg/Defs.tsx — প্রতিটি scene-এ একবার mount করো
export const SvgDefs: React.FC = () => (
  <svg width={0} height={0} style={{ position: "absolute" }} aria-hidden>
    <defs>
      {/* Hero fill — ১৩৫° */}
      <linearGradient id="heroGrad" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%"   stopColor={theme.colors.primaryLite} />
        <stop offset="48%"  stopColor={theme.colors.primary} />
        <stop offset="100%" stopColor={theme.colors.primaryDeep} />
      </linearGradient>

      {/* Surface — সূক্ষ্ম, প্রায় অদৃশ্য (ফ্ল্যাট ভাব ভাঙে) */}
      <linearGradient id="surfGrad" x1="0" y1="0" x2="0.3" y2="1">
        <stop offset="0%"   stopColor={theme.colors.surfaceHi} />
        <stop offset="100%" stopColor={theme.colors.bgAlt} />
      </linearGradient>

      {/* Specular — উপরের কিনারায় আলো */}
      <linearGradient id="specular" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%"   stopColor="#fff" stopOpacity="0.22" />
        <stop offset="45%"  stopColor="#fff" stopOpacity="0.04" />
        <stop offset="100%" stopColor="#fff" stopOpacity="0" />
      </linearGradient>

      {/* Radial glow — hero element-এর পেছনে */}
      <radialGradient id="glowRad">
        <stop offset="0%"   stopColor={theme.colors.primary} stopOpacity="0.45" />
        <stop offset="60%"  stopColor={theme.colors.primary} stopOpacity="0.10" />
        <stop offset="100%" stopColor={theme.colors.primary} stopOpacity="0" />
      </radialGradient>

      {/* Stroke gradient — রেখার দৈর্ঘ্য বরাবর রঙ বদল */}
      <linearGradient id="strokeGrad" x1="0" y1="0" x2="1" y2="0">
        <stop offset="0%"   stopColor={theme.colors.primary} stopOpacity="0" />
        <stop offset="25%"  stopColor={theme.colors.primary} />
        <stop offset="75%"  stopColor={theme.colors.accent} />
        <stop offset="100%" stopColor={theme.colors.accent} stopOpacity="0" />
      </linearGradient>
    </defs>
  </svg>
);
```

> **GOTCHA:** একই `id` দুবার DOM-এ থাকলে Chrome প্রথমটি ধরে। Defs একবারই mount করো, অথবা id-তে scene prefix দাও।

---

## ৩. SVG Filter লাইব্রেরি (এখানেই আসল AE-ভাব আসে)

```tsx
<defs>
  {/* ── A. Soft Glow / Bloom — hero element-এ ── */}
  <filter id="bloom" x="-60%" y="-60%" width="220%" height="220%">
    <feGaussianBlur stdDeviation="10" result="b1" />
    <feGaussianBlur stdDeviation="26" result="b2" />
    <feColorMatrix in="b2" type="matrix"
      values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 1.6 0" result="b2x" />
    <feMerge>
      <feMergeNode in="b2x" /><feMergeNode in="b1" /><feMergeNode in="SourceGraphic" />
    </feMerge>
  </filter>

  {/* ── B. Liquid / Ink distort — Intro archetype 3, transition ── */}
  {/* seed স্থির রাখো; baseFrequency frame থেকে animate করবে (deterministic) */}
  <filter id="liquid" x="-20%" y="-20%" width="140%" height="140%">
    <feTurbulence type="fractalNoise" baseFrequency="0.012 0.02"
      numOctaves="3" seed="7" result="noise" />
    <feDisplacementMap in="SourceGraphic" in2="noise"
      scale="38" xChannelSelector="R" yChannelSelector="G" />
  </filter>

  {/* ── C. Layered depth shadow — ফ্ল্যাট shadow নয় ── */}
  <filter id="depth" x="-40%" y="-40%" width="180%" height="200%">
    <feDropShadow dx="0" dy="2"  stdDeviation="2"  floodOpacity="0.45" />
    <feDropShadow dx="0" dy="14" stdDeviation="16" floodOpacity="0.40" />
    <feDropShadow dx="0" dy="40" stdDeviation="44" floodOpacity="0.30" />
  </filter>

  {/* ── D. Halation — highlight-এর চারপাশে ফিল্মি আভা ── */}
  <filter id="halation" x="-50%" y="-50%" width="200%" height="200%">
    <feColorMatrix type="matrix"
      values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  .6 .6 .3 0 -0.35" result="hi" />
    <feGaussianBlur in="hi" stdDeviation="18" result="hiB" />
    <feFlood floodColor={theme.colors.primaryLite} result="tint" />
    <feComposite in="tint" in2="hiB" operator="in" result="glowTint" />
    <feMerge><feMergeNode in="glowTint" /><feMergeNode in="SourceGraphic" /></feMerge>
  </filter>

  {/* ── E. Grain inside vector — plastic ভাব ভাঙে ── */}
  <filter id="vecGrain">
    <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" seed="3" result="n" />
    <feColorMatrix in="n" type="saturate" values="0" result="ng" />
    <feComposite in="ng" in2="SourceGraphic" operator="in" result="gc" />
    <feBlend in="SourceGraphic" in2="gc" mode="overlay" />
  </filter>

  {/* ── F. Gooey merge — particle/blob একসাথে মিশে যায় ── */}
  <filter id="goo">
    <feGaussianBlur stdDeviation="12" result="blur" />
    <feColorMatrix in="blur" type="matrix"
      values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 24 -10" result="goo" />
    <feBlend in="SourceGraphic" in2="goo" />
  </filter>
</defs>
```

**কর্মক্ষমতা সতর্কতা:** `feTurbulence` ব্যয়বহুল। একটি ফ্রেমে সর্বোচ্চ **২টি** turbulence-ভিত্তিক filter। বড় এলাকায় `baseFrequency` বাড়িয়ে `scale` কমাও।

---

## ৪. Trim Path (AE-এর সবচেয়ে ব্যবহৃত shape অপারেটর)

`pathLength={1}` ব্যবহার করলে দৈর্ঘ্য normalize হয় — হাতে dasharray মাপার দরকার নেই।

```tsx
const DrawPath: React.FC<{ d: string; delay?: number; dur?: number }> =
({ d, delay = 0, dur = 30 }) => {
  const frame = useCurrentFrame();
  const p = prog(frame, delay, dur, ease.inOut);
  return (
    <path d={d} pathLength={1}
      fill="none" stroke="url(#strokeGrad)" strokeWidth={2.5}
      strokeLinecap="round" strokeLinejoin="round"
      strokeDasharray={1} strokeDashoffset={1 - p} />
  );
};
```

**ভ্যারিয়েন্ট:**
- **দুই প্রান্ত থেকে:** `strokeDasharray={`${p} ${1 - p}`}` + `strokeDashoffset={-p / 2}`
- **চলমান খণ্ড (comet):** `strokeDasharray={"0.12 0.88"}` + `strokeDashoffset` animate → একটি আলোর রেখা path ধরে ছোটে
- **Draw তারপর fill:** stroke 0→1 (০–৩০f), তারপর `fill-opacity` 0→1 (৩০–৪২f)

---

## ৫. Path Morphing (deterministic, dependency ছাড়া)

**শর্ত:** দুই path-এ **একই সংখ্যক ও একই ধরনের কমান্ড** থাকতে হবে। তাহলে সংখ্যাগুলো সরাসরি interpolate করা যায়।

```tsx
/** "M12 2L22 12L12 22L2 12Z" ধরনের path থেকে সংখ্যা বের করে lerp */
const morphPath = (a: string, b: string, t: number): string => {
  const na = a.match(/-?[\d.]+/g)!.map(Number);
  const nb = b.match(/-?[\d.]+/g)!.map(Number);
  if (na.length !== nb.length) return t < 0.5 ? a : b;  // fallback: crossfade করো
  let i = 0;
  return a.replace(/-?[\d.]+/g, () => {
    const v = na[i] + (nb[i] - na[i]) * t; i++;
    return v.toFixed(2);
  });
};
```

**ব্যবহার:** play→pause, menu→close, check→circle-check, arrow দিক পরিবর্তন।
**না পারলে:** scale+fade crossfade (৮f) — জোর করে ভাঙা morph কখনো নয়।

### Blob morph (organic, কমান্ড-সংখ্যা সমস্যা নেই)

```tsx
/** n-point radial blob; frame থেকে deterministic deform */
const blobPath = (frame: number, n = 6, r = 180, amp = 26, seed = 5): string => {
  const pts = Array.from({ length: n }, (_, i) => {
    const a = (i / n) * Math.PI * 2;
    const rr = r + noise1D(frame / 40 + i * 1.7, seed) * amp * 2 - amp;
    return [Math.cos(a) * rr, Math.sin(a) * rr] as const;
  });
  // Catmull-Rom → cubic bezier (মসৃণ, বন্ধ আকৃতি)
  let d = `M${pts[0][0].toFixed(1)},${pts[0][1].toFixed(1)}`;
  for (let i = 0; i < n; i++) {
    const p0 = pts[(i - 1 + n) % n], p1 = pts[i], p2 = pts[(i + 1) % n], p3 = pts[(i + 2) % n];
    const c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6];
    const c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
    d += ` C${c1[0].toFixed(1)},${c1[1].toFixed(1)} ${c2[0].toFixed(1)},${c2[1].toFixed(1)} ${p2[0].toFixed(1)},${p2[1].toFixed(1)}`;
  }
  return d + "Z";
};
```

---

## ৬. Generative Vector Forms (deterministic — `Math.random()` নিষিদ্ধ)

| Form | কৌশল | কোথায় |
|---|---|---|
| **Radial repeater** | `Array.from({length:n})` + `rotate(360/n*i)` — AE Repeater | logo mark, loader, burst |
| **Concentric rings** | r += step, opacity -= step, ভিন্ন গতিতে ঘোরে | tech bg, radar |
| **Connected node graph** | seeded বিন্দু + দূরত্ব < threshold হলে রেখা | AI/network সিন |
| **Isometric grid** | `skewY(-30deg)` + `skewX(30deg)` সমন্বয় | architecture, 3D ভাব |
| **Waveform** | `Math.sin` + noise1D সমন্বয়ে polyline | audio, data, pulse |
| **Spiral / helix** | θ বাড়ার সাথে r বাড়ে; z-depth-এ opacity | DNA, growth, journey |
| **Dot matrix fade** | grid-এ বিন্দু, কেন্দ্র থেকে দূরত্ব অনুযায়ী opacity | subtle bg |
| **Contour lines** | nested blobPath, ভিন্ন r | topographic bg |

```tsx
// Connected node graph — deterministic
const nodes = Array.from({ length: 22 }, (_, i) => ({
  x: hash01(i, 11) * 1920,
  y: hash01(i, 22) * 1080,
  r: 2 + hash01(i, 33) * 3,
}));
const links = nodes.flatMap((a, i) =>
  nodes.slice(i + 1).map((b) => ({ a, b, d: Math.hypot(a.x - b.x, a.y - b.y) }))
).filter((l) => l.d < 280);
```

---

## ৭. Mask ও ClipPath (AE track matte-এর সমতুল্য)

| AE ধারণা | SVG/CSS |
|---|---|
| Alpha Matte | `<mask>` সাদা = দৃশ্যমান · কালো = লুকানো |
| Luma Matte | `<mask style="mask-type:luminance">` বা CSS `mask-image: linear-gradient()` |
| Track Matte animate | mask-এর ভেতরের shape-এ transform animate |
| Set Matte | `clipPath` reference একাধিক element-এ |

```tsx
{/* নরম প্রান্তের wipe — hard edge নয়, এটাই প্রিমিয়াম দেখায় */}
<mask id="softWipe">
  <rect width="100%" height="100%" fill="url(#wipeGrad)" />
</mask>
<linearGradient id="wipeGrad" x1="0" y1="0" x2="1" y2="0"
  gradientTransform={`translate(${lerp(p, [0, 1], [-1, 1])} 0)`}>
  <stop offset="0%"  stopColor="#fff" />
  <stop offset="42%" stopColor="#fff" />
  <stop offset="58%" stopColor="#000" />   {/* ১৬% নরম প্রান্ত */}
  <stop offset="100%" stopColor="#000" />
</linearGradient>
```

CSS সংস্করণ (DOM element-এ, দ্রুততর):
```tsx
style={{
  WebkitMaskImage: `linear-gradient(100deg, #000 0%, #000 42%, transparent 58%)`,
  WebkitMaskSize: "300% 100%",
  WebkitMaskPosition: `${lerp(p, [0, 1], [100, -100])}% 0`,
  maskImage: `linear-gradient(100deg, #000 0%, #000 42%, transparent 58%)`,
  maskSize: "300% 100%",
  maskPosition: `${lerp(p, [0, 1], [100, -100])}% 0`,
}}
```

---

## ৮. Icon Upgrade — Annex C-এর আইকনকে প্রিমিয়াম করা

```tsx
const PremiumIcon: React.FC<{ d: string; delay?: number; size?: number }> =
({ d, delay = 0, size = 44 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = springP(frame, fps, delay, "bouncy");
  const draw = prog(frame, delay + 2, 22, ease.inOut);

  return (
    <svg viewBox="0 0 24 24" width={size} height={size}
      style={{ transform: `scale(${lerp(p, [0, 1], [0.6, 1])})`, overflow: "visible" }}>
      {/* স্তর ১ — পেছনে নরম glow */}
      <circle cx="12" cy="12" r="11" fill="url(#glowRad)" opacity={p * 0.5} />
      {/* স্তর ২ — মূল stroke, gradient সহ, draw-on */}
      <path d={d} pathLength={1} fill="none" stroke="url(#heroGrad)"
        strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round"
        strokeDasharray={1} strokeDashoffset={1 - draw}
        filter="url(#depth)" />
      {/* স্তর ৩ — উপরে ক্ষীণ specular */}
      <path d={d} fill="none" stroke="#fff" strokeWidth={0.7}
        strokeLinecap="round" opacity={p * 0.25}
        transform="translate(0,-0.4)" />
    </svg>
  );
};
```

তিনটি স্তর = ফ্ল্যাট আইকন আর ফ্ল্যাট থাকে না। **প্রতিটি hero আইকনে এই প্যাটার্ন।**

---

## ৯. Vector QA Gate

- [ ] কোনো `fill` সরাসরি hex নয় — সব `url(#...)` বা `theme.colors.*`
- [ ] প্রতিটি প্রধান shape-এ ≥২ স্তর (form + highlight/glow)
- [ ] `viewBox` আছে; `width`/`height` hardcode করে aspect ভাঙেনি
- [ ] `strokeLinecap`/`strokeLinejoin="round"` সর্বত্র
- [ ] stroke-width hierarchy মানা (2.5 / 1.5 / 0.75)
- [ ] কোনো raster (png/jpg) আইকন হিসেবে নেই
- [ ] এক ফ্রেমে `feTurbulence` filter ≤ ২টি
- [ ] সব `<defs>` id অনন্য (ডুপ্লিকেট id নেই)
- [ ] morph-এ দুই path-এর কমান্ড-সংখ্যা মিলেছে (নাহলে crossfade fallback)
- [ ] generative form-এ `Math.random()` **নেই** — শুধু `hash01`/`noise1D`
- [ ] `npx remotion still` দিয়ে vector-ভারী ফ্রেম রেন্ডার করে edge sharpness দেখা হয়েছে
