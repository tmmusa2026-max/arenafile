# Annex C — Icon ও Symbol সিস্টেম (v2.0)

> **v2.0 পরিবর্তন:** আইকনের *ব্যবস্থাপনা* এখানে; আইকনকে **প্রিমিয়াম দেখানোর কৌশল** → **Annex L §৮**। দুটো একসঙ্গে পড়তে হবে।

## ১. উৎস ও লাইসেন্স

- **Inline SVG only** — Lucide / Feather / Heroicons / Phosphor / Material Symbols (outline) থেকে path কপি করে `src/components/icons/`-এ। সব MIT/Apache — বাণিজ্যিক ব্যবহারযোগ্য। `ASSETS.md`-তে উৎস + লাইসেন্স।
- **Emoji সম্পূর্ণ নিষিদ্ধ** — platform glyph রঙিন, প্যালেট-বহির্ভূত, hero-color নিয়ম ভাঙে, ব্যাকগ্রাউন্ডে অদৃশ্য হয়।
- আইকন কখনো raster (png) নয় — সব vector, যেকোনো সাইজে sharp।
- আইকন লাইব্রেরি **একটিই** বেছে নাও। দুটো লাইব্রেরি মেশালে stroke ভাষা ভেঙে যায় (Lucide 2px round vs Heroicons 1.5px — চোখে ধরা পড়ে)।

## ২. এক আইকন ভাষা (সারা ভিডিওতে)

| টোকেন | মান |
|---|---|
| Grid | 24×24 (সব আইকন এই canvas-এ) |
| Stroke hierarchy | মূল form **2.2–2.5px** · detail **1.5px** · hairline **0.75px** |
| Cap / join | `round` — ব্যতিক্রম নেই |
| Fill | `url(#heroGrad)` বা `theme.colors.*` — **inline hex কখনো নয়** |
| Size on screen | UI-ভেতরে 16–24px · তালিকায় 32–40px · hero lockup 44–64px |
| Filled variant | শুধু status (সফল/ত্রুটি) — বাকি সব line icon |
| স্তর | প্রতিটি **hero** আইকনে ≥৩ স্তর (glow + stroke + specular — Annex L §৮) |

এক ভিডিওতে ২টির বেশি আইকন স্টাইল (line + filled + duotone) মেশাবে না।

## ৩. Icon Animation Patterns

| প্যাটার্ন | কীভাবে | কখন |
|---|---|---|
| **Stroke Draw-On** | `pathLength={1}` + dashoffset 1→0 | লাইন আইকন এন্ট্রি, টেকনিক্যাল |
| **Icon Pop** | scale 0.6→1.1→1 (spring bouncy) + opacity, 10f | সাধারণ এন্ট্রি |
| **Draw + Fill** | stroke 0→1 (০–২২f) তারপর fill-opacity 0→1 (২২–৩২f) | প্রিমিয়াম reveal |
| **Icon Morph** | path interpolate (Annex L §৫); কমান্ড না মিললে crossfade | অবস্থা পরিবর্তন |
| **Icon Grid Stagger** | 4f offset, ছোট pop | ফিচার গ্রিড |
| **Check Burst** | টিক draw + ৪টি ছোট লাইন বার্স্ট (6f) | সম্পন্ন/সফল |
| **Progress Ring** | circle dashoffset + counter sync | অগ্রগতি |
| **Badge Pulse** | ছোট pop + ১বার pulse (12f) | notification |
| **Icon+Label Lockup** | আইকন → ৬f পরে label (follow-through) | feature উপস্থাপনা |
| **Idle Micro-rotate** | `wiggle(frame, fps, 0.4, 1.2, seed)` deg | ২s+ স্থায়ী আইকন |
| **Draw + Fade Exit** | exit এন্ট্রান্সের চেয়ে দ্রুত (8f) | সব আইকনে |

সব আইকন **stagger করবে** (একসঙ্গে সব নয়)। প্রতি staggered item-এ SFX নয় — গ্রুপ reveal-এ ১টি।

## ৪. ব্যবহার ম্যাট্রিক্স

| জায়গা | স্টাইল | সঙ্গে |
|---|---|---|
| Feature / তালিকা | line icon 32–40px | ছোট label |
| Status | filled + status color | **সবসময় লেবেল টেক্সট সহ** (শুধু রঙে নয় — accessibility) |
| Dashboard / UI mockup | line icon 16–24px | `uiText` |
| Recap / Checklist | animated check | আইটেম টেক্সট |
| Step indicator | number chip | step label |
| Hero lockup | 3-স্তর premium icon (Annex L §৮) | h2/h3 |
| শুধু সাজসজ্জা | **আইকন নয়** — shape/line/particle | — |

## ৫. Lockup ও Badge

- **Icon + Text lockup:** gap সবসময় **pixel-এ** (8–16px), এক baseline-এ, একই entrance group।
- **Badge:** icon পেছনে rounded rect (hero color 12–20% opacity) বা border pill + `insetTop`।
- **Notification dot:** icon-এর উপরে-ডানে 8px dot + একবার pulse।
- আইকন কখনো টেক্সটের উপর বসে পাঠযোগ্যতা কমাবে না।
- **Optical sizing:** বৃত্তাকার আইকন (circle, globe) বর্গাকারের চেয়ে ~৮% বড় করলে চোখে সমান লাগে।

## ৬. Icon QA

- [ ] সব আইকন একটিই লাইব্রেরি থেকে
- [ ] কোনো emoji নেই; কোনো raster আইকন নেই
- [ ] stroke-width hierarchy মানা; সব `round` cap/join
- [ ] fill/stroke `theme` বা `url(#grad)` থেকে — inline hex নেই
- [ ] hero আইকনে ≥৩ স্তর
- [ ] সব আইকনে entrance + exit অ্যানিমেশন আছে
- [ ] status আইকনের সঙ্গে লেবেল টেক্সট আছে
- [ ] `ASSETS.md`-তে আইকন লাইব্রেরি + লাইসেন্স উল্লেখ
