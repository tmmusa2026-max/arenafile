# Annex K — Cinematic Intro & Signature Opening System (নতুন, v2.0)

> **কেন এই Annex:** দর্শক প্রথম ২ সেকেন্ডে সিদ্ধান্ত নেয় দেখবে কি না। v1.0-তে ইন্ট্রো ছিল "একটা hook সিন" — v2.0-তে এটি **আলাদা, কাঠামোবদ্ধ, বাধ্যতামূলক সিস্টেম**।
>
> **নিয়ম:** প্রতিটি ভিডিওতে signature intro থাকবে। দৈর্ঘ্য: short-form ≤ 2.5s · long-form ≤ 5s। **এর বেশি কখনো নয়** — দীর্ঘ ইন্ট্রো retention হত্যা করে।

---

## ১. Intro Beat Sheet (ফ্রেম-নির্দিষ্ট — ৩০fps, ৯০ ফ্রেম = ৩s)

প্রতিটি ইন্ট্রোর ভেতরে এই ৫টি beat থাকবেই। frame সংখ্যা `fps` থেকে আসবে (`timing(fps)`), নিচেরগুলো @30fps রেফারেন্স।

| Beat | Frame | নাম | কী ঘটে | অডিও |
|---|---|---|---|---|
| **1** | 0–4 | **Pre-roll silence** | প্রায় কালো/খালি। ১–২টি ক্ষীণ element breathe করছে। **এই নীরবতাই পরের আঘাতকে শক্তিশালী করে** | riser শুরু (−8f থেকে) |
| **2** | 4–12 | **IMPACT** | প্রধান form/logo/shape হঠাৎ আসে — scale 1.25→1, blur 14→0, exposure flash | `impact_cine_01` (frame 2-এ) |
| **3** | 12–34 | **BUILD** | চারপাশের element stagger হয়ে ভরে ওঠে (ray, grid, particle, rule-line) | `shimmer_tail_01` |
| **4** | 34–58 | **TITLE LOCKUP** | মূল শিরোনাম + eyebrow settle; light-sweep একবার যায় | `whoosh_soft_01` + `glass_tap_01` |
| **5** | 58–80 | **HOLD → EXIT** | ১২–১৬f সম্পূর্ণ স্থির (পড়ার সময়), তারপর দ্রুত exit/transition | `sub_drop_01` (exit-এ) |

**Anti-pattern:** beat 2-এ একসঙ্গে ৫টা জিনিস ঢোকানো। IMPACT = **একটি** form। বাকিরা beat 3-এ।

---

## ২. ৮টি Intro Archetype

কনটেন্টের টোন অনুযায়ী একটি বেছে নাও। একই ভিডিওতে একটিই।

| # | Archetype | ভিজ্যুয়াল ভাষা | কখন | মূল কৌশল |
|---|---|---|---|---|
| 1 | **Light-Streak Logo Sting** | আলোর রেখা কেটে যায় → তার পথে logo/mark জন্মায় → bloom → settle | ব্র্যান্ড, প্রফেশনাল সার্ভিস | `mask-image` sweep + bloom pulse |
| 2 | **Kinetic Type Slam** | বড় শব্দ ভিন্ন দিক থেকে এসে লক হয়; একটি শব্দ hero color | হুক-নির্ভর, শিক্ষামূলক | per-word spring `slam` + স্তরিত depth |
| 3 | **Liquid Ink Reveal** | কালি/তরল ছড়িয়ে পড়ে, তার ভেতর থেকে কনটেন্ট | সৃজনশীল, আবেগী | SVG `feTurbulence` + `feDisplacementMap` on mask |
| 4 | **Particle Assembly** | ছড়ানো বিন্দু ছুটে এসে একটি form গঠন করে | টেক, ডেটা, AI | deterministic seeded positions → converge |
| 5 | **Camera Fly-Through** | ক্যামেরা স্তরের ভেতর দিয়ে ছুটে যায় → শিরোনামে থামে | সিনেমাটিক, গল্প | `translateZ` + perspective + DOF blur |
| 6 | **Glitch Boot-Up** | স্ক্যান-লাইন, RGB split, data flicker → স্থির হয় | ডেভ, সাইবার, টেকনিক্যাল | slice offset + channel shift (৫–৮f মাত্র) |
| 7 | **Shutter / Film Leader** | ক্যামেরা শাটার/film countdown ভাব, letterbox বার নামে | ডকুমেন্টারি, প্রিমিয়াম | bar slide + iris mask + grain burst |
| 8 | **Geometric Build** | রেখা আঁকা হয় → shape বন্ধ হয় → fill আসে → content | আর্কিটেকচার, প্রসেস, B2B | SVG trim-path (`pathLength=1`) |

---

## ৩. Reference Implementation — Light-Streak Logo Sting

```tsx
// src/scenes/Intro.tsx
import { AbsoluteFill, useCurrentFrame, useVideoConfig, Sequence, Audio, staticFile } from "remotion";
import { theme } from "../theme";
import { lerp, prog, springP, timing, breathe, ease } from "../motion";

export const Intro: React.FC<{ title: string; eyebrow?: string }> = ({ title, eyebrow }) => {
  const frame = useCurrentFrame();
  const { fps, width, height } = useVideoConfig();
  const T = timing(fps);

  // Beat 2 — IMPACT (frame 4–12)
  const impact = prog(frame, T.s(0.13), T.s(0.27), ease.out);
  const markScale = lerp(impact, [0, 1], [1.25, 1], ease.out);
  const markBlur  = lerp(impact, [0, 1], [14, 0], ease.out);
  const flash     = lerp(frame, [T.s(0.13), T.s(0.2), T.s(0.4)], [0, 0.55, 0]);

  // Beat 3 — BUILD: rays stagger
  const rays = 14;

  // Beat 4 — light sweep একবার (frame 34–58)
  const sweep = prog(frame, T.s(1.13), T.s(0.8), ease.inOut);

  // Beat 5 — EXIT (দ্রুত, entrance-এর অর্ধেক সময়)
  const exitP = prog(frame, T.s(2.0), T.s(0.33), ease.in);
  const exitScale = lerp(exitP, [0, 1], [1, 1.12], ease.in);
  const exitFade  = lerp(exitP, [0, 1], [1, 0], ease.in);

  return (
    <AbsoluteFill style={{ background: theme.colors.bg, opacity: exitFade }}>
      {/* exposure flash — IMPACT-এর মুহূর্তে */}
      <AbsoluteFill style={{
        background: theme.colors.primaryLite, opacity: flash,
        mixBlendMode: "screen", pointerEvents: "none",
      }} />

      <AbsoluteFill style={{
        alignItems: "center", justifyContent: "center",
        transform: `scale(${exitScale})`,
      }}>
        {/* ── MARK: radial ray build (Beat 2 + 3) ── */}
        <div style={{
          position: "relative", width: 240, height: 240,
          transform: `scale(${markScale * breathe(frame, 0.01)})`,
          filter: `blur(${markBlur}px) ${theme.bloom.iconFilter}`,
        }}>
          {Array.from({ length: rays }).map((_, i) => {
            const p = springP(frame, fps, T.s(0.27) + i * 1.3, "bouncy");
            return (
              <div key={i} style={{
                position: "absolute", left: "50%", top: "50%",
                width: 18, height: 104 * p,
                background: theme.gradients.hero,
                borderRadius: 999, transformOrigin: "50% 0%",
                transform: `translateX(-50%) rotate(${(360 / rays) * i}deg) translateY(18px)`,
              }} />
            );
          })}
        </div>

        {/* ── TITLE LOCKUP (Beat 4) ── */}
        <div style={{ marginTop: 56, textAlign: "center", position: "relative", overflow: "hidden" }}>
          {eyebrow && (
            <div style={{
              ...theme.textStyles.eyebrow, color: theme.colors.primary,
              opacity: prog(frame, T.s(1.13), T.s(0.4)),
              transform: `translateY(${lerp(prog(frame, T.s(1.13), T.s(0.4)), [0, 1], [14, 0])}px)`,
              marginBottom: theme.space.sm,
            }}>{eyebrow}</div>
          )}

          <div style={{ position: "relative", display: "inline-block" }}>
            <div style={{
              ...theme.textStyles.h1, color: theme.colors.text,
              opacity: prog(frame, T.s(1.2), T.s(0.5)),
              transform: `translateY(${lerp(prog(frame, T.s(1.2), T.s(0.5)), [0, 1], [34, 0])}px)`,
              textShadow: theme.bloom.heroText,
            }}>{title}</div>

            {/* light sweep — টেক্সটের উপর একবার */}
            <div style={{
              position: "absolute", inset: 0, pointerEvents: "none",
              background: `linear-gradient(100deg, transparent 38%, ${theme.colors.primaryLite}55 50%, transparent 62%)`,
              transform: `translateX(${lerp(sweep, [0, 1], [-140, 140])}%)`,
              mixBlendMode: "screen",
            }} />
          </div>
        </div>
      </AbsoluteFill>

      {/* ── AUDIO: transient visual-এর ২–৩f আগে ── */}
      <Sequence from={0}>
        <Audio src={staticFile("sfx/riser_soft_01.wav")} volume={0.30} />
      </Sequence>
      <Sequence from={T.s(0.13) - T.sfxLead}>
        <Audio src={staticFile("sfx/impact_cine_01.wav")} volume={0.55} />
      </Sequence>
      <Sequence from={T.s(1.13) - T.sfxLead}>
        <Audio src={staticFile("sfx/whoosh_soft_01.wav")} volume={0.32} />
      </Sequence>
      <Sequence from={T.s(2.0) - T.sfxLead}>
        <Audio src={staticFile("sfx/sub_drop_01.wav")} volume={0.42} />
      </Sequence>
    </AbsoluteFill>
  );
};
```

---

## ৪. Intro Audio Law (সবচেয়ে বেশি উপেক্ষিত, সবচেয়ে বেশি কার্যকর)

```
  frame:  -8        0         4        12              34          58    80
          │  riser ─────────────────▶ │                 │           │     │
          │                  ▓IMPACT  │                 │           │     │
          │                           └─ shimmer tail ──┘           │     │
          │                                       whoosh ──────────▶│     │
          │                                                   sub drop ──▶│
   music: ────────────────────────────────── bed fades in ─────────────────▶
```

1. **Riser ভিডিও শুরুর আগেই শুরু হয় না** — frame 0 থেকে, কিন্তু impact frame 4-এ। riser-এর ৪ ফ্রেম = tension।
2. **IMPACT সাউন্ড visual-এর ২–৩ frame আগে** (`T.sfxLead`)। পরে বাজলে মস্তিষ্ক "আউট অফ সিঙ্ক" ধরে ফেলে।
3. **মিউজিক বেড intro-এর শেষে ঢোকে**, শুরুতে নয় — ইন্ট্রো শেষে বেড ঢুকলে "এখন আসল কনটেন্ট শুরু" সংকেত যায়।
4. **Impact-এর পরে ৬–১০ frame প্রায় নীরবতা** — শূন্যতাই গভীরতা তৈরি করে।
5. ইন্ট্রোতে সর্বোচ্চ **৪টি** সাউন্ড ইভেন্ট। এর বেশি = গোলমাল।

---

## ৫. Outro / End-Card (ইন্ট্রোর প্রতিধ্বনি)

শেষে ইন্ট্রোর ভিজ্যুয়াল ভাষাই ফিরে আসবে (bookend) — কিন্তু **শান্ত সংস্করণে**:

- একই mark, কিন্তু ধীরে (entrance ২× সময়), impact সাউন্ড নয় — `chime_pluck_01`
- CTA থাকলে একটিই, পরিষ্কার, পড়ার জন্য ≥ ৪৫ frame স্থির
- মিউজিক বেড শেষ ১.৫ bar ধরে ধীরে নামবে (`audioEnvelope`)
- **শেষ frame কখনো কালো/ফাঁকা নয়** — শেষ visual-এ থেমে শেষ হবে

---

## ৬. Intro QA Gate (Annex J-এর সঙ্গে — ব্যর্থ হলে ডেলিভারি নয়)

- [ ] ইন্ট্রোর দৈর্ঘ্য সীমার ভেতরে (short ≤2.5s · long ≤5s)
- [ ] ৫টি beat আলাদা করে চেনা যায় (একসাথে সব ঢোকেনি)
- [ ] IMPACT ফ্রেমে **একটিই** প্রধান form
- [ ] Beat 5-এ ≥১২ frame সম্পূর্ণ স্থিরতা আছে
- [ ] Impact SFX visual-এর ২–৩f আগে (frame গুনে যাচাই)
- [ ] ইন্ট্রোতে সাউন্ড ইভেন্ট ≤ ৪টি; clipping নেই
- [ ] মিউজিক বেড intro শেষে ঢুকেছে, শুরুতে নয়
- [ ] Exit entrance-এর চেয়ে দ্রুত
- [ ] Outro ইন্ট্রোর ভাষার সঙ্গে মেলে (bookend)
- [ ] `npx remotion still` দিয়ে frame 2, 8, 20, 45, 70 রেন্ডার করে **চোখে দেখা হয়েছে**
