# Annex D — Photo / Image Pipeline (v2.0 — Masterpiece Grade)

> **v2.0 লক্ষ্য:** "ছবি বসানো" নয় — **প্রতিটি ফ্রেম যেন একটি স্থিরচিত্র হিসেবেও দাঁড়াতে পারে**। কোনো AI-plastic লুক নয়, কোনো লো-রেজ নয়, কোনো "stock ছবি বসানো হয়েছে" ভাব নয়।
>
> **Masterpiece Gate:** কোনো ছবি কম্পোজিশনে যাবে না যতক্ষণ না §৬-এর ৮টি গেট পাস করে।

---

## ১. রেজোলিউশন আইন (আপসহীন)

| আউটপুট | ছবির ন্যূনতম দীর্ঘ বাহু | কারণ |
|---|---|---|
| 1920×1080 | **≥ 3200px** | Ken Burns 1.08× zoom + crop margin |
| 1080×1920 (reel) | **≥ 2600px** | একই |
| full-bleed background | **≥ 3840px** | sharp থাকতেই হবে |
| কার্ডের ভেতর (≤40% frame) | ≥ 1600px | — |

- **কখনো ১.২৫× এর বেশি upscale নয়।** ঝাপসা ছবির চেয়ে graphic fallback ভালো।
- Ken Burns যত zoom করবে, তত বেশি source রেজোলিউশন লাগবে: `প্রয়োজনীয় px = ফ্রেম প্রস্থ × zoomTo × 1.3`
- JPEG quality ≥ 85; ব্যানডিং থাকলে PNG।

---

## ২. উৎসের ক্রম (Fallback Chain)

1. **ইউজারের ছবি** → `public/images/` — সবসময় প্রথম
2. **AI-generated** (টুল থাকলে) — v2.0-তে **উন্নীত**, কারণ concept-নির্দিষ্ট ছবি stock-এ পাওয়া যায় না। §৩-এর prompt architecture বাধ্যতামূলক
3. **Stock** — Pexels · Unsplash · Pixabay (license যাচাই করে, source URL `ASSETS.md`-তে)
4. **Graphic fallback** — gradient panel + premium SVG (Annex L) + typography

> Google Images থেকে সরাসরি ছবি **নিষিদ্ধ** (license অযাচাই)। ছবি ব্যবহার করা না গেলে "ব্যবহার করা হয়েছে" দাবি করবে না।

---

## ৩. AI Image Prompt Architecture

একটি ভিডিওর সব ছবি **একই পৃথিবী থেকে** আসতে হবে। তাই prompt-এর ৬টি ব্লকের মধ্যে ৫টি **লক করা** থাকবে, শুধু SUBJECT বদলাবে।

```
[1 SUBJECT]      ← একমাত্র পরিবর্তনশীল অংশ
[2 SHOT]         ← LOCKED: lens + angle + framing
[3 LIGHT]        ← LOCKED: আলোর ধরন + দিক + সময়
[4 PALETTE]      ← LOCKED: theme রঙের শব্দরূপ
[5 MEDIUM]       ← LOCKED: film stock / render engine ভাষা
[6 NEGATIVE]     ← LOCKED: সবসময় একই
```

### উদাহরণ (Emerald Noir theme, cinematic photography)

```
a software engineer reviewing code on a large monitor in a quiet studio,
85mm lens, shallow depth of field f/1.8, eye-level medium shot, subject off-center right,
soft directional key light from window left, deep falloff, moody low-key, late afternoon,
desaturated teal-green and warm amber palette, deep emerald shadows,
shot on Kodak Portra 400, subtle film grain, natural skin texture, realistic imperfections,
--no text, letters, watermark, logo, signature, extra fingers, plastic skin,
   oversaturated colors, HDR halo, lens flare, distorted hands, cartoon, 3d render
```

### LOCKED ব্লকের প্রিসেট (একটি বেছে নাও, সব ছবিতে একই)

| প্রিসেট | SHOT | LIGHT | MEDIUM |
|---|---|---|---|
| **Cinematic Realism** | 85mm, f/1.8, eye-level | soft key + deep falloff, low-key | Kodak Portra 400, subtle grain |
| **Clean Editorial** | 50mm, f/4, straight-on | large softbox, even, high-key | digital medium format, crisp |
| **Tech Noir** | 35mm, f/2, slight low angle | rim light + practical glow, dark | Cinestill 800T, halation |
| **Documentary** | 35mm, f/2.8, candid | available light, window | Fuji 400H, natural |
| **Product Studio** | 100mm macro, f/8 | three-point, gradient sweep bg | studio digital, ultra sharp |
| **Flat Vector Illus.** | — | flat lighting, no shadow gradient | vector illustration, 2 colors + 1 accent |
| **Isometric 3D** | isometric 45°, orthographic | soft global illumination | clay render, matte material |

### Negative prompt (সবসময়, ব্যতিক্রম নয়)

```
text, letters, words, typography, watermark, logo, signature, caption,
extra fingers, deformed hands, distorted face, plastic skin, waxy skin,
oversaturated, HDR halo, over-sharpened, lens flare, chromatic fringe,
stock-photo smile, cluttered background, low resolution, jpeg artifacts
```

### Anti-AI-look নিয়ম

| ঝুঁকি | প্রতিকার |
|---|---|
| হাতের বিকৃতি | হাতের close-up এড়াও; হাত থাকলে frame-এর ছোট অংশে |
| মুখের "plastic" ভাব | prompt-এ `natural skin texture, realistic imperfections`; মুখ ছোট রাখো |
| অতিরিক্ত নিখুঁত/symmetrical | `candid`, `imperfect`, `off-center` যোগ করো |
| লেখা বিকৃত | ছবিতে কখনো লেখা চাইবে না — টেক্সট Remotion-এ বসবে |
| ব্র্যান্ড লোগো | AI-তে চাইবে না; আসল লোগো ফাইল overlay করো |
| সব ছবি একই রকম | SUBJECT-এ বৈচিত্র্য; কিন্তু LOCKED ব্লক অপরিবর্তিত |
| AI ছবিতে চোখ | দৃষ্টি ক্যামেরা থেকে সরানো (`looking away`) — নিরাপদ |

**`ASSETS.md`-তে প্রতিটি AI ছবির জন্য:** ব্যবহৃত prompt, টুলের নাম, "AI-generated" লেবেল।

---

## ৪. Photo Treatment Library (২৪টি)

ছবি কখনো শুধু `<Img>` হিসেবে বসবে না। ন্যূনতম **Ken Burns + scrim + grade + elevation**।

### বাধ্যতামূলক বেস (প্রতিটি ছবিতে)

| স্তর | কী |
|---|---|
| 1 | **Ken Burns** — scale 1→1.08, pan; পরপর শটে zoom-in/out alternate |
| 2 | **Grade match** — `filter: saturate(1.04) contrast(1.06)` + theme tint soft-light |
| 3 | **Scrim** — টেক্সট থাকলে `theme.gradients.scrimBottom/Side` |
| 4 | **Elevation** — full-bleed ছাড়া সব ছবিতে `theme.elevation.e3` |
| 5 | **Grain match** — গ্লোবাল grain ছবির উপরেও পড়বে (আলাদা দেখাবে না) |

### ট্রিটমেন্ট

| # | ট্রিটমেন্ট | কীভাবে | কোথায় |
|---|---|---|---|
| 1 | Ken Burns | scale + pan (বাধ্যতামূলক) | সব still |
| 2 | Gradient Scrim | contrast-এর জন্য overlay | text + photo |
| 3 | Duotone | grayscale → theme color soft-light | ব্র্যান্ড টোন |
| 4 | Rounded Card Frame | radius 28 + hairline + e3 shadow | ফিচার কার্ড |
| 5 | Mask Reveal | shape mask grow (12–18f) | এন্ট্রি |
| 6 | **Soft-Edge Mask** | `mask-image` gradient — hard edge নয় | প্রিমিয়াম এন্ট্রি |
| 7 | Mosaic Reveal | grid tile stagger 4f | এন্ট্রি |
| 8 | Parallax Stack | ২–৩ স্তর 0.3/0.6/1.0 গতিতে | depth |
| 9 | **Depth-of-Field Pull** | পেছনের স্তরে blur 6→0 | ফোকাস শিফট |
| 10 | Before/After | animated divider | তুলনা |
| 11 | Polaroid Stack | ±3° rotate + stack + shadow | স্টোরি |
| 12 | Photo + HUD | grid/line/label annotation | টেকনিক্যাল |
| 13 | Cutout Collage | bg-মুক্ত subject + shape | এনার্জেটিক |
| 14 | Film Border | সাদা margin + grain | সিনেমাটিক |
| 15 | Text Window | `background-clip: text` | হুক |
| 16 | Split Screen | অর্ধেক ছবি + অর্ধেক graphic | explainer |
| 17 | Layered Panels (2.5D) | ছবি কেটে সামনে/পেছনে | depth |
| 18 | **Light Wrap** | ছবির কিনারায় bg-রঙের নরম আভা | composite বিশ্বাসযোগ্য করে |
| 19 | **Halation Pass** | highlight-এ উষ্ণ bloom (Annex L filter D) | ফিল্মি ভাব |
| 20 | **Anamorphic Crop** | 2.39:1 letterbox, উপরে/নিচে বার | সিনেমাটিক মুহূর্ত |
| 21 | **Chromatic Edge** | কিনারায় 1px RGB split | realism |
| 22 | **Vignette (per-image)** | গ্লোবাল vignette-এর অতিরিক্ত | ফোকাস |
| 23 | **Color Match Pass** | অন্যগুলোর সঙ্গে না মিললে per-asset filter | mismatch সংশোধন |
| 24 | **Reflection/Floor** | নিচে mirrored fade copy (opacity 0.12) | product shot |

---

## ৫. Premium Photo Component (reference)

```tsx
// src/components/photo/PremiumPhoto.tsx
import { AbsoluteFill, Img, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../../theme";
import { lerp, prog, ease } from "../../motion";

export const PremiumPhoto: React.FC<{
  src: string; delay?: number; zoomTo?: number; panX?: number;
  scrim?: "bottom" | "side" | "none"; framed?: boolean; focalX?: number; focalY?: number;
}> = ({ src, delay = 0, zoomTo = 1.08, panX = -26,
       scrim = "bottom", framed = true, focalX = 50, focalY = 45 }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();

  // Ken Burns — পুরো সিন জুড়ে
  const scale = lerp(frame, [0, durationInFrames], [1, zoomTo], ease.inOut);
  const pan   = lerp(frame, [0, durationInFrames], [0, panX], ease.inOut);

  // Soft-edge mask reveal
  const rev = prog(frame, delay, 20, ease.out);
  // DOF pull — এন্ট্রিতে সামান্য blur, তারপর শার্প
  const blur = lerp(rev, [0, 1], [8, 0], ease.out);

  return (
    <div style={{
      position: "absolute", inset: 0,
      borderRadius: framed ? theme.radii.lg : 0,
      overflow: "hidden",
      border: framed ? `1px solid ${theme.colors.line}` : "none",
      boxShadow: framed ? theme.elevation.e3 : "none",
      opacity: rev,
      WebkitMaskImage: "linear-gradient(100deg,#000 0%,#000 45%,transparent 62%)",
      WebkitMaskSize: "260% 100%",
      WebkitMaskPosition: `${lerp(rev, [0, 1], [100, 0])}% 0`,
      maskImage: "linear-gradient(100deg,#000 0%,#000 45%,transparent 62%)",
      maskSize: "260% 100%",
      maskPosition: `${lerp(rev, [0, 1], [100, 0])}% 0`,
    }}>
      <Img src={staticFile(src)} style={{
        width: "100%", height: "100%",
        objectFit: "cover", objectPosition: `${focalX}% ${focalY}%`,
        transform: `scale(${scale}) translateX(${pan}px)`,
        filter: `${theme.grade.filmFilter} blur(${blur}px)`,
      }} />

      {/* Halation — highlight-এ উষ্ণ আভা */}
      <AbsoluteFill style={{
        background: `radial-gradient(ellipse at ${focalX}% ${focalY}%, ${theme.colors.halation}, transparent 62%)`,
        mixBlendMode: "screen", opacity: theme.grade.halationOpacity, pointerEvents: "none",
      }} />

      {/* Light wrap — কিনারায় bg রঙের আভা, composite বিশ্বাসযোগ্য করে */}
      <AbsoluteFill style={{
        boxShadow: `inset 0 0 90px 24px ${theme.colors.bg}`,
        opacity: 0.55, pointerEvents: "none",
      }} />

      {/* Scrim — টেক্সটের contrast */}
      {scrim !== "none" && (
        <AbsoluteFill style={{
          background: scrim === "bottom" ? theme.gradients.scrimBottom : theme.gradients.scrimSide,
          pointerEvents: "none",
        }} />
      )}
    </div>
  );
};
```

---

## ৬. Masterpiece Gate (৮টি — প্রতিটি ছবিতে, ব্যর্থ হলে ছবি বাদ)

প্রতিটি ছবির জন্য `npx remotion still` দিয়ে একটি ফ্রেম রেন্ডার করে **চোখে দেখে** যাচাই:

- [ ] **1. Sharp** — 100%-এ দেখে ঝাপসা/pixelated নয়; upscale ≤1.25×
- [ ] **2. Composed** — subject rule-of-thirds বা সচেতনভাবে কেন্দ্রে; মুখ/লোগো/মূল অংশ crop-এ কাটেনি
- [ ] **3. Graded** — ছবির রঙ theme-এর সঙ্গে মিশেছে; "বাইরে থেকে বসানো" লাগছে না
- [ ] **4. Readable** — উপরে টেক্সট থাকলে contrast ≥ 4.5:1 (scrim আছে)
- [ ] **5. Natural** — AI হলে: হাত/মুখ/লেখা বিকৃত নয়, plastic skin নেই
- [ ] **6. Moving** — Ken Burns আছে; ছবি স্থির দাঁড়িয়ে নেই
- [ ] **7. Integrated** — grain ও vignette ছবির উপরেও পড়েছে; light wrap আছে
- [ ] **8. Licensed** — source + license `ASSETS.md`-তে; AI হলে prompt সহ "AI-generated"

> একটি ছবিও ৮টি গেট পাস না করলে: সেটি বাদ দিয়ে graphic fallback ব্যবহার করো এবং delivery note-এ জানাও।
