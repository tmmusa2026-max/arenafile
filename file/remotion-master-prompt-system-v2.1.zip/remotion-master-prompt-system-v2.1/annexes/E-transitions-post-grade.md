# Annex E — Transitions, Backgrounds ও Cinematic Post/Grade (v2.0)

> **v2.0 পরিবর্তন:** ১২ → **২২টি ট্রানজিশন** (৭টি AE-গ্রেড নতুন, কোড সহ)। Post stack ৬ → **৯ স্তর** (halation, light wrap, bar, split-tone যুক্ত)। Shadow/elevation সিস্টেম বাধ্যতামূলক।

---

## ১. Transition লাইব্রেরি (২২টি)

প্রতিটি **8–14 frame @30fps** (60fps-এ স্কেল)। ট্রানজিশনের মাঝবিন্দু **beat grid**-এ (Annex I §৬)।

### Tier 1 — বেসিক (দ্রুত, নিরাপদ)

| # | ট্রানজিশন | কীভাবে | কোথায় |
|---|---|---|---|
| 1 | Cut (on beat) | সরাসরি | দ্রুত পেসিং |
| 2 | Slide / Wipe | প্যানেল স্লাইড | সাধারণ |
| 3 | Crossfade | 12–18f opacity | ধীর/সংবেদনশীল মুহূর্ত |
| 4 | Split Panel | ২–৩ স্লাইস ভিন্ন দিকে | তালিকা→তালিকা |
| 5 | Letterbox Bars | বার আসে, মাঝে cut | চ্যাপ্টার |

### Tier 2 — ক্যামেরা ও শক্তি

| # | ট্রানজিশন | কীভাবে | কোথায় |
|---|---|---|---|
| 6 | Whip Pan + blur | bg 1500px/6f + blur(10px), মাঝে cut | এনার্জেটিক |
| 7 | Zoom Blur / Scale-through | A scale→1.35 + fade, B 0.82→1 | হুক→বডি |
| 8 | **Dolly Push-Through** | `translateZ` + perspective, DOF blur সহ | সিনেমাটিক |
| 9 | Light Leak / Flash | আলোর ঝলক + fade | ইমোশনাল শিফট |
| 10 | Glitch Cut / RGB split | 5–8f slice + channel shift | ডেভ/টেক |
| 11 | **Shutter Snap** | iris/bar দ্রুত বন্ধ-খোলা + flash | ফটো/প্রোডাক্ট |

### Tier 3 — AE-গ্রেড (v2.0 নতুন, কোড §২-এ)

| # | ট্রানজিশন | কীভাবে | কোথায় |
|---|---|---|---|
| 12 | **Luma Matte Wipe** | gradient mask নরম প্রান্তে সরে যায় | প্রিমিয়াম সর্বত্র |
| 13 | **Displacement Morph** | `feTurbulence` + `feDisplacementMap` বেড়ে-কমে | ক্রিয়েটিভ |
| 14 | **Liquid / Ink Bleed** | blob path morph + goo filter | আবেগী, ব্র্যান্ড |
| 15 | **Mask Shape Wipe** | hero-color আকৃতি সুইপ | ব্র্যান্ডেড |
| 16 | **Match Cut** | দুই সিনে একই আকৃতি/অবস্থান | স্মার্ট সংযোগ |
| 17 | **Morph Cut (shape)** | shape A → shape B path interpolate | প্রসেস/রূপান্তর |
| 18 | **Particle Dissolve** | grid tile scatter + converge | টেক/ডেটা |
| 19 | **Page Curl / Fold** | 3D rotateY দুই অর্ধে | ডকুমেন্ট/ধাপ |
| 20 | **Light Streak Pass** | আলোর রেখা কেটে যায়, পেছনে cut | ইন্ট্রো/লোগো |
| 21 | **Type Through** | বড় অক্ষরের ভেতর দিয়ে ক্যামেরা ঢোকে | হুক |
| 22 | **Grade Flash** | ১ ফ্রেম exposure/invert pop, তারপর cut | ইমপ্যাক্ট (≤২বার) |

### সিলেকশন নিয়ম

- পরপর **একই ট্রানজিশন নয়**; ১ মিনিটে ২–৪টি স্টাইল যথেষ্ট
- Tier 3 ব্যয়বহুল — পুরো ভিডিওতে ৩–৫ বার, যেখানে অর্থ আছে
- ট্রানজিশন **অর্থ সহায়তা করবে**, "এফেক্ট দেখাতে" নয়
- Tutorial-এ: শুধু cut/slide; UI state কখনো ঢাকবে না
- একই দিকে তাকিয়ে থাকা দুই সিনে শুধু cut

---

## ২. AE-গ্রেড ট্রানজিশন — কোড

### ১২. Luma Matte Wipe (সবচেয়ে বেশি ব্যবহার্য)

নরম প্রান্তই প্রিমিয়াম দেখায় — hard edge amateur।

```tsx
const LumaWipe: React.FC<{ progress: number; angle?: number; soft?: number;
  children: React.ReactNode }> = ({ progress, angle = 100, soft = 18, children }) => {
  const m = `linear-gradient(${angle}deg, #000 0%, #000 ${50 - soft}%, transparent ${50 + soft}%, transparent 100%)`;
  return (
    <AbsoluteFill style={{
      WebkitMaskImage: m, maskImage: m,
      WebkitMaskSize: "300% 100%", maskSize: "300% 100%",
      WebkitMaskPosition: `${lerp(progress, [0, 1], [100, -100])}% 0`,
      maskPosition: `${lerp(progress, [0, 1], [100, -100])}% 0`,
    }}>{children}</AbsoluteFill>
  );
};
```

### ১৩. Displacement Morph

```tsx
const DisplaceOut: React.FC<{ progress: number; children: React.ReactNode }> =
({ progress, children }) => {
  // bell curve — মাঝে সর্বোচ্চ বিকৃতি, দুই প্রান্তে শূন্য
  const amt = Math.sin(progress * Math.PI) * 90;
  return (
    <>
      <svg width={0} height={0} aria-hidden>
        <filter id="dispT">
          <feTurbulence type="fractalNoise" baseFrequency="0.009 0.016"
            numOctaves="2" seed="11" result="n" />
          <feDisplacementMap in="SourceGraphic" in2="n" scale={amt}
            xChannelSelector="R" yChannelSelector="G" />
        </filter>
      </svg>
      <AbsoluteFill style={{ filter: "url(#dispT)", opacity: 1 - progress * 0.35 }}>
        {children}
      </AbsoluteFill>
    </>
  );
};
```

### ৮. Dolly Push-Through (সত্যিকারের 3D)

```tsx
const DollyThrough: React.FC<{ p: number; children: React.ReactNode }> = ({ p, children }) => (
  <AbsoluteFill style={{ perspective: 1400, perspectiveOrigin: "50% 50%" }}>
    <AbsoluteFill style={{
      transform: `translateZ(${lerp(p, [0, 1], [0, 700], ease.whip)}px)`,
      filter: `blur(${Math.sin(p * Math.PI) * 9}px)`,
      opacity: lerp(p, [0.55, 1], [1, 0], ease.in),
    }}>{children}</AbsoluteFill>
  </AbsoluteFill>
);
```

### ২০. Light Streak Pass

```tsx
const streakX = lerp(p, [0, 1], [-30, 130]);
<AbsoluteFill style={{
  background: `linear-gradient(104deg, transparent ${streakX - 14}%, ${theme.colors.primaryLite}cc ${streakX}%, transparent ${streakX + 14}%)`,
  mixBlendMode: "screen",
  filter: "blur(10px)",
}} />
// cut ঠিক streakX ≈ 50 হওয়ার frame-এ
```

### `@remotion/transitions` সংস্করণ

```tsx
import { TransitionSeries, springTiming } from "@remotion/transitions";
import { slide } from "@remotion/transitions/slide";

<TransitionSeries>
  <TransitionSeries.Sequence durationInFrames={90}><SceneA /></TransitionSeries.Sequence>
  <TransitionSeries.Transition
    presentation={slide({ direction: "from-right" })}
    timing={springTiming({ config: theme.spring.smooth, durationInFrames: 12 })} />
  <TransitionSeries.Sequence durationInFrames={150}><SceneB /></TransitionSeries.Sequence>
</TransitionSeries>
```
> `linearTiming` নয় — `springTiming` ব্যবহার করো। linear ট্রানজিশনই "টেমপ্লেট" ভাব দেয়।

---

## ৩. Background সিস্টেম (ফ্ল্যাট সম্পূর্ণ নিষিদ্ধ)

প্রতিটি সিনে এর একটি, drift motion সহ:

| ব্যাকগ্রাউন্ড | গঠন | কোথায় |
|---|---|---|
| **Gradient mesh / orbs** | ২–৩টি blurred radial orb, sin-wave drift | ডিফল্ট |
| **Technical grid** | SVG pattern, opacity ≤0.12, ধীর parallax | টেক |
| **Dot matrix** | কেন্দ্র থেকে দূরত্ব অনুযায়ী opacity fade | subtle |
| **Contour / topographic** | nested blobPath (Annex L §৫) | organic |
| **Node network** | seeded বিন্দু + সংযোগ রেখা | AI/data |
| **Layered panels** | সামনে/পেছনে স্তর, ভিন্ন parallax | depth |
| **Volumetric light** | কোণ থেকে নরম আলোর কোণ (conic-gradient + blur) | সিনেমাটিক |
| **Clean light/dark** | প্রায় খালি + একটি সূক্ষ্ম gradient | বিরতি সিন |

**নিয়ম:** background সাহায্য করবে, ঢাকবে না। পরপর দুই সিনে একই background নয়; কিন্তু visual identity এক।

---

## ৪. Cinematic Post Stack — ৯ স্তর (স্থির ক্রম, প্রতিটি সিনে)

```
   ┌─ 9. Vignette              ← সবচেয়ে উপরে
   │  8. Grain (film flicker)
   │  7. Letterbox / film bars (ঐচ্ছিক)
   │  6. Chromatic aberration  (শুধু দ্রুত move/impact)
   │  5. Halation              (highlight-এ উষ্ণ bloom)
   │  4. Split-tone grade      (shadow ঠান্ডা / highlight উষ্ণ)
   │  3. Color grade overlay   (hero color soft-light)
   │  2. Content: graphics, type, UI
   │  1. Assets: photo, video
   └─ 0. Background mesh       ← সবচেয়ে নিচে
```

```tsx
// src/components/post/PostStack.tsx — প্রতিটি scene এটি wrap করবে
export const PostStack: React.FC<{ children: React.ReactNode; impact?: number }> =
({ children, impact = 0 }) => {
  const frame = useCurrentFrame();
  const g = theme.grade;
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;

  return (
    <AbsoluteFill>
      {/* 0–2 */}
      {children}

      {/* 3. hero color grade */}
      <AbsoluteFill style={{ backgroundColor: theme.colors.primary,
        mixBlendMode: g.tintBlend, opacity: g.tintOpacity, pointerEvents: "none" }} />

      {/* 4. split tone */}
      <AbsoluteFill style={{ pointerEvents: "none", mixBlendMode: "soft-light",
        background: `linear-gradient(180deg, ${g.splitToneHighlight}, transparent 46%, ${g.splitToneShadow})` }} />

      {/* 5. halation */}
      <AbsoluteFill style={{ pointerEvents: "none", mixBlendMode: "screen",
        opacity: g.halationOpacity,
        background: `radial-gradient(ellipse 60% 48% at 50% 44%, ${theme.colors.halation}, transparent 70%)` }} />

      {/* 6. chromatic aberration — শুধু impact মুহূর্তে */}
      {impact > 0.01 && (
        <AbsoluteFill style={{ pointerEvents: "none", mixBlendMode: "screen",
          opacity: impact * 0.5,
          background: `linear-gradient(90deg, rgba(255,0,60,0.16), transparent 18%, transparent 82%, rgba(0,140,255,0.16))`,
          transform: `scale(${1 + impact * 0.004})` }} />
      )}

      {/* 7. film bars */}
      <AbsoluteFill style={{ pointerEvents: "none", background: theme.gradients.filmBars }} />

      {/* 8. grain */}
      <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: noise,
        backgroundSize: "220px", opacity: g.grainOpacity, mixBlendMode: g.grainBlend,
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px` }} />

      {/* 9. vignette */}
      <AbsoluteFill style={{ pointerEvents: "none", background: g.vignette }} />
    </AbsoluteFill>
  );
};
```

### টিউনিং

| প্যারামিটার | Dark theme | Light theme |
|---|---|---|
| `tintOpacity` | 0.16–0.24 | 0.08–0.14 |
| `grainOpacity` | 0.045–0.055 | 0.025–0.035 |
| `grainBlend` | `overlay` | `multiply` |
| vignette গভীরতা | 0.28–0.34 | 0.12–0.18 |
| halation | 0.14–0.20 | 0.06–0.10 |

---

## ৫. Shadow & Elevation সিস্টেম (বাধ্যতামূলক)

একটি `box-shadow` = ফ্ল্যাট। প্রতিটি উঁচু surface-এ **৩ স্তর**: ambient (বড়, নরম) + key (দিকনির্দেশক) + contact (ছোট, তীক্ষ্ণ)। `theme.elevation.e1…e4` এটাই এনকোড করে।

| Element | Elevation | অতিরিক্ত |
|---|---|---|
| chip / badge | `e1` | `insetTop` |
| কার্ড | `e2` | hairline border |
| image card / UI mockup | `e3` | `insetGlass` |
| hero element / modal | `e4` | `bloom.hero` |

**নিয়ম:** যে element যত উঁচু, তার shadow তত **বড় ও নরম** (ঘন নয়)। `0 4px 8px rgba(0,0,0,0.9)` = খারাপ; `0 48px 96px -40px rgba(0,0,0,0.65)` = ভালো।

---

## ৬. Atmosphere Elements (সংযতে — এক ফ্রেমে একটিই)

| Element | সীমা | কখন |
|---|---|---|
| Floating dust / bokeh | 10–20টি, opacity 0.08–0.25, deterministic position | depth |
| Light sweep | কার্ড/টেক্সটের উপর 8–12f | hero reveal |
| Volumetric shaft | conic-gradient + blur(40px), opacity ≤0.12 | সিনেমাটিক |
| Light leak | খুব হালকা, কোণ থেকে | সিন ট্রানজিশন |
| Node network | ধীর draw | কানেকশন/টেক |
| Liquid blob | sin/cos drift | creative |
| Wireframe globe/cube | CSS 3D ধীর ঘূর্ণন | গ্লোবাল/টেক |

particle কখনো টেক্সট/UI অস্পষ্ট করবে না। সব position `hash01()` থেকে — `Math.random()` নয়।

---

## ৭. Post QA Gate

- [ ] প্রতিটি সিনে ৯-স্তর stack আছে; ক্রম সঠিক (grain/vignette সবার উপরে)
- [ ] কোনো ফ্ল্যাট সলিড background নেই
- [ ] প্রতি ফ্রেমে glowing/hero element ≤ ১টি
- [ ] পরপর দুই সিনে একই ট্রানজিশন নেই
- [ ] ট্রানজিশনের মাঝবিন্দু beat-এ snap করা
- [ ] Tier 3 ট্রানজিশন ≤ ৫ বার
- [ ] `feTurbulence` এক ফ্রেমে ≤ ২টি (পারফরম্যান্স)
- [ ] সব shadow `theme.elevation.*` থেকে; inline box-shadow নেই
- [ ] Chromatic aberration শুধু impact মুহূর্তে, স্থায়ীভাবে নয়
- [ ] Light theme হলে grade/grain মান কমানো হয়েছে

---

## ১১. রেন্ডার পারফরম্যান্স — মাঠে পরীক্ষিত

এই অ্যানেক্সের grade stack একটি বাস্তব ২-CPU / ১ GB মেশিনে ১৯২০×১০৮০ @ ৩০fps
রেন্ডার করে মাপা হয়েছে। ফলাফল থেকে পাওয়া নিয়মগুলো:

### ১১.১ বড় `filter: blur()` = সবচেয়ে বড় খরচ

Software rasterizer-এ blur-এর খরচ **O(area × radius)**। একটি ১৫০০×১৫০০ orb-এ
`blur(90px)` একাই ফ্রেম-টাইম ৩ গুণ বাড়িয়ে দেয়।

| পদ্ধতি | ফ্রেম-টাইম | চেহারা |
|---|---|---|
| `radial-gradient` + `blur(70–90px)` | ~৩.০ s/frame | নরম |
| multi-stop `radial-gradient`, blur নেই | **~০.৯ s/frame** | **দৃশ্যত অভিন্ন** |

**নিয়ম:** background orb/glow-এ কখনো `blur()` দেবে না। `radial-gradient`
এমনিতেই নরম — ৪–৫টি stop দিয়ে falloff লিখলে blur সম্পূর্ণ অপ্রয়োজনীয়।

```ts
// ❌ ধীর
background: `radial-gradient(circle, ${P}20, transparent 62%)`,
filter: "blur(70px)",

// ✅ দ্রুত — একই চেহারা
background: `radial-gradient(circle, ${P}1f 0%, ${P}17 22%,
             ${P}0d 42%, ${P}05 60%, transparent 76%)`,
```

`blur()` শুধু সেখানেই, যেখানে এটি **অ্যানিমেট হয়** (যেমন focus-in reveal-এ
`blur(10px) → 0`) — কারণ সেখানে এটি অর্থবহ, আর radius ছোট।

### ১১.২ delayRender timeout

লোকাল ফন্ট লোড করলে ডিফল্ট ৩০ s টাইমআউট ধীর মেশিনে ফেল করে:

```
Error: A delayRender() "load-fonts" was called but not cleared after 30000ms
```

**সমাধান** — দুই জায়গাতেই সেট করো:

```ts
// fonts.ts
const handle = delayRender("load-fonts", { timeoutInMilliseconds: 120000 });

// remotion.config.ts
Config.setDelayRenderTimeoutInMilliseconds(120000);
```

### ১১.৩ Headless Shell-এর সিস্টেম লাইব্রেরি

পরিষ্কার Linux কন্টেইনারে প্রথম রেন্ডার এই এরর দেয়:

```
chrome-headless-shell: error while loading shared libraries: libnss3.so
```

Chromium নিজে নেমে যায়, কিন্তু OS লাইব্রেরি থাকে না। একবার চালাও:

```bash
sudo apt-get update && sudo apt-get install -y \
  libnss3 libnspr4 libatk1.0-0 libatk-bridge2.0-0 libatspi2.0-0 \
  libxdamage1 libxkbcommon0 libasound2 libcups2 libdrm2 libgbm1 \
  libpango-1.0-0 libcairo2 fonts-liberation
```

### ১১.৪ বাজেট

| লক্ষ্য | ফ্রেম-টাইম (১০৮০p, ২ CPU) |
|---|---|
| আরামদায়ক | ≤ ১.০ s/frame |
| সহনীয় | ≤ ২.০ s/frame |
| ঠিক করো | > ২.৫ s/frame |

> ২.৫ হলে ধারাবাহিকভাবে কাটো: বড় `blur()` → gradient; একসাথে চলা
`feTurbulence` → ১টি; পুরো-স্ক্রিন blend স্তর ৯ → ৬; `backdrop-filter` → বাদ।
