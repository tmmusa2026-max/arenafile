# Annex B — AE-Grade Text Animation System (v2.0)

> **v2.0 পরিবর্তন:** ২২ → **৩৬টি প্রিসেট**; spec-table থেকে **চালানোর মতো কোড**; AE "Text Animator" মডেল সরাসরি ম্যাপ করা; বাংলা সেফটি আরও কঠোর।
>
> **একটি নিয়ম সবার উপরে:** প্রতিটি টেক্সট এন্ট্রান্সে **≥৩টি প্রপার্টি একসঙ্গে** (v1.0-তে ছিল ২টি) — opacity + transform + (blur বা mask)। শুধু fade = তাৎক্ষণিক বাতিল।

---

## ১. AE Text Animator → Remotion মডেল

After Effects-এ টেক্সট অ্যানিমেশন = **Range Selector** (কোন অংশ) + **Animator Properties** (কী বদলায়) + **Offset** (সময়ে সরে যায়)। Remotion-এ হুবহু:

```tsx
/**
 * AE Range Selector-এর সমতুল্য।
 * units: "word" | "line"  (বাংলায় "char" কখনো নয় — §৫)
 */
const useRangeSelector = (
  count: number, frame: number, fps: number,
  { delay = 0, per = 3, shape = "ramp" as "ramp" | "smooth" | "ease",
    reverse = false }: Partial<{ delay: number; per: number; shape: string; reverse: boolean }> = {},
) => (index: number) => {
  const i = reverse ? count - 1 - index : index;
  const local = frame - delay - i * per;
  if (shape === "smooth") return springP(local + delay, fps, delay, "smooth");
  if (shape === "ease") return prog(frame, delay + i * per, 18, ease.out);
  return springP(frame, fps, delay + i * per, "snappy");   // ramp (ডিফল্ট)
};
```

| AE ধারণা | Remotion |
|---|---|
| Range Selector Start/End | index ফিল্টার |
| Range Selector Offset | `delay + i * per` |
| Range Selector Shape | `shape` প্যারামিটার (ramp/smooth/ease) |
| Animator: Position | `translateY/X` |
| Animator: Scale | `scale()` |
| Animator: Opacity | `opacity` |
| Animator: Blur | `filter: blur()` |
| Animator: Rotation | `rotateX/Z` |
| Animator: Tracking | **বাংলায় নিষিদ্ধ** — শুধু EN |
| Wiggly Selector | `wiggle(frame, fps, freq, amp, seed)` — deterministic |

---

## ২. Preset Library (৩৬টি)

### Tier 1 — Core (সবচেয়ে বেশি ব্যবহার্য)

| প্রিসেট | কখন | প্রপার্টি | ~সময় @30 | Bangla |
|---|---|---|---|---|
| **Title Slam** | হুক/বড় শিরোনাম | scale 1.18→1, opacity, blur 10→0 | 14–18f | ✅ |
| **Word Cascade** | মাঝারি হেডলাইন | শব্দ stagger: y+28, opacity, scale 0.94 | 3f/শব্দ | ✅ |
| **Line Mask Rise** | বড় বাক্য | clip-path mask + y slide + opacity | 8f/লাইন | ✅ |
| **Blur Focus Pull** | স্টেটমেন্ট | blur 14→0, scale 1.06→1, opacity | 18–22f | ✅ |
| **Eyebrow Track-In** | ছোট label | opacity, y−10, letterSpacing (EN only) | 16f | ✅* |
| **Highlight Sweep** | গুরুত্বপূর্ণ শব্দ | pill/underline বাঁ→ডান | 12f | ✅ |
| **Word Pop** | ছোট অ্যাকসেন্ট | scale 0.7→1.08→1 (bouncy) | 10f | ✅ |
| **Kinetic Stack** | পোস্টার হুক | লাইন স্ট্যাক, একটি slide একটি স্থির | 18f | ✅ |

### Tier 2 — Premium (v2.0 উন্নীত)

| প্রিসেট | কখন | প্রপার্টি | Bangla |
|---|---|---|---|
| **Gradient Sheen** | কীওয়ার্ড | `background-clip:text` + sheen sweep একবার | ✅ |
| **Depth Extrude** | বড় হুক | ৫–৮টি offset কপি (3D extrude ভাব) + hero fill | ✅ |
| **Light Wipe Reveal** | প্রিমিয়াম শিরোনাম | নরম mask-gradient সুইপ + bloom pulse | ✅ |
| **Mask Rise + Blur** | cinematic লাইন | mask + blur + y একসাথে | ✅ |
| **3D Word Flip** | তালিকা | rotateX −80→0, perspective 900 | ✅ শব্দে |
| **Split & Reassemble** | টুল/ফিচার নাম | ২ অংশ স্লাইড করে মিলে | ✅ phrase-এ |
| **Text Window** | ছবি দেখাতে | টেক্সটের ভেতর ছবি + ধীর pan | ✅ |
| **Quote Reveal** | উদ্ধৃতি | কোটেশন mark draw + লাইন রিভিল | ✅ |
| **Echo Trail** | স্পিড বোঝাতে | ৩–৪টি ডিম কপি ট্রেইল | ✅ |
| **Stroke Draw** | টেকনিক্যাল শিরোনাম | SVG stroke-dashoffset | ⚠️ EN |
| **Odometer Roll** | সংখ্যা | ডিজিট roll, tabular-nums | ✅ |
| **Counter Count-Up** | শতাংশ | interpolate + suffix | ✅ |
| **Marquee Strip** | ট্যাগ স্ট্রিপ | infinite marquee (পড়ার গতি) | ✅ |

### Tier 3 — Accent (সীমিত — ভিডিওপ্রতি ১–২ বার)

| প্রিসেট | কখন | Bangla |
|---|---|---|
| **RGB Split Impact** | ইমপ্যাক্ট | ✅ (শব্দ-স্তরে) |
| **Glitch Flicker** | ডেভ/টেক সিন | ✅ সংযতে |
| **Scramble Decode** | EN টেকনিক্যাল শব্দ | ❌ |
| **Typewriter + Caret** | চ্যাট/সার্চ/টার্মিনাল UI | ✅ শব্দে |
| **Shatter In** | বড় reveal | ✅ শব্দে |
| **Liquid Distort** | ক্রিয়েটিভ | ✅ |
| **Neon Flicker-On** | ব্র্যান্ড/নাইট থিম | ✅ |
| **Elastic Drop** | playful | ✅ |
| **Blur Streak Pass** | দ্রুত সিন | ✅ |
| **Chromatic Breathe** | idle hero টেক্সট | ✅ |
| **Rolling Lines** | তালিকা→তালিকা | ✅ |
| **Weight Morph** | EN variable font | ❌ বাংলায় |
| **Perspective Tilt-In** | কার্ড শিরোনাম | ✅ |
| **Counter Blur Roll** | বড় সংখ্যা | ✅ |
| **Underline Grow** | CTA | ✅ |

**নিয়ম:** প্রতি সিনে **১টি primary + ১টি secondary** টেক্সট মোশন। একই প্রিসেট ৩+ বার নয়। Tier 3 মোট ২–৩ বার।

---

## ৩. Reference Implementations

### Word Cascade (কাজের ঘোড়া — বাংলা-সেফ)

```tsx
export const WordCascade: React.FC<{
  text: string; delay?: number; per?: number; style?: React.CSSProperties;
  highlight?: string;   // এই শব্দটি hero color পাবে (লাইনে সর্বোচ্চ ১টি)
}> = ({ text, delay = 0, per = 3, style, highlight }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <div style={{
      display: "flex", flexWrap: "wrap",
      gap: `${Math.round((Number(style?.fontSize) || 120) * 0.26)}px`,  // px — em নয়!
      wordBreak: "keep-all", letterSpacing: 0, ...style,
    }}>
      {text.split(" ").map((word, i) => {
        const p  = springP(frame, fps, delay + i * per, "snappy");
        const bl = lerp(p, [0, 1], [9, 0], ease.out);
        const isHi = highlight && word.includes(highlight);
        return (
          <span key={i} style={{
            display: "inline-block",
            opacity: p,                                              // প্রপার্টি ১
            transform: `translateY(${lerp(p, [0, 1], [30, 0])}px)
                        scale(${lerp(p, [0, 1], [0.94, 1])})`,       // প্রপার্টি ২+৩
            filter: `blur(${bl}px)`,                                 // প্রপার্টি ৪
            color: isHi ? theme.colors.primary : undefined,
            textShadow: isHi ? theme.bloom.heroText : undefined,
          }}>{word}</span>
        );
      })}
    </div>
  );
};
```

> **GOTCHA (v1.0-এ ছিল, এখনো সবচেয়ে সাধারণ বাগ):** flex `gap` **pixel-এ** দাও। `gap: "0.26em"` দিলে em = parent-এর font-size ধরে, আর parent-এ font-size না থাকলে gap প্রায় শূন্য হয়ে শব্দ জোড়া লেগে যায়।

### Depth Extrude (AE 3D text-এর CSS সমতুল্য)

```tsx
export const DepthExtrude: React.FC<{ text: string; delay?: number; depth?: number }> =
({ text, delay = 0, depth = 7 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = springP(frame, fps, delay, "slam");
  const tilt = lerp(p, [0, 1], [-14, 0], ease.out);

  return (
    <div style={{ position: "relative", perspective: 1000 }}>
      <div style={{ transform: `rotateX(${tilt}deg) scale(${lerp(p, [0, 1], [1.16, 1])})`,
                    opacity: p, transformStyle: "preserve-3d" }}>
        {/* পেছনের extrude স্তর — গাঢ় থেকে হালকা */}
        {Array.from({ length: depth }).map((_, i) => (
          <div key={i} style={{
            ...theme.textStyles.h1, position: "absolute", inset: 0,
            color: theme.colors.primaryDeep,
            opacity: (1 - i / depth) * 0.5 * p,
            transform: `translate(${(depth - i) * 1.6}px, ${(depth - i) * 1.6}px)`,
          }}>{text}</div>
        ))}
        {/* সামনের মুখ — gradient fill */}
        <div style={{
          ...theme.textStyles.h1, position: "relative",
          background: theme.gradients.textSheen,
          WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent",
          filter: `blur(${lerp(p, [0, 1], [8, 0], ease.out)}px)`,
        }}>{text}</div>
      </div>
    </div>
  );
};
```

### Light Wipe Reveal

```tsx
export const LightWipe: React.FC<{ text: string; delay?: number }> = ({ text, delay = 0 }) => {
  const frame = useCurrentFrame();
  const p = prog(frame, delay, 26, ease.out);
  const sweep = prog(frame, delay + 6, 22, ease.inOut);
  const m = "linear-gradient(100deg,#000 0%,#000 44%,transparent 60%)";

  return (
    <div style={{ position: "relative", display: "inline-block" }}>
      <div style={{
        ...theme.textStyles.h1, color: theme.colors.text,
        WebkitMaskImage: m, maskImage: m,
        WebkitMaskSize: "260% 100%", maskSize: "260% 100%",
        WebkitMaskPosition: `${lerp(p, [0, 1], [100, 0])}% 0`,
        maskPosition: `${lerp(p, [0, 1], [100, 0])}% 0`,
        transform: `translateY(${lerp(p, [0, 1], [18, 0])}px)`,
        filter: `blur(${lerp(p, [0, 1], [6, 0])}px)`,
      }}>{text}</div>

      {/* আলোর রেখা একবার পার হয় */}
      <div style={{
        position: "absolute", inset: 0, pointerEvents: "none", mixBlendMode: "screen",
        opacity: Math.sin(sweep * Math.PI),
        background: `linear-gradient(100deg, transparent ${sweep * 130 - 18}%,
                     ${theme.colors.primaryLite}99 ${sweep * 130}%,
                     transparent ${sweep * 130 + 18}%)`,
      }} />
    </div>
  );
};
```

### Exit (প্রতিটি টেক্সট ব্লকে — বাদ দেওয়া যাবে না)

```tsx
const { enter, exit } = inOutProgress(frame, { start: delay, inDur: 20, end: sceneEnd, outDur: 10 });
style={{
  opacity: enter * exit,
  transform: `translateY(${lerp(enter,[0,1],[28,0])}px)
              translateY(${lerp(1 - exit,[0,1],[0,-34])}px)
              scale(${lerp(enter,[0,1],[0.95,1]) * lerp(1 - exit,[0,1],[1,1.03])})`,
}}
```
Exit সবসময় entrance-এর **প্রায় অর্ধেক সময়ে** (20f vs 10f)।

---

## ৪. AE Motion Principles → সংখ্যায়

| নীতি | কীভাবে | মান |
|---|---|---|
| **Anticipation** | বড় মুভের আগে ছোট বিপরীত মুভ | `anticipate()`, দৈর্ঘ্যের ৩০%, travel-এর ১২% |
| **Overshoot & Settle** | spring config | `slam` (হুক) · `snappy` (শব্দ) · `smooth` (ব্লক) · `bouncy` (অ্যাকসেন্ট) |
| **Follow-through** | secondary element পরে | মূল থামার ৪–৮f পরে |
| **Staging** | এক ফ্রেমে একটি hero মুভ | বাকি স্থির বা `breathe()` |
| **Timing contrast** | HIT → hold → build | hold ১৫–২০f; এই স্থিরতাই premium |
| **Motion hierarchy** | headline > sub > label | একসাথে এক গতিতে কখনো নয় |
| **Rhythm** | প্রথম ১৫f-এ মুভ | ৯০f পর্যন্ত নতুন element ছাড়া নয় |
| **Spatial continuity** | যে দিক থেকে এসেছে সেদিকেই যাবে | exit দিক = entrance দিকের বিপরীত নয় |

---

## ৫. বাংলা টেক্সট সেফটি (আরও কঠোর — v2.0)

1. **কখনো অক্ষর ধরে ভাঙবে না।** যুক্তাক্ষর (ক্ষ, ত্র, জ্ঞ), কার (ি, ী, ে, ৈ, ো, ৌ), ফলা, রেফ, হসন্ত ভেঙে যায়। সব অ্যানিমেশন **শব্দ / লাইন / phrase** স্তরে।
2. `text.split(" ")` — শুধু space-এ। **`split("")` সম্পূর্ণ নিষিদ্ধ।**
3. `letterSpacing: 0` · `wordBreak: "keep-all"` · বাংলায় tracking animate নয়।
4. **নিষিদ্ধ প্রিসেট (বাংলায়):** Scramble Decode · character-flip · stroke-text · letterSpacing animate · per-character typewriter.
5. **lineHeight 1.25–1.4** — hero display-এ tight lineHeight দিলে কার/ফলা কেটে যায়।
6. **`overflow: hidden` সাবধানে** — mask-এ উপরের কার (ি, ী, ৈ) কেটে যেতে পারে। mask box-এ উপরে-নিচে ≥0.18em padding।
7. মিক্সড বাংলা+English লাইনে **baseline align** যাচাই করো।
8. **ফন্ট:** Anek Bangla · Hind Siliguri · Noto Sans Bengali · Noto Serif Bengali · Baloo Da 2 · Tiro Bangla। সর্বোচ্চ ২টি family। **সব offline bundle** (`public/fonts/`) — CDN নয়, রেন্ডারে fail করে।
9. **Render-পূর্ব টেস্ট স্ট্রিং** (একটি still রেন্ডার করে চোখে দেখা বাধ্যতামূলক):
   ```
   ক্ষ ত্র জ্ঞ ঙ্ক্ষ হৃ রুদ্র কৌ শ্রী ৩৯%
   বাংলা ও English baseline টেস্ট — 0123 ০১২৩
   উৎকৃষ্ট দৃষ্টিভঙ্গি · সংস্কৃতি · বিশ্ববিদ্যালয়
   ```
   দেখবে: যুক্তাক্ষর ভাঙেনি · কার সঠিক জায়গায় · রেফ ঠিক আছে · baseline মিলেছে · কোনো glyph box (□) নেই।

### ফন্ট offline bundle করা — **সিঙ্ক্রোনাস CSS, async গেট নয়**

> এই সেকশনটি অনুমান নয়। একটি পূর্ণ ২০ সেকেন্ডের ডেমো রেন্ডার করতে গিয়ে
> নিচের প্রতিটি পদ্ধতি **ভেঙেছে**, তারপর যেটি টিকেছে সেটিই এখানে।

#### যা কাজ করে

```bash
# ১. পূর্ণ .ttf নামাও (generic User-Agent দিলে Google .ttf দেয়)
# ২. দরকারি গ্লিফে subset + woff2 করো
python3 -m fontTools.subset AnekBangla-Regular.ttf \
  --unicodes="U+0000-00FF,U+0980-09FF,U+200C-200D,U+2018-201D,U+2013-2014" \
  --layout-features='*' --flavor=woff2 \
  --output-file=AnekBangla-Regular.woff2
```

`--layout-features='*'` **বাধ্যতামূলক** — GSUB টেবিল বাদ পড়লে বাংলা
যুক্তাক্ষর (ক্ত, ফ্রে, স্টা) ভেঙে যাবে।

তারপর ফন্ট বাইনারি base64 data URI হিসেবে বান্ডলে এম্বেড করে
**বিশুদ্ধ CSS** দিয়ে প্রয়োগ করো:

```tsx
// src/fonts.ts — কোনো প্রমিস নেই, কোনো delayRender নেই
import * as F from "./fonts-data";   // base64 স্ট্রিং, স্ক্রিপ্টে জেনারেট করা

const DEFS: Array<[string, string, string]> = [
  ["Anek Bangla",   F.AnekBangla_Regular,   "400"],
  ["Anek Bangla",   F.AnekBangla_ExtraBold, "800"],
  ["Hind Siliguri", F.HindSiliguri_Regular, "400"],
];

const css = DEFS.map(([family, src, weight]) =>
  `@font-face{font-family:"${family}";src:url(${src}) format("woff2");` +
  `font-weight:${weight};font-style:normal;font-display:block;}`).join("\n");

if (typeof document !== "undefined" &&
    !document.getElementById("embedded-fonts")) {
  const el = document.createElement("style");
  el.id = "embedded-fonts";
  el.textContent = css;
  document.head.appendChild(el);
}
```

`font-display: block` — ফন্ট প্রস্তুত না হওয়া পর্যন্ত টেক্সট **অদৃশ্য**
থাকে, ভুল fallback গ্লিফ দিয়ে রেন্ডার হয় না।

#### ⚠️ যা কাজ করে **না** — চারটিই পরীক্ষিত ও ব্যর্থ

| # | পদ্ধতি | ফল |
|---|---|---|
| ১ | `new FontFace(...).load()` → `document.fonts.ready` → `continueRender` | ফ্রেম **৬০**-এ hang |
| ২ | `@remotion/fonts`-এর `loadFont({ url: staticFile(...) })` | ফ্রেম **৬০/৩৪৫**-এ hang |
| ৩ | একই, কিন্তু base64 data URI (নেটওয়ার্ক সম্পূর্ণ বাদ) | **প্রথম ফ্রেমেই** hang |
| ৪ | `document.fonts.load()` + ৮ সেকেন্ডের `setTimeout` fallback | `setTimeout`-ই ফায়ার করে না |

প্রতিটির এক এরর:

```
A delayRender() "Loading font Anek Bangla (…)" was called
but not cleared after 118000ms
```

**মূল কারণ:** Remotion ফ্রেম ক্যাপচারের মাঝে ব্রাউজার পেজ থ্রটল ও
রিসাইকেল করে। ফলে পেজের ভেতরের async কাজ — প্রমিস, টাইমার,
`FontFace.load()` — নির্ভরযোগ্যভাবে এগোয় না। #৩ ও #৪ এটাই প্রমাণ করে:
নেটওয়ার্ক সরিয়ে দিলেও hang হয়, আর fallback টাইমারটাও চলে না।

> **নিয়ম:** রেন্ডারের সময় ফন্ট (বা অন্য কোনো critical asset) **async
> গেটের পেছনে রাখবে না**। যা সিঙ্ক্রোনাসভাবে করা যায়, সিঙ্ক্রোনাসভাবেই করো।

**লক্ষণীয়:** `remotion still` এই চারটির সবগুলোতেই পাস করে — একটিমাত্র
পেজ লোড হয় বলে। বাগটা শুধু **পূর্ণ ভিডিও রেন্ডারে** ধরা পড়ে। তাই
"still ঠিক আছে" কখনোই ফন্ট সেটআপ যাচাইয়ের প্রমাণ নয়।

#### ফন্ট ফরম্যাট: বাংলার জন্য সাবধানতা

Google Fonts-এর ডিফল্ট woff2 **unicode-range দিয়ে subset-split** — বাংলা
গ্লিফ এক ফাইলে, ল্যাটিন আরেক ফাইলে, প্রতি weight-এ একাধিক ফাইল।
পূর্ণ `.ttf` নামিয়ে নিজে subset করলে প্রতি weight-এ একটি ফাইলেই সব আসে।

নামানোর পর **যাচাই করো** ফাইলে আসলেই বাংলা গ্লিফ আছে কিনা — ভুল subset
একটি নীরব ব্যর্থতা, টেক্সট tofu (□□□) হয়ে রেন্ডার হবে:

```python
from fontTools.ttLib import TTFont
t = TTFont("AnekBangla-Regular.woff2")
assert 0x0995 in t.getBestCmap(), "বাংলা গ্লিফ নেই"
assert "GSUB" in t, "GSUB নেই — যুক্তাক্ষর ভাঙবে"
```

---

## ৬. Typography Tokens ও Layout নিয়ম

| টোকেন | মান |
|---|---|
| `h1` | display 100–160px (landscape) / 80–140px (reel), w800, lh 1.26 |
| `h2` | display 48–72px, w700, lh 1.30 |
| `h3` | display 36–48px, w700 |
| `eyebrow` | body 18–24px, w600 |
| `label` | body 16–22px, w500, textDim |
| `chip` | body 14–18px, w600, pill bg |
| `bigNumber` | mono, w700–800, tabular-nums |
| `uiText` | body 12–16px |

- **Highlight নীতি:** এক লাইনে সর্বোচ্চ **১টি** শব্দ hero color/underline/pill।
- **লাইন দৈর্ঘ্য:** frame প্রস্থের ≤৬২% (`theme.layout.maxTextWidth`)। বাংলায় লাইনে ৬–৯ শব্দ।
- **Safe zone:** landscape 140/100px · reel 90/260px (platform UI)। টেক্সট কখনো edge স্পর্শ করবে না।
- **সংখ্যা নীতি:** এক ভিডিওতে একটিই — হয় Latin (0–9) নয় বাংলা (০–৯)। ডেটা/টেকনিক্যালে Latin।
- **Optical alignment:** বড় টেক্সটে বাঁ-প্রান্তে ২–৪px negative margin দিলে চোখে বেশি সারিবদ্ধ লাগে।

---

## ৭. Text QA Gate

- [ ] প্রতিটি এন্ট্রান্সে ≥৩টি প্রপার্টি animate হয়েছে
- [ ] প্রতিটি টেক্সট ব্লকের exit আছে, entrance-এর চেয়ে দ্রুত
- [ ] কোনো `split("")` নেই; সব বাংলা অ্যানিমেশন শব্দ/লাইন স্তরে
- [ ] flex gap pixel-এ (em নয়) — শব্দ জোড়া লাগেনি
- [ ] `letterSpacing: 0`, `wordBreak: keep-all` বাংলা টেক্সটে
- [ ] mask/overflow-এ কার/রেফ কাটেনি (still দেখে যাচাই)
- [ ] ফন্ট `delayRender` দিয়ে লোড; offline bundle
- [ ] টেস্ট স্ট্রিং still রেন্ডার করে চোখে দেখা হয়েছে
- [ ] এক লাইনে ≤১টি highlight
- [ ] প্রতি সিনে ≤২টি টেক্সট মোশন (১ primary + ১ secondary)
- [ ] কোনো `interpolate` linear নয়; সবগুলোতে clamp
- [ ] Safe zone মানা; কোনো টেক্সট edge-এ কাটেনি
