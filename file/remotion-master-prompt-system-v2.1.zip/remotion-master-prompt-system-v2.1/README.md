# Remotion Cinematic Motion Graphics — Master Prompt System **v2.0**

এই প্যাকেজটি একটি **সম্পূর্ণ প্রম্পট সিস্টেম** — যেকোনো AI Agent-কে দিলে সে আপনার transcript (TXT/SRT) থেকে **After Effects-মানের, সিনেমাটিক Motion Graphics Video** তৈরি করবে (সম্পূর্ণ Remotion project + ZIP ডেলিভারি সহ)।

> **v1.0 → v2.0:** ১,৩৩৪ → **৪,৩৫০+ লাইন**। নতুন: সিনেমাটিক ইন্ট্রো সিস্টেম · প্রিমিয়াম SVG ল্যাব · স্টুডিও-গ্রেড মিউজিক ও সাউন্ড ইঞ্জিন (চালানোর মতো কোড) · AE মোশন ইঞ্জিন · Masterpiece-গ্রেড ফটো পাইপলাইন · ১২-পয়েন্ট Premium Gate। সম্পূর্ণ তালিকা: [`CHANGELOG.md`](CHANGELOG.md)

---

## কী কী আছে

### মূল
| ফাইল | কী করে |
|---|---|
| **`MASTER-PROMPT.md`** | মূল প্রম্পট — এটিই এজেন্টকে দেবেন। সব নিয়ম, Quality Bar, workflow, ডেলিভারি |
| **`CHANGELOG.md`** | v1.0 → v2.0 কী কী বদলেছে |

### Annexes (A–L)
| ফাইল | কী করে |
|---|---|
| `A-style-library.md` | **২৪টি** scene স্টাইল + premium requirement + scene composition নিয়ম |
| `B-text-animations.md` | **৩৬টি** AE-মানের টেক্সট প্রিসেট + চালানোর মতো কোড + কঠোর বাংলা সেফটি |
| `C-icon-symbol-system.md` | Icon/Symbol ব্যবস্থাপনা (stroke hierarchy, animation pattern) |
| `D-photo-image-pipeline.md` | রেজোলিউশন আইন · AI prompt architecture · **২৪টি** treatment · **Masterpiece Gate** |
| `E-transitions-post-grade.md` | **২২টি** ট্রানজিশন (কোড সহ) + **৯-স্তর** cinematic post stack + elevation সিস্টেম |
| `F-motion-sound-principles.md` | ১২ নীতি → সংখ্যা · velocity thinking · camera rig · pacing |
| `G-tutorial-interaction-kit.md` | Tutorial cursor/click/step + honesty tier + **premium polish** |
| `H-component-recipes.md` | **৪০টি** কপি-পেস্ট রেসিপি + **GOTCHA তালিকা** |
| `I-sound-design-system.md` | 🆕 সম্পূর্ণ সাউন্ড সিস্টেম — কিট · mix bus · LUFS · ducking · beat grid |
| `J-master-qa-checklist.md` | সম্পূর্ণ QA + 🏆 **১২-পয়েন্ট Premium Gate** |
| `K-intro-signature-system.md` | 🆕 **সিনেমাটিক ইন্ট্রো** — ৫-beat sheet · ৮ archetype · intro audio law |
| `L-svg-vector-lab.md` | 🆕 **প্রিমিয়াম SVG** — gradient · filter · trim-path · morph · generative |
| `M-video-broll-pipeline.md` | 🆕 **ভিডিও ফুটেজ** — fallback chain · ক্লিপ আইন · `<OffthreadVideo>` · grade match · video QA |
| `N-caption-color-engine.md` | 🆕 **ক্যাপশন ও কালার ইঞ্জিন** — প্রতিটি লেখার নিজের রং, palette cycle · contrast law · safe area · কোড |

### Templates & Tools
| ফাইল | কী করে |
|---|---|
| `templates/theme.ts` | থিম টোকেন — রং, gradient, **৩-স্তর elevation**, bloom, typography, grade, layout |
| `templates/motion.ts` | 🆕 **AE মোশন ইঞ্জিন** — easing, spring, timing, deterministic noise, camera, ducking |
| `templates/project-structure.md` | প্রজেক্ট কাঠামো + naming + scripts |
| `tools/make-audio.mjs` | 🆕 **চালানোর মতো** সাউন্ড জেনারেটর — ১৪টি SFX + মিউজিক বেড, dependency ছাড়া |

---

## কীভাবে ব্যবহার করবেন

1. AI-কে বলুন: **"এই `MASTER-PROMPT.md` অনুযায়ী কাজ করো"** — সঙ্গে আপনার transcript (TXT এবং/অথবা SRT)।
2. সঙ্গে `annexes/`, `templates/`, `tools/` ফোল্ডার দিন (AI ফাইল পড়তে পারলে) — অথবা প্রয়োজন অনুযায়ী Annex-এর টেক্সট paste করুন।
3. ঐচ্ছিক: লোগো, ছবি, মিউজিক, voiceover (`public/voiceover.mp3`) — থাকলে আরও ভালো ফল।
4. AI শুধু **একটাই প্রশ্ন করবে: কালার স্কিম** (৪–৬টি স্কিম দেখিয়ে)। বাকি সব সে নিজে ঠিক করবে।
5. ডিফল্টে **প্রিভিউ মোড**: আপনি পাবেন সম্পূর্ণ project ZIP + ৪টি কমান্ড।
6. ভিডিও রেন্ডার চাইলে বলুন **"রেন্ডার করো"**।

---

## সাউন্ড জেনারেটর — এখনই চালিয়ে দেখুন

কোনো npm install লাগে না, কোনো ডাউনলোড নয়, কোনো লাইসেন্স ঝামেলা নেই:

```bash
node tools/make-audio.mjs --out public/sfx --music-out public/music \
     --bpm 84 --key D --bars 24 --mood cinematic
```

তৈরি হবে:
- `public/sfx/` — ১৪টি SFX (whoosh, pop, click, chime, thud, tick, riser, impact, sub-drop, shimmer, glass-tap, boom …)
- `public/music/bed_main.wav` — loop-safe মিউজিক বেড (pad + sub bass + arp + soft perc, mix bus সহ)
- `MIX-REPORT.json` — প্রতিটি ফাইলের **peak / RMS / LUFS / clipping flag + beat grid** (QA এখান থেকে, অনুমানে নয়)

| ফ্ল্যাগ | মান |
|---|---|
| `--mood` | `cinematic` · `calm` · `tech` · `uplifting` |
| `--bpm` | 60–140 (ডিফল্ট 84) |
| `--key` | C…B (ডিফল্ট D) |
| `--bars` | `ceil(seconds × bpm / 240) + 2` |
| `--no-music` | শুধু SFX |

**যাচাইকৃত:** 48kHz / 16-bit স্টেরিও WAV · সম্পূর্ণ deterministic (একই আর্গুমেন্টে বিট-বাই-বিট একই ফাইল) · Node.js 20-এ পরীক্ষিত, শূন্য dependency।

---

## Windows PowerShell সেটআপ (AI যে প্রজেক্ট দেবে)

```powershell
cd <প্রজেক্ট ফোল্ডার>
npm install
node tools/make-audio.mjs --out public/sfx --music-out public/music
npx remotion studio
npx remotion render src/index.ts Main out/video.mp4 --codec h264 --crf 17
```
বিস্তারিত প্রজেক্টের নিজস্ব `README.md`-তে থাকবে।

---

## নকশার সিদ্ধান্ত (v2.0)

- **ইনপুট:** TXT = content source · SRT = timing source; দুটোই না থাকলে যা দেওয়া হয়েছে তাই
- **রঙ:** একটিই প্রশ্ন (emerald/lime identity থেকে ৪–৬টি স্কিম); ইউজার আগে রং দিলে প্রশ্ন নেই
- **ইন্ট্রো:** বাধ্যতামূলক signature intro — short ≤2.5s · long ≤5s, bookend outro সহ
- **অডিও:** মিউজিক বেড **ডিফল্টে চালু** (v1.0-এ নিষিদ্ধ ছিল) + VO ducking + beat-synced cut
- **ছবি:** ইউজারের > AI-generated (prompt architecture) > stock > graphic fallback — প্রতিটিতে Masterpiece Gate
- **ভিডিও (v2.1):** ইউজারের B-roll > AI ভিডিও > স্টক ভিডিও > ছবি+camera move > ভেক্টর — প্রতিটি ক্লিপ ২–৬s, `OffthreadVideo`, grade match
- **ক্যাপশন (v2.1):** প্রতিটি লেখার নিজের রং, palette cycle-এ ঘোরে; পরপর দুটি এক নয়, contrast ≥ ৪.৫:১
- **বাংলা টেক্সট:** অক্ষরে কখনো ভাঙবে না — সব অ্যানিমেশন শব্দ/লাইন স্তরে; ফন্ট offline + `delayRender`
- **Determinism:** `Math.random()` নিষিদ্ধ — seeded noise; দুবার render → একই ফল
- **Tutorial:** থাকলে বাস্তব ধাপ-প্রদর্শন বাধ্যতামূলক (কল্পিত UI নয়)

---

## লাইসেন্স নোট

- এই প্রম্পট সিস্টেম আপনার নিজের ব্যবহারের জন্য — যেমন চান তেমন সম্পাদনা করতে পারেন।
- `tools/make-audio.mjs`-এর তৈরি সব অডিও **সম্পূর্ণ আপনার** — procedurally synthesized, কোনো তৃতীয় পক্ষের কপিরাইট নেই।
- প্রজেক্টে ব্যবহৃত icon (Lucide/Feather/Heroicons/Phosphor), stock ফটো (Pexels/Unsplash/Pixabay) ও font-এর নিজ নিজ লাইসেন্স মানতে হবে — AI প্রতিটির source + license `ASSETS.md`-তে লিখবে।

---

## ডেমো — সিস্টেমটি আসলে কী বানায়

`remotion-demo/` ফোল্ডারে একটি **চলমান প্রমাণ** আছে: ২০ সেকেন্ড,
১৯২০×১০৮০, ৩০fps, সম্পূর্ণ অডিও সহ — পুরোটাই এই সিস্টেমের নিয়ম মেনে।

```bash
cd remotion-demo
npm install
npm run audio          # মিউজিক + ১৪টি SFX তৈরি
npm run studio         # লাইভ এডিটর
npm run render:safe    # out/video.mp4
```

ডেমোটি বানাতে গিয়ে রেন্ডারে যা যা ভেঙেছিল, তার প্রতিটি এখন অ্যানেক্সে
সংশোধিত — বিশেষ করে Annex B (ফন্ট) ও Annex E §১১ (পারফরম্যান্স)।
বিস্তারিত `CHANGELOG.md` → v2.0.1।
