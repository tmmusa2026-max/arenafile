# Annex N — Caption Timeline ও Color Engine (v2.1)

> **v2.6 অগ্রাধিকার:** `MASTER-PROMPT.md`-এর v2.6 সংহত নিয়ম ও Annex Q এখানে বর্ণিত বিরোধী বাধ্যতামূলক সংখ্যা/পদ্ধতির চেয়ে প্রাধান্য পাবে; পুরোনো রেসিপি উদাহরণ মাত্র।

> **কী সমাধান করে:** ট্রান্সক্রিপ্ট/SRT থেকে নিচে দিয়ে ক্যাপশন উঠবে, **প্রতিটি ক্যাপশনের নিজের একটা রং** থাকবে, পুরোনো লেখা বেরিয়ে গেলে নতুন লেখা **নতুন রঙে** ঢুকবে — এবং রংগুলো একটা নির্দিষ্ট ছন্দে (palette cycle) ঘুরবে, এলোমেলোভাবে নয়।

---

## ১. ক্যাপশন বনাম Subtitle (গুরুত্বপূর্ণ পার্থক্য)

| | Subtitle (নিষিদ্ধ) | Caption (এই annex) |
|---|---|---|
| লেখা | পুরো বাক্য, শব্দ ধরে ধরে | **১–৬ শব্দের শট**, অর্থ ধরে ভাঙা |
| সময় | VO-র সঙ্গে হুবহু | ব্লক ধরে (২.৫–৪s), beat-এ স্ন্যাপ |
| চেহারা | সাদা টেক্সট + কালো বাক্স | প্রিমিয়াম টাইপোগ্রাফি, transform + blur + mask |
| কাজ | পড়ানো | **বলা + দেখানো** |

**নিয়ম:** ক্যাপশনে transcript-এর শব্দ বদলাবে না, কিন্তু ছোট করতে পারবে (ফিলার/পুনরাবৃত্তি বাদ), অর্থ অটুট রেখে।

---

## ২. টাইমিং — কোথা থেকে আসবে

### SRT থাকলে
1. প্রতিটি SRT cue → ১–৩টি caption-এ ভাঙো (শব্দসীমায়, অক্ষরে নয়)।
2. শব্দ-স্তরের সময়: cue-এর `start…end` সমানভাবে ভাগ করে **শব্দের দৈর্ঘ্য অনুপাতে** (character-weighted)।
3. ক্যাপশনের শেষ = পরের শুরুর **−৩ frame** (নিঃশ্বাসের জায়গা)।
4. beat grid থাকলে ±৪ frame-এর মধ্যে নিকটতম বীটে স্ন্যাপ করো (Annex I §৬)।

### শুধু TXT থাকলে
`দৈর্ঘ্য ≈ অক্ষরসংখ্যা × 0.055s` (বাংলা ~= ১৮ অক্ষর/সেকেন্ড) — min ২.২s, max ৪.২s প্রতি ক্যাপশনে।

### TS ম্যাপ (project structure-এ)
```ts
export type Cap = { id:string; from:number; to:number; text:string; hue:number; style:"A"|"B"|"C"; };
// from/to = frame; hue = palette index (নিচে §৩)
```

---

## ৩. Color Engine — "প্রতিটি লেখার নিজের রং"

### ৩.১ প্যালেট (theme.ts-এ একবার)
```ts
export const captionPalette = [
  "#3BE8A0", // emerald
  "#FFC24B", // amber
  "#57C7FF", // sky
  "#B79CFF", // violet
  "#FF8A6B", // coral
] as const;
```
- **৩–৫টি রং।** এর বেশি হলে রং আলাদা করে চেনা যায় না — visual unity ভাঙে (Annex A §৩)।
- রংগুলো `theme.palette`-এর extended family হতে হবে; হঠাৎ neon ম্যাজেন্টা বসাবে না।

### ৩.২ সাইকেল নিয়ম (deterministic)
```ts
const hueOf = (i:number) => captionPalette[(i * 2 + sceneIndex) % captionPalette.length];
```
- **পরপর দুটি ক্যাপশনের রং কখনো এক নয়** (step ২ → `+2` গুণক)।
- একই রং পরের বার ফিরে আসে ৩–৫ ক্যাপশন পরে — ছন্দ তৈরি হয়, কিন্তু পুনরাবৃত্তি ধরা পড়ে না।
- `Math.random()` নয় — index-ভিত্তিক, তাই দুবার render-এ হুবহু একই।

### ৩.৩ প্রতি ক্যাপশনে রঙের ব্যবহার (৩টি অনুমোদিত স্টাইল)

| স্টাইল | চেহারা | কখন |
|---|---|---|
| **B — Word Highlight** | লেখা সাদা/ধূসর, কথা বলার সঙ্গে সঙ্গে **এক শব্দের ওপর রং + glow** আসে, আগের শব্দ হালকা সাদা, পরের শব্দ ধূসর | ✅ **ডিফল্ট — ইউজারের পছন্দ** |
| A — Color Cycle | পুরো লাইনে একটা গ্রেডিয়েন্ট বয়ে যায়; base = ক্যাপশনের রং, হাইলাইট = সাদা | বিকল্প (আউট্রো/লম্বা বর্ণনায়) |
| C — Two-Tone | মূল লেখা সাদা, key phrase ক্যাপশনের রঙে + shadow | বিকল্প (কর্পোরেট/তথ্যবহুল) |

> **ডিফল্ট = B।** ইউজার স্পষ্টভাবে অন্য স্টাইল না চাইলে B-ই ব্যবহার করবে।

**স্টাইল এক ভিডিওতে একটাই** — মাঝে বদলাবে না (Annex A §৩ visual unity)।

### ৩.৪ Contrast Law (অটো-যাচাই)
1. নিচের ব্যান্ডে **scrim** বাধ্যতামূলক (Δluma নিশ্চিত করে)।
2. তারপরও রঙের **WCAG contrast ≥ 4.5:1** ফ্রেমের গড় luma-র বিপরীতে।
3. না হলে ক্রমে: `lighten(color, .22)` → drop-shadow বাড়াও → scrim opacity +0.08।
```ts
export const ensureContrast = (hex:string, bgLuma:number) => {
  let c = hex, guard = 0;
  while (contrast(c, bgLuma) < 4.5 && guard++ < 4) c = lighten(c, 0.22);
  return c;
};
```
**নিষিদ্ধ:** অন্ধকার ফুটেজে গাঢ় লাল/নীল লেখা · রঙিন ফুটেজে সাদা লেখা কোনো shadow ছাড়া · এক ফ্রেমে দুটি ভিন্ন রঙের hero টেক্সট।

---

## ৪. মোশন (প্রতি ক্যাপশনে হুবহু এই ৪ ধাপ)

| ধাপ | সময় (৩০fps) | কী হয় |
|---|---|---|
| ১ · Rail/Accent in | ০–১২f | বাঁ দিকে ছোট রঙিন রেল বাড়ে (ক্যাপশনের রং), bloom জ্বলে |
| ২ · Word stagger in | ৩–২৪f | শব্দ প্রতি **৩–৬f** ব্যবধানে: `opacity 0→1`, `y +26px→0`, `blur 9→0` |
| ৩ · Idle | বাকি সময় | হালকা breathing (±0.4%); **পড়ার লেখা নড়ে না** |
| ৪ · Exit | শেষ ৮–১০f | `blur 0→7`, `opacity →0`, `y −18` — এন্ট্রান্সের **অর্ধেক** সময়ে |

- **অক্ষর কখনো ভাঙবে না** — `split("")` নিষিদ্ধ (Annex B §৫)। শব্দ/লাইন স্তরেই সব।
- গ্রেডিয়েন্ট (স্টাইল A) **একটা continuous background** হিসেবে পুরো লাইনে বয়ে যায় — শব্দ প্রতি আলাদা গ্রেডিয়েন্ট দিলে প্রতি শব্দে রং "রিসেট" দেখায় (সাধারণ ভুল)।

### ৪.১ স্টাইল B — ওয়ার্ড হাইলাইটের নিয়ম (ডিফল্ট)
| ধাপ | নিয়ম |
|---|---|
| শব্দ ভাগ | শব্দগুলো একইসঙ্গে (stagger ৩f) ঢোকে — ক্যারাoke-এর মতো এক-এক করে নয়; পড়ার গতি তাতে ভালো থাকে |
| হাইলাইট চলা | কথার সঙ্গে এগোয়; প্রতিটি শব্দ **~০.২৮–০.৩২s** aktif থাকে (৩ কমান্ড/শব্দের বেশি নয়) |
| রং | aktif শব্দ = `captionPalette`-এর ক্যাপশন-রং + `textShadow: 0 0 28px <রং>55` · আগের শব্দ = `rgba(242,250,246,.82)` · পরের শব্দ = `rgba(235,245,240,.34)` |
| scale | aktif শব্দে **≤1.06** — এর বেশি হলে লাইন কাঁপে |
| এক ফ্রেমে | **একটাই** রঙিন শব্দ (hero rule) |
| exit | পুরো লাইন একসঙ্গে (৮–১০f) — শব্দ প্রতি exit নয় |

---

## ৫. Lay-out ও Safe Area

| অ্যাসপেক্ট | নিচ থেকে দূরত্ব | পাশের মার্জিন | ফন্ট (1080p) | সর্বোচ্চ লাইন |
|---|---|---|---|---|
| 16:9 (1920×1080) | ১১–১৩% | ৬–৭% | ৪৮–৫৬px | ২ |
| 9:16 (1080×1920) | ২০–২৪% | ৮% | ৬৪–৭৬px | ৩ |
| 1:1 (1080×1080) | ১৬% | ৭% | ৫২px | ২ |

- প্ল্যাটফর্ম UI-এর জন্য নিচে **≈১৪০px (9:16)** ফাঁকা রাখো (TikTok/Reels ক্যাপশন বাটন)।
- লেখা **এক লাইনে ≤ ৩২ অক্ষর** — তার বেশি হলে ভাঙো, ছোট করো না।
- **⚠️ Wrap gotcha:** শব্দগুলো `<span style="white-space:nowrap">` হলে শব্দের মাঝে স্পেস না থাকলে (শুধু `margin`) লাইন **ভাঙে না, ডানে উপচে পড়ে**। কনটেইনার হবে `display:flex; flex-wrap:wrap; column-gap:.30em` (px/em; margin নয়) — তাহলে শব্দ অটুট থাকে অথচ লাইন ঠিক সময়ে ভাঙে।
- ক্যাপশন কখনো সাবজেক্টের মুখ ঢাকবে না (মুখ ডিটেকশন/ম্যানুয়াল চেক)।

---

## ৬. Reference implementation (Remotion)

```tsx
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { ease, lerp, timing } from "../motion";

const PALETTE = ["#3BE8A0", "#FFC24B", "#57C7FF", "#B79CFF", "#FF8A6B"];

export const ColorCaption: React.FC<{
  text: string; colorIndex: number; sceneIndex: number; safe?: boolean;
}> = ({ text, colorIndex, sceneIndex }) => {
  const frame = useCurrentFrame();
  const t = timing(30);
  const color = PALETTE[(colorIndex * 2 + sceneIndex) % PALETTE.length];
  const words = text.split(" ");                      // শব্দে ভাঙা — অক্ষরে নয়
  const shift = lerp(frame, [0, 90], [0, -220], ease.inOutSoft); // গ্রেডিয়েন্ট বয়ে যায়

  return (
    <AbsoluteFill style={{ justifyContent: "flex-end", padding: "0 6.5% 11.5%" }}>
      <div style={{ position: "relative", filter: "drop-shadow(0 3px 18px rgba(0,0,0,.55))" }}>
        <span style={{
          position: "absolute", left: -22, top: 4, width: 3, borderRadius: 3,
          height: "92%", background: color,
          boxShadow: `0 0 18px ${color}88, 0 0 44px ${color}55`,
          transform: `scaleY(${lerp(frame, [0, 12], [0, 1], ease.out)})`,
          transformOrigin: "top",
        }}/>
        <div style={{
          display: "flex", flexWrap: "wrap", gap: "0.30em",   // px/em নয় — flex gap
          fontFamily: "NotoBn", fontWeight: 600, fontSize: 52,
          lineHeight: 1.34, letterSpacing: 0, wordBreak: "keep-all",
        }}>
          {words.map((w, i) => {
            const p = lerp(frame, [3 + i * 4, 33 + i * 4], [0, 1], ease.out);
            return (
              <span key={i} style={{
                display: "inline-block", whiteSpace: "nowrap",
                opacity: p, transform: `translateY(${(1 - p) * 26}px)`,
                filter: `blur(${(1 - p) * 9}px)`,
                backgroundImage: `linear-gradient(100deg, ${color} 0%, ${color} 18%, #fff 32%, ${color} 46%, ${color} 62%, #fff 78%, ${color} 92%)`,
                backgroundSize: "62% 100%", backgroundPosition: `${shift}px 0`,
                backgroundClip: "text", WebkitBackgroundClip: "text",
                color: "transparent", WebkitTextFillColor: "transparent",
              }}>{w}</span>
            );
          })}
        </div>
      </div>
    </AbsoluteFill>
  );
};
```
> `backgroundClip:"text"` + `backgroundPosition` — Remotion-এ (Chromium) নিখুঁতভাবে কাজ করে ও deterministic; গ্রেডিয়েন্ট নিজে আঁকতে হবে না।

---

## ৭. Caption QA Gate (৯টি)

| # | চেক |
|---|---|
| ১ | কোনো ক্যাপশনে ভুল বানান/কল্পিত কথা নেই; অর্থ অটুট |
| ২ | পরপর দুটি ক্যাপশনের রং এক নয়; প্যালেট থেকে বাইরে যায়নি |
| ৩ | প্রতি ক্যাপশনে contrast ≥ ৪.৫:১ (সবচেয়ে উজ্জ্বল ফ্রেমে) |
| ৪ | এন্ট্রান্সে ≥৩ প্রপার্টি; exit আছে ও দ্রুততর |
| ৫ | বাংলা অক্ষর অটুট (`split("")` নেই), টেস্ট স্ট্রিং still-এ দেখা হয়েছে |
| ৬ | safe area: 9:16-এ নিচে ≥১৪০px ফাঁকা, লেখা প্ল্যাটফর্ম UI-তে ঢোকেনি |
| ৭ | ক্যাপশন কখনো মুখ/মূল সাবজেক্ট ঢাকেনি |
| ৮ | প্রতি ক্যাপশনে ≤১টি hero রং (glow); একই ফ্রেমে দুটি color cast নেই |
| ৯ | দুবার render → ক্যাপশনের রং ও টাইমিং হুবহু এক |
