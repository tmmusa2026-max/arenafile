# Annex P — Delivery Preview Page (v2.5)

## লক্ষ্য ও অগ্রাধিকার
কাজ শেষে platform-এ live preview চালানো সম্ভব হলে একটি delivery page দেখাও; চ্যাটেও প্রকৃত ZIP/download link ও verification status দাও। এটি MASTER-PROMPT-এর v2.5 অংশ অনুযায়ী আগের সংক্ষিপ্ত response rule-এর ওপর প্রযোজ্য। Placeholder preview-কে সমাপ্তি বলে দাবি করা যাবে না।

## কাজের ক্রম
1. Remotion source/assets তৈরি করে প্রকৃত project ZIP বানাও; ZIP integrity পরীক্ষা করো। Upload অনুরোধ অনুযায়ী `tools/upload-gofile.sh` ব্যবহার করো। Service/network ব্যর্থ হলে কারণ ও local ZIP দাও; কখনও উদ্ভাবিত URL নয়। গোপনীয় তথ্য ZIP-এ রেখো না।
2. ভিডিও render স্পষ্টভাবে চাওয়া হলে MP4 render ও playback যাচাই করে delivery page-এর কাছে কপি করো। শুধু project ZIP বা চাওয়া না হওয়া অবস্থায় নতুন MP4 render হয়েছে বলে দাবি নয়: Remotion Studio preview সম্ভব হলে তা কীভাবে খুলবে লেখো; অন্যথায় স্পষ্ট `ভিডিও এখনো রেন্ডার করা হয়নি`। ব্যবহারকারীর সম্মতি অনুযায়ী ছোট sample render তৈরি করলে সেটিকে sample হিসেবে চিহ্নিত করো। ভিডিও তৈরি করলেই preview চলছে মনে করবে না; ভিডিও ফাইল সরাসরি playable হতে হবে।
3. project বা আলাদা delivery folder-এ `make-delivery-page.py`-এর সাহায্যে `index.html` তৈরি করো। শুধু আসল নিশ্চিত GoFile URL এবং সত্যিই যাচাইকৃত MP4 path দাও। নিচের উদাহরণের মানগুলো কেবল উদাহরণ, response-এ placeholder URL নয়। Generator নিজে upload বা render করে না।

```bash
python3 tools/make-delivery-page.py --output delivery/index.html \
  --zip-url 'https://gofile.io/d/REAL_ID' \
  --video delivery/preview.mp4 --video-label 'রেন্ডার করা ভিডিও' \
  --status 'প্রজেক্ট ও ভিডিও যাচাই করা হয়েছে'
```

যদি upload/video না হয়, `--zip-url`/`--video` বাদ দাও এবং `--status`-এ সত্য লিখো। ভিডিও ব্রাউজারে চলার জন্য generator ভিডিও ফাইলকে HTML-এর পাশে copy করে; preview তে সঠিক URL থাকবে। বড় MP4 delivery folder-এ আনলে disk space পরীক্ষা করো। ব্যক্তিগত তথ্য public preview-তে রেখো না।

4. Platform preview চাইলে বর্তমান পরিবেশের উপযুক্ত long-running server ব্যবহার করে `delivery/`-কে 0.0.0.0-এ serve করো; host/origin allowlist ও iframe embedding সমস্যা থাকলে ঠিক করো। Browser-facing code কখনো localhost endpoint hardcode করবে না। Tool/platform বিধিনিষেধে ফাইল preview sandbox থেকে আপলোড লিংক বা video load ব্যর্থ হতে পারে: live preview অথবা chat link বিকল্প হিসেবে দাও, এবং যা যাচাই করা যায়নি তা জানাও।
5. Preview খোলে কি না, পুরো link wrap হয়ে দৃশ্যমান/selectable কি না, copy ব্যর্থ হলে manual selection করা যায় কি না এবং MP4 থাকলে আসলে playback হয় কি না পরীক্ষা করো। Browser-এর clipboard access/secure-context সীমাবদ্ধতার কারণে কপি গ্যারান্টি নয়। UI-তে link সাধারণ text ও anchor হিসেবে দৃশ্যমান রাখো, শুধু বাটনের ওপর নির্ভর নয়।

**Honesty:** status সফল শুধু বাস্তবে যাচাইয়ের পর; URL দৃশ্যমান থাকলেও GoFile retention/access নিশ্চিত নয়। অচালিত page, ফাইলবিহীন video, fake URL বা empty placeholder কখনো সফল delivery নয়। ব্যবহারকারীর final chat-এ download link ও প্রয়োজনে কী সীমাবদ্ধ তা দাও।
