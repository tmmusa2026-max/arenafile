# Annex Q — নির্ভরযোগ্য বাংলা, অ্যানিমেশন, SVG ও QA (v2.6)

এই নির্দেশনা Master Prompt-এর সংহত v2.6 নিয়মের অধীনে। প্রকৃত পরীক্ষা ছাড়া কোনো পদক্ষেপ সফল বা ছবির মান ভাল বলে দাবি নয়। পুরোনো Annex-এর বিরোধী aesthetic সংখ্যাগুলো উদাহরণ মাত্র।

## ধাপ ও বাধা
1. Input inventory: transcript/SRT, voiceover, format/fps, asset/rights এবং পরিবেশে Node, browser, render ও network উপলব্ধ কি না। duration বা timing অনুপস্থিত হলে অনুমান জানাও।
2. `starter/` থেকে কাজ শুরু করা যায়: bundled Noto Sans Bengali + OFL, `FontTest`, reusable `BanglaText`, `Caption`, `QuoteIcon`, `SampleScene`। `npm ci`, `npm run check`, `npm run typecheck`। স্টার্টারের sample text প্রকৃত কনটেন্ট নয়—final output থেকে সরাতে হবে। User asset/license যাচাই ও offline bundle করো।
3. `npm run font-test` দিয়ে font test still রেন্ডার, তারপর চোখে যুক্তাক্ষর, রেফ/ফলা, কারচিহ্ন, সংখ্যা, বাংলা-ইংরেজি, punctuation ও clipping দেখো। Visual check tool না থাকলে unverified বলো। FontGate FontFace + delayRender-এর bounded implementation; স্থানীয় পরিবেশে সমস্যা হলে লগ পরীক্ষা, অফলাইন CSS alternative Annex B অনুসারে বাস্তব পরীক্ষা; কোন method সব পরিবেশে সফল এমন দাবি নয়। Missing system library হলে platform/permission অনুযায়ী নিরাপদ সমাধান; access না থাকলে কারণ ও কাজের ফাইল দাও।
4. storyboard table: scene ID, transcript অংশ, start/end ও duration, অর্থ, layout/hierarchy, assets/rights, text, animation/hold এবং transition। User-এর তথ্যের বাইরে fake facts নয়। সম্পূর্ণ project-এ mapping পুনর্মিলন করো।
5. Sample scene-এ still ও ছোট motion sample (অনুমতি/সামর্থ্য অনুযায়ী) render করে যাচাই; তারপর প্রতিটি scene implement করো। Typography safe area, legibility, clip/overflow, contrast, timing ও বাংলা glyph পরীক্ষা। নির্দিষ্ট facts বা ব্যক্তির ছবি সত্যতার সঙ্গে মেলাও।

## অ্যানিমেশন ব্যর্থ হলে
- প্রথমে TypeScript/runtime error ও exact property/fps/frame timing যাচাই, frame-driven deterministic `interpolate` বা `spring` দিয়ে সংশোধন। অন্তত তিনটি representative সময়ে (start/middle/end) output পরীক্ষা; সম্ভব হলে moving sample দেখো। প্রকৃত সম্পাদনা/পরীক্ষা ছাড়া retry দাবি নয়।
- জটিল camera/morph/filter ব্যর্থ হলে সর্বোচ্চ তিনটি বাস্তব সংশোধন/সরলীকরণ: (১) problematic property ঠিক করা; (২) simpler transform+opacity, built-in easing ও stagger; (৩) static readable visual বা hard cut। উপযুক্ত সময়ে static scene পেশাদারসম্মত; readability ও transcript sync বজায় রাখো। Environment blocker থাকলে অনর্থক retry না করে কারণ ও fallback জানাও।
- Animation কাজ না করলে জটিল animation কাজ করেছে বলে দাবি নয়; user-কে fallback বা test না হওয়ার কথা বলো।

## SVG ব্যর্থ হলে
- Annex O §৩.১ অনুযায়ী প্রাসঙ্গিক scene-এ SVG-first: valid viewBox ও basic shapes, component/still check, error-driven fixes, complexity কমানো; সর্বোচ্চ তিন প্রকৃত চেষ্টা। Starter-এর static `QuoteIcon` জটিল motion-এর বদলে একটি tested-by-typecheck pattern, অন্য symbol হিসেবে ভুল ব্যবহার নয়।
- ব্যর্থ হলে উপযুক্ত user asset; না থাকলে Annex D/M অনুযায়ী প্রামাণিক উৎস ও প্রত্যেক asset-এর license পরীক্ষা করে web photo/short video। Asset না পেলে accessible text/basic shape; অপরীক্ষিত ছবি বা বানানো তথ্য নয়।

## QA gate ও report
- Automated: `npm run check`, `npm run typecheck`, ZIP integrity, file/asset presence; সম্ভবে duration ও frame range পরীক্ষা। এগুলো visual quality প্রমাণ করে না।
- Visual: font card, গুরুত্বপূর্ণ দৃশ্যের শুরু/মাঝ/শেষ still এবং পূর্ণ বা representative motion playback; safe area, text, transitions, বাংলা, audio sync, facts/rights যাচাই। সম্পূর্ণ ভিডিও চাওয়া হলে শেষ থেকে শুরু অবধি দেখার চেষ্টা। যা করা হয়নি `not run` বলো।
- Final: actual project ZIP, asset/licenses, font, README, commands; GoFile upload এবং delivery page Annex P, সঙ্গে chat-এ বাস্তব URL। render না হলে not rendered, browser/server unavailable হলে preview unavailable, সবকিছুর কারণ জানাও।
