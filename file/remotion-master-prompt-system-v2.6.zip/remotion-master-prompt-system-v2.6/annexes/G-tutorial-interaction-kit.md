# Annex G — Tutorial Interaction Kit (v2.0)

> **v2.6 অগ্রাধিকার:** `MASTER-PROMPT.md`-এর v2.6 সংহত নিয়ম ও Annex Q এখানে বর্ণিত বিরোধী বাধ্যতামূলক সংখ্যা/পদ্ধতির চেয়ে প্রাধান্য পাবে; পুরোনো রেসিপি উদাহরণ মাত্র।

> Master Prompt ধাপ ৮-এর বাস্তবায়ন স্তর। Tutorial থাকলে এই kit ব্যবহার করবে।
>
> **v2.0 পরিবর্তন:** §৭ যুক্ত — tutorial UI-কে প্রিমিয়াম দেখানোর নিয়ম। Tutorial মানে "সাদামাটা" নয়; শুধু **সংযত**।

## ১. Interaction Elements

| Element | আচরণ | spec |
|---|---|---|
| **Cursor** | bezier path-এ মসৃণ চলাচল; target-এ ease-into | আসল mouse cursor আকৃতি (SVG), drop shadow; গতি মানবে যেন পড়া যায় |
| **Click ripple** | cursor-এর নিচে বৃত্ত ৮f expand + fade + click SFX | সঠিক উপাদানেই |
| **Hover glow** | গুরুত্বপূর্ণ button-এর চারপাশে 2px ring (hero color) | click-এর আগে ১০–১৫f |
| **Highlight box** | rounded rect outline + কোণে ছোট corner-mark | গুরুত্বপূর্ণ option নির্দেশে |
| **Typing + caret** | input field-এ শব্দ ধরে টাইপ + ব্লিংক কার্সর | বাংলায় শব্দ ধরে |
| **Scroll** | content translate + scroll indicator | পরবর্তী option দেখাতে |
| **Dropdown/Toggle/Checkbox** | open/flip/check অ্যানিমেশন + state change | সঙ্গে soft pop/click SFX |
| **Tab/Page change** | content crossfade + tab pill slide | ধাপ পরিবর্তনে |
| **Zoom-to-detail** | scale 1.4–1.8 + ফোকাস area center-এ | ছোট UI দেখাতে |
| **Step chip** | "Step 01" pill — ধাপ অনুযায়ী বদলায় | প্রতি ধাপে |
| **Callout arrow** | লাইন draw-on + ছোট label | কোথায় দেখবে নির্দেশে |
| **Success state** | check burst + হালকা green flash (হলে) | কাজ সম্পন্নে; বাস্তব confirmation থাকলেই |
| **Step rail** | ০১→০২→০৩ progress bar/chip | বহু-ধাপ tutorial-এ |

## ২. Cursor Physics

- চলাচল: `interpolate` + `ease.inOut`, ছোট overshoot নয়; দূরত্ব বেশি হলে দ্রুত মাঝে, শেষে ধীর (human-like)
- click: পৌঁছানোর ৬–১০f পরে (দর্শক লক্ষ্য করার আগে click নয়) + ripple + SFX
- একসঙ্গে একাধিক highlight নয়; এক সময়ে একটি target
- অনাবশ্যক দ্রুত/এলোমেলো cursor নয় — প্রতিটি মুভের উদ্দেশ্য
- **Sync নিয়ম:** cursor যেখানে click করছে, visible UI-তে ঠিক সেখানেই state পরিবর্তন হবে — দুটোর মধ্যে অসামঞ্জস্য নয়

## ৩. Scene Continuity (UI State Object প্যাটার্ন)

```tsx
// src/data/tutorialState.ts — প্রতি ধাপের UI অবস্থা frame-based
export const steps = [
  { id: 1, from: 0,   to: 90,  screen: "home",     highlight: "settings-icon" },
  { id: 2, from: 90,  to: 180, screen: "settings", highlight: "security-row" },
  { id: 3, from: 180, to: 270, screen: "security", highlight: "toggle-2fa" },
  // ...
];
```
- প্রতিটি ধাপ আগের ধাপের ফলাফল থেকে যৌক্তিকভাবে শুরু হবে (Website → Login → Dashboard → Settings → …)
- অকারণে অন্য page/account/interface-এ যাবে না; খোলা tab/menu ধরে রাখবে
- ধাপের পরে ফলাফল **hold** (১৫–২৫f) — দর্শক বোঝার সময়
- পরবর্তী ধাপে যাওয়ার ট্রানজিশন UI ঢাকবে না

## ৪. Honesty Tiers (Authentic Interface Accuracy)

| Tier | কখন | আচরণ |
|---|---|---|
| **1. আসল screenshot/রেকর্ডিং** | ইউজার দিয়েছে বা নির্ভরযোগ্য উৎস থেকে সংগ্রহ করা যায় | সবচেয়ে ভালো; `public/ui-refs/`-এ; লাইসেন্স নোট |
| **2. UI recreation (কোডে)** | আসল UI নেই কিন্তু গঠন জানা | আসল UI-এর কাছাকাছি পরিষ্কার recreation — **কখনো আসল screenshot বলে দাবি করবে না**; স্ক্রিনে watermark নয়, কিন্তু README/ডেলিভারি নোটে উল্লেখ থাকবে |
| **3. Abstracted UI** | নিশ্চিত তথ্য নেই | সাধারণ UI কাঠামো; **ভুল বাটন/মেনু/সেটিং নাম তৈরি করবে না** — অনিশ্চয়তা delivery note-এ |

- UI সময়ের সঙ্গে বদলায়; সম্ভব হলে বর্তমান interface যাচাই করো
- button-এর নাম, menu-অবস্থান, setting-এর নাম বাস্তব interface-এর সঙ্গে মিলবে; নিশ্চিত না হলে সাধারণ label ("Settings", "Save") + uncertainty note
- বাস্তবে না থাকলে কল্পিত success message/confirmation নয়

## ৫. Tutorial Annotation নিয়ম

- ছোট ও পরিষ্কার label: "Step 01", "Click Here", "Open Settings", "Enter Details", "Save Changes", "Confirmation" — সংশ্লিষ্ট ধাপের সঙ্গে মিলে
- পুরো বাক্য subtitle নয়; transcript পুনরাবৃত্তি নয়
- annotation UI element ঢাকবে না; সবসময় পড়ার মতো contrast
- step indicator + arrow + highlight — একসঙ্গে একাধিক নয়; ধাপ অনুযায়ী

## ৬. Pre-render Tutorial Check (Annex J-এর সঙ্গে)

- [ ] প্রতিটি ধাপ transcript-এর ক্রম ও অর্থের সঙ্গে মিলে
- [ ] সঠিক button/option/field দেখানো হয়েছে
- [ ] Cursor সঠিক জায়গায় click করছে; UI state ঠিক সেখানে বদলাচ্ছে
- [ ] UI continuity আছে; কোনো ধাপ বাদ পড়েনি
- [ ] Annotation পড়ার মতো সময় পেয়েছে; UI ঢাকেনি
- [ ] শুরু থেকে শেষ অনুসরণযোগ্য; দর্শক ভিডিও দেখে কাজটি করতে পারবে
- [ ] Recreation/uncertainty থাকলে তা delivery note-এ উল্লেখ আছে

---

## ৭. Premium Tutorial Polish (v2.0 নতুন)

Tutorial সিনেও ভিডিওর প্রিমিয়াম ভাষা বজায় থাকবে — শুধু মোশন **সংযত** হবে, মান নয়।

| দিক | বেসিক (এড়াও) | প্রিমিয়াম (করো) |
|---|---|---|
| **UI ফ্রেম** | খালি সাদা আয়তক্ষেত্র | `BrowserMockup` (Annex H §৩১) — chrome + e4 shadow + inset glass |
| **Cursor** | ডিফল্ট তীর | SVG cursor + 2-স্তর drop-shadow + সামান্য scale-on-click |
| **Highlight** | লাল বর্ডার | hero-color ring + corner mark + নরম outer glow |
| **Zoom-to-detail** | হঠাৎ scale | `ease.inOut` ২২f + পেছনে DOF blur বাড়ে |
| **ধাপ পরিবর্তন** | hard cut | cross-dissolve ৮f, UI frame স্থির থাকে |
| **Annotation** | প্লেইন টেক্সট | chip/pill-এ, elevation `e1`, entrance `outBack` |
| **Background** | ফ্ল্যাট | BgMesh ধীরে — কিন্তু opacity কমিয়ে (UI-ই নায়ক) |
| **ধাপ সম্পন্ন** | কিছু না | Check Burst + `click_crisp_01` + ১৮f hold |

### Cursor physics (উন্নত)

```tsx
// দূরত্ব বেশি হলে দ্রুত মাঝে, শেষে ধীর — মানুষের মতো
const t = prog(frame, moveStart, moveDur, ease.inOut);
const cx = lerp(t, [0, 1], [from.x, to.x]);
const cy = lerp(t, [0, 1], [from.y, to.y]);
// arc — সরলরেখায় কখনো নয় (AE principle: Arcs)
const arc = Math.sin(t * Math.PI) * -28;
// click: পৌঁছানোর ৮f পরে
const clickP = prog(frame, moveStart + moveDur + 8, 8, ease.out);
const press = 1 - Math.sin(clickP * Math.PI) * 0.12;
```

### Tutorial-এ অডিও

| ইভেন্ট | সাউন্ড | ভলিউম |
|---|---|---|
| cursor move | **কিছু না** (সবচেয়ে সাধারণ ভুল) | — |
| click | `click_crisp_01` | 0.34 |
| toggle/dropdown | `latch_click_01` | 0.30 |
| ধাপ সম্পন্ন | `pop_soft_01` | 0.28 |
| সব ধাপ শেষ | `chime_pluck_01` | 0.32 |
| মিউজিক বেড | tutorial অংশে **−4 dB অতিরিক্ত নামবে** | 0.12 |

> Tutorial চলাকালে মিউজিক পিছিয়ে যাবে — দর্শকের মনোযোগ ধাপে থাকা চাই।
