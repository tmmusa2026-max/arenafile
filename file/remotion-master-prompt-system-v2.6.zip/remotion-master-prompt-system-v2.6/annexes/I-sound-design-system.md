# Annex I — Sound Design & Music System (v2.0 — সম্পূর্ণ পুনর্লিখিত)

> **v2.6 অগ্রাধিকার:** `MASTER-PROMPT.md`-এর v2.6 সংহত নিয়ম ও Annex Q এখানে বর্ণিত বিরোধী বাধ্যতামূলক সংখ্যা/পদ্ধতির চেয়ে প্রাধান্য পাবে; পুরোনো রেসিপি উদাহরণ মাত্র।

> **v1.0 থেকে বড় পরিবর্তন:** v1.0-তে মিউজিক **নিষিদ্ধ** ছিল ("শুধু SFX")। v2.0-তে **মিউজিক বেড ডিফল্টে চালু** — কারণ প্রিমিয়াম ভিডিওর অনুভূতির ৫০% আসে অডিও থেকে। তবে নিয়ম কঠোর: মিউজিক কখনো কনটেন্ট ঢাকবে না।
>
> **টুল:** `tools/make-audio.mjs` — কোনো dependency/ডাউনলোড/লাইসেন্স ছাড়াই ১৪টি SFX + মিউজিক বেড সিন্থেসাইজ করে। Deterministic (একই আর্গুমেন্টে বিট-বাই-বিট একই ফাইল)।

---

## ০. এক কমান্ডে পুরো সাউন্ড কিট

```bash
node tools/make-audio.mjs --out public/sfx --music-out public/music \
     --bpm 84 --key D --bars 24 --mood cinematic
```

| ফ্ল্যাগ | মান | প্রভাব |
|---|---|---|
| `--mood` | `cinematic` · `calm` · `tech` · `uplifting` | chord progression, scale, perc ঘনত্ব |
| `--bpm` | 60–140 (ডিফল্ট 84) | beat grid — scene cut এখান থেকে |
| `--key` | C…B (ডিফল্ট D) | মূল সুর |
| `--bars` | ভিডিও দৈর্ঘ্য অনুযায়ী | `bars ≈ ceil(seconds × bpm / 240) + 2` |
| `--no-music` | — | শুধু SFX |

আউটপুট `MIX-REPORT.json`-এ প্রতিটি ফাইলের **peak / RMS / LUFS-approx / clipping flag** থাকে — Annex J-এর audio QA এটা দেখেই পূরণ করবে, অনুমানে নয়।

---

## ১. সাউন্ড কিট (১৪টি — সীমিত সেট, এটাই identity)

| ফাইল | ইভেন্ট | দৈর্ঘ্য | টার্গেট peak |
|---|---|---|---|
| `whoosh_soft_01` | টেক্সট/শিরোনাম এন্ট্রি, সিন ট্রানজিশন | 0.62s | −9 dB |
| `whoosh_reverse_01` | pull-out, সিন প্রস্থান | 0.60s | −9 dB |
| `pop_soft_01` | কার্ড/UI reveal | 0.20s | −8 dB |
| `click_crisp_01` | বাটন, টিক, চেকমার্ক | 0.10s | −10 dB |
| `latch_click_01` | toggle, switch, dropdown | 0.14s | −10 dB |
| `chime_pluck_01` | লোগো reveal, outro | 1.10s | −8 dB |
| `thud_soft_01` | হুক/মূল বার্তা (সংযত) | 0.40s | −7 dB |
| `tick_soft_01` | কাউন্টার চলাকালে | 0.06s | −14 dB |
| `riser_soft_01` | hook/chapter-এর আগে tension | 1.80s | −8 dB |
| `impact_cine_01` | **ইন্ট্রো IMPACT** — পুরো ভিডিওতে ≤২বার | 2.20s | −3 dB |
| `sub_drop_01` | ইন্ট্রো→বডি, বড় শিফট | 1.40s | −4 dB |
| `shimmer_tail_01` | highlight/glow tail | 1.60s | −11 dB |
| `glass_tap_01` | প্রিমিয়াম micro-interaction | 0.50s | −11 dB |
| `boom_tail_01` | chapter/section পরিবর্তন | 2.60s | −4 dB |

প্রতিটিতে band-limited synthesis + soft attack + Schroeder reverb + de-click fade। **কোনো raw sine beep নয়।**

---

## ২. মিউজিক বেড — উৎসের ক্রম

1. **ইউজারের দেওয়া মিউজিক** (`public/music/`) — সবসময় প্রথম
2. **লাইসেন্সড উৎস** (ইউজার চাইলে ও লাইসেন্স যাচাই করা গেলে): Uppbeat · Pixabay Music · Free Music Archive (CC) · YouTube Audio Library — **লাইসেন্স টেক্সট `ASSETS.md`-তে হুবহু**
3. **In-project synthesis** (`tools/make-audio.mjs`) — ডিফল্ট; কপিরাইট ঝুঁকি শূন্য, ভিডিওর দৈর্ঘ্যে ঠিক মাপা
4. **মিউজিক নেই** — শুধু যদি ইউজার বলে, বা কনটেন্ট গুরুগম্ভীর/সংবেদনশীল

> কখনো "royalty-free music ব্যবহার করেছি" দাবি করবে না যদি ফাইল সত্যিই প্রজেক্টে না থাকে। অনুপস্থিত থাকলে স্পষ্ট জানাবে।

---

## ৩. Mix Bus — সংখ্যা, অনুমান নয়

### লাউডনেস টার্গেট

| প্ল্যাটফর্ম | Integrated LUFS | True Peak |
|---|---|---|
| YouTube / long-form | **−14 LUFS** | −1.0 dBTP |
| Instagram / TikTok / Reels | **−14 LUFS** | −1.0 dBTP |
| কেবল প্রিভিউ/অভ্যন্তরীণ | −16 LUFS | −1.0 dBTP |

### স্তরবিন্যাস (gain staging)

```
  Voiceover (থাকলে)     ████████████████████  0 dB   ← সবসময় উপরে
  SFX                   ███████████            −8 dB
  Music bed (VO সহ)     ██████                 −16 dB
  Music bed (VO ছাড়া)   ██████████             −10 dB
  Ambience/texture      ███                    −22 dB
```

Remotion-এ:
```tsx
<Audio src={staticFile("music/bed_main.wav")} volume={hasVO ? 0.16 : 0.30} />
<Audio src={staticFile("sfx/whoosh_soft_01.wav")} volume={0.34} />
```

### Frequency slotting (সবচেয়ে কম বোঝা, সবচেয়ে কার্যকর কৌশল)

| ব্যান্ড | কে দখল করবে | কে সরে যাবে |
|---|---|---|
| 20–80 Hz | sub (`sub_drop`, `impact`) | বাকি সব HPF |
| 80–200 Hz | মিউজিকের bass | — |
| **200 Hz – 4 kHz** | **ভয়েসওভার** | মিউজিকে এখানে −2.5 dB dip (make-audio.mjs স্বয়ংক্রিয় করে) |
| 4–10 kHz | SFX transient (click, pop) | — |
| 10 kHz+ | air/shimmer | — |

এই কারণেই জেনারেটর মিউজিক বেডে 2.5kHz-এ একটি peak-dip বসায় — VO থাকলে EQ-ducking ছাড়াই পরিষ্কার শোনা যায়।

---

## ৪. Ducking — sidechain compression-এর Remotion সংস্করণ

`motion.ts`-এর `duck()` ব্যবহার করো। VO/গুরুত্বপূর্ণ SFX-এর সময় মিউজিক নিজে থেকে নেমে যাবে।

```tsx
import { duck } from "../motion";

// SRT থেকে VO সেগমেন্টের frame range তৈরি করো
const voRanges: Array<[number, number]> = timeline.cues.map((c) => [c.startFrame, c.endFrame]);

<Audio
  src={staticFile("music/bed_main.wav")}
  volume={(f) => duck(f, 0.30, voRanges, fps, -8)}   // −8 dB নামবে
/>
```

- **Attack** 0.12s (দ্রুত নামে) · **Release** 0.35s (ধীরে ফেরে) — এটাই প্রাকৃতিক শোনায়
- Depth −6 থেকে −10 dB। −12-এর বেশি = "পাম্পিং", শ্রোতা টের পায়
- বড় impact SFX-এর সময়ও ducking দাও — তাহলে impact আরও বড় শোনায়

---

## ৫. Sound ↔ Motion Sync Law

```
       −3f          0f              +12f
        │           │                │
  SFX   ▓▓▓▓▓▓▓▓▓▓▓▓│                     ← transient এখানে
  VIS   ░░░░░░░░░░░░█████████████████     ← element এখানে settle করে
              ↑
        মস্তিষ্ক এটাকে "নিখুঁত sync" পড়ে
```

| নিয়ম | মান |
|---|---|
| SFX শুরু | visual settle-এর **২–৩ frame আগে** (`timing(fps).sfxLead`) |
| দেরিতে বাজলে | "ভাঙা" শোনায় — ১ frame দেরিও চোখে পড়ে |
| এক ফ্রেমে একসাথে | সর্বোচ্চ **২টি** SFX; ৩টি = কাদা |
| প্রতি staggered item-এ | **কখনো না** — গ্রুপ reveal-এ একটিই সাউন্ড |
| পুরো ভিডিওতে | ইভেন্ট ঘনত্ব ≈ প্রতি ১.৫–৩ সেকেন্ডে ১টি |
| একই ইভেন্ট | একই সাউন্ড (pitch ±৩%, volume ±১০% ভেরিয়েশন চলবে) |
| নীরবতা | প্রতি ১৫–২০s-এ অন্তত একবার ২s+ SFX-মুক্ত জায়গা |

---

## ৬. Beat Grid — cut মিউজিকের সঙ্গে মেলানো

```tsx
import { beatGrid } from "../motion";
const G = beatGrid(fps, 84);     // MIX-REPORT.json-এ bpm আছে

G.framesPerBeat  // 21.43 @30fps
G.at(4)          // ৪র্থ bar-এর frame → এখানে scene cut
G.snap(137)      // 137 → নিকটতম beat-এ snap
```

**নিয়ম:**
- প্রতিটি scene cut নিকটতম beat-এ snap করো (±2 frame পর্যন্ত টানা যায়)
- বড় reveal সবসময় **bar-এর ১ম beat**-এ
- ইন্ট্রোর IMPACT = bar 1, beat 1
- Transition-এর মাঝবিন্দু beat-এ, শুরু নয়

---

## ৭. Audio QA Gate (MIX-REPORT.json দেখে পূরণ করো — অনুমানে নয়)

- [ ] `MIX-REPORT.json`-এ কোনো ফাইলে `clipping: true` নেই
- [ ] প্রতিটি SFX টার্গেট peak-এর ±1.5 dB-এর মধ্যে (level match)
- [ ] মিউজিক বেড integrated LUFS রিপোর্ট করা হয়েছে
- [ ] ফাইনাল মিক্সে true peak ≤ −1.0 dBTP
- [ ] VO থাকলে ducking প্রয়োগ হয়েছে; VO কোথাও ঢাকা পড়েনি (শুনে যাচাই)
- [ ] প্রতিটি SFX visual-এর ২–৩f আগে (frame গুনে যাচাই, অনুমানে নয়)
- [ ] এক ফ্রেমে ≥৩টি SFX কোথাও নেই
- [ ] মিউজিক ইন্ট্রো শেষে ঢুকেছে, শেষে ধীরে নেমেছে (hard cut নয়)
- [ ] scene cut beat grid-এ snap করা
- [ ] সব audio-র source/license `ASSETS.md`-তে ("synthesized in-project via tools/make-audio.mjs" লিখলেই যথেষ্ট)
- [ ] **রেন্ডার করা MP4 শুনে যাচাই** — preview শোনা যথেষ্ট নয়

---

## ৮. নিষিদ্ধ

- কার্টুনি/গেমি beep, ৮-বিট blip, হাই-পিচ ধাতব শব্দ
- প্রতিটি অ্যানিমেশনে সাউন্ড (সবচেয়ে সাধারণ amateur ভুল)
- লুপ শোনা যায় এমন মিউজিক (bar boundary-তে স্পষ্ট জোড়া)
- VO-এর উপরে মিউজিক; ducking ছাড়া বেড
- Hard cut দিয়ে audio শুরু/শেষ (click তৈরি হয় — `deClick` সবসময়)
- যাচাই না করে "audio sync ঠিক আছে" দাবি
- লাইসেন্স না জেনে কোনো মিউজিক/SFX

---

## ১১. মিক্সে বেড বসানো — মাঠে ধরা পড়া দুটি ফাঁদ

ডেমো রেন্ডার করার পর অডিও মেপে দুটি সমস্যা পাওয়া গেছে। দুটোই নীরব
ব্যর্থতা — কোনো এরর দেয় না, শুধু ভিডিওটা "ফাঁকা" শোনায়।

### ১১.১ বেডের নীরব intro বার

`make-audio.mjs` যে বেড বানায় তাতে একটি **ইচ্ছাকৃত musical build**
থাকে — প্রথম ৪–৫ সেকেন্ড প্রায় নীরব, তারপর পূর্ণ arrangement ঢোকে:

```
 0s  -71.7 dB
 1s  -55.2 dB
 2s  -47.8 dB █
 3s  -46.0 dB ██
 4s  -42.5 dB ████
 5s  -19.5 dB ████████████████████   ← এখানে আসল বেড শুরু
```

২০ সেকেন্ডের ভিডিওতে বেডটা ০s থেকে বাজালে প্রথম এক-চতুর্থাংশ জুড়ে
কোনো মিউজিক শোনা যাবে না। ডেমোতে ঠিক এটাই হয়েছিল — ৪–৭ সেকেন্ড
(হুক সিনের পুরোটা) মাপে **−৫৫ থেকে −৬৫ dB**, অর্থাৎ কার্যত নীরব।

**সমাধান** — নীরব বার বাদ দিয়ে শুরু করো:

```tsx
<Audio
  src={staticFile("music/bed_main.wav")}
  trimBefore={132}      // ≈ ৪.৪s @ ৩০fps — build বাদ
  volume={...}
/>
```

> **নিয়ম:** বেড ব্যবহারের আগে তার **প্রতি-সেকেন্ড RMS** দেখো। যে বার
> থেকে পূর্ণ শক্তি, সেখান থেকেই `trimBefore`। ছোট ভিডিওতে (< ৩০s)
> বেডের build-up বাজানোর মতো সময় থাকে না।

### ১১.২ বেস গেইন বেডের নিজের লেভেলের সাথে মিলিয়ে দাও

বেড মাস্টার করা হয় **≈ −২০ dB RMS / −৩ dB পিক**-এ (crest factor ~১৯ dB)।
`volume={0.26}` দিলে মিক্সে বেড নামে −৩১ dB RMS-এ — SFX-এর নিচে চাপা
পড়ে যায়, শ্রোতা শুধু SFX শোনে।

| ব্যবহার | বেস গেইন | মিক্সে বেড |
|---|---|---|
| ভয়েসওভারের নিচে | ০.২৫–০.৩০ | ≈ −৩১ dB RMS |
| **ভয়েসওভার নেই (টেক্সট-অনলি ভিডিও)** | **০.৪৫–০.৫৫** | **≈ −২৬ dB RMS** |
| মিউজিক-ফরোয়ার্ড টিজার | ০.৬৫–০.৭৫ | ≈ −২৩ dB RMS |

ducking depth −৫ থেকে −৮ dB-ই যথেষ্ট। এর বেশি দিলে বেড পুরো "গায়েব"
হয়ে যায় এবং কাটের মতো শোনায়, sidechain-এর মতো নয়।

### ১১.৩ বেড বাসে কম্প্রেসর — ঐচ্ছিক নয়

জেনারেট করা arrangement-এ পারকাশন তীক্ষ্ণ শিখর তৈরি করে, আর বারের
ফাঁকে স্তর ২০+ dB নেমে যায়। কম্প্রেসর ছাড়া বেডটা "চালু-বন্ধ" শোনায়।

`make-audio.mjs` এখন মিউজিক বাসে একটি soft-knee কম্প্রেসর চালায়:

```js
compress(mix, {
  thresholdDb: -34, ratio: 4, attack: 0.025,
  release: 0.32, knee: 10, makeupDb: 9,
});
```

মাপা ফল (৮৪ BPM · cinematic · ২৪ bar):

| | কম্প্রেসর ছাড়া | কম্প্রেসর সহ |
|---|---|---|
| উচ্চ অংশ | −১৯.৬ dB RMS | −২৪.০ dB RMS |
| ফাঁকা বার | −৪৩.৩ dB RMS | −৩৪.৮ dB RMS |
| **সুইং** | **২৩.৮ dB** | **১১.০ dB** |

একই সাথে প্যাডে দুটি পরিবর্তন: বার-বাফার `bar * 1.08` → `bar * 1.8`
(পরের বারে গড়িয়ে crossfade), এবং পুরো দৈর্ঘ্যজুড়ে একটি **sustain
drone** স্তর যা কখনো গেট হয় না।

**লক্ষ্য:** বেডের সুইং ১২ dB-এর নিচে। এর বেশি হলে ছোট ভিডিওতে
ফাঁকগুলো নীরবতা হিসেবে ধরা পড়বে।

### ১১.৪ রেন্ডারের পর অডিও **মেপে** দেখো

চোখে দেখা যায় না, তাই যাচাই বাধ্যতামূলক:

```bash
npx remotion ffmpeg -y -i out/video.mp4 -vn -ac 1 -ar 8000 \
  -c:a pcm_s16le /tmp/a.wav
```

```python
import wave, struct, math
w = wave.open("/tmp/a.wav"); n = w.getnframes(); sr = w.getframerate()
s = struct.unpack(f"<{n}h", w.readframes(n))
for i in range(0, n - sr, sr):                    # প্রতি সেকেন্ডে RMS
    win = s[i:i+sr]
    r = math.sqrt(sum(x*x for x in win) / len(win))
    db = 20*math.log10(r/32768) if r else -99
    print(f"{i//sr:3d}s {db:6.1f} dB", "█" * max(0, int((db+55)/1.8)))
```

**গেট:** কোনো এক সেকেন্ডও −৪৫ dB-এর নিচে থাকবে না, যদি না সেটা
ইচ্ছাকৃত নাটকীয় বিরতি হয়। নিচে থাকলে বেড হয় শুরু হয়নি, নয়তো
অতিরিক্ত duck হয়েছে, নয়তো গেইন খুব কম।
