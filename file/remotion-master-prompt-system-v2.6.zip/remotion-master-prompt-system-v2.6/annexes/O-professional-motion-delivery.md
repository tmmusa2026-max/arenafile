# Annex O — Professional Motion, SVG & Delivery (v2.2)

> **v2.6 অগ্রাধিকার:** `MASTER-PROMPT.md`-এর v2.6 সংহত নিয়ম ও Annex Q এখানে বর্ণিত বিরোধী বাধ্যতামূলক সংখ্যা/পদ্ধতির চেয়ে প্রাধান্য পাবে; পুরোনো রেসিপি উদাহরণ মাত্র।

এই Annex ও Master Prompt-এর v2.2 অগ্রাধিকার অংশ আগের বিরোধী বাধ্যতামূলক aesthetic ও font নিয়মের ওপর প্রযোজ্য। এগুলো বাস্তব পরিস্থিতির নির্দেশনা, সফল রেন্ডারের প্রমাণ নয়।

## ১. Storyboard ও visual direction
কোডের আগে একটি table: scene ID, start/end (সময় ও frame), মূল বক্তব্য, দৃশ্যের উদ্দেশ্য, visual hierarchy, layout, asset/অধিকার, primary/secondary motion, curve, narration sync, hold ও transition। SRT থাকলে আসল timing ব্যবহার; শুধু TXT হলে অনুমান স্পষ্টভাবে চিহ্নিত। Scene-এর গতি ও composition বৈচিত্র্যময়, গুরুত্বপূর্ণ লেখা পড়ার সময় যথেষ্ট। Silent/minimal দৃশ্য গ্রহণযোগ্য। তথ্য বা footage বানিয়ে সত্য বলে দাবি নয়।

## ২. Motion ও compositing
- `templates/motion.ts`-এর `propertyProgress` দিয়ে position, scale, rotation আলাদা start, duration এবং easing পেতে পারে। `customCurve(x1,y1,x2,y2)` দিয়ে Bézier নিয়ন্ত্রণ; x 0–1, y overshoot করতে পারে। fps অনুযায়ী frame গণনা করো। Anticipation/overshoot কেবল উপযুক্ত বস্তুতে; text পড়ার সময় স্থিতিশীল রাখো।
- 2.5D camera/parallax গল্পে প্রয়োজন হলে। Motion blur কেবল দ্রুত movement-এ নান্দনিকভাবে দরকার হলে, উপযুক্ত Remotion API ও version যাচাই করে। Mask/clip-path, alpha matte, blending বা light effect ব্যবহার আগে representative render পরীক্ষা করো; AE-এর সব feature সমতুল্য বলে দাবি করবে না।
- Preview: blur/post কম বা বন্ধ, কম resolution; final: নির্বাচিত effect চালু ও target resolution। আলো ও composition একই রাখো। বড় blur/filter ব্যয়বহুল: বাজেট ছাড়ালে আগে blur area/sample কমাও, static/pre-rendered asset বা gradient নাও। Animation frame-based ও deterministic।

## ৩. SVG output contract
ব্যবহারকারীর চাহিদা অনুযায়ী `assets/svg/name.svg` standalone এবং/অথবা `src/components/svg/Name.tsx` তৈরি করো। `viewBox`, সঠিক aspect ratio, অর্থবহ group ID ও পরিষ্কার path রাখো। External font/image এড়াও বা নির্ভরতা document করো; standalone SVG-তে script বাদ। React-এর একাধিক instance-এ gradient/filter/clipPath ID unique করো (যেমন stable `useId`); reference matching পরীক্ষা করো। Flat, gradient বা detailed style উদ্দেশ্য অনুযায়ী; animation-এর পৃথক layers রাখো। জটিল morph-এর আগে command type/order, count ও topology যাচাই; numeric count শুধু যথেষ্ট নয়। না মিললে tested library বা opacity/scale crossfade। standalone SVG viewer ও Remotion still-এ পরীক্ষা; AI প্রকৃত SVG তৈরি না করলে করেছে বলে দাবি করবে না।

## ৩.১ SVG-first retry ও web media fallback (v2.4)

যখন visual plan-এ SVG/icon/diagram উপযুক্ত, তখন **প্রথমে SVG বানানোর আন্তরিক চেষ্টা বাধ্যতামূলক**; শুধু SVG এড়াতে web image বেছে নেবে না। ব্যবহারকারী বাস্তব ছবি/ভিডিও চাইলে বা বাস্তব ছবি বেশি সত্যনিষ্ঠ হলে সেটি জোর করে SVG করবে না।

1. Scene-এর বিষয় থেকে simple geometry, layer, viewBox ও রঙ নির্ধারণ করো। নিজে minimal standalone SVG বা React SVG তৈরি করো; কাজের প্রয়োজন অনুযায়ী paths, basic shapes ও labels ব্যবহার করো; asset যথার্থ রাখো। SVG code লিখলেই সফল ধরা যাবে না: file/component যাচাই, project-এ integrate, এবং সম্ভব হলে still render ও visual inspection করো।
2. প্রথম প্রচেষ্টা ব্যর্থ হলে error ও কারণ দেখো; malformed XML/JSX, invalid path, duplicate defs IDs, clipping, missing font বা dependency ঠিক করে দ্বিতীয় প্রচেষ্টা চালাও। আবার ব্যর্থ হলে তৃতীয় প্রচেষ্টায় complexity কমাও: basic SVG shapes, কম layers, no filters/morph; দরকার হলে animated morph-এর বদলে static shape/opacity reveal। প্রতিটি প্রচেষ্টা প্রকৃত কাজ ও পরীক্ষা হবে; একই ব্যর্থতা অকারণে অসীম পুনরাবৃত্তি নয়। API বা render tool unavailable হলে ব্যর্থতার বদলে **যাচাই করা যায়নি** বলো; প্রকৃত পরীক্ষার ফল বানাবে না। গুরুতর environment blocker হলে অর্থহীন retries না করে কারণ জানিয়ে fallback-এ যাও।
3. তিনটি বাস্তব প্রচেষ্টার পরও কাজ না হলে বা environment blocker থাকলে scene-এর উদ্দেশ্য বজায় রেখে user-provided media আগে; না থাকলে উপলব্ধ browser (Chrome থাকলে Chrome, না থাকলে অন্য উপযুক্ত web/search tool) দিয়ে বৈধ photo অথবা সংক্ষিপ্ত video clip খোঁজো। Chrome নিজে image source বা license নয়। Annex D/M অনুযায়ী মূল asset page, license, privacy এবং বাস্তব বিষয়ের যথার্থতা যাচাই করো। User-এর উদ্দেশ্য অস্পষ্ট হলে commercial use ও editing অনুমোদিত media অগ্রাধিকার। license অজানা/অনুপযুক্ত হলে ব্যবহার নয়।
4. Download করা media উপযুক্তভাবে `public/images/` বা `public/video/`-এ রেখে composition, crop, grading ও প্রয়োজনে মৃদু motion করো। Video-র নিজের audio অপ্রয়োজনীয় হলে mute, duration/timing ও rights যাচাই। `ASSETS.md`-এ প্রত্যেক উৎস ও credit লিখে project ZIP-এ প্রয়োজনীয় assets রাখো। Search, download, license verification বা asset ব্যবহার আসলেই হয়েছে কি না রিপোর্ট করো।
5. Web media-ও না পাওয়া গেলে ব্যবহারকারীর ছবি/ক্লিপ চাও অথবা প্রকল্পে নিরাপদ typography/basic shape fallback ব্যবহার করো; placeholder-কে বাস্তব ছবি বলে উপস্থাপন নয়। User-কে কোনো unresolved scene ও অসম্পূর্ণ verification জানান। GoFile upload শুধু ZIP তৈরি ও যাচাইয়ের পরে।

## ৪. QA ও delivery
- শুরু/middle/end এবং প্রতিটি গুরুত্বপূর্ণ composition-এ representative still রেন্ডার করে দেখো; দীর্ঘ বা complex scene হলে বাড়তি frame। বাংলা যুক্তাক্ষর, overflow, contrast, safe area ও font দেখো।
- সংক্ষিপ্ত চলমান preview-এ easing, timing, sync, blur ও transition দেখো। final render করা হলে সম্পূর্ণ দেখে অডিও, resolution ও duration যাচাই করো। যা পরীক্ষা করা হয়নি স্পষ্টভাবে লিখো।
- ZIP-এ source, প্রকৃত assets ও license notes, font, package manifest/lock (থাকলে), scripts, render commands ও README অন্তর্ভুক্ত। `node_modules`, cache, secrets, credentials ও অপ্রয়োজনীয় বড় output বাদ। ZIP integrity যাচাই করে local copy রাখো।

## ৫. GoFile upload — ব্যবহারকারীর অনুরোধ
ব্যবহারকারীর ZIP upload চাওয়া অনুমতি হিসেবে বিবেচ্য; অন্য কারও ব্যক্তিগত তথ্য বা গোপনীয় asset থাকলে sharing করার আগে নিশ্চিত হও। ZIP নিরীক্ষা ও যাচাইয়ের পরে:

```bash
unzip -t project.zip
bash tools/upload-gofile.sh project.zip
```

`curl` ও `python3` দরকার। Optional `GOFILE_TOKEN` environment variable-এ existing account token রাখা যায়; terminal history, project ZIP ও chat-এ token রাখা বা প্রকাশ করা নয়। Script GoFile-এর documented `POST https://upload.gofile.io/uploadfile`-এ multipart file পাঠায়; token না থাকলে guest upload হতে পারে। সফল `status=ok` ও `data.downloadPage` থাকলেই শুধু সেই URL উপস্থাপন করো, এবং local ZIP-ও দাও। Response-এর guestToken বা account token শেয়ার করবে না। লিংকটি সাধারণত third-party download page, permanent direct file URL নয়; retention/expiry বা access service-নির্ভর। HTTP/API/network error হলে কারণ জানাও, retry কেবল উপযুক্ত হলে; লিংক বানাবে না। Service/API পরিবর্তিত হতে পারে: https://gofile.io/api দেখো।
