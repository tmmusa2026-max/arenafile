# Annex H — Component Recipes (v2.0 — ৪০টি কপি-পেস্ট রেসিপি)

> **v2.6 অগ্রাধিকার:** `MASTER-PROMPT.md`-এর v2.6 সংহত নিয়ম ও Annex Q এখানে বর্ণিত বিরোধী বাধ্যতামূলক সংখ্যা/পদ্ধতির চেয়ে প্রাধান্য পাবে; পুরোনো রেসিপি উদাহরণ মাত্র।

> সব component দুটি import করবে: `theme` (`src/theme.ts`) ও `motion` (`src/motion.ts`)।
> **কোনো `interpolate()` linear নয়; সবসময় clamp** — তাই raw `interpolate` নয়, `lerp()` ব্যবহার করো।
> কোডে inline hex / easing / magic frame number নয়।

```tsx
// প্রতিটি ফাইলের স্ট্যান্ডার্ড হেডার
import { AbsoluteFill, Img, Audio, Sequence, staticFile,
         useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { lerp, prog, springP, inOutProgress, anticipate, breathe, floatY,
         wiggle, hash01, noise1D, timing, ease, cameraTransform,
         depthBlur, shutterBlur, beatGrid, duck } from "../motion";
```

---

## A. Foundation (1–8)

### 1. Entrance — কাজের ঘোড়া (≥৩ প্রপার্টি)
```tsx
export const Entrance: React.FC<{ delay?: number; from?: "bottom"|"left"|"right"|"scale";
  children: React.ReactNode }> = ({ delay = 0, from = "bottom", children }) => {
  const frame = useCurrentFrame(); const { fps } = useVideoConfig();
  const p = springP(frame, fps, delay, "smooth");
  const d = 40;
  const t = from === "bottom" ? `translateY(${lerp(p,[0,1],[d,0])}px)`
          : from === "left"   ? `translateX(${lerp(p,[0,1],[-d,0])}px)`
          : from === "right"  ? `translateX(${lerp(p,[0,1],[d,0])}px)` : "";
  return <div style={{
    opacity: p, transform: `${t} scale(${lerp(p,[0,1],[0.94,1])})`,
    filter: `blur(${lerp(p,[0,1],[8,0])}px)`,
  }}>{children}</div>;
};
```

### 2. Staggered children
```tsx
{items.map((it, i) => <Entrance key={i} delay={start + i * T.stagger.card}>{it}</Entrance>)}
// offset: শব্দ 3f · কার্ড 4f · বড় ব্লক 6f
```

### 3. SceneWrap — entrance + exit + post stack একসাথে
```tsx
export const SceneWrap: React.FC<{ children: React.ReactNode; impact?: number }> =
({ children, impact = 0 }) => {
  const frame = useCurrentFrame(); const { durationInFrames } = useVideoConfig();
  const { enter, exit } = inOutProgress(frame, { inDur: 16, end: durationInFrames, outDur: 9 });
  return (
    <AbsoluteFill style={{ opacity: enter * exit,
      transform: `scale(${lerp(enter,[0,1],[1.02,1])})` }}>
      <PostStack impact={impact}>{children}</PostStack>
    </AbsoluteFill>
  );
};
```

### 4. BgMesh — ফ্ল্যাট background নিষিদ্ধ
```tsx
export const BgMesh: React.FC<{ seed?: number }> = ({ seed = 1 }) => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50, d2 = Math.cos(frame / 70) * 40;
  return (
    <AbsoluteFill style={{ background: theme.colors.bg, overflow: "hidden" }}>
      <div style={{ position: "absolute", width: 1300, height: 1300, borderRadius: "50%",
        top: -480, left: -320 + d1, filter: "blur(60px)",
        background: `radial-gradient(circle, ${theme.colors.primary}30, transparent 62%)` }} />
      <div style={{ position: "absolute", width: 950, height: 950, borderRadius: "50%",
        bottom: -420, right: -260 - d2, filter: "blur(80px)",
        background: `radial-gradient(circle, ${theme.colors.accent}22, transparent 65%)` }} />
      {/* সূক্ষ্ম grid — ফ্ল্যাট ভাব ভাঙে */}
      <AbsoluteFill style={{ opacity: 0.07,
        backgroundImage: `linear-gradient(${theme.colors.text} 1px, transparent 1px),
                          linear-gradient(90deg, ${theme.colors.text} 1px, transparent 1px)`,
        backgroundSize: "88px 88px",
        transform: `translate(${d1 * 0.2}px, ${d2 * 0.2}px)` }} />
    </AbsoluteFill>
  );
};
```

### 5–9. PostStack (grade/split-tone/halation/grain/vignette) → **Annex E §৪** (সম্পূর্ণ কোড)

### 10. GlassCard — প্রিমিয়াম surface
```tsx
export const GlassCard: React.FC<{ delay?: number; children: React.ReactNode;
  elevation?: "e1"|"e2"|"e3"|"e4" }> = ({ delay = 0, children, elevation = "e3" }) => {
  const frame = useCurrentFrame(); const { fps } = useVideoConfig();
  const p = springP(frame, fps, delay, "smooth");
  return (
    <div style={{
      opacity: p,
      transform: `translateY(${lerp(p,[0,1],[34,0])}px) scale(${lerp(p,[0,1],[0.96,1])*breathe(frame,0.006)})`,
      background: theme.gradients.surface,
      backdropFilter: "blur(24px)",
      border: `1px solid ${theme.colors.line}`,
      borderRadius: theme.radii.lg,
      boxShadow: `${theme.elevation[elevation]}, ${theme.elevation.insetGlass}`,
      padding: theme.space.lg,
    }}>{children}</div>
  );
};
```

---

## B. Text (11–18) → সম্পূর্ণ কোড **Annex B §৩**

| # | Recipe | Annex B রেফারেন্স |
|---|---|---|
| 11 | `WordCascade` (বাংলা-সেফ) | §৩ |
| 12 | `LineMaskRise` | §২ Tier 1 |
| 13 | `DepthExtrude` | §৩ |
| 14 | `LightWipe` | §৩ |
| 15 | `GradientSheen` | §২ Tier 2 |
| 16 | `HighlightSweep` | নিচে ↓ |
| 17 | `Counter` / `OdometerRoll` | নিচে ↓ |
| 18 | Text exit | §৩ |

### 16. Highlight Sweep (pill / underline)
```tsx
export const Highlight: React.FC<{ children: React.ReactNode; delay?: number;
  variant?: "underline"|"pill" }> = ({ children, delay = 0, variant = "underline" }) => {
  const frame = useCurrentFrame();
  const s = prog(frame, delay, 14, ease.inOut);
  return (
    <span style={{ position: "relative", display: "inline-block",
      padding: variant === "pill" ? "2px 16px" : 0 }}>
      <span style={{ position: "relative", zIndex: 1 }}>{children}</span>
      <span style={{ position: "absolute", left: 0, zIndex: 0,
        bottom: variant === "pill" ? 0 : 4,
        top: variant === "pill" ? 0 : undefined,
        height: variant === "pill" ? "100%" : 12,
        width: `${s * 100}%`,
        background: theme.gradients.hero,
        opacity: variant === "pill" ? 0.22 : 0.38,
        borderRadius: variant === "pill" ? theme.radii.pill : 8,
        transformOrigin: "left center" }} />
    </span>
  );
};
```

### 17. Counter (সংখ্যা সবসময় স্ক্রিপ্টের — কল্পিত নয়)
```tsx
export const Counter: React.FC<{ to: number; delay?: number; suffix?: string;
  decimals?: number }> = ({ to, delay = 0, suffix = "", decimals = 0 }) => {
  const frame = useCurrentFrame(); const { fps } = useVideoConfig();
  const p = springP(frame, fps, delay, "precise");
  const v = lerp(p, [0, 1], [0, to]);
  return <span style={{ ...theme.textStyles.bigNumber, color: theme.colors.text,
    textShadow: theme.bloom.heroText }}>{v.toFixed(decimals)}{suffix}</span>;
};
```

---

## C. Photo & Media (19–24) → সম্পূর্ণ কোড **Annex D §৫**

| # | Recipe | নোট |
|---|---|---|
| 19 | `PremiumPhoto` (Ken Burns + mask + halation + light wrap + scrim) | Annex D §৫ |
| 20 | `KenBurns` (মিনিমাল সংস্করণ) | নিচে ↓ |
| 21 | `ParallaxStack` | নিচে ↓ |
| 22 | `BeforeAfter` | divider animate |
| 23 | `VideoClip` | **`<OffthreadVideo>`, কখনো `<Video>` নয়** |
| 24 | `PhotoGrid` (mosaic stagger) | tile 4f offset |

### 20. KenBurns (প্রতিটি still-এ — ব্যতিক্রম নেই)
```tsx
export const KenBurns: React.FC<{ src: string; zoomTo?: number; dir?: 1|-1 }> =
({ src, zoomTo = 1.08, dir = 1 }) => {
  const frame = useCurrentFrame(); const { durationInFrames } = useVideoConfig();
  const a = dir > 0 ? [1, zoomTo] as const : [zoomTo, 1] as const;
  return <Img src={staticFile(src)} style={{
    width: "100%", height: "100%", objectFit: "cover",
    transform: `scale(${lerp(frame,[0,durationInFrames],a,ease.inOut)})
                translateX(${lerp(frame,[0,durationInFrames],[0,-26*dir],ease.inOut)}px)`,
    filter: theme.grade.filmFilter,
  }} />;
};
// পরপর শটে dir alternate করো (1, -1, 1, -1) — একঘেয়েমি ভাঙে
```

### 21. ParallaxStack
```tsx
const x = lerp(frame, [0, 90], [0, -120], ease.inOut);
<div style={{ transform: `translateX(${x * 0.3}px)` }}><Bg /></div>
<div style={{ transform: `translateX(${x * 0.6}px)` }}><Mid /></div>
<div style={{ transform: `translateX(${x}px)` }}><Fg /></div>
```

---

## D. Vector & SVG (25–30) → সম্পূর্ণ কোড **Annex L**

| # | Recipe | Annex L রেফারেন্স |
|---|---|---|
| 25 | `SvgDefs` (gradient + filter লাইব্রেরি) | §২, §৩ |
| 26 | `DrawPath` (trim path) | §৪ |
| 27 | `morphPath()` / `blobPath()` | §৫ |
| 28 | `PremiumIcon` (৩-স্তর) | §৮ |
| 29 | Node network / particle field | §৬ |
| 30 | Soft-edge mask (`LumaWipe`) | §৭ + Annex E §২ |

---

## E. UI & Data (31–35)

### 31. BrowserMockup (tutorial ও ফিচার সিনে)
```tsx
export const BrowserMockup: React.FC<{ url?: string; children: React.ReactNode;
  delay?: number }> = ({ url = "example.com", children, delay = 0 }) => {
  const frame = useCurrentFrame(); const { fps } = useVideoConfig();
  const p = springP(frame, fps, delay, "smooth");
  return (
    <div style={{
      opacity: p,
      transform: `translateY(${lerp(p,[0,1],[40,0])}px) scale(${lerp(p,[0,1],[0.95,1])})
                  perspective(1400px) rotateX(${lerp(p,[0,1],[6,0])}deg)`,
      borderRadius: theme.radii.lg, overflow: "hidden",
      border: `1px solid ${theme.colors.line}`,
      boxShadow: `${theme.elevation.e4}, ${theme.elevation.insetGlass}`,
      background: theme.colors.surface,
    }}>
      <div style={{ height: 46, display: "flex", alignItems: "center", gap: 8,
        padding: "0 16px", background: theme.colors.bgAlt,
        borderBottom: `1px solid ${theme.colors.line}` }}>
        {["#FF5F57", "#FEBC2E", "#28C840"].map((c) => (
          <div key={c} style={{ width: 11, height: 11, borderRadius: 999, background: c, opacity: 0.85 }} />
        ))}
        <div style={{ ...theme.textStyles.uiText, color: theme.colors.textDim,
          marginLeft: 14, padding: "4px 14px", borderRadius: theme.radii.pill,
          background: theme.colors.bg, flex: 1, maxWidth: 420 }}>{url}</div>
      </div>
      <div style={{ position: "relative" }}>{children}</div>
    </div>
  );
};
```

### 32. ProgressRing
```tsx
const p = springP(frame, fps, delay, "precise"), R = 54, C = 2 * Math.PI * R;
<svg width={128} height={128}>
  <circle cx={64} cy={64} r={R} fill="none" stroke={theme.colors.line} strokeWidth={8} />
  <circle cx={64} cy={64} r={R} fill="none" stroke="url(#heroGrad)" strokeWidth={8}
    strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - p * pct)}
    transform="rotate(-90 64 64)" filter="url(#bloom)" />
</svg>
```

### 33. BarChart (শুধু স্ক্রিপ্টের সংখ্যা)
```tsx
{data.map((d, i) => {
  const p = springP(frame, fps, delay + i * 4, "smooth");
  return <div key={i} style={{ height: `${d.value * p}%`,
    background: i === heroIndex ? theme.gradients.hero : theme.colors.surfaceHi,
    borderRadius: `${theme.radii.sm}px ${theme.radii.sm}px 0 0`,
    boxShadow: i === heroIndex ? theme.bloom.subtle : "none" }} />;
})}
```

### 34. StepRail / 35. DeviceMockup → একই প্যাটার্ন (gradient surface + elevation + stagger)

---

## F. Transitions & Camera (36–38) → **Annex E §২**, **Annex F §৩**

| # | Recipe |
|---|---|
| 36 | `LumaWipe` · `DisplaceOut` · `DollyThrough` · Light Streak |
| 37 | `CameraRig` (depth + DOF) |
| 38 | Motion blur: `<Trail layers={4} lagInFrames={0.4}>` বা `shutterBlur()` |

---

## G. Audio (39–40)

### 39. SFX sync (২–৩f আগে — ব্যতিক্রম নেই)
```tsx
const T = timing(fps);
<Sequence from={Math.max(0, entranceFrame - T.sfxLead)}>
  <Audio src={staticFile("sfx/whoosh_soft_01.wav")} volume={0.34} />
</Sequence>
```

### 40. Music bed + ducking
```tsx
const voRanges = timeline.cues.map((c) => [c.startFrame, c.endFrame] as [number, number]);
<Audio src={staticFile("music/bed_main.wav")}
       volume={(f) => duck(f, hasVO ? 0.18 : 0.30, voRanges, fps, -8)} />
```

---

## ⚠️ GOTCHA তালিকা (যেগুলো সবচেয়ে বেশি ভাঙে)

| সমস্যা | কারণ | সমাধান |
|---|---|---|
| শব্দ জোড়া লেগে যায় | flex `gap` em-এ | **pixel-এ** gap |
| প্রিভিউ ঠিক, রেন্ডার ভুল | ফন্ট লোড হওয়ার আগে ক্যাপচার | `delayRender`/`continueRender` |
| element আগে/পরে দেখা যায় | clamp নেই | `lerp()` ব্যবহার (clamp built-in) |
| রেন্ডার প্রতিবার ভিন্ন | `Math.random()`, `Date.now()` | `hash01()`, `noise1D()` |
| বাংলা কার কেটে যায় | mask/`overflow:hidden` টাইট | উপরে-নিচে ≥0.18em padding |
| grain টেক্সটের নিচে | layer order ভুল | grain/vignette **সবার উপরে** |
| ছবি ঝাপসা | উৎস রেজোলিউশন কম | Annex D §১ মাপ |
| SFX "আউট অফ সিঙ্ক" | ঠিক frame-এ বাজছে | **২–৩f আগে** |
| duplicate SVG id | একাধিক `<defs>` mount | scene prefix বা একবার mount |
| দুটো `id="heroGrad"` | Chrome প্রথমটি ধরে | id অনন্য করো |
| transition "সস্তা" | `linearTiming` | `springTiming` |
| দ্রুত মুভে "চপি" | motion blur নেই | `<Trail>` বা `shutterBlur()` |
| Windows-এ path ভাঙে | backslash | সবসময় `staticFile()` + forward slash |
| ভিডিও atlas error | `<Video>` ব্যবহার | **`<OffthreadVideo>`** |
