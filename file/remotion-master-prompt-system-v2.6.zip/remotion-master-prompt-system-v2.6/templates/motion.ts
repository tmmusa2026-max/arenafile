// motion.ts — AE-grade motion engine (v2.0)
// Adobe After Effects-এর graph editor আচরণ Remotion-এ deterministic ভাবে।
// কোনো component-এ raw bezier/magic number নয় — সব এখান থেকে।
//
// v2.2: প্রয়োজন অনুযায়ী linear বা nonlinear easing বেছে নিন।
//        সব interpolate()-এ extrapolateLeft + extrapolateRight: "clamp"।

import { Easing, interpolate, spring } from "remotion";

/* ──────────────────────────────────────────────────────────────
   1. EASING — AE curve equivalents
   AE-তে যা "Easy Ease"/"Exponential"/"Custom", Remotion-এ তার bezier।
   ────────────────────────────────────────────────────────────── */
export const ease = {
  /** AE "Easy Ease Out" — সব entrance-এর ডিফল্ট (easeOutExpo) */
  out: Easing.bezier(0.16, 1, 0.3, 1),
  /** easeOutQuint — একটু কম আগ্রাসী entrance */
  outSoft: Easing.bezier(0.22, 1, 0.36, 1),
  /** easeOutBack — ছোট overshoot (chip, badge, icon) */
  outBack: Easing.bezier(0.34, 1.56, 0.64, 1),
  /** AE "Easy Ease" দুই পাশে — camera move, Ken Burns, morph */
  inOut: Easing.bezier(0.83, 0, 0.17, 1),
  /** easeInOutCubic — নরম, দীর্ঘ move */
  inOutSoft: Easing.bezier(0.65, 0, 0.35, 1),
  /** easeInExpo — শুধু exit */
  in: Easing.bezier(0.7, 0, 0.84, 0),
  /** whip pan / impact-এর জন্য তীক্ষ্ণ in-out */
  whip: Easing.bezier(0.9, 0, 0.1, 1),
  /** anticipation: সামান্য পেছনে গিয়ে ছুটে যাওয়া */
  anticipate: Easing.bezier(0.68, -0.4, 0.27, 1.4),
} as const;

/* ──────────────────────────────────────────────────────────────
   2. SPRING CONFIGS — physical motion personality
   ────────────────────────────────────────────────────────────── */
export const springs = {
  /** UI pop, শব্দ, ছোট element — দ্রুত settle, হালকা overshoot */
  snappy: { damping: 14, stiffness: 160, mass: 0.6 },
  /** বড় block, panel, image card — ভারী, মসৃণ */
  smooth: { damping: 20, stiffness: 90, mass: 1 },
  /** logo, icon, playful accent — স্পষ্ট bounce */
  bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  /** hero title slam — প্রায় critically damped, খুব দ্রুত */
  slam: { damping: 18, stiffness: 240, mass: 0.5 },
  /** counter/odometer — overshoot ছাড়া, ধীরে settle */
  precise: { damping: 30, stiffness: 60, mass: 1 },
  /** গভীর, cinematic — বড় camera push */
  cinematic: { damping: 26, stiffness: 55, mass: 1.4 },
} as const;

/* ──────────────────────────────────────────────────────────────
   3. TIMING SCALE — সব সময় fps থেকে, magic number নয়
   ব্যবহার: const T = timing(fps); T.entrance → frame সংখ্যা
   ────────────────────────────────────────────────────────────── */
export const timing = (fps: number) => {
  const s = (seconds: number) => Math.round(seconds * fps);
  return {
    s,
    impact: s(0.1),      //  3f @30 — flash, hit
    micro: s(0.2),       //  6f — chip, badge, icon pop
    quick: s(0.33),      // 10f — exit
    entrance: s(0.6),    // 18f — standard entrance
    settle: s(0.83),     // 25f — বড় block entrance
    hold: s(0.6),        // 18f — পড়ার জন্য স্থিরতা
    readHold: s(1.2),    // 36f — দীর্ঘ লাইন পড়ার সময়
    transition: s(0.4),  // 12f — scene transition
    stagger: {
      word: Math.max(2, Math.round(fps * 0.1)),   // 3f @30
      card: Math.max(3, Math.round(fps * 0.14)),  // 4f @30
      block: Math.max(4, Math.round(fps * 0.2)),  // 6f @30
    },
    /** SFX transient visual-এর কত frame আগে লাগবে */
    sfxLead: Math.max(2, Math.round(fps * 0.08)), // 2–3f
  };
};

/* ──────────────────────────────────────────────────────────────
   4. DETERMINISTIC NOISE — AE-এর wiggle() এর বিকল্প
   ⚠️ Math.random() কখনো নয় — render আর preview ভিন্ন হয়ে যাবে।
   ────────────────────────────────────────────────────────────── */

/** 32-bit hash → [0,1); একই input সবসময় একই output */
export const hash01 = (n: number, seed = 1): number => {
  let h = Math.imul(n ^ seed, 2654435761);
  h ^= h >>> 15;
  h = Math.imul(h, 2246822507);
  h ^= h >>> 13;
  return (h >>> 0) / 4294967296;
};

/** মসৃণ 1D value noise — cosine interpolation */
export const noise1D = (x: number, seed = 1): number => {
  const i = Math.floor(x);
  const f = x - i;
  const u = (1 - Math.cos(f * Math.PI)) * 0.5;
  return hash01(i, seed) * (1 - u) + hash01(i + 1, seed) * u;
};

/**
 * AE wiggle(freq, amp) — deterministic।
 * @param frame   বর্তমান frame
 * @param fps     composition fps
 * @param freq    প্রতি সেকেন্ডে কতবার দোলা
 * @param amp     সর্বোচ্চ বিচ্যুতি (px বা deg)
 * @param seed    একাধিক element-এ ভিন্ন seed দিলে phase আলাদা হবে
 */
export const wiggle = (
  frame: number, fps: number, freq = 2, amp = 6, seed = 1,
): number => (noise1D((frame / fps) * freq, seed) - 0.5) * 2 * amp;

/** octave-যুক্ত noise — বেশি organic (হাতে ধরা ক্যামেরা, কাগজের কাঁপুনি) */
export const fbm = (
  frame: number, fps: number, freq = 1.2, amp = 8, seed = 1, octaves = 3,
): number => {
  let v = 0, a = amp, f = freq;
  for (let o = 0; o < octaves; o++) {
    v += (noise1D((frame / fps) * f, seed + o * 97) - 0.5) * 2 * a;
    a *= 0.5; f *= 2.07;
  }
  return v;
};

/* ──────────────────────────────────────────────────────────────
   5. CORE HELPERS
   ────────────────────────────────────────────────────────────── */

const CLAMP = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/**
 * সবসময় clamp করা interpolate — এটাই ব্যবহার করবে, raw interpolate নয়।
 * ২-বিন্দু বা N-বিন্দু দুটোই চলে: lerp(f, [0,10,30], [0, 0.5, 0])
 */
export const lerp = (
  frame: number,
  range: readonly number[],
  output: readonly number[],
  easing = ease.out,
): number =>
  interpolate(frame, range as number[], output as number[], {
    easing, ...CLAMP,
  });

/** 0→1 progress, easing সহ */
export const prog = (
  frame: number, start: number, duration: number, easing = ease.out,
): number => lerp(frame, [start, start + duration], [0, 1], easing);

/**
 * Entrance + Exit একসঙ্গে — প্রতিটি element-এ এটাই।
 * Exit সবসময় entrance-এর চেয়ে দ্রুত (AE rule)।
 */
export const inOutProgress = (
  frame: number,
  opts: {
    start?: number; inDur?: number;
    end: number; outDur?: number;
  },
): { enter: number; exit: number; p: number } => {
  const { start = 0, inDur = 18, end, outDur = 10 } = opts;
  const enter = lerp(frame, [start, start + inDur], [0, 1], ease.out);
  const exit = lerp(frame, [end - outDur, end], [1, 0], ease.in);
  return { enter, exit, p: enter * exit };
};

/**
 * Anticipation — বড় move-এর আগে ছোট বিপরীত move (AE principle #1)।
 * returns: anticipation phase-এ ঋণাত্মক offset, তারপর মূল move
 */
export const anticipate = (
  frame: number, start: number, dur: number,
  travel: number, antAmount = 0.12,
): number => {
  const antDur = Math.round(dur * 0.3);
  if (frame < start) return 0;
  if (frame < start + antDur) {
    return lerp(frame, [start, start + antDur], [0, -travel * antAmount], ease.inOutSoft);
  }
  return lerp(frame, [start + antDur, start + dur], [-travel * antAmount, travel], ease.out);
};

/** idle breathing — ২s+ স্ক্রিনে থাকা element কখনো স্থির নয় */
export const breathe = (frame: number, amount = 0.015, period = 22): number =>
  1 + Math.sin(frame / period) * amount;

export const floatY = (frame: number, amount = 3, period = 30): number =>
  Math.sin(frame / period) * amount;

/** overshoot ছাড়া spring progress — helper wrapper */
export const springP = (
  frame: number, fps: number,
  delay = 0, config: keyof typeof springs = "smooth",
): number => spring({ frame: frame - delay, fps, config: springs[config] });

/* ──────────────────────────────────────────────────────────────
   6. CAMERA RIG — 2.5D depth (AE camera এর CSS equivalent)
   ────────────────────────────────────────────────────────────── */

export type CameraState = { x: number; y: number; z: number; rot: number };

/** z: ধনাত্মক = কাছে। parallax factor স্বয়ংক্রিয় */
export const cameraTransform = (cam: CameraState, layerDepth = 0): string => {
  const par = 1 - layerDepth * 0.35; // depth 0 = foreground, 2 = far bg
  return [
    `translate3d(${(-cam.x * par).toFixed(2)}px, ${(-cam.y * par).toFixed(2)}px, 0)`,
    `scale(${(1 + cam.z * 0.001 * par).toFixed(4)})`,
    `rotate(${(cam.rot * par).toFixed(3)}deg)`,
  ].join(" ");
};

/** layer-depth অনুযায়ী DOF blur — দূরের layer সামান্য নরম */
export const depthBlur = (layerDepth: number, focusDepth = 0, strength = 1.6): string =>
  `blur(${(Math.abs(layerDepth - focusDepth) * strength).toFixed(2)}px)`;

/* ──────────────────────────────────────────────────────────────
   7. SHUTTER / MOTION BLUR helper
   AE shutter angle 180° = exposure অর্ধেক frame।
   দ্রুত move-এ (>30px/frame) Trail বা এই directional blur।
   ────────────────────────────────────────────────────────────── */
export const shutterBlur = (
  velocityPxPerFrame: number, shutterAngle = 180, max = 14,
): string => {
  const px = Math.min(Math.abs(velocityPxPerFrame) * (shutterAngle / 360), max);
  return px < 0.5 ? "none" : `blur(${px.toFixed(2)}px)`;
};

/* ──────────────────────────────────────────────────────────────
   8. BEAT GRID — মিউজিকের সঙ্গে cut মেলাতে
   ────────────────────────────────────────────────────────────── */
export const beatGrid = (fps: number, bpm: number) => {
  const framesPerBeat = (fps * 60) / bpm;
  return {
    framesPerBeat,
    bar: framesPerBeat * 4,
    /** নিকটতম beat-এ snap */
    snap: (frame: number) => Math.round(frame / framesPerBeat) * framesPerBeat,
    /** n-তম beat-এর frame */
    beat: (n: number) => Math.round(n * framesPerBeat),
    /** n-তম bar-এর frame */
    at: (n: number) => Math.round(n * framesPerBeat * 4),
  };
};

/* ──────────────────────────────────────────────────────────────
   9. AUDIO DUCKING — VO/SFX এলে music নামবে (sidechain-এর বিকল্প)
   ব্যবহার: <Audio volume={(f) => duck(f, 0.28, vo Ranges, fps)} />
   ────────────────────────────────────────────────────────────── */
export const duck = (
  frame: number, base: number,
  ranges: Array<[number, number]>, fps: number,
  depthDb = -8,
): number => {
  const atk = Math.round(fps * 0.12);
  const rel = Math.round(fps * 0.35);
  const floorGain = base * Math.pow(10, depthDb / 20);
  let g = base;
  for (const [a, b] of ranges) {
    if (frame >= a - atk && frame <= b + rel) {
      const down = lerp(frame, [a - atk, a], [base, floorGain], ease.inOutSoft);
      const up = lerp(frame, [b, b + rel], [floorGain, base], ease.inOutSoft);
      g = Math.min(g, frame < a ? down : frame > b ? up : floorGain);
    }
  }
  return g;
};

/** ছোট fade-in/out — কোনো audio কখনো hard-cut হবে না (click রোধ) */
export const audioEnvelope = (
  frame: number, durationInFrames: number, fps: number, peak = 1,
): number => {
  const f = Math.round(fps * 0.25);
  return Math.min(
    lerp(frame, [0, f], [0, peak], ease.inOutSoft),
    lerp(frame, [durationInFrames - f, durationInFrames], [peak, 0], ease.inOutSoft),
  );
};

export const motion = {
  ease, springs, timing, lerp, prog, inOutProgress, anticipate,
  breathe, floatY, springP, wiggle, fbm, noise1D, hash01,
  cameraTransform, depthBlur, shutterBlur, beatGrid, duck, audioEnvelope,
} as const;


/** v2.2: independent timing/easing for each property; deterministic frame input. */
export const propertyProgress = (frame: number, start: number, duration: number, curve: (t: number) => number = ease.out): number => {
  if (duration <= 0) return frame < start ? 0 : 1;
  return interpolate(frame, [start, start + duration], [0, 1], { easing: curve, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
};
/** Custom cubic Bézier; x control points must remain in [0,1]. */
export const customCurve = (x1: number, y1: number, x2: number, y2: number) => {
  if (x1 < 0 || x1 > 1 || x2 < 0 || x2 > 1) throw new Error("Bezier x values must be between 0 and 1");
  return Easing.bezier(x1, y1, x2, y2);
};
