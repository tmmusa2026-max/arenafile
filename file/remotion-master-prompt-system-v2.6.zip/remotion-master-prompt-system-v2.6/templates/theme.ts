// theme.ts — প্রতিটি Remotion প্রজেক্টের single source of truth (v2.0 Cinematic)
// কোম্পোনেন্টে কখনো inline color/shadow/easing/radius নয় — সব এখান থেকে।
// Motion curve ও noise: ./motion.ts (আলাদা ফাইল)।

import { ease, springs } from "./motion";

/* ──────────────────────────────────────────────────────────────
   1. COLOR — 60/30/10 + cinematic grade tokens
   User-এর নির্বাচিত scheme (MASTER-PROMPT ধাপ ৩) এখানে বসাও।
   ডিফল্ট: Emerald Noir identity।
   ────────────────────────────────────────────────────────────── */
const palette = {
  bg: "#070A09",          // base 60% — pure black নয়, সামান্য আভা (cinematic)
  bgAlt: "#0C1211",       // secondary surface 30%
  surface: "#111917",     // card/panel
  surfaceHi: "#18231F",   // raised card / hover state
  line: "rgba(255,255,255,0.08)",   // hairline border
  lineStrong: "rgba(255,255,255,0.16)",

  primary: "#10B981",     // HERO — প্রতি ফ্রেমে সর্বোচ্চ ১টি element
  primaryDeep: "#059669", // gradient-এর গাঢ় প্রান্ত
  primaryLite: "#6EE7B7", // specular highlight / light wrap
  accent: "#A3E635",      // 10% accent
  accentDeep: "#65A30D",

  text: "#F0FDF4",        // off-white — pure #FFF নয় (চোখে আরামদায়ক)
  textDim: "#94A3B8",
  textFaint: "rgba(240,253,244,0.45)",

  danger: "#EF4444",      // শুধু error/status
  warn: "#F59E0B",
  success: "#22C55E",     // শুধু status — সবসময় label সহ

  /** grade/bloom-এ ব্যবহৃত — raw hex নয়, এই token */
  glow: "rgba(16,185,129,0.40)",
  glowSoft: "rgba(16,185,129,0.18)",
  halation: "rgba(110,231,183,0.22)", // highlight-এর চারপাশে উষ্ণ ছোঁয়া
  shadowColor: "rgba(0,0,0,0.60)",
} as const;

/* ──────────────────────────────────────────────────────────────
   2. ELEVATION — real depth, "একটা box-shadow" নয়
   প্রতিটি স্তর = ambient (বড়, নরম) + key (দিকনির্দেশক) + contact (ছোট, তীক্ষ্ণ)
   ────────────────────────────────────────────────────────────── */
const elevation = {
  /** flat surface — শুধু hairline */
  e0: "none",
  /** chip, badge, small pill */
  e1: [
    "0 1px 2px rgba(0,0,0,0.30)",
    "0 4px 12px -4px rgba(0,0,0,0.35)",
  ].join(", "),
  /** standard card */
  e2: [
    "0 1px 2px rgba(0,0,0,0.35)",
    "0 8px 24px -8px rgba(0,0,0,0.45)",
    "0 24px 48px -24px rgba(0,0,0,0.55)",
  ].join(", "),
  /** raised panel, image card, UI mockup */
  e3: [
    "0 2px 4px rgba(0,0,0,0.40)",
    "0 16px 40px -12px rgba(0,0,0,0.55)",
    "0 48px 96px -40px rgba(0,0,0,0.65)",
  ].join(", "),
  /** hero element, modal, foreground layer */
  e4: [
    "0 4px 8px rgba(0,0,0,0.45)",
    "0 32px 64px -16px rgba(0,0,0,0.60)",
    "0 80px 140px -60px rgba(0,0,0,0.75)",
  ].join(", "),
  /** inner highlight — কাচ/গ্লস ভাব (উপরের কিনারায় আলো) */
  insetTop: "inset 0 1px 0 rgba(255,255,255,0.10)",
  insetGlass: [
    "inset 0 1px 0 rgba(255,255,255,0.12)",
    "inset 0 -1px 0 rgba(0,0,0,0.25)",
  ].join(", "),
} as const;

/* ──────────────────────────────────────────────────────────────
   3. BLOOM / GLOW — শুধু hero element-এ, প্রতি ফ্রেমে ১টি
   ────────────────────────────────────────────────────────────── */
const bloom = {
  /** hero card/shape-এর চারপাশে */
  hero: `0 0 40px ${palette.glowSoft}, 0 0 100px ${palette.glowSoft}, 0 0 180px rgba(16,185,129,0.10)`,
  /** hero টেক্সটে (textShadow) */
  heroText: `0 0 24px ${palette.glowSoft}, 0 0 60px rgba(16,185,129,0.14)`,
  /** সংযত — secondary accent */
  subtle: `0 0 24px rgba(16,185,129,0.14)`,
  /** icon drop-shadow (filter) */
  iconFilter: `drop-shadow(0 0 12px ${palette.glowSoft}) drop-shadow(0 2px 6px rgba(0,0,0,0.5))`,
} as const;

/* ──────────────────────────────────────────────────────────────
   4. GRADIENT — ফ্ল্যাট fill নিষিদ্ধ; সব surface-এ সূক্ষ্ম gradient
   ────────────────────────────────────────────────────────────── */
const gradients = {
  surface: `linear-gradient(160deg, ${palette.surfaceHi} 0%, ${palette.surface} 58%, ${palette.bgAlt} 100%)`,
  hero: `linear-gradient(135deg, ${palette.primaryLite} 0%, ${palette.primary} 45%, ${palette.primaryDeep} 100%)`,
  accent: `linear-gradient(135deg, ${palette.accent} 0%, ${palette.accentDeep} 100%)`,
  /** টেক্সটে background-clip করার জন্য */
  textSheen: `linear-gradient(100deg, ${palette.text} 0%, ${palette.text} 38%, ${palette.primaryLite} 50%, ${palette.text} 62%, ${palette.text} 100%)`,
  /** ছবির উপর scrim — টেক্সট পড়ার contrast */
  scrimBottom: `linear-gradient(0deg, rgba(6,16,11,0.92) 0%, rgba(6,16,11,0.55) 32%, transparent 68%)`,
  scrimSide: `linear-gradient(90deg, rgba(6,16,11,0.90) 0%, rgba(6,16,11,0.45) 38%, transparent 72%)`,
  /** cinematic bar — উপরে/নিচে হালকা গাঢ় */
  filmBars: `linear-gradient(180deg, rgba(0,0,0,0.28), transparent 18%, transparent 82%, rgba(0,0,0,0.34))`,
} as const;

/* ──────────────────────────────────────────────────────────────
   5. TYPOGRAPHY — সর্বোচ্চ ২টি প্রধান family
   বাংলা: lineHeight 1.25–1.4, letterSpacing 0, word-break: keep-all
   ────────────────────────────────────────────────────────────── */
const fonts = {
  /** বাংলা+EN hero display */
  display: `"Anek Bangla", "Hind Siliguri", "Noto Sans Bengali", system-ui, sans-serif`,
  /** body/label */
  body: `"Hind Siliguri", "Noto Sans Bengali", "Anek Bangla", system-ui, sans-serif`,
  /** সংখ্যা/কোড (Latin only) */
  mono: `"JetBrains Mono", "Geist Mono", ui-monospace, monospace`,
} as const;

const textStyles = {
  /** hero slam — landscape 100–160px, reels 80–140px */
  h1: {
    fontFamily: fonts.display, fontWeight: 800, fontSize: 128,
    lineHeight: 1.26, letterSpacing: 0, wordBreak: "keep-all" as const,
  },
  h2: {
    fontFamily: fonts.display, fontWeight: 700, fontSize: 68,
    lineHeight: 1.3, letterSpacing: 0, wordBreak: "keep-all" as const,
  },
  h3: {
    fontFamily: fonts.display, fontWeight: 700, fontSize: 44,
    lineHeight: 1.34, letterSpacing: 0, wordBreak: "keep-all" as const,
  },
  eyebrow: {
    fontFamily: fonts.body, fontWeight: 600, fontSize: 26,
    lineHeight: 1.4, letterSpacing: 0, // EN-only হলে 0.4 চলবে
  },
  label: { fontFamily: fonts.body, fontWeight: 500, fontSize: 28, lineHeight: 1.45 },
  chip: { fontFamily: fonts.body, fontWeight: 600, fontSize: 20, lineHeight: 1.3 },
  bigNumber: {
    fontFamily: fonts.mono, fontWeight: 700, fontSize: 96,
    fontVariantNumeric: "tabular-nums" as const, letterSpacing: "-0.02em",
  },
  uiText: { fontFamily: fonts.body, fontWeight: 500, fontSize: 18, lineHeight: 1.4 },
  caption: { fontFamily: fonts.body, fontWeight: 500, fontSize: 22, lineHeight: 1.45 },
} as const;

/* ──────────────────────────────────────────────────────────────
   6. SPACING / RADII — pixel-এ (em নয়; বড় টেক্সটে em gap ≈ শূন্য)
   ────────────────────────────────────────────────────────────── */
const space = { xs: 8, sm: 14, md: 24, lg: 40, xl: 64, xxl: 96, gutter: 120 } as const;
const radii = { sm: 10, md: 18, lg: 28, xl: 40, xxl: 56, pill: 999 } as const;

/* ──────────────────────────────────────────────────────────────
   7. GRADE — post stack-এর সংখ্যা (Annex E)
   dark theme-এর মান; light theme-এ কমাও (নোট দেখো)
   ────────────────────────────────────────────────────────────── */
const grade = {
  /** hero color soft-light overlay — dark 0.16–0.24, light 0.08–0.14 */
  tintOpacity: 0.06,
  tintBlend: "soft-light" as const,
  /** lift/gamma/gain সদৃশ — CSS filter দিয়ে */
  filmFilter: "saturate(1.06) contrast(1.07) brightness(1.01)",
  /** shadow-এ ঠান্ডা, highlight-এ উষ্ণ (split tone) */
  splitToneShadow: "rgba(12,42,66,0.22)",
  splitToneHighlight: "rgba(255,221,170,0.10)",
  vignette: "radial-gradient(ellipse 78% 72% at 50% 48%, transparent 52%, rgba(0,0,0,0.30) 100%)",
  grainOpacity: 0.048,
  grainBlend: "overlay" as const,   // light theme-এ "multiply"
  chromaticPx: 1.2,                 // শুধু দ্রুত move/impact-এ
  halationOpacity: 0.09,
} as const;

/* ──────────────────────────────────────────────────────────────
   8. LAYOUT — safe zone, grid
   ────────────────────────────────────────────────────────────── */
const layout = {
  landscape: { w: 1920, h: 1080, safeX: 140, safeY: 100, columns: 12 },
  reel: { w: 1080, h: 1920, safeX: 90, safeY: 260, columns: 6 }, // 9:16 UI safe zone
  maxTextWidth: 0.62,  // frame width-এর অনুপাত — এর বেশি চওড়া লাইন নয়
} as const;

export const theme = {
  colors: palette,
  gradients,
  elevation,
  bloom,
  fonts,
  textStyles,
  space,
  radii,
  grade,
  layout,
  ease,      // motion.ts থেকে re-export — component-এ একটাই import
  spring: springs,
} as const;

export type Theme = typeof theme;
export { ease, springs };
