# Project Structure Template (v2.0)

```
project/
├─ src/
│  ├─ index.ts                 # registerRoot(RemotionRoot)
│  ├─ Root.tsx                 # <Composition id="Main" .../>
│  ├─ theme.ts                 # templates/theme.ts থেকে (রং/gradient/elevation/bloom/type/grade)
│  ├─ motion.ts                # templates/motion.ts থেকে (easing/spring/timing/noise/camera/duck)
│  ├─ fonts.ts                 # offline font loading + delayRender/continueRender
│  ├─ data/
│  │  ├─ timeline.ts           # SRT→frame map, scene boundaries, durationInFrames, beat grid
│  │  └─ tutorialState.ts      # tutorial steps (Annex G §3)
│  ├─ scenes/
│  │  ├─ Scene00_Intro.tsx     # ← Annex K signature intro (বাধ্যতামূলক)
│  │  ├─ Scene01_Hook.tsx
│  │  ├─ Scene02_Context.tsx
│  │  ├─ ...
│  │  └─ Scene99_Outro.tsx     # ← bookend (ইন্ট্রোর শান্ত প্রতিধ্বনি)
│  └─ components/
│     ├─ text/                 # WordCascade, LineMaskRise, DepthExtrude, LightWipe (Annex B)
│     ├─ icons/                # inline SVG icon path (Annex C)
│     ├─ svg/                  # SvgDefs, DrawPath, blobPath, PremiumIcon (Annex L)
│     ├─ ui/                   # GlassCard, BrowserMockup, chart, ProgressRing (Annex H §E)
│     ├─ photo/                # PremiumPhoto, KenBurns, ParallaxStack (Annex D §5)
│     ├─ tutorial/             # Cursor, ClickRipple, StepChip, HighlightBox (Annex G)
│     ├─ transitions/          # LumaWipe, DisplaceOut, DollyThrough (Annex E §2)
│     ├─ camera/               # CameraRig (Annex F §3)
│     └─ post/                 # BgMesh, PostStack (৯ স্তর — Annex E §4)
├─ public/
│  ├─ images/                  # সব ছবি (user/AI/stock)
│  ├─ logos/                   # ইউজারের লোগো (আসল ফাইল, বিকৃত নয়)
│  ├─ ui-refs/                 # tutorial screenshot/reference
│  ├─ fonts/                   # offline font (Anek Bangla, Hind Siliguri …) — CDN নয়
│  ├─ sfx/                     # make-audio.mjs থেকে ১৪টি WAV + MIX-REPORT.json
│  ├─ music/                   # bed_main.wav + MIX-REPORT.json
│  └─ voiceover.mp3            # (ঐচ্ছিক)
├─ tools/
│  └─ make-audio.mjs           # SFX + music generator (Annex I)
├─ out/                        # render output (video.mp4, check_*.png)
├─ ASSETS.md                   # প্রতিটি asset-এর source + license + AI prompt (হলে)
├─ README.md                   # Windows PowerShell: install / audio / studio / render / errors
├─ package.json
└─ tsconfig.json
```

## Naming conventions
- Composition ID: `Main` (ইউজার ভিন্ন না বললে)
- Scene files: `Scene00_Intro.tsx` … `Scene99_Outro.tsx` (ক্রম সংখ্যা + ভূমিকা)
- SFX: `public/sfx/<type>_<mood>_01.wav`
- Check frames: `out/check_<frame>.png`

## package.json scripts
```json
{
  "scripts": {
    "audio":  "node tools/make-audio.mjs --out public/sfx --music-out public/music --bpm 84 --mood cinematic",
    "studio": "remotion studio",
    "render": "remotion render src/index.ts Main out/video.mp4 --codec h264 --crf 17",
    "still":  "remotion still src/index.ts Main out/check.png --overwrite"
  }
}
```
entry ফাইলের আসল নাম অনুযায়ী command মিলিয়ে নেবে — **placeholder রাখবে না**।

## Composition config (Root.tsx)
```tsx
<Composition
  id="Main"
  component={Main}
  durationInFrames={timeline.total}   // SRT শেষ timestamp → frame (+ outro padding)
  fps={30}
  width={1920}
  height={1080}
/>
```
- রিল/শর্ট: width 1080, height 1920
- 60fps: ইউজার চাইলে বা খুব দ্রুত মোশনে — সব animation frame-based বলে স্কেল হবে
- `durationInFrames` ↔ scene content মিলবে; শেষে dead air নয়

## Scene timeline প্যাটার্ন (beat-synced)
```ts
// src/data/timeline.ts
import { beatGrid } from "../motion";
const fps = 30, bpm = 84;
const G = beatGrid(fps, bpm);

export const timeline = {
  bpm, fps,
  scenes: [
    { id: "intro",  from: 0,         dur: G.at(1) },          // bar 0–1
    { id: "hook",   from: G.at(1),   dur: G.at(2) - G.at(1) },
    { id: "body1",  from: G.at(2),   dur: G.at(5) - G.at(2) },
    // ...
  ],
  cues: [] as Array<{ startFrame: number; endFrame: number; text: string }>,
  get total() { const l = this.scenes.at(-1)!; return l.from + l.dur; },
};
```
প্রতিটি scene boundary beat-এ পড়ছে — তাই cut স্বয়ংক্রিয়ভাবে মিউজিকের সঙ্গে মিলে যায়।
