# Asset sources and rights

একটি row বা section প্রতি asset। অজানা তথ্য বানাবে না; `Unknown / not verified` লিখে asset ব্যবহার বন্ধ রাখো। License/terms-এর শর্ত বুঝে ব্যবহার ও প্রয়োজনীয় credit নিশ্চিত করো।

## [Asset filename]
- Scene ID ও ব্যবহারের উদ্দেশ্য:
- Project path: `public/images/...`
- Original asset page URL:
- Creator / rights holder:
- License / version ও license URL:
- License বা terms যাচাইয়ের তারিখ:
- Commercial use ও edit অনুমোদন/শর্ত:
- Attribution-এর সঠিক text ও কোথায় দেখানো হবে:
- Modifications / crop:
- ব্যক্তির সম্মতি / property / trademark-এর প্রাসঙ্গিক সীমা:
- বাস্তব ঘটনা হলে subject, location ও date verification source:
- Status: verified / pending / not usable (কারণ):
