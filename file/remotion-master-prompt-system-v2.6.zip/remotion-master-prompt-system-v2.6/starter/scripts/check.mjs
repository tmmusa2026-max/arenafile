import {existsSync, statSync} from 'node:fs';
const files=['public/fonts/NotoSansBengali.ttf','public/fonts/OFL.txt','src/index.ts','src/root.tsx','src/scenes.tsx'];
let ok=true;for(const f of files){const pass=existsSync(f)&&statSync(f).size>0;console.log(`${pass?'OK':'MISSING'} ${f}`);if(!pass)ok=false;}if(!ok)process.exitCode=1;
