# Verification record

2026-10-29, sandbox, Node 20.20.2: npm install, `npm run check` and `npm run typecheck` passed. `npm run font-test` attempted but Chromium could not start: `libnspr4.so` missing. No still, video, glyph shaping, motion, browser playback or visual correctness was verified here. Resolve browser system dependencies in your own environment, run font and sample commands in README, and visually inspect results. Tests are environment-specific.
