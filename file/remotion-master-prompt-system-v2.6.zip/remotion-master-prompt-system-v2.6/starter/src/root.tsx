import React from 'react';
import {Composition} from 'remotion';
import {FontTest, SampleScene} from './scenes';
export const Root: React.FC = () => <>
  <Composition id="FontTest" component={FontTest} durationInFrames={1} fps={30} width={1920} height={1080}/>
  <Composition id="SampleScene" component={SampleScene} durationInFrames={150} fps={30} width={1920} height={1080}/>
</>;
