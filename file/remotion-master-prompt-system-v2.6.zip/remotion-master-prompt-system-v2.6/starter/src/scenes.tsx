import React, {useEffect, useState} from 'react';
import {AbsoluteFill, Easing, interpolate, staticFile, useCurrentFrame, useVideoConfig, delayRender, continueRender, cancelRender} from 'remotion';

// Explicit local font and bounded loading: no silent fallback when fonts fail.
const FontGate: React.FC<React.PropsWithChildren> = ({children}) => {
  const [handle] = useState(() => delayRender('Loading bundled Bengali font', {timeoutInMilliseconds: 30000}));
  useEffect(() => {
    let cancelled = false;
    const face = new FontFace('NotoLocal', `url("${staticFile('fonts/NotoSansBengali.ttf')}")`);
    const timer = setTimeout(() => {if (!cancelled) cancelRender(new Error('Bengali font loading timed out'));}, 25000);
    face.load().then(loaded => {if (!cancelled) {(document.fonts as FontFaceSet & {add: (font: FontFace) => void}).add(loaded); clearTimeout(timer); continueRender(handle);}}).catch(e => {clearTimeout(timer); if (!cancelled) cancelRender(e);});
    return () => {cancelled = true; clearTimeout(timer);};
  }, [handle]);
  return <div style={{fontFamily:'NotoLocal, sans-serif', width:'100%',height:'100%'}}>{children}</div>;
};
const palette = {bg:'#071d1b', text:'#f0faf6', accent:'#5ee0b6', muted:'#b3cdc5'};
const frameStyle: React.CSSProperties={padding:'90px 110px',background:palette.bg,color:palette.text};
export const BanglaText: React.FC<{text:string; size?:number; color?:string}> = ({text,size=72,color=palette.text}) => <div style={{fontFamily:'NotoLocal, sans-serif',fontSize:size,color,lineHeight:1.4,letterSpacing:0,whiteSpace:'pre-wrap',overflowWrap:'break-word'}}>{text}</div>;
export const Caption: React.FC<{text:string}> = ({text}) => <div style={{position:'absolute',left:110,right:110,bottom:85,textAlign:'center'}}><span style={{background:'rgba(0,0,0,.72)',borderRadius:12,padding:'12px 20px',display:'inline-block'}}><BanglaText text={text} size={38}/></span></div>;
// Stable prebuilt SVG: no generated path morph, unique local scene use.
export const QuoteIcon: React.FC = () => <svg viewBox="0 0 200 160" width="260" aria-hidden="true"><path d="M75 28C42 28 25 48 25 73c0 22 15 34 35 34-3 13-13 24-28 31l9 13c33-10 51-36 51-70 0-35-9-53-17-53Zm90 0c-33 0-50 20-50 45 0 22 15 34 35 34-3 13-13 24-28 31l9 13c33-10 51-36 51-70 0-35-9-53-17-53Z" fill={palette.accent} opacity=".65"/></svg>;
export const FontTest: React.FC = () => <FontGate><AbsoluteFill style={frameStyle}><BanglaText text="বাংলা ফন্ট পরীক্ষা — যুক্তাক্ষর ও কারচিহ্ন" size={68}/><div style={{height:48}}/><BanglaText text={'স্বাধীনতা • গণঅভ্যুত্থান • দৃষ্টান্ত • পৃথিবী\nক্ষ ত্র জ্ঞ শ্র র‍্য ক্র র্ক • কিঞ্চিৎ • হৃৎপিণ্ড\nবাংলা ১২৩৪৫৬৭৮৯০ — English 1234567890\nআমি বাংলায় গান গাই। বিশ্বজুড়ে মানুষের গল্প।'} size={49} color={palette.muted}/></AbsoluteFill></FontGate>;
export const SampleScene: React.FC = () => {const frame=useCurrentFrame();const {fps}=useVideoConfig();const t=interpolate(frame,[0,0.7*fps],[0,1],{easing:Easing.bezier(.22,1,.36,1),extrapolateLeft:'clamp',extrapolateRight:'clamp'});return <FontGate><AbsoluteFill style={frameStyle}><div style={{position:'absolute',left:110,top:260,opacity:t,transform:`translateY(${(1-t)*28}px)`}}><BanglaText text="এখানে আপনার গল্পের শিরোনাম" size={70}/><BanglaText text="নমুনা দৃশ্য — প্রকৃত তথ্য নয়" size={47} color={palette.accent}/></div><div style={{position:'absolute',right:220,top:280,opacity:t}}><QuoteIcon/></div><Caption text="এটি টাইমিং ও বাংলা ফন্ট পরীক্ষার নমুনা"/></AbsoluteFill></FontGate>;};
