# বাংলা Remotion starter
নমুনা মাত্র, আপনার কনটেন্ট নয়। Noto Sans Bengali (OFL.txt দেখুন) offline bundled। একটি sample scene ও font card আছে; পূর্ণ ভিডিও বা দৃশ্যমান সঠিকতার গ্যারান্টি নয়। Node 20+ ও Chromium/Remotion প্রয়োজন।

```bash
npm ci
npm run check
npm run typecheck
npm run font-test
npm run sample-still
npm run sample-video
npm run studio
```
`out/font-test.png` ও `out/sample.png` চোখে দেখুন—যুক্তাক্ষর, রেফ/ফলা, clipping, লাইনভাঙা ও মিশ্র টেক্সট যাচাই। sample ভিডিও শুরু থেকে শেষ দেখুন। `FontGate` স্থানীয় font স্পষ্টভাবে load করে failure/timeout রিপোর্ট করে; নির্দিষ্ট পরিবেশে FontFace/delayRender সমস্যা হতে পারে, এমন হলে error জানিয়ে Annex B-এর বিকল্প পরীক্ষা করুন। পরীক্ষাহীন fallback সফল বলে দাবি নয়। Scene-এ প্রকৃত content ও সময় বসান; নমুনার placeholders চূড়ান্ত ভিডিওতে রাখবেন না। SVG বা animation জটিল হলে সহজ verified component, static visual বা অধিকার যাচাইকৃত footage ব্যবহার করুন।
