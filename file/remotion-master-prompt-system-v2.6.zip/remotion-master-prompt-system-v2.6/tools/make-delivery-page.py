#!/usr/bin/env python3
"""Make a standalone delivery HTML page from verified, real outputs; no render/upload."""
import argparse
import html
import shutil
from pathlib import Path
from urllib.parse import urlparse, quote

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--output', required=True, help='Output HTML path')
p.add_argument('--zip-url', default='', help='Actual confirmed HTTPS download page')
p.add_argument('--video', help='Existing rendered MP4 file; copied beside the HTML')
p.add_argument('--video-label', default='ভিডিও প্রিভিউ')
p.add_argument('--status', default='স্ট্যাটাস এখনো নিশ্চিত করা হয়নি।')
a = p.parse_args()
out = Path(a.output)
out.parent.mkdir(parents=True, exist_ok=True)
if a.zip_url:
    parsed = urlparse(a.zip_url)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
        p.error('--zip-url must be an HTTPS URL without credentials')
video_html = '<div class="empty">ভিডিও এখনো রেন্ডার করা হয়নি বা প্রিভিউর জন্য উপলব্ধ নয়। প্রকল্পটি Remotion Studio-তে দেখতে পারেন।</div>'
if a.video:
    video = Path(a.video)
    if not video.is_file() or video.suffix.lower() != '.mp4':
        p.error('--video must be an existing MP4 file')
    dest = out.parent / 'preview-video.mp4'
    if video.resolve() != dest.resolve():
        shutil.copy2(video, dest)
    video_html = f'<video controls playsinline preload="metadata" src="{quote(dest.name)}">আপনার ব্রাউজারে ভিডিও চালানো যাচ্ছে না।</video><p class="hint">{html.escape(a.video_label)}</p>'
if a.zip_url:
    u = html.escape(a.zip_url, quote=True)
    link_html = f'''<label for="download-url">সম্পূর্ণ ডাউনলোড লিংক</label><textarea id="download-url" readonly rows="2" spellcheck="false">{u}</textarea><div class="actions"><button type="button" id="copy">লিংক কপি করুন</button><a class="open" href="{u}" target="_blank" rel="noopener noreferrer">ডাউনলোড পেজ খুলুন ↗</a></div><p class="hint" id="copy-status" aria-live="polite">কপি কাজ না করলে ওপরের লিংকটি নির্বাচন করে নিজে কপি করুন।</p>'''
else:
    link_html = '<div class="empty">GoFile লিংক এখনো পাওয়া যায়নি। আপলোডের অবস্থা চ্যাটে দেখুন।</div>'
page = '''<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ভিডিও প্রজেক্ট ডেলিভারি</title><style>
*{box-sizing:border-box}body{margin:0;background:#f2f5f9;color:#14223b;font:16px/1.6 system-ui,sans-serif}main{max-width:940px;margin:auto;padding:40px 20px 60px}header{margin-bottom:28px}.eyebrow{font-size:13px;color:#5045c5;font-weight:700;letter-spacing:.08em}h1{font-size:clamp(28px,5vw,40px);line-height:1.2;margin:8px 0}h2{font-size:21px;margin:0 0 12px}.muted,.hint{color:#55647a}.card{background:white;border:1px solid #dce4ef;border-radius:18px;padding:24px;margin:16px 0;box-shadow:0 8px 25px #1524450c}.status{background:#eef2ff;border-left:4px solid #635bdb;padding:13px 16px;border-radius:7px;white-space:pre-wrap}video{display:block;width:100%;max-height:540px;background:#111;border-radius:12px}.empty{background:#f5f7fb;border:1px dashed #c4cfdd;padding:22px;border-radius:10px;color:#53647b}label{display:block;font-weight:700;margin-bottom:8px}textarea{display:block;width:100%;resize:vertical;border:1px solid #b9c8dd;border-radius:10px;background:#f8faff;padding:12px;font:15px/1.5 monospace;color:#172d54;overflow-wrap:anywhere}.actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:14px}button,.open{border:0;border-radius:9px;padding:11px 16px;font:inherit;font-weight:700;cursor:pointer}button{background:#5145cd;color:white}.open{background:#edf0ff;color:#4033b1;text-decoration:none}.hint{font-size:14px;margin-bottom:0}a:focus,button:focus,textarea:focus{outline:3px solid #a79fff;outline-offset:2px}</style></head><body><main><header><span class="eyebrow">PROJECT DELIVERY</span><h1>আপনার ভিডিও প্রজেক্ট</h1><p class="muted">প্রিভিউ দেখুন এবং ডাউনলোড লিংক সংগ্রহ করুন।</p></header><section class="card"><h2>কাজের অবস্থা</h2><div class="status">__STATUS__</div></section><section class="card"><h2>ভিডিও প্রিভিউ</h2>__VIDEO__</section><section class="card"><h2>প্রজেক্ট ZIP</h2>__LINK__</section></main><script>
const button=document.getElementById('copy');if(button){button.addEventListener('click',async()=>{const field=document.getElementById('download-url'),msg=document.getElementById('copy-status');try{if(!navigator.clipboard||!window.isSecureContext)throw new Error('clipboard unavailable');await navigator.clipboard.writeText(field.value);msg.textContent='লিংক কপি হয়েছে।';}catch(e){field.focus();field.select();msg.textContent='স্বয়ংক্রিয় কপি সম্ভব হয়নি। নির্বাচিত লিংকটি নিজে কপি করুন।';}})}
</script></body></html>'''
page = page.replace('__STATUS__', html.escape(a.status)).replace('__VIDEO__', video_html).replace('__LINK__', link_html)
out.write_text(page, encoding='utf-8')
print(out)
