#!/usr/bin/env bash
# Upload an already-reviewed ZIP; prints only the confirmed download page.
set -euo pipefail
if [[ $# -ne 1 || ! -f "$1" ]]; then echo 'Usage: bash upload-gofile.sh PATH_TO_ZIP' >&2; exit 2; fi
command -v curl >/dev/null || { echo 'curl is required' >&2; exit 2; }
command -v python3 >/dev/null || { echo 'python3 is required' >&2; exit 2; }
response=$(mktemp)
trap 'rm -f "$response"' EXIT
args=(--silent --show-error --fail --connect-timeout 30 --max-time 1800 -X POST -F "file=@$1" -o "$response")
# Avoid putting the token in the argument list; curl reads the header from stdin.
if [[ -n "${GOFILE_TOKEN:-}" ]]; then
  if [[ "$GOFILE_TOKEN" == *$'\n'* || "$GOFILE_TOKEN" == *$'\r'* ]]; then echo 'Invalid token' >&2; exit 2; fi
  if ! printf 'Authorization: Bearer %s\n' "$GOFILE_TOKEN" | curl "${args[@]}" -H @- https://upload.gofile.io/uploadfile; then echo 'GoFile upload failed (network or HTTP error).' >&2; exit 1; fi
else
  if ! curl "${args[@]}" https://upload.gofile.io/uploadfile; then echo 'GoFile upload failed (network or HTTP error).' >&2; exit 1; fi
fi
python3 - "$response" <<'PY'
import json, sys
from urllib.parse import urlparse
try:
    with open(sys.argv[1], encoding='utf-8') as f: data = json.load(f)
    url = data.get('data', {}).get('downloadPage', '')
    parsed = urlparse(url)
    if data.get('status') != 'ok' or parsed.scheme != 'https' or parsed.hostname not in ('gofile.io', 'www.gofile.io'):
        raise ValueError('API did not return a valid download page')
    print(url)
except (OSError, ValueError, TypeError, AttributeError):
    print('GoFile upload failed: invalid or unsuccessful API response.', file=sys.stderr)
    sys.exit(1)
PY
