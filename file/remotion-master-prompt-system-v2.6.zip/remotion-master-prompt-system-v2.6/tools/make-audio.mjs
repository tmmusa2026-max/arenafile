#!/usr/bin/env node
/**
 * make-audio.mjs — Studio-grade SFX + Music bed generator (v2.0)
 * ───────────────────────────────────────────────────────────────
 * কোনো ডাউনলোড নয়, কোনো লাইসেন্স ঝামেলা নয়, কোনো dependency নয়।
 * বিশুদ্ধ Node.js DSP দিয়ে 48kHz / 16-bit stereo WAV তৈরি করে।
 *
 *   node tools/make-audio.mjs --out public/sfx
 *   node tools/make-audio.mjs --out public/sfx --bpm 90 --key F --bars 32 --mood calm
 *
 * আউটপুট:
 *   public/sfx/*.wav          — ১৪টি SFX (Annex I কিট)
 *   public/music/bed_main.wav — মিউজিক বেড (loop-safe)
 *   public/music/MIX-REPORT.json — peak/RMS/LUFS-approx, QA-এর জন্য
 *
 * সব আউটপুট deterministic — একই আর্গুমেন্টে বিট-বাই-বিট একই ফাইল।
 */

import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const SR = 48000;

/* ═══════════════════ 0. CLI ═══════════════════ */
const argv = process.argv.slice(2);
const arg = (k, d) => {
  const i = argv.indexOf(`--${k}`);
  return i >= 0 && argv[i + 1] ? argv[i + 1] : d;
};
const OUT = arg("out", "public/sfx");
const MUSIC_OUT = arg("music-out", OUT.replace(/sfx\/?$/, "music"));
const BPM = Number(arg("bpm", 84));
const KEY = arg("key", "D");
const BARS = Number(arg("bars", 24));
const MOOD = arg("mood", "cinematic"); // cinematic | calm | tech | uplifting
const NO_MUSIC = argv.includes("--no-music");

/* ═══════════════════ 1. Deterministic PRNG ═══════════════════ */
const mulberry32 = (a) => () => {
  a |= 0; a = (a + 0x6d2b79f5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

/* ═══════════════════ 2. Buffer helpers ═══════════════════ */
const buf = (sec) => new Float64Array(Math.max(1, Math.round(sec * SR)));
const secs = (b) => b.length / SR;

const add = (dst, src, atSec = 0, gain = 1) => {
  const o = Math.round(atSec * SR);
  for (let i = 0; i < src.length; i++) {
    const j = o + i;
    if (j >= 0 && j < dst.length) dst[j] += src[i] * gain;
  }
  return dst;
};

const mulGain = (b, g) => { for (let i = 0; i < b.length; i++) b[i] *= g; return b; };

/* ═══════════════════ 3. Envelopes ═══════════════════ */
/** exponential-ish ADSR; a/d/r সেকেন্ডে */
const adsr = (b, { a = 0.002, d = 0.05, s = 0.0, r = 0.08, curve = 2.2 } = {}) => {
  const n = b.length, A = a * SR, D = d * SR, R = r * SR;
  const S = Math.max(0, n - A - D - R);
  for (let i = 0; i < n; i++) {
    let g;
    if (i < A) g = Math.pow(i / Math.max(1, A), 1 / curve);
    else if (i < A + D) g = 1 + (s - 1) * Math.pow((i - A) / Math.max(1, D), 1 / curve);
    else if (i < A + D + S) g = s;
    else g = s * Math.pow(Math.max(0, 1 - (i - A - D - S) / Math.max(1, R)), curve);
    b[i] *= g;
  }
  return b;
};

/** পুরো buffer জুড়ে percussive decay */
const decay = (b, tau = 0.08, attack = 0.0015) => {
  const A = Math.max(1, attack * SR);
  for (let i = 0; i < b.length; i++) {
    const at = i < A ? i / A : 1;
    b[i] *= at * Math.exp(-i / SR / tau);
  }
  return b;
};

/** audio কখনো hard-cut নয় — click রোধ */
const deClick = (b, ms = 4) => {
  const n = Math.max(2, Math.round((ms / 1000) * SR));
  for (let i = 0; i < n && i < b.length; i++) {
    const g = i / n;
    b[i] *= g;
    b[b.length - 1 - i] *= g;
  }
  return b;
};

/* ═══════════════════ 4. Oscillators & noise ═══════════════════ */
const osc = (b, freqFn, shape = "sine", phase0 = 0) => {
  let ph = phase0;
  for (let i = 0; i < b.length; i++) {
    const t = i / SR;
    const f = typeof freqFn === "function" ? freqFn(t, i / b.length) : freqFn;
    ph += (2 * Math.PI * f) / SR;
    const p = ph % (2 * Math.PI);
    let v;
    switch (shape) {
      case "tri": v = (2 / Math.PI) * Math.asin(Math.sin(p)); break;
      case "saw": v = 2 * (p / (2 * Math.PI)) - 1; break;
      case "sqr": v = Math.sin(p) >= 0 ? 1 : -1; break;
      // band-limited-ish saw: কম harmonic, aliasing কম
      case "softsaw": v = Math.sin(p) * 0.7 + Math.sin(2 * p) * 0.22 + Math.sin(3 * p) * 0.1; break;
      default: v = Math.sin(p);
    }
    b[i] += v;
  }
  return b;
};

const noise = (b, seed = 7, color = "white") => {
  const rnd = mulberry32(seed);
  let last = 0, b0 = 0, b1 = 0, b2 = 0;
  for (let i = 0; i < b.length; i++) {
    const w = rnd() * 2 - 1;
    let v = w;
    if (color === "pink") {
      b0 = 0.99765 * b0 + w * 0.0990460;
      b1 = 0.96300 * b1 + w * 0.2965164;
      b2 = 0.57000 * b2 + w * 1.0526913;
      v = (b0 + b1 + b2 + w * 0.1848) * 0.22;
    } else if (color === "brown") {
      last = (last + 0.02 * w) / 1.02; v = last * 3.5;
    }
    b[i] += v;
  }
  return b;
};

/* ═══════════════════ 5. Biquad filters (RBJ cookbook) ═══════════════════ */
const biquad = (b, type, f0, Q = 0.707, gainDb = 0) => {
  const w0 = (2 * Math.PI * Math.min(f0, SR * 0.45)) / SR;
  const cw = Math.cos(w0), sw = Math.sin(w0);
  const alpha = sw / (2 * Q);
  const A = Math.pow(10, gainDb / 40);
  let b0, b1, b2, a0, a1, a2;
  switch (type) {
    case "lp": b0 = (1 - cw) / 2; b1 = 1 - cw; b2 = b0; a0 = 1 + alpha; a1 = -2 * cw; a2 = 1 - alpha; break;
    case "hp": b0 = (1 + cw) / 2; b1 = -(1 + cw); b2 = b0; a0 = 1 + alpha; a1 = -2 * cw; a2 = 1 - alpha; break;
    case "bp": b0 = alpha; b1 = 0; b2 = -alpha; a0 = 1 + alpha; a1 = -2 * cw; a2 = 1 - alpha; break;
    case "peak": b0 = 1 + alpha * A; b1 = -2 * cw; b2 = 1 - alpha * A; a0 = 1 + alpha / A; a1 = -2 * cw; a2 = 1 - alpha / A; break;
    case "ls": {
      const s = 2 * Math.sqrt(A) * alpha;
      b0 = A * ((A + 1) - (A - 1) * cw + s); b1 = 2 * A * ((A - 1) - (A + 1) * cw); b2 = A * ((A + 1) - (A - 1) * cw - s);
      a0 = (A + 1) + (A - 1) * cw + s; a1 = -2 * ((A - 1) + (A + 1) * cw); a2 = (A + 1) + (A - 1) * cw - s; break;
    }
    case "hs": {
      const s = 2 * Math.sqrt(A) * alpha;
      b0 = A * ((A + 1) + (A - 1) * cw + s); b1 = -2 * A * ((A - 1) + (A + 1) * cw); b2 = A * ((A + 1) + (A - 1) * cw - s);
      a0 = (A + 1) - (A - 1) * cw + s; a1 = 2 * ((A - 1) - (A + 1) * cw); a2 = (A + 1) - (A - 1) * cw - s; break;
    }
    default: return b;
  }
  const n0 = b0 / a0, n1 = b1 / a0, n2 = b2 / a0, d1 = a1 / a0, d2 = a2 / a0;
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  for (let i = 0; i < b.length; i++) {
    const x = b[i];
    const y = n0 * x + n1 * x1 + n2 * x2 - d1 * y1 - d2 * y2;
    x2 = x1; x1 = x; y2 = y1; y1 = y;
    b[i] = y;
  }
  return b;
};

/** সময়-পরিবর্তনশীল lowpass — sweep/whoosh-এর জন্য */
const sweepLP = (b, fStart, fEnd, Q = 0.9) => {
  let y1 = 0, y2 = 0, x1 = 0, x2 = 0;
  for (let i = 0; i < b.length; i++) {
    const t = i / b.length;
    const f0 = Math.min(fStart * Math.pow(fEnd / fStart, t), SR * 0.45);
    const w0 = (2 * Math.PI * f0) / SR, cw = Math.cos(w0), sw = Math.sin(w0);
    const al = sw / (2 * Q);
    const b0 = (1 - cw) / 2, b1 = 1 - cw, b2 = b0, a0 = 1 + al, a1 = -2 * cw, a2 = 1 - al;
    const x = b[i];
    const y = (b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2) / a0;
    x2 = x1; x1 = x; y2 = y1; y1 = y;
    b[i] = y;
  }
  return b;
};

/* ═══════════════════ 6. Space: Schroeder reverb ═══════════════════ */
const reverb = (b, { mix = 0.18, size = 0.5, damp = 0.35 } = {}) => {
  const combs = [1116, 1188, 1277, 1356].map((d) => Math.round(d * (0.6 + size)));
  const allp = [556, 441].map((d) => Math.round(d * (0.6 + size)));
  const wet = new Float64Array(b.length);
  for (const d of combs) {
    const line = new Float64Array(d);
    let idx = 0, lp = 0;
    const fb = 0.78 + size * 0.14;
    for (let i = 0; i < b.length; i++) {
      const out = line[idx];
      lp = out * (1 - damp) + lp * damp;
      line[idx] = b[i] + lp * fb;
      idx = (idx + 1) % d;
      wet[i] += out * 0.25;
    }
  }
  for (const d of allp) {
    const line = new Float64Array(d);
    let idx = 0;
    for (let i = 0; i < wet.length; i++) {
      const bufOut = line[idx];
      const out = -wet[i] + bufOut;
      line[idx] = wet[i] + bufOut * 0.5;
      idx = (idx + 1) % d;
      wet[i] = out;
    }
  }
  for (let i = 0; i < b.length; i++) b[i] = b[i] * (1 - mix) + wet[i] * mix;
  return b;
};

/* ═══════════════════ 7. Dynamics & metering ═══════════════════ */
/**
 * Feed-forward soft-knee কম্প্রেসর (envelope follower + makeup gain)।
 * মিউজিক বেডের জন্য অপরিহার্য: জেনারেট করা arrangement-এ পারকাশন
 * উচ্চ শিখর তৈরি করে আর বারের ফাঁকে স্তর ২০+ dB নেমে যায়। সেই বেড
 * ছোট ভিডিওতে বসালে ফাঁকগুলো "নীরবতা" হিসেবে শোনা যায়।
 */
const compress = (b, {
  thresholdDb = -24, ratio = 4, attack = 0.01,
  release = 0.25, knee = 6, makeupDb = 0,
} = {}) => {
  const atkC = Math.exp(-1 / Math.max(1, attack * SR));
  const relC = Math.exp(-1 / Math.max(1, release * SR));
  const mk = Math.pow(10, makeupDb / 20);
  let env = 0;
  for (let i = 0; i < b.length; i++) {
    const x = Math.abs(b[i]);
    env = (x > env ? atkC : relC) * env + (1 - (x > env ? atkC : relC)) * x;
    const edb = env > 1e-9 ? 20 * Math.log10(env) : -120;
    const over = edb - thresholdDb;
    let gr = 0;                                   // gain reduction, dB
    if (over > knee / 2) gr = over * (1 - 1 / ratio);
    else if (over > -knee / 2) {
      const t = over + knee / 2;
      gr = (1 - 1 / ratio) * t * t / (2 * knee);  // soft knee
    }
    b[i] *= Math.pow(10, -gr / 20) * mk;
  }
  return b;
};

const softClip = (b, drive = 1) => {
  for (let i = 0; i < b.length; i++) b[i] = Math.tanh(b[i] * drive) / Math.tanh(drive);
  return b;
};

const peakOf = (b) => { let p = 0; for (const v of b) p = Math.max(p, Math.abs(v)); return p; };
const rmsOf = (b) => { let s = 0; for (const v of b) s += v * v; return Math.sqrt(s / b.length); };
const db = (x) => (x <= 1e-9 ? -Infinity : 20 * Math.log10(x));

/** true-peak ceiling সহ normalize */
const normalize = (b, targetDb = -1.0) => {
  const p = peakOf(b);
  if (p < 1e-9) return b;
  return mulGain(b, Math.pow(10, targetDb / 20) / p);
};

/** K-weighting আনুমানিক LUFS (integrated) — QA রিপোর্টের জন্য */
const lufsApprox = (b) => {
  const c = Float64Array.from(b);
  biquad(c, "hs", 1500, 0.707, 4);   // head shelf
  biquad(c, "hp", 38, 0.5);           // RLB
  const blockN = Math.round(0.4 * SR), hop = Math.round(0.1 * SR);
  const loud = [];
  for (let i = 0; i + blockN <= c.length; i += hop) {
    let s = 0;
    for (let j = i; j < i + blockN; j++) s += c[j] * c[j];
    const ms = s / blockN;
    if (ms > 1e-12) loud.push(-0.691 + 10 * Math.log10(ms));
  }
  if (!loud.length) return -Infinity;
  const gated = loud.filter((l) => l > -70);
  if (!gated.length) return -Infinity;
  const rel = gated.reduce((a, x) => a + x, 0) / gated.length - 10;
  const fin = gated.filter((l) => l > rel);
  const use = fin.length ? fin : gated;
  return use.reduce((a, x) => a + x, 0) / use.length;
};

/* ═══════════════════ 8. Stereo & WAV writer ═══════════════════ */
/** Haas-মুক্ত নিরাপদ width (mono-compatible) */
const widen = (b, amount = 0.25, seed = 3) => {
  const L = Float64Array.from(b), R = Float64Array.from(b);
  biquad(L, "peak", 2800, 1.0, amount * 2.2);
  biquad(R, "peak", 2200, 1.0, -amount * 2.2);
  const d = Math.round(SR * 0.00035 * amount); // < 0.5ms — phase-safe
  const Rd = new Float64Array(R.length);
  for (let i = 0; i < R.length; i++) Rd[i] = R[Math.max(0, i - d)];
  return [L, Rd];
};

const writeWav = (path, chans) => {
  const n = chans[0].length, ch = chans.length;
  const data = Buffer.alloc(n * ch * 2);
  for (let i = 0; i < n; i++) {
    for (let c = 0; c < ch; c++) {
      let v = Math.max(-1, Math.min(1, chans[c][i]));
      data.writeInt16LE(Math.round(v * 32767), (i * ch + c) * 2);
    }
  }
  const h = Buffer.alloc(44);
  h.write("RIFF", 0); h.writeUInt32LE(36 + data.length, 4); h.write("WAVE", 8);
  h.write("fmt ", 12); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20);
  h.writeUInt16LE(ch, 22); h.writeUInt32LE(SR, 24);
  h.writeUInt32LE(SR * ch * 2, 28); h.writeUInt16LE(ch * 2, 32); h.writeUInt16LE(16, 34);
  h.write("data", 36); h.writeUInt32LE(data.length, 40);
  writeFileSync(path, Buffer.concat([h, data]));
};

/* ═══════════════════ 9. SFX KIT (১৪টি) ═══════════════════ */
const SFX = {
  /** টেক্সট/শিরোনাম এন্ট্রি, সিন ট্রানজিশন */
  "whoosh_soft_01": () => {
    const b = buf(0.62);
    noise(b, 11, "pink");
    sweepLP(b, 420, 5200, 0.8);
    biquad(b, "hp", 260, 0.7);
    adsr(b, { a: 0.14, d: 0.1, s: 0.55, r: 0.3, curve: 1.8 });
    return reverb(b, { mix: 0.14, size: 0.4, damp: 0.5 });
  },
  /** বিপরীতমুখী — সিনের শেষে / pull-out */
  "whoosh_reverse_01": () => {
    const b = buf(0.6);
    noise(b, 23, "pink");
    sweepLP(b, 5200, 420, 0.8);
    biquad(b, "hp", 240, 0.7);
    adsr(b, { a: 0.3, d: 0.1, s: 0.6, r: 0.14, curve: 1.6 });
    return reverb(b, { mix: 0.16, size: 0.45, damp: 0.5 });
  },
  /** কার্ড/UI reveal */
  "pop_soft_01": () => {
    const b = buf(0.2);
    osc(b, (t) => 760 * Math.exp(-t * 16) + 190, "sine");
    const n = buf(0.06); noise(n, 31, "white"); biquad(n, "bp", 2400, 1.4); mulGain(n, 0.18);
    add(b, n, 0);
    decay(b, 0.045, 0.0015);
    biquad(b, "lp", 6500, 0.7);
    return reverb(b, { mix: 0.09, size: 0.25, damp: 0.6 });
  },
  /** বাটন, টিক, চেকমার্ক */
  "click_crisp_01": () => {
    const b = buf(0.1);
    noise(b, 47, "white");
    biquad(b, "hp", 1900, 0.9);
    biquad(b, "peak", 4200, 1.6, 5);
    decay(b, 0.012, 0.0004);
    const body = buf(0.1);
    osc(body, (t) => 1500 * Math.exp(-t * 60) + 420, "sine");
    decay(body, 0.015, 0.0004); mulGain(body, 0.4);
    add(b, body, 0);
    return reverb(b, { mix: 0.06, size: 0.2, damp: 0.7 });
  },
  /** toggle/switch — একটু ভারী click */
  "latch_click_01": () => {
    const b = buf(0.14);
    noise(b, 53, "white"); biquad(b, "bp", 1500, 1.1); decay(b, 0.016, 0.0005);
    const t2 = buf(0.09); noise(t2, 59, "white"); biquad(t2, "bp", 2600, 1.4);
    decay(t2, 0.01, 0.0004); mulGain(t2, 0.55);
    add(b, t2, 0.035);
    return reverb(b, { mix: 0.08, size: 0.25, damp: 0.6 });
  },
  /** লোগো reveal */
  "chime_pluck_01": () => {
    const b = buf(1.1);
    const f = 880;
    [[1, 1], [2.01, 0.42], [3.02, 0.2], [4.98, 0.1], [6.4, 0.05]].forEach(([m, g]) => {
      const p = buf(1.1); osc(p, f * m, "sine");
      decay(p, 0.34 / Math.sqrt(m), 0.002); add(b, p, 0, g);
    });
    biquad(b, "lp", 9000, 0.7);
    return reverb(b, { mix: 0.26, size: 0.62, damp: 0.3 });
  },
  /** হুক/মূল বার্তা — সংযত */
  "thud_soft_01": () => {
    const b = buf(0.4);
    osc(b, (t) => 92 * Math.exp(-t * 11) + 48, "sine");
    decay(b, 0.1, 0.002);
    const n = buf(0.08); noise(n, 71, "brown"); biquad(n, "lp", 600); mulGain(n, 0.22);
    add(b, n, 0);
    biquad(b, "lp", 1600, 0.6);
    return b;
  },
  /** কাউন্টার */
  "tick_soft_01": () => {
    const b = buf(0.06);
    noise(b, 83, "white"); biquad(b, "bp", 3200, 2.0);
    decay(b, 0.007, 0.0003);
    return mulGain(b, 0.85);
  },
  /** হুক/শেষের আগে tension */
  "riser_soft_01": () => {
    const b = buf(1.8);
    noise(b, 97, "pink");
    sweepLP(b, 500, 7800, 1.1);
    biquad(b, "hp", 300, 0.7);
    const tone = buf(1.8);
    osc(tone, (t) => 220 * Math.pow(2, t / 1.8 * 1.6), "softsaw");
    biquad(tone, "lp", 4200, 0.8); mulGain(tone, 0.14);
    add(b, tone, 0);
    for (let i = 0; i < b.length; i++) b[i] *= Math.pow(i / b.length, 1.9);
    return reverb(b, { mix: 0.2, size: 0.6, damp: 0.4 });
  },
  /** cinematic impact — শুধু ইন্ট্রো/বড় reveal-এ (সর্বোচ্চ ২বার) */
  "impact_cine_01": () => {
    const b = buf(2.2);
    const sub = buf(2.2);
    osc(sub, (t) => 62 * Math.exp(-t * 2.4) + 34, "sine");
    decay(sub, 0.55, 0.003); add(b, sub, 0, 1);
    const crack = buf(0.35); noise(crack, 101, "white");
    biquad(crack, "hp", 900, 0.8); decay(crack, 0.05, 0.0008);
    add(b, crack, 0, 0.3);
    const tail = buf(2.0); noise(tail, 103, "pink");
    sweepLP(tail, 3000, 300, 0.7); decay(tail, 0.6, 0.01);
    add(b, tail, 0.02, 0.22);
    biquad(b, "lp", 7000, 0.7);
    return reverb(b, { mix: 0.3, size: 0.8, damp: 0.25 });
  },
  /** bass drop — ইন্ট্রো থেকে বডিতে যাওয়ার মুহূর্ত */
  "sub_drop_01": () => {
    const b = buf(1.4);
    osc(b, (t) => 140 * Math.exp(-t * 3.2) + 32, "sine");
    decay(b, 0.42, 0.004);
    biquad(b, "lp", 220, 0.7);
    return mulGain(b, 0.95);
  },
  /** শেষের glow / highlight tail */
  "shimmer_tail_01": () => {
    const b = buf(1.6);
    [1319, 1760, 2093, 2637].forEach((f, i) => {
      const p = buf(1.6); osc(p, f, "sine");
      decay(p, 0.5 - i * 0.07, 0.05);
      add(b, p, i * 0.045, 0.3 - i * 0.05);
    });
    biquad(b, "hp", 900, 0.7);
    return reverb(b, { mix: 0.38, size: 0.85, damp: 0.2 });
  },
  /** glass/UI tap — প্রিমিয়াম micro-interaction */
  "glass_tap_01": () => {
    const b = buf(0.5);
    [2093, 3136, 4186].forEach((f, i) => {
      const p = buf(0.5); osc(p, f, "sine");
      decay(p, 0.09 - i * 0.02, 0.0008); add(b, p, 0, 0.5 - i * 0.13);
    });
    biquad(b, "hp", 1400, 0.7);
    return reverb(b, { mix: 0.22, size: 0.5, damp: 0.35 });
  },
  /** chapter/section change */
  "boom_tail_01": () => {
    const b = buf(2.6);
    osc(b, (t) => 55 * Math.exp(-t * 1.8) + 30, "sine");
    decay(b, 0.8, 0.006);
    const air = buf(2.4); noise(air, 107, "pink");
    sweepLP(air, 1800, 200, 0.6); decay(air, 0.9, 0.05);
    add(b, air, 0.03, 0.16);
    return reverb(b, { mix: 0.34, size: 0.9, damp: 0.22 });
  },
};

/** SFX লেভেল টার্গেট — পুরো কিট একই ধারায় (Annex I §৪ level match) */
const SFX_PEAK_DB = {
  whoosh_soft_01: -9, whoosh_reverse_01: -9, pop_soft_01: -8,
  click_crisp_01: -10, latch_click_01: -10, chime_pluck_01: -8,
  thud_soft_01: -7, tick_soft_01: -14, riser_soft_01: -8,
  impact_cine_01: -3, sub_drop_01: -4, shimmer_tail_01: -11,
  glass_tap_01: -11, boom_tail_01: -4,
};

/* ═══════════════════ 10. MUSIC BED ═══════════════════ */
const NOTE = { C: 0, "C#": 1, D: 2, "D#": 3, E: 4, F: 5, "F#": 6, G: 7, "G#": 8, A: 9, "A#": 10, B: 11 };
const hz = (semi) => 440 * Math.pow(2, (semi - 9) / 12);

const MOODS = {
  cinematic: { prog: [0, -3, -5, -7], scale: [0, 2, 3, 5, 7, 8, 10], padLp: 2200, arpGain: 0.16, percGain: 0.22, subGain: 0.5 },
  calm:      { prog: [0, 5, -4, -2], scale: [0, 2, 4, 5, 7, 9, 11], padLp: 1500, arpGain: 0.10, percGain: 0.08, subGain: 0.38 },
  tech:      { prog: [0, -5, -3, -7], scale: [0, 2, 3, 5, 7, 8, 10], padLp: 2600, arpGain: 0.22, percGain: 0.34, subGain: 0.55 },
  uplifting: { prog: [0, 7, 5, 2],    scale: [0, 2, 4, 7, 9],        padLp: 2400, arpGain: 0.2,  percGain: 0.26, subGain: 0.45 },
};

const makeMusic = () => {
  const M = MOODS[MOOD] ?? MOODS.cinematic;
  const root = (NOTE[KEY] ?? 2) + 48; // octave 3-ish
  const spb = 60 / BPM, bar = spb * 4;
  const total = bar * BARS + 2.5;
  const mix = buf(total);
  const rnd = mulberry32(20251023);

  // ── Pad: detuned softsaw stack through moving lowpass
  for (let i = 0; i < BARS; i++) {
    const deg = M.prog[i % M.prog.length];
    const chord = [0, 3, 7, 10].map((iv) => root + deg + iv);
    const start = i * bar;
    // বার-দৈর্ঘ্যের চেয়ে লম্বা বাফার — পরের বারে গড়িয়ে গিয়ে crossfade হয়,
    // নইলে প্রতি বার-সীমানায় প্যাড শূন্যে নেমে ফাঁক তৈরি করে
    const padBuf = buf(bar * 1.8);
    chord.forEach((n, k) => {
      [-6, 0, 6].forEach((cents) => {
        const v = buf(bar * 1.08);
        osc(v, hz(n) * Math.pow(2, cents / 1200), "softsaw");
        mulGain(v, 0.1 / (k + 1.6));
        add(padBuf, v, 0);
      });
    });
    const openness = 0.75 + 0.25 * Math.sin((i / BARS) * Math.PI);
    sweepLP(padBuf, M.padLp * 0.55, M.padLp * openness, 0.6);
    adsr(padBuf, { a: 0.45, d: 0.3, s: 0.80, r: bar * 0.75, curve: 1.6 });
    add(mix, padBuf, start, 0.34);
  }

  // ── Sustain drone: পুরো দৈর্ঘ্য জুড়ে একটানা, কখনো গেট হয় না।
  // এটি ছাড়া বার-সীমানায় বেড প্রায় নীরব হয়ে যায় (Annex I §১১.১)।
  {
    const droneBuf = buf(total);
    [0, 7, 12].forEach((iv, k) => {
      [-5, 5].forEach((cents) => {
        const v = buf(total);
        osc(v, hz(root + iv - 12) * Math.pow(2, cents / 1200), "softsaw");
        mulGain(v, 0.08 / (k + 1.4));
        add(droneBuf, v, 0);
      });
    });
    biquad(droneBuf, "lp", M.padLp * 0.5, 0.6);
    // শুধু দুই প্রান্তে fade — মাঝখানে স্তর সম্পূর্ণ ধ্রুব
    adsr(droneBuf, { a: 1.1, d: 0.2, s: 1.0, r: 1.6, curve: 1.2 });
    add(mix, droneBuf, 0, 0.30);
  }

  // ── Sub bass: root, bar-এর ১ ও ৩ beat-এ
  for (let i = 0; i < BARS; i++) {
    const deg = M.prog[i % M.prog.length];
    [0, 2].forEach((beat) => {
      const v = buf(spb * 1.7);
      osc(v, hz(root + deg - 24), "sine");
      decay(v, 0.4, 0.02);
      biquad(v, "lp", 180, 0.7);
      add(mix, v, i * bar + beat * spb, M.subGain * 0.5);
    });
  }

  // ── Arp: scale থেকে deterministic pattern (16th note)
  const arpPat = [0, 4, 2, 5, 1, 4, 3, 6];
  for (let i = 0; i < BARS; i++) {
    if (i < 2) continue; // intro-তে arp নেই — ধীরে ভরে ওঠে
    const deg = M.prog[i % M.prog.length];
    for (let s = 0; s < 8; s++) {
      if (rnd() < 0.18) continue;
      const sd = M.scale[arpPat[s] % M.scale.length];
      const v = buf(spb * 0.9);
      osc(v, hz(root + deg + sd + 12), "tri");
      decay(v, 0.1, 0.002);
      biquad(v, "lp", 4200, 0.8);
      reverb(v, { mix: 0.3, size: 0.6, damp: 0.35 });
      add(mix, v, i * bar + s * (spb / 2), M.arpGain * (0.6 + 0.4 * Math.sin(s)));
    }
  }

  // ── Soft perc: kick (1,3) + closed hat (off-beat)
  for (let i = 2; i < BARS; i++) {
    [0, 2].forEach((beat) => {
      const k = buf(0.4);
      osc(k, (t) => 110 * Math.exp(-t * 14) + 44, "sine");
      decay(k, 0.11, 0.002); biquad(k, "lp", 900, 0.7);
      add(mix, k, i * bar + beat * spb, M.percGain * 0.9);
    });
    for (let s = 1; s < 8; s += 2) {
      const h = buf(0.09);
      noise(h, 211 + s + i, "white"); biquad(h, "hp", 7000, 0.8);
      decay(h, 0.016, 0.0004);
      add(mix, h, i * bar + s * (spb / 2), M.percGain * 0.16);
    }
  }

  // ── Mix bus: HPF rumble → gentle glue → tone shaping
  biquad(mix, "hp", 28, 0.6);
  biquad(mix, "peak", 320, 0.9, -1.6);   // mud control
  biquad(mix, "peak", 2500, 0.8, -2.4);  // VO slot খালি (frequency ducking)
  biquad(mix, "hs", 9000, 0.7, 1.2);     // air
  // bed glue — ফাঁকা বারগুলোকে তুলে আনে যাতে বেড একটানা শোনায়
  compress(mix, {
    thresholdDb: -34, ratio: 4, attack: 0.025,
    release: 0.32, knee: 10, makeupDb: 9,
  });
  softClip(mix, 1.25);

  // ── Arrangement envelope: ধীরে ঢোকা, শেষে ধীরে বেরোনো
  const fi = Math.round(bar * 1.2 * SR), fo = Math.round(bar * 1.5 * SR);
  for (let i = 0; i < mix.length; i++) {
    const gi = i < fi ? Math.pow(i / fi, 1.5) : 1;
    const go = i > mix.length - fo ? Math.pow((mix.length - i) / fo, 1.4) : 1;
    mix[i] *= gi * go;
  }
  return mix;
};

/* ═══════════════════ 11. RUN ═══════════════════ */
mkdirSync(OUT, { recursive: true });
const report = { generatedAt: new Date().toISOString(), sampleRate: SR, sfx: {}, music: null };

console.log(`\n🔊 SFX তৈরি হচ্ছে → ${OUT}`);
for (const [name, fn] of Object.entries(SFX)) {
  let mono = fn();
  deClick(mono, 3);
  normalize(mono, SFX_PEAK_DB[name] ?? -9);
  const [L, R] = widen(mono, 0.18, 5);
  const p = join(OUT, `${name}.wav`);
  writeWav(p, [L, R]);
  const info = {
    seconds: +secs(mono).toFixed(3),
    peakDb: +db(peakOf(mono)).toFixed(2),
    rmsDb: +db(rmsOf(mono)).toFixed(2),
    clipping: peakOf(mono) >= 0.999,
  };
  report.sfx[name] = info;
  console.log(`   ✓ ${name.padEnd(20)} ${info.seconds.toFixed(2)}s  peak ${info.peakDb}dB  rms ${info.rmsDb}dB`);
}

if (!NO_MUSIC) {
  mkdirSync(MUSIC_OUT, { recursive: true });
  console.log(`\n🎵 মিউজিক বেড → ${MUSIC_OUT}  (${MOOD} · ${KEY} · ${BPM}bpm · ${BARS} bars)`);
  let m = makeMusic();
  deClick(m, 20);
  normalize(m, -3.0);
  const [L, R] = widen(m, 0.42, 9);
  writeWav(join(MUSIC_OUT, "bed_main.wav"), [L, R]);
  report.music = {
    file: "bed_main.wav", mood: MOOD, key: KEY, bpm: BPM, bars: BARS,
    seconds: +secs(m).toFixed(2),
    peakDb: +db(peakOf(m)).toFixed(2),
    rmsDb: +db(rmsOf(m)).toFixed(2),
    lufsApprox: +lufsApprox(m).toFixed(2),
    framesPerBeat30fps: +((30 * 60) / BPM).toFixed(3),
    framesPerBeat60fps: +((60 * 60) / BPM).toFixed(3),
  };
  console.log(`   ✓ bed_main.wav  ${report.music.seconds}s  peak ${report.music.peakDb}dB  ~${report.music.lufsApprox} LUFS`);
  console.log(`   ↳ beat grid: ${report.music.framesPerBeat30fps} frames/beat @30fps`);
  writeFileSync(join(MUSIC_OUT, "MIX-REPORT.json"), JSON.stringify(report, null, 2));
}

writeFileSync(join(OUT, "MIX-REPORT.json"), JSON.stringify(report, null, 2));
console.log(`\n✅ সম্পন্ন। QA রিপোর্ট: ${join(OUT, "MIX-REPORT.json")}\n`);
