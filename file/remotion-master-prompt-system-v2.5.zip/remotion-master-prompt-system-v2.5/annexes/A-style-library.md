# Annex A — স্টাইল লাইব্রেরি ও সিলেকশন সিস্টেম (v2.0)

> **v2.2 অগ্রাধিকার:** `MASTER-PROMPT.md`-এর v2.2 ও Annex O-এর নিয়ম এখানে পুরোনো বাধ্যতামূলক style/motion/font checklist-এর ওপর প্রযোজ্য। নিচের preset ও সংখ্যা পরিস্থিতি অনুযায়ী ব্যবহারযোগ্য উদাহরণ।

> প্রতিটি সিনের জন্য এই লাইব্রেরি থেকে স্টাইল বেছে নেবে। **রং কখনো স্টাইল ঠিক করবে না** — রং সবসময় user-এর নির্বাচিত scheme। স্টাইল থেকে নেবে শুধু কাঠামো ও ভিজ্যুয়াল ভাষা।
>
> **v2.0 পরিবর্তন:** ১৬ → **২৪টি স্টাইল**; প্রতিটিতে **Premium Requirement** কলাম যুক্ত — ওটা না থাকলে স্টাইলটি বেসিক দেখাবে।

---

## ১. স্টাইল লাইব্রেরি (২৪টি)

### Tier A — Core (যেকোনো বিষয়ে কাজ করে)

| # | স্টাইল | বর্ণনা | কোথায় | **Premium Requirement** |
|---|---|---|---|---|
| 1 | **Glossy UI Mockup** | ব্রাউজার/অ্যাপ উইন্ডো, টুলবার, কার্ড, toggle | টুল/ফিচার, tutorial | `insetGlass` + e3 shadow + সূক্ষ্ম reflection |
| 2 | **Kinetic Typography** | বড় bold টাইপ, scale/slide/highlight ছন্দ | হুক/মূল বার্তা | Depth Extrude বা Gradient Sheen (Annex B) |
| 3 | **Glass Cards** | অর্ধ-স্বচ্ছ স্তরযুক্ত প্যানেল | বৈশিষ্ট্য-তালিকা | `backdrop-filter: blur(24px)` + hairline + inset highlight |
| 4 | **Bento Grid** | বিভিন্ন আকারের কার্ড grid | ওভারভিউ | প্রতিটি কার্ডে ভিন্ন elevation; stagger 4f |
| 5 | **Minimal Clean** | প্রচুর negative space, ১–২ element | বিরতি/স্থানান্তর | background-এ একটি volumetric light shaft |
| 6 | **Statement Card** | মাঝে একটি শক্তিশালী লেখা | মূল উক্তি | Light Wipe Reveal + vignette গভীর |
| 7 | **Dark Tech** | গাঢ় গ্রিড, glow line, node, HUD | ডেভ/টেকনিক্যাল | mono label + node network bg (Annex L §৬) |
| 8 | **Data Dashboard** | কার্ড, chart, progress, big number | সংখ্যা/তথ্য | শুধু স্ক্রিপ্টের সংখ্যা; Odometer Roll |

### Tier B — Structural

| # | স্টাইল | বর্ণনা | কোথায় | **Premium Requirement** |
|---|---|---|---|---|
| 9 | **Timeline Process Flow** | ধাপ-রেখা, line draw-on + node | প্রক্রিয়া | SVG trim-path (`pathLength=1`), node pop follow-through |
| 10 | **Hub and Spoke** | কেন্দ্রে বিষয়, চারপাশে সংযুক্ত | সম্পর্ক/টুল | সংযোগ রেখায় comet dash চলবে |
| 11 | **Before/After Split** | দুই পাশে তুলনা | সমস্যা vs সমাধান | divider-এ animated light line + duotone contrast |
| 12 | **Checklist Recap Grid** | টিকমার্ক সহ grid | সারসংক্ষেপ | Check Burst + stagger; গ্রুপে ১টি SFX |
| 13 | **3D Carousel** | perspective-এ ঘূর্ণায়মান প্যানেল | একাধিক আইটেম | পেছনের প্যানেলে DOF blur + opacity falloff |
| 14 | **Split Screen** | অর্ধেক ছবি + অর্ধেক কনটেন্ট | explainer | animated divide + parallax ভিন্ন গতিতে |
| 15 | **Comparison Table** | সারি-কলাম তুলনা | ফিচার তুলনা | সারি stagger; highlight row-এ hero tint |
| 16 | **Step Rail** | ০১→০২→০৩ progress | বহু-ধাপ | rail fill animate + active chip bloom |

### Tier C — Expressive (সংযতে — ভিডিওপ্রতি ১–২টি)

| # | স্টাইল | বর্ণনা | কোথায় | **Premium Requirement** |
|---|---|---|---|---|
| 17 | **Gradient Fluid** | তরল gradient blob, morphing | আবেগ/সৃজনশীল | `blobPath()` deterministic morph + goo filter |
| 18 | **Flat Vector Isometric** | আইসোমেট্রিক চিত্র | কনসেপ্ট ব্যাখ্যা | ৩ স্তর (base/mid/top) + ambient occlusion shadow |
| 19 | **Line Draw Doodle** | এক লাইনে আঁকা | সহজ ব্যাখ্যা | trim-path + stroke gradient; কখনো uniform stroke নয় |
| 20 | **Cinematic Photo Frame** | full-bleed ছবি + minimal type | গল্প/আবেগ | Annex D Masterpiece Gate + anamorphic bar |
| 21 | **Particle Field** | বিন্দু/কণা converge-diverge | AI/ডেটা/ভবিষ্যৎ | seeded position; goo বা bloom filter |
| 22 | **Code / Terminal** | সিনট্যাক্স-রঙিন কোড ব্লক | ডেভ কনটেন্ট | mono font, line-by-line reveal, caret, window chrome |
| 23 | **Map / Geo** | মানচিত্র + pin + path | লোকেশন/বিস্তার | path draw-on + pin drop (bouncy) + ripple |
| 24 | **Device Mockup** | ফোন/ল্যাপটপ frame-এ কনটেন্ট | অ্যাপ/প্রোডাক্ট | বাস্তব aspect ratio, screen reflection, e4 shadow |

---

## ২. সিলেকশন গাইড

| কনটেন্ট | প্রথম পছন্দ | বিকল্প |
|---|---|---|
| ইন্ট্রো / হুক | Annex K archetype | Kinetic Typography |
| একাধিক টুল/আইটেম | Hub and Spoke · Bento Grid | 3D Carousel |
| একটি টুলের ব্যাখ্যা | Glossy UI Mockup | Glass Cards |
| ধাপ / প্রক্রিয়া | Timeline Process Flow | Step Rail |
| সমস্যা বনাম সমাধান | Before/After Split | Comparison Table |
| সংখ্যা / তথ্য | Data Dashboard | Big-number Statement |
| বিরতি / স্থানান্তর | Minimal Clean | Statement Card |
| আবেগ / গল্প | Cinematic Photo Frame | Gradient Fluid |
| টেকনিক্যাল/কোড | Code / Terminal | Dark Tech |
| অ্যাপ/প্রোডাক্ট | Device Mockup | Glossy UI Mockup |
| সমাপ্তি / CTA | Checklist Recap Grid | Kinetic Typography + CTA |

---

## ৩. ভিজ্যুয়াল ঐক্য (Visual Unity)

- সারা ভিডিওতে **একই ফন্ট, radius, shadow স্কেল, রং ও motion-ব্যক্তিত্ব**। সিনে সিনে বদলাবে **layout** — রং/ফন্ট নয়।
- এক মিনিটে **৩–৫টি স্টাইল** যথেষ্ট; দরকারে পুনর্ব্যবহার। জোর করে নতুন স্টাইল নয়।
- **পরপর দুই সিনে একই layout নয়।** কোনো সিন শুধু টেক্সটে নয় — প্রতিটিতে একটি মূল ভিজ্যুয়াল।
- সব রং, easing, spring, shadow, radius `theme.ts`-এ; কম্পোনেন্টে inline নয়।
- স্টাইলের কারণে বক্তব্য অস্পষ্ট হলে **সরল স্টাইলই ভালো**।

---

## ৪. Scene Composition নিয়ম (v2.0 নতুন)

প্রতিটি সিনে এই চারটি থাকবেই:

| # | উপাদান | কেন |
|---|---|---|
| 1 | **একটি স্পষ্ট focal point** | দর্শকের চোখ কোথায় যাবে তা নির্ধারিত |
| 2 | **Depth — ন্যূনতম ৩ স্তর** | bg mesh · mid content · fg accent (ভিন্ন parallax) |
| 3 | **একটি breathing element** | ২s+ স্থায়ী কিছুতে `breathe()` বা `floatY()` |
| 4 | **Asymmetric balance** | সব কিছু কেন্দ্রে নয় — ওজন একদিকে, ভারসাম্য অন্যদিকে |

**গ্রিড:** landscape 12-column, gutter 120px · reel 6-column, gutter 90px। উপাদান grid-এ snap করবে — চোখে আন্দাজে নয়।

**Rule of thirds:** hero element ⅓ রেখায় বা ছেদবিন্দুতে। পুরো-কেন্দ্র শুধু Statement Card-এ।
