# Annex F — Motion Principles ও Camera Language (v2.0)

> **v2.2 অগ্রাধিকার:** `MASTER-PROMPT.md`-এর v2.2 ও Annex O-এর নিয়ম এখানে পুরোনো বাধ্যতামূলক style/motion/font checklist-এর ওপর প্রযোজ্য। নিচের preset ও সংখ্যা পরিস্থিতি অনুযায়ী ব্যবহারযোগ্য উদাহরণ।

> **v2.0 পরিবর্তন:** সাউন্ড টাইমিং সম্পূর্ণভাবে **Annex I**-তে সরানো হয়েছে (এখন সেটি একটি পূর্ণ mix সিস্টেম)। এই Annex এখন শুধু **মোশন ও ক্যামেরা** — তবে অনেক গভীর: velocity graph, camera rig, physical motion।

---

## ১. Twelve Principles → Remotion (সংখ্যায়)

| নীতি | নিয়ম | বাস্তবায়ন | মান |
|---|---|---|---|
| **Anticipation** | বড় মুভের আগে ছোট বিপরীত মুভ | `anticipate()` | দৈর্ঘ্যের ৩০%, travel-এর ১২% |
| **Squash & Stretch** | দ্রুত মুভে সামান্য বিকৃতি | `scaleX/scaleY` বিপরীত | ±৪% সর্বোচ্চ (UI-তে বেশি নয়) |
| **Staging** | এক ফ্রেমে একটিই হিরো মুভ | বাকি স্থির বা `breathe()` | — |
| **Follow-through** | secondary পরে আসে | delay | ৪–৮f |
| **Overlapping action** | অংশগুলো ভিন্ন সময়ে থামে | ভিন্ন spring config | — |
| **Slow in / Slow out** | linear সম্পূর্ণ নিষিদ্ধ | `ease.*` | — |
| **Arcs** | সরলরেখায় মুভ নয় | x ও y ভিন্ন easing | y-তে `ease.out`, x-এ `ease.inOut` |
| **Secondary action** | মূল মুভের সঙ্গে ছোট সঙ্গী মুভ | icon/underline/chip | মূলের ৬f পরে |
| **Timing** | HIT → hold → build → HIT | — | hold ১৫–২০f |
| **Exaggeration** | overshoot | `spring.bouncy/snappy` | — |
| **Solid drawing** | depth ধারাবাহিক | parallax factor স্থির | 0.3 / 0.6 / 1.0 |
| **Appeal** | উদ্দেশ্যহীন মোশন নয় | — | প্রতিটি মুভের কারণ থাকবে |

### Easing টেবিল (`motion.ts`)

| নাম | curve | কোথায় |
|---|---|---|
| `ease.out` | bezier(0.16, 1, 0.3, 1) | **সব entrance** (ডিফল্ট) |
| `ease.outSoft` | bezier(0.22, 1, 0.36, 1) | কম আগ্রাসী entrance |
| `ease.outBack` | bezier(0.34, 1.56, 0.64, 1) | chip, badge — ছোট overshoot |
| `ease.inOut` | bezier(0.83, 0, 0.17, 1) | camera move, Ken Burns, morph |
| `ease.inOutSoft` | bezier(0.65, 0, 0.35, 1) | দীর্ঘ নরম move |
| `ease.in` | bezier(0.7, 0, 0.84, 0) | **শুধু exit** |
| `ease.whip` | bezier(0.9, 0, 0.1, 1) | whip pan, impact |
| `ease.anticipate` | bezier(0.68, −0.4, 0.27, 1.4) | anticipation সহ মুভ |

### Spring টেবিল

| নাম | damping / stiffness / mass | কোথায় |
|---|---|---|
| `slam` | 18 / 240 / 0.5 | hero title — দ্রুততম |
| `snappy` | 14 / 160 / 0.6 | UI pop, শব্দ |
| `smooth` | 20 / 90 / 1.0 | বড় element, panel |
| `bouncy` | 11 / 170 / 0.7 | logo, icon, playful |
| `precise` | 30 / 60 / 1.0 | counter — overshoot নেই |
| `cinematic` | 26 / 55 / 1.4 | বড় camera push |

---

## ২. Velocity Thinking (AE graph editor-এর মানসিকতা)

অ্যানিমেশন ভালো না লাগলে **position** দেখো না — **velocity** দেখো।

| লক্ষণ | কারণ | সমাধান |
|---|---|---|
| "সস্তা/টেমপ্লেট" লাগছে | linear velocity | `ease.out` প্রয়োগ |
| "ভারী/অলস" লাগছে | peak velocity খুব দেরিতে | `ease.out` (easeOutExpo) — শুরুতেই দ্রুত |
| "ঝাঁকুনি" লাগছে | velocity হঠাৎ শূন্য | spring বা `ease.inOut` |
| "আলগা/তরল" লাগছে | overshoot বেশি | damping বাড়াও (14 → 20) |
| "যান্ত্রিক" লাগছে | সব একই easing | hierarchy দাও: headline `smooth`, chip `snappy` |
| "জগাখিচুড়ি" লাগছে | সব একসঙ্গে ঢুকছে | stagger (৩–৬f) |

**সূত্র:** প্রিমিয়াম মোশন = **দ্রুত শুরু → দীর্ঘ settle → সম্পূর্ণ স্থিরতা**। শেষ অংশটাই সবচেয়ে বেশি উপেক্ষিত। ধ্রুব মোশন = amateur।

---

## ৩. Camera Language (2.5D — CSS/transform)

```tsx
// src/components/camera/CameraRig.tsx
export const CameraRig: React.FC<{
  cam: CameraState; depth?: number; focus?: number; children: React.ReactNode;
}> = ({ cam, depth = 0, focus = 0, children }) => (
  <AbsoluteFill style={{
    transform: cameraTransform(cam, depth),
    filter: depthBlur(depth, focus, 1.6),
    willChange: "transform",
  }}>{children}</AbsoluteFill>
);

// scene-এ: একটি camera state, একাধিক depth
const cam = {
  x: lerp(frame, [0, 120], [0, 60], ease.inOut),
  y: 0,
  z: lerp(frame, [0, 120], [0, 40], ease.inOut),
  rot: wiggle(frame, fps, 0.25, 0.25, 9),   // খুব সামান্য handheld
};
<CameraRig cam={cam} depth={2} focus={1}><BgMesh /></CameraRig>
<CameraRig cam={cam} depth={1} focus={1}><MidContent /></CameraRig>
<CameraRig cam={cam} depth={0} focus={1}><Foreground /></CameraRig>
```

| মুভ | কীভাবে | কখন |
|---|---|---|
| **Push-in** | `cam.z` 0→40 ধীরে + parallax | ফোকাস বাড়াতে |
| **Pull-out** | `cam.z` 40→0 | বড় চিত্র দেখাতে |
| **Pan** | `cam.x` পরিবর্তন | পাশে কিছু দেখাতে |
| **Orbit** | perspective + `rotateY` | 3D carousel |
| **Dolly-through** | `translateZ` বড় মান + DOF | transition (Annex E §৮) |
| **Handheld** | `wiggle()` 0.2–0.4 deg, 1–2px | সিনেমাটিক বাস্তবতা |
| **Rack focus** | `focus` depth পরিবর্তন | মনোযোগ সরাতে |
| **Micro-shake** | impact-এ ৩–৫f, 2–4px | শুধু বড় impact-এ |

**নিয়ম:** প্রতি সিনে **১টি** camera move যথেষ্ট। দ্রুত মুভে (>30px/frame) motion blur — `shutterBlur()` বা `<Trail>`।

---

## ৪. Depth & Parallax স্কেল

| স্তর | depth মান | parallax factor | blur (focus=1) |
|---|---|---|---|
| Foreground accent | 0 | 1.00 | 1.6px |
| Main content | 1 | 0.65 | 0 (শার্প) |
| Mid graphics | 1.5 | 0.47 | 0.8px |
| Background mesh | 2 | 0.30 | 1.6px |
| Far atmosphere | 3 | 0.0 (প্রায় স্থির) | 3.2px |

ধারাবাহিকতা জরুরি: একটি সিনে যে element depth 2-এ, পরের সিনেও একই ভূমিকার element depth 2-এ থাকবে।

---

## ৫. Idle Life (কোনো ফ্রেম মৃত নয়)

```tsx
const s  = breathe(frame, 0.015, 22);          // scale 0.985–1.015
const y  = floatY(frame, 3, 30);               // ±3px
const r  = wiggle(frame, fps, 0.3, 0.6, seed); // ±0.6deg, deterministic
```

| Element | Idle motion |
|---|---|
| ২s+ স্থায়ী কার্ড | `breathe` + `floatY` |
| Background orb | ধীর sin drift (period 55–70) |
| আইকন | micro-rotate `wiggle` |
| Particle | ধীর upward drift + opacity sin |
| **পড়ার টেক্সট** | **স্থির** — breathing শুধু চারপাশে |

> গুরুত্বপূর্ণ টেক্সট পড়ার সময় নড়লে পাঠযোগ্যতা কমে। চারপাশের element নড়বে, টেক্সট নয়।

---

## ৬. Pacing নিয়ম

| দৈর্ঘ্য | গড় সিন দৈর্ঘ্য | সিন সংখ্যা |
|---|---|---|
| 15–30s (reel) | 2.5–4s | 5–9 |
| 60s | 3.5–5s | 12–17 |
| 2–3 min | 4–7s | 20–40 |
| 5 min+ | 5–9s + চ্যাপ্টার মার্কার | 35–60 |

- **প্রথম ১৫ frame-এ** একটি মুভ হতেই হবে (না হলে দর্শক চলে যায়)
- **৯০ frame-এর বেশি** নতুন element ছাড়া যাবে না
- প্রতি ২০–৩০s-এ একটি **pacing reset** (Minimal Clean সিন) — চোখের বিশ্রাম
- দ্রুত অংশের পরে ধীর অংশ; ধ্রুব গতি একঘেয়ে

---

## ৭. Motion QA Gate

- [ ] কোনো `interpolate` linear নয় (gradient/marquee position ছাড়া)
- [ ] সব `interpolate`-এ `extrapolateLeft` ও `extrapolateRight: "clamp"`
- [ ] প্রতিটি entrance-এ ≥৩টি প্রপার্টি
- [ ] প্রতিটি element-এর exit আছে, entrance-এর চেয়ে দ্রুত
- [ ] প্রতি সিনে ≤১টি camera move, ≤১টি hero মুভ
- [ ] stagger প্রয়োগ হয়েছে (কিছুই একসঙ্গে ঢোকেনি)
- [ ] ২s+ স্থায়ী প্রতিটি element-এ idle motion আছে
- [ ] পড়ার টেক্সট স্থির (breathing নেই)
- [ ] দ্রুত মুভে motion blur আছে
- [ ] কোনো `Math.random()` নেই — সব `hash01`/`noise1D`/`wiggle`
- [ ] সব timing `fps` থেকে (`timing(fps)`), magic number নয়
- [ ] প্রতি সিনে ≥১৫f সম্পূর্ণ স্থিরতা আছে (hold)
