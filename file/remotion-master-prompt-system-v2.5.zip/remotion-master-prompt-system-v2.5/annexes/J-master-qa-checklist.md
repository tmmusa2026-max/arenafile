# Annex J — Master QA Checklist (v2.0)

> **v2.2 অগ্রাধিকার:** `MASTER-PROMPT.md`-এর v2.2 ও Annex O-এর নিয়ম এখানে পুরোনো বাধ্যতামূলক style/motion/font checklist-এর ওপর প্রযোজ্য। নিচের preset ও সংখ্যা পরিস্থিতি অনুযায়ী ব্যবহারযোগ্য উদাহরণ।

> এই checklist চালাও — **প্রতিটি ধাপ বাস্তবে করা হয়েছে হলেই tick**। করা হয়নি এমন ধাপ ডেলিভারি নোটে স্পষ্টে লিখবে; সফল দাবি করবে না।
>
> **v2.0 নতুন:** §K (Premium Gate) — এই ১২টি ব্যর্থ হলে ভিডিও "প্রিমিয়াম" নয়, ডেলিভারি আটকাবে।

---

## A. Pre-flight (Setup)
- [ ] Node.js / npm version পরীক্ষিত; `npm install` সফল
- [ ] Dependency compatibility (remotion + react version মিল)
- [ ] `package.json` scripts — `render` script সত্যিকারের composition-এ যুক্ত
- [ ] Entry point (`src/index.ts`) ও Composition ID (`Main`) সঠিক
- [ ] Missing imports / syntax error / missing module নেই
- [ ] Missing asset নেই; image/audio/font path সঠিক (`staticFile()`)
- [ ] Windows path compatibility (forward slash)
- [ ] ফন্ট **offline bundle** (`public/fonts/`), CDN নয়; `delayRender`/`continueRender` ব্যবহৃত
- [ ] বাংলা যুক্তাক্ষর/কার/রেফ/baseline — টেস্ট স্ট্রিং still রেন্ডার করে **চোখে দেখা হয়েছে**
- [ ] Scene timing, fps, resolution সঠিক
- [ ] `theme.ts`/`motion.ts` ছাড়া কোথাও inline hex / easing / shadow / magic frame নেই
- [ ] কোডে কোনো `Math.random()` / `Date.now()` নেই (determinism)

## B. Content Integrity
- [ ] Transcript-এর সম্পূর্ণ অংশ বিশ্লেষিত; কিছু বাদ পড়েনি
- [ ] Scene plan ↔ transcript consistency (অর্থ/ক্রম অক্ষুণ্ণ)
- [ ] কোনো কল্পিত তথ্য/সংখ্যা/দাবি/slogan/placeholder নেই
- [ ] সম্পূর্ণ transcript subtitle হিসেবে নেই; শুধু headline/keyword/label/visual
- [ ] Watermark/অযাচিত branding নেই
- [ ] 2D cartoon human নেই; emoji-as-icon নেই

## C. টাইমিং ও SRT (থাকলে)
- [ ] SRT start/end → frame conversion নির্ভুল, deterministic
- [ ] কোনো segment-এর লেখা নির্ধারিত start-এর আগে দেখা যায়নি (৪–৬f আগেও নয়)
- [ ] cue বদলানোর পর পুরানো visual অকারণে স্থির নেই
- [ ] timestamp gap/overlap শনাক্ত ও নথিভুক্ত
- [ ] শেষে blank/frozen frame নেই; duration ↔ শেষ timestamp মিল
- [ ] scene cut beat grid-এ snap করা (মিউজিক থাকলে)

## D. Visual Frame Inspection (বাধ্যতামূলক — চোখে দেখা)
- [ ] মূল ফ্রেমগুলো `npx remotion still` দিয়ে রেন্ডার করে দেখা হয়েছে (≥৮টি ফ্রেম)
- [ ] Spacing bug নেই; flex gap **pixel-এ** (em নয়) — শব্দ জোড়া লাগেনি
- [ ] টেক্সট frame edge-এ কাটছে না; safe zone মানা (9:16-এ মাঝের ~৭৫%)
- [ ] Element entrance-এর আগে / exit-এর পর দেখা যাচ্ছে না (clamp)
- [ ] Layer order সঠিক — ৯-স্তর post stack, grain+vignette সবার উপরে
- [ ] প্রতি ফ্রেমে hero color/glow ≤ ১ element; contrast পাঠযোগ্য (≥4.5:1)
- [ ] কোনো ফ্ল্যাট সলিড background নেই
- [ ] সব still-এ Ken Burns; দ্রুত মুভে motion blur
- [ ] Exit animated ও entrance-এর চেয়ে দ্রুত
- [ ] সমস্যা পেলে ঠিক করে **পুনরায় render → আবার দেখা** হয়েছে

## E. ছবি/অ্যাসেট
- [ ] প্রতিটি ছবি **Masterpiece Gate** (Annex D §৬) ৮/৮ পাস করেছে
- [ ] কোনো broken/missing image নেই; stretch/দুর্বল crop নেই
- [ ] মুখ/লোগো/গুরুত্বপূর্ণ অংশ কাটেনি
- [ ] AI ছবিতে বিকৃত হাত/মুখ/লেখা নেই; plastic skin নেই
- [ ] সব ছবিতে grade match + grain + light wrap প্রয়োগ হয়েছে
- [ ] প্রতিটি ছবির source + license `ASSETS.md`-তে; AI হলে prompt সহ
- [ ] Logo বিকৃত/পুনঃসৃষ্টি করা হয়নি

## F. Vector / SVG (Annex L §৯)
- [ ] কোনো `fill` সরাসরি hex নয়
- [ ] প্রতিটি প্রধান shape-এ ≥২ স্তর; hero আইকনে ≥৩ স্তর
- [ ] stroke-width hierarchy মানা; round cap/join সর্বত্র
- [ ] সব `<defs>` id অনন্য
- [ ] এক ফ্রেমে `feTurbulence` ≤ ২টি
- [ ] কোনো raster আইকন নেই

## G. Tutorial (প্রযোজ্য হলে — Annex G)
- [ ] প্রতিটি ধাপ transcript-এর সঙ্গে মিলে; কোনো ধাপ বাদ পড়েনি
- [ ] সঠিক button/option/field (honesty tier মানা)
- [ ] Cursor যেখানে click করছে, UI state ঠিক সেখানেই বদলাচ্ছে
- [ ] UI continuity আছে (আগের ধাপের page/tab/state ধরে রাখা)
- [ ] Annotation পড়ার মতো; UI ঢাকছে না
- [ ] দর্শক দেখে কাজটি করতে পারবে
- [ ] Recreation/uncertainty delivery note-এ উল্লেখ আছে

## H. Audio (Annex I §৭ — `MIX-REPORT.json` দেখে)
- [ ] `MIX-REPORT.json`-এ কোথাও `clipping: true` নেই
- [ ] প্রতিটি SFX টার্গেট peak-এর ±1.5 dB-এর মধ্যে
- [ ] ফাইনাল মিক্স true peak ≤ −1.0 dBTP; integrated ≈ −14 LUFS
- [ ] প্রতিটি SFX visual-এর **২–৩f আগে** (frame গুনে যাচাই)
- [ ] এক ফ্রেমে ≥৩টি SFX কোথাও নেই
- [ ] মিউজিক ইন্ট্রো শেষে ঢুকেছে, শেষে ধীরে নেমেছে
- [ ] VO থাকলে ducking প্রয়োগ; VO কোথাও ঢাকা পড়েনি
- [ ] সব audio-র source/license `ASSETS.md`-তে
- [ ] **রেন্ডার করা MP4 শুনে যাচাই** (preview শোনা যথেষ্ট নয়)

## I. Intro / Outro (Annex K §৬)
- [ ] ইন্ট্রো দৈর্ঘ্য সীমার ভেতরে (short ≤2.5s · long ≤5s)
- [ ] ৫টি beat আলাদা করে চেনা যায়; IMPACT ফ্রেমে একটিই form
- [ ] Beat 5-এ ≥১২f সম্পূর্ণ স্থিরতা
- [ ] ইন্ট্রোতে সাউন্ড ইভেন্ট ≤ ৪টি
- [ ] Outro ইন্ট্রোর ভাষার সঙ্গে মেলে (bookend)
- [ ] শেষ frame কালো/ফাঁকা নয়

## J. Final Render QA
- [ ] ভিডিও শুরু থেকে শেষ **দেখা হয়েছে** (প্রিভিউ নয় — rendered output)
- [ ] Text clipping, বাংলা অক্ষর, broken image, transition, timing ঠিক
- [ ] Resolution ও fps সঠিক; শেষে blank frame নেই
- [ ] ফাইল সাইজ যুক্তিসঙ্গত; codec/crf সঠিক

---

## K. 🏆 PREMIUM GATE (v2.0 — ১২টি, সব পাস করতেই হবে)

> এগুলোর একটিও ব্যর্থ হলে আউটপুট "প্রিমিয়াম" নয়। ঠিক করে পুনরায় render — নাহলে delivery note-এ স্পষ্ট স্বীকারোক্তি।

| # | গেট | যাচাই |
|---|---|---|
| 1 | **Signature intro আছে** | Annex K beat sheet মানা, দৈর্ঘ্য সীমার ভেতরে |
| 2 | **কোনো ফ্ল্যাট পৃষ্ঠ নেই** | প্রতিটি surface-এ gradient; প্রতিটি সিনে ৯-স্তর stack |
| 3 | **Depth দৃশ্যমান** | প্রতিটি সিনে ≥৩ parallax স্তর |
| 4 | **Shadow ৩-স্তরে** | সব elevation `theme.elevation.*` থেকে |
| 5 | **≥৩ প্রপার্টি entrance** | কোনো শুধু-fade entrance নেই |
| 6 | **Exit সর্বত্র** | প্রতিটি element-এর exit আছে, দ্রুততর |
| 7 | **কোনো ফ্রেম মৃত নয়** | ২s+ স্থায়ী সব element-এ idle motion |
| 8 | **সম্পূর্ণ স্থিরতাও আছে** | প্রতি সিনে ≥১৫f hold (ধ্রুব মোশন নয়) |
| 9 | **ছবি masterpiece-গ্রেড** | Annex D ৮/৮ গেট; কোনো AI-plastic লুক নেই |
| 10 | **SVG প্রিমিয়াম** | gradient fill + depth + ≥২ স্তর; কোনো ফ্ল্যাট vector নেই |
| 11 | **অডিও সম্পূর্ণ** | মিউজিক বেড + ducking + SFX ২–৩f আগে + LUFS টার্গেট |
| 12 | **Determinism** | একই কমান্ডে দুবার render → একই ফল (`Math.random()` নেই) |

---

## L. Delivery
- [ ] ZIP (node_modules ছাড়া) তৈরি; extract করে README অনুযায়ী চলে
- [ ] `README.md` (PowerShell: install / audio / studio / render / error handling)
- [ ] `ASSETS.md` (সব asset-এর source + license; AI হলে prompt)
- [ ] ৪টি কমান্ড (আসল path/ID সহ — placeholder নয়)
- [ ] `MIX-REPORT.json` অন্তর্ভুক্ত
- [ ] যে পরীক্ষাগুলো **বাস্তবে** সম্পন্ন হয়েছে তা তালিকাবদ্ধ; limitation/missing asset স্পষ্ট
- [ ] কোনো command চালানো সম্ভব না হলে সেটি জানানো হয়েছে
