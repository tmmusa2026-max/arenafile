# Prompt Router ও Context Budget

## উদ্দেশ্য

সব ফাইল একসঙ্গে পড়লে গুরুত্বপূর্ণ নির্দেশনা তালিকার মধ্যে হারিয়ে যেতে পারে। Router প্রজেক্টের ধরন ও বর্তমান কাজ অনুযায়ী কোন ফাইল এখন দরকার তা ঠিক করে। Hard constraints সবসময় থাকবে, catalog শুধু প্রয়োজনে আসবে।

এই package-এ কোনো reference video বা visual style reference নেই। Validation reports শুধু technical capability বোঝায়।

## ১. সর্বদা পড়তে হবে

1. `MASTER_PROMPT.md` বা `PROMPT_COMPACT.md`
2. `project/PROJECT_BRIEF.md` বা পূরণ করা `project.json`
3. `12_DECISION_ENGINE.md`
4. `13_QA_AND_DELIVERY.md`
5. `14_OUTPUT_CONTRACT.md`
6. `19_SCORED_QA_RUBRIC.md`
7. `20_AUTONOMOUS_MEDIA_AND_PUBLIC_DELIVERY.md`
8. `21_PREMIUM_SUBTITLE_SYSTEM.md`
9. `22_DIALOGUE_SPECIFIC_SVG_SYSTEM.md`

Node implementation হলে অতিরিক্ত:

- `11_NODE_RENDER_PIPELINE.md`
- `15_EFFECT_CAPABILITY_MATRIX.md`
- `18_RESPONSIVE_AND_PERFORMANCE.md`
- `validation/README.md`

## ২. কাজভিত্তিক loading

| বর্তমান কাজ | পড়ার ফাইল | এড়ানো যায় |
|---|---|---|
| Bengali two-file intake | `20`, `01`, `02`, project files | Effects catalog, particle details |
| Brief ও content lock | `01`, `02`, project files | Effects catalog, particle details |
| Audio alignment | `02`, `21`, `validation/reports/audio-benchmark.md` | SVG catalog, transitions |
| Creative route | `01`, `03`, `16`, `17` | Render code, sound synthesis |
| Typography | `04`, `05`, `21`, `validation/reports/font-benchmark.md` | Audio effects, simulation catalog |
| Subtitle reveal ও highlight | `21`, subtitle config, recipe, schema ও timing utility | Unrelated effect catalog |
| SVG selection | `06`, `12`, `16`, `22` | Long text recipes, audio effects |
| Dialogue-specific SVG map | `22`, `02`, `06`, dialogue recipe, schema, map ও validator | Unrelated effect catalog |
| Technical explainer language | `23`, explainer recipe, style config, schema ও timing utility | Political ও documentary examples |
| Web media research | `20`, `libraries/media-sourcing.json`, media schema | Unrelated text recipes |
| Transition design | `08`, `16`, `17` | Font diagnostics, audio benchmark |
| 3D বা particles | `09`, capability matrix, performance budget | Political ও documentary examples |
| Sound | `10`, sound recipes, sound map | SVG path operators |
| Implementation | `11`, `15`, `18`, `validation/README.md` | Creative theory that is already locked |
| Public preview ও ZIP | `20`, `libraries/public-delivery.json`, delivery schema, preview template | Effects catalog |
| Final QA | `13`, `14`, `19`, `22`, project-specific proof এবং QC | Unselected recipe libraries |

## ৩. Genre route

### Political বা স্মরণীয়

- `01_DIRECTION_AND_STORY.md`
- `03_MOTION_SYSTEM.md`
- `04_TYPOGRAPHY.md`
- Text recipes T03, T05, T06, T07, T17, T20
- Vector recipes V02, V03, V04, V09, V23, V28
- `08_TRANSITIONS_AND_COMPOSITING.md`
- `17_ANTI_TEMPLATE_AND_FAILURES.md`
- `examples/POLITICAL_EXAMPLE.md`

Brief না চাইলে glitch, shatter, celebration, aggressive camera ও heavy bevel catalog এড়াও।

### Product promo

- `01`, `03`, `04`, `08`, `09`, `16`, `18`
- Text recipes T01, T09, T10, T12, T15, T16, T18
- Vector recipes V08, V11, V12, V13, V14, V24, V27
- `examples/PRODUCT_PROMO_EXAMPLE.md`

### Documentary

- `01`, `02`, `04`, `08`, `09`, `17`
- Text recipes T03, T04, T05, T07, T15, T17, T20
- Vector recipes V03, V20, V21, V23
- `examples/DOCUMENTARY_EXAMPLE.md`
- Source discipline ও audio alignment method
- `20_AUTONOMOUS_MEDIA_AND_PUBLIC_DELIVERY.md` ও media provenance rules

### Explainer

- `01`, `03`, `06`, `08`, `12`, `16`, `23`
- Text recipes T12, T15, T16, T18 এবং প্রয়োজনে T21
- Vector recipes V07, V08, V09, V10, V13, V14, V15 থেকে V17, শুধু data থাকলে
- Technical dialogue-এর অর্থ অনুযায়ী V29 থেকে V34 এবং `libraries/explainer-recipes.json`
- Keyword echo, chapter pill, actual timeline rail ও authorized watermark-এর জন্য `project/explainer-style.json`

## ৪. Context budget

| অংশ | প্রস্তাবিত বাজেট |
|---|---:|
| Active brief ও hard constraints | 15 শতাংশ |
| Current scene plan ও source excerpt | 20 শতাংশ |
| প্রাসঙ্গিক recipes | 25 শতাংশ |
| Implementation details | 25 শতাংশ |
| QA ও output contract | 15 শতাংশ |

বিরাট catalog সরাসরি prompt-এ আটকে না দিয়ে workspace file হিসেবে দিন। প্রয়োজনীয় অংশ পড়তে বলুন। Compact prompt ব্যবহার করলেও hard constraints বাদ যাবে না।

## ৫. Recipe retrieval

AI প্রথমে লিখবে:

```text
Need:
Scene role:
Tone:
Duration:
Aspect ratio:
Content unit:
Dialogue ID, speech act ও semantic focus:
Actual dialogue start ও end:
Previous dialogue SVG signature:
Hard constraints:
Previous motif:
Next motif:
```

তারপর `libraries/effect-selection.json`, `text-recipes.json`, `vector-recipes.json`, `dialogue-svg-recipes.json`, প্রযোজ্য হলে `explainer-recipes.json`, এবং `transition-recipes.json` থেকে candidate নির্বাচন করবে। Generator family কেবল direction, finished dialogue SVG নয়। শুধু নির্বাচিত ও বাদ দেওয়া entries context-এ আনবে।

## ৬. Reference-free policy

- Validation font, color, synthetic sound বা diagnostic layout কপি করবে না।
- Generic scene-plan example-এর timing actual project-এ আরোপ করবে না।
- আগের কোনো sample-কে quality target ধরবে না।
- Active brief-এর বাইরে signature style, recurring palette বা fixed composition ধরে নেবে না।
- Selected effect project-specific tool-এ implement এবং prove না হলে `untested` থাকবে।

## ৭. Response-এর আগে router check

- Active brief-এর সঙ্গে পড়া modules মিলছে কি?
- অপ্রাসঙ্গিক catalog কি সিদ্ধান্তকে প্রভাবিত করছে?
- Validation output কি ভুলভাবে style reference হয়ে গেছে?
- Selected effects কি chosen tool-এ verified?
- Final QA-এর proof কি সেই নতুন project থেকেই এসেছে?
- External media থাকলে `20` ও media provenance rules কি applied?
- Public delivery-র আগে command log, preview template ও link verification rules কি loaded?
- প্রতিটি dialogue-এর জন্য `22`, unique SVG map, meaningful difference এবং per-dialogue proof কি loaded?
- Subtitle থাকলে `21` এবং actual-word highlight timing কি loaded?
- Technical explainer হলে `23`, stable keyword echo, actual progress rail এবং watermark permission checks কি loaded?
