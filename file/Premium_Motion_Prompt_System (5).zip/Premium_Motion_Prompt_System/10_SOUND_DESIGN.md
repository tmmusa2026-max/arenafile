# 10. Sound Design

## ১. Hierarchy

ভয়েস-ওভার থাকলে prioritization:

1. Voice clarity ও intelligibility
2. অনুমোদিত music বা ambience, থাকলে
3. Narrative sound accent
4. Tiny UI বা text tick

Sound design ভিডিওর গতি বোঝাবে, নিজে আলাদা performance শুরু করবে না।

## ২. Source voice নীতি

Brief-এ voice অপরিবর্তিত রাখতে বললে:

- Trim নয়
- Cut নয়
- Time-stretch নয়
- Pitch change নয়
- Noise reduction, EQ, compression বা reverb নয়
- Extra silence padding নয়
- অনুমোদিত codec conversion ও muxing করা যায়, duration ও timing অক্ষুণ্ণ রেখে

Voice cleanup-এর অনুমতি থাকলে আলাদা processed version, settings ও before-after verification রাখো। কখনো মূল file overwrite নয়।

## ৩. সংযত default palette

Brief-এ অন্য কিছু না থাকলে:

- Word বা ছোট text entry-এ খুব subtle tick, সব শব্দে নয়
- Hero headline-এর settle-এ soft stamp
- Transition-এর জন্য আলাদা whoosh নয়, যদি না brief অনুমোদন করে
- Music bed নয়, যদি না brief চায়
- Ambience নয়, যদি না brief চায়
- Counter tick নয়
- Repeated notification sound নয়

Caption-এর প্রতি word-এ tick দেওয়া সাধারণত ক্লান্তিকর। শুধু hero text বা structural event-এ sound দাও।

## ৪. Synthesized sound recipes

সব sound নিজে synthesize করলে license সহজ হয়। Deterministic sample generation এবং fixed sample rate ব্যবহার করো।

### S01: Soft Text Tick

- Source: sine বা triangle oscillator, খুব ছোট filtered noise click ঐচ্ছিক
- Frequency: 900 থেকে 1800 Hz region, voice-এর intelligibility band-এ অতিরিক্ত energy নয়
- Duration: 20 থেকে 45 ms
- Attack: 1 থেকে 3 ms
- Decay: exponential-shaped fast decay
- Filter: high-frequency harshness সীমিত
- Level: voice-এর সময় কমপক্ষে 12 dB নিচে, সাধারণত আরও নিচে
- ব্যবহার: ছোট annotation বা selected text entry

### S02: Warm Headline Stamp

- Source: low sine body + filtered noise transient + দুর্বল upper partial
- Body frequency: 80 থেকে 160 Hz region, device playback পরীক্ষা করো
- Duration: 100 থেকে 220 ms
- Attack: 2 থেকে 6 ms
- Decay: নরম, কোনো abrupt cutoff নয়
- Level: voice-এর নিচে, low-frequency energy voice-কে mask না করে
- ব্যবহার: hero settle, শক্তিশালী visual impact

### S03: Quiet Resolve Tone

- Source: দুটি সম্পর্কিত sine partial, dissonant নয়
- Duration: 180 থেকে 350 ms
- Envelope: soft attack, smooth release
- ব্যবহার: কেবল brief-এ tonal resolve অনুমোদিত হলে
- Avoid: musical jingle, স্মরণীয় দৃশ্যে অতিরিক্ত আবেগ

### S04: Paper-like Editorial Touch

- Source: filtered noise with short irregular envelope
- Duration: 40 থেকে 90 ms
- Filter: band-limited, soft
- ব্যবহার: documentary frame বা page-like mask
- Avoid: actual paper motion না থাকলে

### S05: UI Confirmation

- Source: two quiet sine pings with short interval
- Duration: 80 থেকে 160 ms total
- ব্যবহার: product UI-এর স্পষ্ট confirmation
- Avoid: fake feature action, repeated list items

## ৫. Sync

- Sound event visual event-এর master timeline থেকে তৈরি হবে।
- Tick: text reveal-এর প্রথম দৃশ্যমান frame বা mask onset।
- Stamp: optical impact বা spring settle-এর প্রথম contact moment।
- Resolve: final line settle বা motif convergence।
- Sound-এর attack frame-accurate হবে। Render-এর audio stream offset probe করো।
- Visual motion blur-এর কারণে impact কোন frame-এ অনুভূত হয় তা দেখে ঠিক করো।
- Sample-accurate generation পাওয়া গেলে সেটিকে frame grid-এ quantize না করে রাখা যায়, কিন্তু perceived sync যাচাই বাধ্যতামূলক।

## ৬. Level ও ducking

- Voice চলাকালে effect voice-এর তুলনায় কমপক্ষে 12 dB নিচে।
- এটি peak, short-term loudness ও perceived masking দিয়ে যাচাই করো, শুধু file gain নয়।
- Voice-এর বিরতিতে effect একটু শোনা গেলেও অতিরিক্ত উজ্জ্বল নয়।
- Music অনুমোদিত হলে sidechain ducking নরম ও প্রায় অদৃশ্য হবে।
- Sudden gain jump নয়।
- Limiter দিয়ে সমস্যা ঢাকবে না। Headroom রাখো।
- Final AAC encode-এর পরে clipping ও level আবার পরীক্ষা করো।

## ৭. Frequency discipline

- Voice-এর প্রধান intelligibility range-এ অতিরিক্ত tick energy নয়।
- Low stamp যেন ছোট speaker-এ অদৃশ্য না হয়, অতি শান্ত upper transient দিতে পারো।
- Harsh 2 থেকে 5 kHz transient সীমিত রাখো, বিশেষ করে headphones-এ।
- Sub-bass-only impact এড়াও।
- Repeated sound-এর pitch ও timbre সামান্য বদলাতে পারো, কিন্তু random variation নয়। Narrative hierarchy অনুযায়ী বদলাও।

## ৮. Stereo ও mono

- Voice mono হলে center রাখো।
- Stereo effect খুব সামান্য width নিতে পারে, কিন্তু phase-safe হতে হবে।
- Mono fold-down পরীক্ষা করো।
- Text-এর screen position অনুসারে sound pan করা default নয়, এটি distraction হতে পারে।
- Vertical mobile video-তে small speaker এবং mono playback অগ্রাধিকার দাও।

## ৯. Music ও ambience, অনুমোদিত হলে

- License বা original synthesis document করো।
- Music-এর beat-এর সঙ্গে কাট করা বাধ্যতামূলক নয়, speech rhythm আগে।
- স্মরণীয় ভিডিওতে sentimental over-scoring এড়াও।
- Product promo-তে rhythm section text reveal-কে সাহায্য করবে, তাড়াহুড়ো করবে না।
- Documentary ambience source location-এর প্রমাণ না থাকলে misleading soundscape নয়।
- Voice-এর নিচে music-এর frequency space ও level নিয়ন্ত্রণ করো।

## ১০. Sound event table

| Event ID | Scene | Visual event | Sound recipe | Ideal time | Audio sample | Relative level | Duration | Note |
|---|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |  |

## ১১. Sound QA

- Voice কি সবসময় সবচেয়ে স্পষ্ট?
- কোনো sound কি শব্দের ওপর চড়ে বোঝা নষ্ট করছে?
- Tick কি অতিরিক্ত ঘন?
- Stamp কি visual impact-এর আগে বা পরে শোনা যাচ্ছে?
- Headphone, laptop speaker ও phone speaker-এ কি ফল গ্রহণযোগ্য?
- Mono fold-down-এ কি sound হারিয়ে যাচ্ছে?
- AAC encode-এর পরে কি click বা pre-echo এসেছে?
- Original voice-এর duration ও start time কি অক্ষুণ্ণ?
- কোনো unlicensed sound বা music আছে কি?
- শেষে কি abrupt audio cutoff হয়েছে, যদি না মূল voice-এই তা থাকে?
