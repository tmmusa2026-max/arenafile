# উদাহরণ: রাজনৈতিক বা স্মরণীয় ভিডিও

এটি নির্বাচন পদ্ধতির উদাহরণ, কোনো চূড়ান্ত স্ক্রিপ্ট বা রাজনৈতিক দাবি নয়। বন্ধনীর শব্দগুলো আসল সোর্স দিয়ে প্রতিস্থাপন করতে হবে।

## ধরে নেওয়া brief

- উদ্দেশ্য: সোর্সে থাকা বক্তৃতার মূল বার্তা মর্যাদাপূর্ণভাবে উপস্থাপন
- Tone: grave, reflective, confident
- Visual: abstract typography, কোনো নতুন তথ্য নয়
- Audio: ভয়েস-ওভার, music নয়, খুব কম sound accent
- Restricted: party symbol, real portrait, violence, red wash, bounce

## AI-এর creative thesis

`বার্তার ওজন typography-এর প্রকাশ ও স্থিরতায় থাকবে। সরু রেখা ও বিন্দু সময়, স্মৃতি ও সমষ্টিকে বোঝাবে। কোনো আক্রমণাত্মক বা উৎসবমুখর motion নয়।`

## দৃশ্য নির্বাচন

| Scene | Source role | Visual problem | নির্বাচন | কারণ |
|---|---|---|---|---|
| S01 | `[প্রেক্ষাপট বা উদ্ধৃতি]` | মনোযোগ তৈরি করতে হবে, তবে aggressive hook নয় | T03 Soft 3D Flip + V02 Poetic Rules + C01 Quiet Push | editorial ও reflective, text স্পষ্ট থাকে |
| S02 | `[মূল বার্তা]` | মূল শব্দ স্থির ও মনে রাখার মতো করতে হবে | T01-এর restrained variant + V09 Convergence Lines + S02 if approved | authority আছে, কিন্তু overshoot সীমিত |
| S03 | `[ইতিহাস বা ক্রম]`, সোর্সে থাকলে | সময় বোঝাতে হবে, তারিখ যোগ করা যাবে না | T05 Curtain Line Down + V03 Timeline | Trim Paths ও tick rhythm ক্রম বোঝায় |
| S04 | `[শেষ বাক্য]` | আগের motion স্থির করে মর্যাদাপূর্ণ সমাপ্তি দরকার | T20 Quiet End Hold + V04 Rings to single line + X02 | emotional resolution, হঠাৎ cut নয় |

## Dialogue SVG নির্দেশ

টেবিলের V recipes কেবল direction। প্রতিটি semantic dialogue-এর জন্য আলাদা original SVG source, unique visual signature এবং `dialogue-svg-map.json` entry তৈরি করতে হবে। পরপর উক্তিতে primary generator বা geometry এবং composition বা motion বদলাতে হবে। শুধু রং, scale বা position বদলানো যাবে না। Transition-এর shared line, dot বা ring কেবল secondary handoff motif হবে, আগের primary SVG-এর copy নয়।

## Transition reasoning

- S01 underline S02-এর convergence path-এর প্রথম segment হতে পারে।
- S02-এর ছোট dots S03 timeline-এর tick-এ converge করতে পারে, যদি এটি অর্থপূর্ণ হয়।
- S03-এর ring বা circular marker S04-এর memory ring হয়ে যেতে পারে।
- Natural pause ছোট হলে দীর্ঘ morph বাদ দিয়ে intentional cut নাও।

## বাদ দেওয়া design

| বাদ দেওয়া | কারণ |
|---|---|
| Back Out scale pop | grave tone-এর সঙ্গে সাংঘর্ষিক |
| Persistent glitch | factual ও মর্যাদাপূর্ণ বার্তাকে অস্থির দেখায় |
| Red full-screen grade | restricted color ও অতিরিক্ত aggression |
| Fast particle explosion | স্মরণ বা বক্তৃতার ওজন নষ্ট করে |
| Music swell | brief-এ music নেই |

## Reuse

- রাজনৈতিক: quote, thesis, সময়রেখা ও শেষ বাক্যে ব্যবহারযোগ্য।
- প্রোমো: শুধু motion restraint ও underline handoff reuse করা যায়, metaphor বদলাতে হবে।
- ডকুমেন্টারি: একই structure source quote, context ও reflection-এ কার্যকর।
