# উদাহরণ: Documentary বা Explainer

এটি generic workflow উদাহরণ। কোনো বাস্তব ঘটনা, তারিখ, স্থান বা ব্যক্তির তথ্য ধরে নেওয়া হয়নি।

## ধরে নেওয়া brief

- উদ্দেশ্য: source narration-এর একটি ধারণা ধাপে ধাপে বোঝানো
- Tone: editorial, calm, grounded
- Visual: abstract frame, source-approved image থাকলে সীমিত ব্যবহার
- Texture: fine grain, soft warm grade
- Audio: voice-কেন্দ্রিক, অনুমোদিত ambience না থাকলে silence

## AI-এর creative thesis

`তথ্য ধীরে ফোকাসে আসবে। Frame, path ও typography একই archive-like spatial language ব্যবহার করবে, কিন্তু কৃত্রিম পুরোনো damage বা অনুমোদনহীন ইতিহাস তৈরি করবে না।`

## দৃশ্য নির্বাচন

| Scene | Source role | Visual problem | নির্বাচন | কারণ |
|---|---|---|---|---|
| S01 | `[প্রেক্ষাপট]` | দর্শককে জায়গা বা ধারণার পরিসর দিতে হবে | V23 Structural Frame + T17 Editorial Line + C01 | editorial context, অতিরিক্ত effects নয় |
| S02 | `[মূল ধারণা]` | দীর্ঘ লাইন পড়ার সময় দরকার | T04 Focus Pull In + V02 Rules + subtle grain | ধীরে স্পষ্ট হয়, hold পর্যাপ্ত |
| S03 | `[প্রমাণ বা উদাহরণ]` | source-কে নতুন decoration-এর নিচে চাপা যাবে না | T15 Annotation Lock + V23 Frame + approved asset | evidence ও label স্পষ্ট |
| S04 | `[প্রক্রিয়া বা ক্রম]` | causality বোঝাতে হবে | V08 Flow Path + V10 Divergence, প্রয়োজন হলে + X08 | ধারণাগুলোর সম্পর্ক দৃশ্যমান |
| S05 | `[ভাবনা বা সমাপ্তি]` | তথ্য থেকে reflection-এ যেতে হবে | T07 বা T20 + X07 Focus Handoff + V20 Bokeh | soft depth, কিন্তু মূল text sharp |

## Dialogue SVG নির্দেশ

V23 বা অন্য generator family দুবার এলেও প্রতিটি semantic dialogue-এর primary SVG আলাদা source geometry, composition বা motion পাবে। প্রতিটি উক্তির জন্য unique asset ID, source file ও visual signature `dialogue-svg-map.json`-এ লিখো। Approved photo বা clip-এ ছোট dialogue-specific annotation ব্যবহার করো, evidence ঢাকবে না। Frame edge, underline বা connector secondary handoff হিসেবে চলতে পারে, duplicate primary SVG নয়।

## Source discipline

- তারিখ, location, map, quote attribution ও data কেবল source-এ থাকলে।
- Archival frame ব্যবহার করলেই asset archival বলে দাবি করা যাবে না।
- Grain ও warm grade যেন নতুন historical evidence-এর ভ্রম না তৈরি করে।
- অনুমোদিত ambient sound না থাকলে location sound বানাবে না।

## Transition reasoning

- S01 frame-এর একটি edge S02-এর underline হতে পারে।
- S02 underline S03-এর evidence connector-এ বদলাতে পারে।
- S03 connector S04 flow path-এর প্রথম অংশ হতে পারে।
- S04-এর একটি node S05-এর soft bokeh point-এ focus out করতে পারে।

## বাদ দেওয়া design

| বাদ দেওয়া | কারণ |
|---|---|
| Burn film transition | generic archival cliché |
| Heavy dust ও scratch | source-এর বয়স সম্পর্কে ভুল ধারণা দিতে পারে |
| Random map lines | অনুমোদনহীন location বোঝাতে পারে |
| অতিরিক্ত timeline ticks | information density বাড়ায় |
| Slow motion on every asset | pacing একঘেয়ে ও artificial হয় |

## Reuse

- রাজনৈতিক: context, quote ও evidence structure ব্যবহারযোগ্য, source discipline একই।
- প্রোমো: focus handoff ও process path ব্যবহার করা যায়, grain ও archival frame সাধারণত বাদ।
- ডকুমেন্টারি: পুরো structure reusable, প্রতিটি asset ও claim আসল source দিয়ে বদলাতে হবে।
