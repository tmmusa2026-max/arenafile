# 13. Quality Assurance ও Delivery

## ১. QA-এর নীতি

QA মানে শুধু ফাইল তৈরি হয়েছে দেখা নয়। Source, timeline, typography, motion, sound, encoding এবং চোখে দেখা ফল আলাদাভাবে যাচাই করতে হবে। কোনো check সত্যিকারে করা হয়নি, তাহলে `not_tested` লিখবে। `pass` লিখতে হলে প্রমাণ থাকতে হবে।

Status মান:

- `pass`: যাচাই করা হয়েছে, মানদণ্ড পূরণ
- `fail`: যাচাই করা হয়েছে, মানদণ্ড পূরণ হয়নি
- `warning`: সীমাবদ্ধতা বা ঝুঁকি আছে
- `not_tested`: এই পরিবেশে যাচাই করা যায়নি

## ২. Stage A: Content lock

- Final script ও source audio-এর মিল আছে কি?
- কোনো শব্দ বাদ, যোগ বা বদলেছে কি?
- Caption-এর spelling ও punctuation source-এর মতো কি?
- অনুমোদনহীন তথ্য, নাম, সংখ্যা, তারিখ, দাবি বা CTA আছে কি?
- সব asset-এর অনুমতি ও license নথিভুক্ত কি?
- প্রতিটি semantic dialogue-এর exact source text, unique asset ID, original SVG source file ও semantic concept কি `dialogue-svg-map.json`-এ আছে?
- Keyword echo ও chapter label-এর প্রতিটি phrase কি approved source থেকে এসেছে এবং echo required subtitle-কে replace করেনি?
- Watermark ব্যবহৃত হলে original PNG বা SVG এবং verified permission record আছে কি? Permission অস্পষ্ট asset import বাদ আছে কি?
- External media-এর actual content, source, creator, attribution ও scene relevance যাচাই করা কি?
- Generic বা archival media-কে actual event footage হিসেবে উপস্থাপন করা হয়নি তো?
- সংবেদনশীল content-এ dignity ও নিরাপত্তা বজায় আছে কি?
- Caption, headline, SVG text, label, screenshot, external media-এর baked-in text, video metadata, generated file বা filename-এ em dash বা U+2014 আছে কি?
- Source-এ U+2014 থাকলে শুধু punctuation বদলেছে এবং সব word, number ও fact অক্ষুণ্ণ কি? Replacement log আছে কি?

## ৩. Stage B: Timing ও audio

- আসল speech region ও SRT alignment যাচাই করা হয়েছে কি?
- প্রতিটি word-এর timing method ও confidence আছে কি?
- কোনো visual শব্দের পরে আসছে কি?
- প্রতিটি dialogue SVG কি তার actual speech start-এর আগে বা সঙ্গে এসেছে এবং dialogue timing map-এর সঙ্গে মেলে?
- Staged build-এর base, subject, relationship ও result কি সঠিক source phrase-এর আগে বা সঙ্গে এসেছে?
- Keyword echo-এর reveal ও accent কি actual phrase timing মেনে চলে এবং accent reveal-এর পরে আসে?
- Progress rail-এর value কি final actual duration ও current frame time থেকে এসেছে?
- Transition natural pause-এর সঙ্গে সামঞ্জস্যপূর্ণ কি?
- শেষ শব্দ পর্যন্ত caption ও headline আছে কি, brief অনুযায়ী?
- Original audio-এর start, duration ও content অক্ষুণ্ণ কি?
- Final container-এর audio, video ও total duration probe করা হয়েছে কি?
- Target duration-এর সঙ্গে পার্থক্য রিপোর্ট করা হয়েছে কি?
- Effect voice-এর তুলনায় কমপক্ষে 12 dB নিচে কি, যখন voice চলছে?
- Final AAC-তে click, gap বা offset নেই কি?

## ৪. Stage C: Typography

- সব প্রয়োজনীয় glyph আছে কি?
- যুক্তাক্ষর, কার, রেফ, ফলা নির্ভুল কি?
- কোনো অক্ষর আলাদা animate হয়নি তো?
- Letter-spacing বা tracking animation হয়নি তো, অনুমোদন ব্যতীত?
- Mask, blur, scale ও rotation-এ কোনো মাত্রা কাটছে না তো?
- Caption-এর line break phrase-aware কি?
- Caption-এ active word ঝাঁকুনি ছাড়া বদলাচ্ছে কি?
- Teal-highlighted word এবং বর্তমানে শোনা word একই কি?
- Active color word reveal-এর পরে এসেছে কি এবং previous word off-white base-এ ফিরেছে কি?
- Caption-এর বাঁ পাশে vertical bar, pipe, dash বা bullet নেই তো?
- Active word scale-এর কারণে line jump নেই কি?
- Keyword echo-এর previous phrase কি স্থির এবং echo কি whole shaped phrase-এ reveal হয়?
- Subtitle, keyword echo, chapter pill, watermark ও progress rail-এর collision নেই কি?
- Font family দুইটির বেশি নয় তো?
- Font files ও licenses bundled কি?
- Final encoded frame-এ ছোট text পড়া যাচ্ছে কি?

## ৫. Stage D: Motion

- প্রতিটি প্রধান motion-এর named curve আছে কি?
- Linear বা default ease দৃশ্যগত গতিতে আছে কি?
- Entry ও exit আলাদা designed কি?
- Stagger decreasing ও overlapping কি, যেখানে উপযুক্ত?
- কোনো velocity discontinuity বা হঠাৎ থামা আছে কি?
- Overshoot tone-এর সঙ্গে মিলে কি?
- Ambient motion 1 থেকে 2 px-এর মতো সূক্ষ্ম কি, text-এর জন্য?
- Camera drift shake-এ পরিণত হয়নি তো?
- Motion blur সব প্রাসঙ্গিক moving layer-এ আছে কি?
- 180 degree shutter equivalent sampling হয়েছে কি?
- প্রতি frame-এ কমপক্ষে 8 sub-sample হয়েছে কি, brief অনুযায়ী?
- Reduced-motion প্রয়োজন হলে তা তৈরি ও পরীক্ষা করা হয়েছে কি?

## ৬. Stage E: Visual ও compositing

- প্রথম frame থেকেই intentional composition বা motion আছে কি?
- প্রতি মুহূর্তে একটি primary focal point আছে কি?
- Background-এ subtle depth আছে কি, banding নয়?
- Color dominance ও accent hierarchy সামঞ্জস্যপূর্ণ কি?
- Restricted color শুধু অনুমোদিত জায়গায় আছে কি?
- Glow শুধু উজ্জ্বল অংশে এবং clipping ছাড়া কি?
- Shadow, gradient ও inner glow অতিরিক্ত নয় তো?
- Grain ও vignette text-এর readability নষ্ট করছে না তো?
- Chromatic aberration খুব ছোট ও সীমিত কি?
- Matte fringe, alpha darkening বা effect bounds clipping নেই কি?
- Transition-এর mid-frame-এ হাতে আঁকা মতো অর্থপূর্ণ handoff আছে কি?
- প্রতিটি dialogue-এর primary SVG কি আলাদা এবং visual signature কি duplicate নয়?
- পরপর dialogue-এর SVG-তে primary generator বা geometry এবং composition বা motion-এর অন্তত একটি কি সত্যিকারে বদলেছে?
- কোনো SVG কি শুধু color, opacity, position, scale, text বা duration-এর clone?
- Shared secondary motif কি continuity দিচ্ছে, কিন্তু primary form-কে একই রাখেনি তো?
- Real-media scene-এর dialogue annotation কি footage-এর গুরুত্বপূর্ণ অংশ ঢাকছে না?
- কোনো visual element কি সস্তা preset বা generic template ভাব দিচ্ছে?

## ৭. Proof frame protocol

চূড়ান্ত render-এর আগে প্রতি scene-এর অন্তত:

- Start: প্রথম অর্থপূর্ণ composition
- Mid: animation-এর সবচেয়ে জটিল intermediate state
- End: settled বা handoff state

এক scene-এ একাধিক dialogue থাকলে প্রতিটি dialogue-এর unique SVG-এর জন্য আলাদা start, mid ও end proof দাও। শুধু scene-level তিনটি frame দিয়ে সব dialogue SVG যাচাই করা হয়েছে বলা যাবে না। প্রতিটি proof-এ dialogue ID, asset ID ও visual uniqueness review লিখো।

প্রয়োজনে অতিরিক্ত:

- Mask reveal-এর 50 শতাংশ
- Maximum blur
- Maximum overshoot
- Particle dispersion-এর মাঝ
- Transition-এর exact midpoint
- Caption-এর দীর্ঘতম word active
- Keyword echo-এর phrase addition এবং post-reveal accent-এর আলাদা frame
- Progress rail-এর beginning, middle ও end-এর measured encoded frame
- Vertical বা square crop-এর equivalent frame

প্রস্তাবিত naming:

```text
proof/S01_start.png
proof/S01_mid.png
proof/S01_end.png
proof/S01_transition_mid.png
proof/D001_SVG_start.png
proof/D001_SVG_mid.png
proof/D001_SVG_end.png
```

Proof sheet-এ scene, time, frame number এবং QA focus লেখা যায়। On-screen final video-তে এই debug text যাবে না।

## ৮. চোখে দেখার checklist

প্রতিটি proof frame বা short preview দেখে লিখো:

- কোথায় চোখ যাচ্ছে?
- Text কি সত্যি sharp ও সম্পূর্ণ?
- Frame-এর generated বা external media-এর কোনো visible text-এ em dash বা U+2014 নেই তো?
- কোনো accidental tangency বা collision আছে কি?
- Stroke একই মানের দেখাচ্ছে কি?
- দীর্ঘ Bengali word-এর visual weight ঠিক আছে কি?
- Intermediate frame-এ shape ভেঙে যাচ্ছে কি?
- এই dialogue-এর SVG কি আগের dialogue থেকে চোখে দেখেও আলাদা এবং তার অর্থের সঙ্গে প্রাসঙ্গিক?
- Particles কি shaped source থেকে এসেছে বলে বোঝা যায়?
- আলো কি মূল বিষয়কে সাহায্য করছে?
- এই frame-টি একটি premium poster হিসেবেও কি ইচ্ছাকৃত?

শুধু স্থির frame যথেষ্ট নয়। Motion preview-এও velocity, sync এবং readable hold দেখতে হবে।

## ৯. Stage F: Technical probe

Final MP4 decode ও probe করে রিপোর্ট করো:

| Check | Expected | Measured | Status |
|---|---|---|---|
| Container | MP4 |  |  |
| Video codec | H.264 বা brief |  |  |
| Audio codec | AAC বা brief |  |  |
| Width ও height | Brief |  |  |
| Frame rate | Brief |  |  |
| Frame count | Timebase অনুযায়ী |  |  |
| Container duration | Target |  |  |
| Video duration | Target বা documented tolerance |  |  |
| Audio duration | Original target |  |  |
| Audio start offset | 0 বা source match |  |  |
| Pixel format | yuv420p বা brief |  |  |
| Color metadata | Brief |  |  |
| Bitrate | Quality target |  |  |
| Decode errors | 0 |  |  |
| Black frames | অনুমোদিত ছাড়া 0 |  |  |
| Silent gap | অনুমোদিত ছাড়া 0 |  |  |

## ১০. Final encoded review

- MP4-কে আবার decode করে proof frame তুলো।
- Raw frame এবং encoded frame-এর text, grain ও color পার্থক্য দেখো।
- অন্তত স্বাভাবিক গতিতে একবার পুরো ভিডিও review করো।
- Audio-video sync final file-এ যাচাই করো।
- Encoded video-র সব text layer, subtitle stream, external media frame ও metadata-তে U+2014 নেই যাচাই করো। Text scan দিয়ে baked-in footage ধরা যায় না, তাই representative frame ও motion preview-এর visual review বাধ্যতামূলক।
- Phone-sized preview-তে caption ও focal hierarchy দেখো।
- Progress rail-এর fill actual time-এর সঙ্গে মিলছে কি না beginning, middle ও end-এ মাপো এবং subtitle বা platform UI collision দেখো।
- Enabled watermark-এর aspect ratio, safe area এবং content-scene behavior encoded frame-এ যাচাই করো।
- Loop playback-এর ভুলে শেষে extra frame যোগ করবে না।
- Download file খুলে যাচ্ছে এবং filename সঠিক কি না দেখো।

## ১১. Delivery package

প্রস্তাবিত কাঠামো:

```text
delivery/
  index.html
  media/
    final.mp4
  source/
    project files
    scene-plan.json
    word-timing.json
    dialogue-svg-map.json
    explainer-style.json, technical explainer হলে
  assets/
    fonts ও licenses
    dialogue/
      প্রতিটি dialogue-এর আলাদা original SVG
    অন্যান্য original vectors
    verified web media
  licenses/
    external media licenses ও attribution
  proof/
    scene proof frames
    proof sheet
  reports/
    timing-table.md
    effect-map.md
    recipes.md
    sound-map.md
    dialogue-svg-validation.json
    explainer-validation.json, technical explainer হলে
    qc-report.md
  media-manifest.json
  delivery-report.json
  README.md
```

ব্যবহারকারী শুধু final video চাইলে আলাদা সহজ download দাও, কিন্তু production archive-এর জন্য source ও reports আলাদা রাখো।

## ১২. Public delivery QA

- Exact executed install, render, QC ও packaging commands কি log-এ আছে?
- Preview page-এ native video controls এবং সঠিক relative MP4 path আছে কি?
- Preview page, direct MP4 ও delivery ZIP কি আলাদা public URL হিসেবে publish হয়েছে?
- Unauthenticated request দিয়ে তিনটি URL যাচাই করা হয়েছে কি?
- MP4-এর content type ও web playback encoding সঠিক কি?
- ZIP download করে CRC বা hash যাচাই করা হয়েছে কি?
- Actual player-এ playback না দেখলে `playback_observed: false` লেখা হয়েছে কি?
- Login, expiration, region restriction বা hosting limitation স্পষ্ট লেখা হয়েছে কি?
- Fabricated URL, placeholder link বা local path-কে public link বলা হয়নি তো?

## ১৩. Final sign-off

চূড়ান্ত উত্তরে সংক্ষিপ্তভাবে দাও:

- Final file path বা link
- Verified public preview, direct MP4 ও delivery ZIP link, hosting থাকলে
- Exact executed render ও QC commands
- External media-এর source, license ও attribution report
- Exact measured specs
- ব্যবহৃত tool ও pipeline
- কোন কোন automated check pass
- কোন কোন visual check সত্যি করা হয়েছে
- কোন warning বা limitation আছে
- Source ও documentation কোথায়

কোনো public link তৈরি করা যায়নি, তাহলে public link আছে বলবে না। Workspace file দিলে সেটিকে public URL বলবে না।
