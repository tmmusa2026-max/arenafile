# 22. Dialogue-Specific SVG System

## উদ্দেশ্য

প্রতিটি semantic dialogue-এর জন্য একটি আলাদা primary SVG তৈরি হবে। কথার অর্থ, উদ্দেশ্য, আবেগ ও narrative role যেন SVG-এর geometry, composition এবং motion-এ প্রতিফলিত হয়। একই SVG বারবার ব্যবহার করে শুধু text, রং বা position বদলানো যাবে না।

## ১. Dialogue unit কী

Dialogue unit মানে একটি সম্পূর্ণ অর্থপূর্ণ উক্তি বা কথার অংশ, mechanical SRT cue নয়।

- একটি SRT cue-তে একটি সম্পূর্ণ dialogue থাকতে পারে।
- দীর্ঘ sentence কয়েকটি SRT cue-তে ভাগ থাকলে সেগুলো একই dialogue হতে পারে।
- খুব ছোট সম্পর্কিত fragments একই অর্থ চালিয়ে গেলে একটি dialogue group করো।
- প্রশ্ন এবং তার উত্তর আলাদা dialogue।
- বক্তব্য এবং তার বিপরীত দিক আলাদা dialogue হতে পারে।
- অর্থ, speaker, প্রশ্নের ধরন বা narrative role বদলালে নতুন dialogue unit শুরু করো।

প্রতিটি dialogue-এর actual audio start ও end থাকবে। SRT guide, actual speech timing primary।

## ২. প্রতি dialogue-এর আলাদা SVG বাধ্যতামূলক

প্রতিটি dialogue unit-এর জন্য:

```text
dialogue_id
exact_source_text
actual_start
actual_end
speech_act
semantic_focus
emotion
narrative_role
unique_svg_asset_id
unique_visual_signature
```

একটি dialogue-এর primary SVG অন্য dialogue-এর primary SVG-এর হুবহু copy হতে পারবে না। আলাদা `asset_id` দিয়ে একই visual duplicate রাখাও গ্রহণযোগ্য নয়।

## ৩. শুধু variation নয়, meaningful difference

নতুন dialogue-এর SVG-এর সঙ্গে আগেরটির তুলনায়:

1. Primary generator বা geometry signature বদলাতে হবে।
2. Composition বা motion signature-এর অন্তত একটি বদলাতে হবে।
3. `difference_from_previous` ফিল্ডে প্রকৃত পার্থক্য লিখতে হবে।
4. `visual_signature` আলাদা হতে হবে।

নিচের পরিবর্তন একা যথেষ্ট নয়:

- শুধু hue বা color
- শুধু opacity
- শুধু X বা Y position
- শুধু scale
- একই path-এর অল্প length change
- একই layout-এ text বদলানো
- একই animation-এর শুধু duration বদলানো

Brand palette, font এবং visual tone consistent থাকবে। Uniqueness মানে visual chaos নয়।

## ৪. Dialogue analysis

প্রতিটি উক্তি থেকে নির্বাচন করো:

| Analysis | প্রশ্ন |
|---|---|
| Speech act | প্রশ্ন, বক্তব্য, উত্তর, তুলনা, নির্দেশ, সতর্কতা, প্রতিশ্রুতি, স্মৃতি নাকি অন্যকিছু? |
| Semantic focus | মূল ব্যক্তি, বস্তু, সম্পর্ক, প্রক্রিয়া, সময়, স্থান বা ধারণা কী? |
| Narrative role | Hook, context, evidence, turn, peak, resolve নাকি অন্য? |
| Emotion | Grave, warm, urgent, hopeful, curious, confident নাকি অন্য? |
| Visual problem | দর্শক কী বুঝলে SVG সাহায্য করবে? |
| Continuity | আগের dialogue থেকে কোন secondary motif এগিয়ে যেতে পারে? |

Keyword দেখে আকার বাছাই করবে না। পুরো sentence-এর অর্থ এবং আশেপাশের dialogue বিবেচনা করো।

## ৫. Speech act থেকে original SVG direction

| Dialogue type | সম্ভাব্য primary SVG direction | Motion direction |
|---|---|---|
| প্রশ্ন | Open path, unresolved endpoint, incomplete geometry | Endpoint search, controlled opening |
| স্পষ্ট বক্তব্য | Anchored structure, resolved frame, stable nodes | Settle, align, quiet emphasis |
| উত্তর | Previously open form-এর নতুন resolved geometry | Close, connect, resolve |
| তুলনা | Asymmetric dual forms, split space, unequal paths | Counter movement, matched comparison |
| প্রক্রিয়া | Original flow path, staged nodes, directional connector | Trim path, sequential activation |
| সময় বা ইতিহাস | Timeline, layered traces, chronological markers | Progressive draw, temporal travel |
| সংযোগ | Unique node topology, bridge, convergence path | Signal travel, gather |
| ভাঙন বা ক্ষয় | Fragmenting contour, dissolving geometry | Controlled separation, decay |
| সতর্কতা | Restricted enclosure, narrowing path, boundary form | Compression, restrained alert accent |
| আশা বা উন্নতি | Rising path, expanding aperture, upward geometry | Lift, open, breathe |
| সংখ্যা | Approved data-driven chart বা measured geometry | Accurate reveal, no invented values |
| ব্যক্তি বা স্থান | Original map, portrait frame, location connector, প্রযোজ্য হলে | Focus, annotate, contextual handoff |

এগুলো starting direction, fixed template নয়। একই dialogue type-এর দুটি উক্তিতেও ভিন্ন metaphor এবং geometry তৈরি করো।

## ৬. Real media-এর সঙ্গে SVG

News photo বা video clip ব্যবহার হলেও dialogue-specific SVG থাকবে, তবে তা হতে পারে:

- ছোট location connector
- Source-approved data marker
- Unique frame বা mask
- Person বা object-এর annotation path
- Timeline segment
- Contextual underline বা boundary
- Clip-এর অর্থের সঙ্গে সম্পর্কিত minimal geometry

Real footage ঢেকে বড় decorative SVG দেওয়ার দরকার নেই। ছোট হলেও primary SVG-এর semantic কাজ এবং আলাদা visual signature থাকতে হবে।

## ৭. Continuity রক্ষা করে আলাদা করো

আলাদা SVG মানে পরস্পরনিরপেক্ষ scene নয়।

- আগের SVG-এর একটি secondary motif পরেরটিতে আসতে পারে।
- Shared color, stroke behavior বা material consistency থাকতে পারে।
- আগের path-এর endpoint পরের নতুন geometry-এর শুরু হতে পারে।
- Previous SVG সম্পূর্ণভাবে morph করে next SVG হলে next-এর geometry এবং composition সত্যিকারে নতুন হতে হবে।
- Shared motif-এর কারণে primary visual signature একই রাখা যাবে না।

Continuity-এর জন্য আগের SVG-এর ছোট অংশ reuse করা যায়, কিন্তু `continuity_from` এবং `difference_from_previous` লিখতে হবে।

## ৮. Repeated বা similar dialogue

একই ধরনের কথা বারবার এলে:

- প্রথম occurrence-এর base concept থেকে নতুন stage তৈরি করো।
- Repetition জোরালো হলে geometry-এর density, openness, direction বা structure বদলাও।
- একই প্রশ্ন ফিরলে আগের unresolved form-এর নতুন state ব্যবহার করতে পারো।
- উত্তর এলে আগের open form-এর সঙ্গে সম্পর্কিত কিন্তু আলাদা resolved form দাও।
- শুধু color বা scale বদলে repetition দেখাবেন না।

## ৯. File ও metadata structure

প্রতিটি dialogue-এর original SVG আলাদা file হিসেবে রাখো:

```text
assets/
  dialogue/
    D001.svg
    D002.svg
    D003.svg
project/
  dialogue-svg-map.json
```

প্রতিটি SVG-এর জন্য `dialogue-svg-map.json`-এ রাখো:

```text
dialogue_id
source_text
start
end
speech_act
semantic_focus
emotion
asset_id
concept
primary_generator
geometry_signature
composition_signature
motion_signature
visual_signature
difference_from_previous
continuity_from
shared_motif
source_file
original
```

SVG-এর ভেতরে Bengali text রাখলে verified shaping প্রয়োজন। SVG text, metadata ও filename-এ U+2014 নিষিদ্ধ।

## ১০. Validation rule

`validation/src/dialogue-svg.js` নিচের কাজ করে:

- Dialogue ID unique কি না
- SVG asset ID unique কি না
- Actual start ও end valid কি না
- SVG source file আলাদা, safe relative path এবং original status আছে কি না
- Visual signature সত্যিকারে unique কি না
- Signature-এর ভেতরের generator, geometry, composition ও motion মিলছে কি না
- আগের dialogue থেকে primary এবং অন্তত একটি secondary difference আছে কি না
- শুধু color-only clone বাদ পড়ছে কি না
- `requireProof: true` দিলে প্রতি dialogue-এর অন্তত তিনটি আলাদা proof path আছে কি না
- `rootDir` দিলে referenced SVG file সত্যিকারে project root-এর ভেতরে আছে কি না

Completed production map যাচাই করতে `allowEmpty: false`, `requireProof: true` এবং project-এর `rootDir` ব্যবহার করো। Generic template-এর জন্য empty map অনুমোদিত। Package regression চালাতে `npm run test:dialogue-svg` ব্যবহার করো।

এই validation creative quality-এর বিকল্প নয়। Final renderer-এর proof frame-এ আলাদা SVG-এর পাঠযোগ্যতা ও relevance দেখতে হবে।

## ১১. Dialogue SVG QA

- প্রতিটি semantic dialogue-এর একটি primary SVG আছে কি?
- দুটি dialogue-এর primary SVG হুবহু একই কি?
- পার্থক্য কি শুধু color, opacity, position বা scale-এর?
- SVG-এর অর্থ dialogue-এর sentence context-এর সঙ্গে মেলে কি?
- Question, answer, comparison, process ও resolve-এর visual behavior আলাদা কি?
- Shared motif continuity দিচ্ছে, কিন্তু primary form একই নয় তো?
- SVG entry actual dialogue-এর আগে বা সঙ্গে, পরে নয় তো?
- Real media-এর সঙ্গে SVG collision বা clutter হচ্ছে না তো?
- সব SVG original বা approved source থেকে তৈরি কি?
- Bengali shaping, U+2014 এবং encoded proof পরীক্ষা করা হয়েছে কি?

প্রতিটি dialogue-এর start, mid ও end frame দেখে relevance এবং uniqueness লিখতে হবে। একই proof frame বা contact sheet দিয়ে সব dialogue-এর pass দাবি করা যাবে না।

## ১২. Staged technical build

Technical explainer-এ একটি dialogue-এর primary SVG কয়েকটি meaningful state-এ তৈরি হতে পারে। Base, subject, relationship ও result layer actual speech beat-এ যোগ হবে। এটি একই dialogue-এর ভেতরের choreography, পরের dialogue-এর uniqueness-এর বিকল্প নয়।

- Base বা context dialogue শুরুর আগে বা প্রথম phrase-এ প্রস্তুত করো।
- Subject উচ্চারণের সঙ্গে মূল geometry আনো।
- সম্পর্ক বা প্রক্রিয়ার phrase-এ connector, topology বা comparison যোগ করো।
- ফলের phrase-এ success, error বা resolution দেখাও, আগে ফল উল্টে দেবে না।
- আগের layer-এর semantic role স্থির রাখো এবং readable hold দাও।
- প্রতিটি beat-এর `start`, `source_phrase`, `visual_change` ও `purpose` scene plan-এ লিখো।
- পরের dialogue-এ নতুন source SVG এবং নতুন primary geometry বা generator দরকার। আগের SVG-তে শুধু নতুন state, color বা text যোগ করে সেটি পূরণ করা যাবে না।

Browser playback, device comparison, container anatomy, API conversation, code handoff, terminal result এবং data transformation-এর reusable directions `23_TECHNICAL_EXPLAINER_LANGUAGE.md` ও `libraries/explainer-recipes.json`-এ আছে। এগুলো finished SVG template নয়।
