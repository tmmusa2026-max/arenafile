# প্রজেক্ট ব্রিফ

এটি reusable project brief। Initial intake-এ AI বাংলায় শুধু voice-over ও SRT চাইবে এবং এই ফাইল পূরণ করার জন্য অতিরিক্ত প্রশ্ন করবে না। ব্যবহারকারী অতিরিক্ত brand বা delivery নির্দেশ দিতে চাইলে এই ফাইল ব্যবহার করুন। যা জানা নেই তাতে `অনির্ধারিত` লিখুন। দুটি input পাওয়ার পরে AI নিরাপদ default নিয়ে এগোবে এবং শুধু গুরুত্বপূর্ণ blocker-এ প্রশ্ন করবে।

## ১. পরিচয়

- প্রজেক্টের নাম:
- সংস্করণ:
- দায়িত্বপ্রাপ্ত ব্যক্তি বা দল:
- ডেলিভারির তারিখ:

## ২. উদ্দেশ্য

- ভিডিওটি কেন বানানো হচ্ছে:
- দর্শক কারা:
- দর্শক কী বুঝবে, অনুভব করবে বা করবে:
- ভিডিওর ধরন: রাজনৈতিক / প্রোডাক্ট প্রোমো / ডকুমেন্টারি / এক্সপ্লেইনার / ব্র্যান্ড / সোশ্যাল / অন্যান্য
- এক বাক্যে মূল বার্তা:
- পছন্দের আবেগ, সর্বোচ্চ ৩টি:
- অপছন্দের আবেগ বা ধাঁচ:

## ৩. কনটেন্ট

- চূড়ান্ত স্ক্রিপ্টের ফাইল:
- ভয়েস-ওভার ফাইল:
- SRT বা transcript ফাইল:
- on-screen language:
- Caption দরকার: হ্যাঁ / না
- Subtitle base color: `#F5F7FA`
- Active spoken word color: `#2ED3A6`
- Word reveal-এর পরে actual speech highlight: হ্যাঁ
- Leading vertical bar, pipe, dash বা bullet: না
- প্রতিটি semantic dialogue-এর আলাদা original primary SVG: হ্যাঁ
- Dialogue SVG map: `project/dialogue-svg-map.json`
- Technical explainer style: `project/explainer-style.json`, প্রযোজ্য হলে
- Semantic keyword echo দরকার: হ্যাঁ / না, তবে এটি verbatim subtitle-এর বিকল্প নয়
- Source-supported chapter pill: প্রয়োজন হলে
- Actual global timeline progress rail: হ্যাঁ / না
- Color-only, position-only বা scale-only SVG clone: না
- বাধ্যতামূলক on-screen শব্দ বা phrase:
- কোনো তথ্য, নাম, সংখ্যা বা তারিখ বদলানো যাবে কি:
- নতুন তথ্য যোগের অনুমতি: না / শুধু অনুমোদনের পর
- সংবেদনশীল বিষয় বা এড়াতে হবে এমন চিত্র:

## ৪. অডিও

- ভয়েস-ওভার অপরিবর্তিত থাকবে: হ্যাঁ / না
- অডিওর নির্দিষ্ট দৈর্ঘ্য, জানা থাকলে:
- Music অনুমোদিত: হ্যাঁ / না
- Ambience অনুমোদিত: হ্যাঁ / না
- Text tick: হ্যাঁ / না / প্রয়োজন অনুযায়ী
- Soft headline stamp: হ্যাঁ / না / প্রয়োজন অনুযায়ী
- Whoosh বা অন্য effect:
- Sound reference:
- Loudness target, থাকলে:

## ৫. দৈর্ঘ্য ও প্ল্যাটফর্ম

- চূড়ান্ত দৈর্ঘ্য: অডিওর সমান / নির্দিষ্ট:
- Resolution: 1920 x 1080 / 1080 x 1920 / 1080 x 1080 / অন্যান্য
- Frame rate: 30 / 60 / অন্যান্য
- Aspect ratio:
- প্ল্যাটফর্ম:
- Safe area বা UI overlap:
- আলাদা cutdown দরকার:

## ৬. ভিজ্যুয়াল পরিচয়

- Brand color:
- Background color:
- Primary accent:
- Secondary accent:
- Restricted color ও তার ব্যবহার:
- Font file বা font family:
- সর্বোচ্চ font family: 2
- Logo বা watermark file:
- Watermark permission status: required / verified / not_applicable
- Permission অস্পষ্ট হলে watermark import: না
- অন্যান্য brand rule:
- Visual style: abstract / editorial / minimal / cinematic / technical / organic / অন্যান্য
- Background texture:
- পছন্দের reference ও কেন পছন্দ:
- অপছন্দের reference ও কেন অপছন্দ:

## ৭. Asset

| ফাইল | ধরন | ব্যবহার বাধ্যতামূলক? | লাইসেন্স বা অনুমতি | মন্তব্য |
|---|---|---|---|---|
|  |  |  |  |  |

- AI দিয়ে নতুন raster image তৈরির অনুমতি:
- শুধু মৌলিক vector ব্যবহার করতে হবে কি:
- প্রতিটি dialogue-এর জন্য আলাদা `.svg` source file এবং unique visual signature বাধ্যতামূলক: হ্যাঁ
- Real-media scene-এ ছোট dialogue-specific SVG annotation অনুমোদিত: হ্যাঁ, footage না ঢাকলে
- ছবি বা footage ব্যবহার করা যাবে কি:
- বাইরে থেকে asset download করা যাবে কি:
- News বা documentary প্রসঙ্গে rights-verified photo ও short clip ব্যবহার করা যাবে কি:
- Generic বা archival media হলে স্পষ্ট label দরকার কি:
- Verified media না পেলে মৌলিক SVG fallback অনুমোদিত কি:
- প্রতিটি external asset-এর source, creator, license ও attribution record বাধ্যতামূলক: হ্যাঁ

## ৮. মোশন নির্দেশনা

- সামগ্রিক গতি: restrained / balanced / energetic
- Camera movement:
- 3D depth:
- Particle:
- Distortion বা glitch:
- Overshoot বা bounce:
- Transition পছন্দ:
- Transition অপছন্দ:
- Motion sensitivity বা accessibility সীমা:
- বিশেষ কোনো effect বাধ্যতামূলক:
- বিশেষ কোনো effect নিষিদ্ধ:

## ৯. Technical delivery

- Render engine: Node.js / অন্যান্য
- System FFmpeg ছাড়া চলতে হবে: হ্যাঁ / না
- System Python ছাড়া চলতে হবে: হ্যাঁ / না
- HTML canvas নিষিদ্ধ: হ্যাঁ / না
- শুধু `npm install` ও `npm run render`: হ্যাঁ / না
- Temporal sub-sample, সর্বনিম্ন: 8
- Shutter angle: 180 degree
- Video codec: H.264
- Audio codec: AAC
- Bitrate বা quality target:
- Color space: Rec.709 / অন্যান্য
- Alpha channel দরকার: না / হ্যাঁ, ফর্ম্যাট:
- Source project দরকার: হ্যাঁ / না
- Editable scene config দরকার: হ্যাঁ / না

## ১০. বাধ্যবাধকতা

- ভিডিওতে অবশ্যই যা থাকবে:
- ভিডিওতে যা থাকবে না:
- ভিডিওর visible text, caption, SVG, external media text, metadata ও generated files-এ em dash বা U+2014 নিষিদ্ধ: হ্যাঁ
- Duplicate dialogue SVG asset বা visual signature নিষিদ্ধ: হ্যাঁ
- পরপর dialogue-এ primary generator বা geometry এবং composition বা motion বদলানো বাধ্যতামূলক: হ্যাঁ
- Legal বা policy সীমা:
- Font ও asset license সীমা:
- File size সীমা:
- Public download link দরকার: হ্যাঁ / না
- Playable public preview page দরকার: হ্যাঁ / না
- Direct public MP4 link দরকার: হ্যাঁ / না
- সম্পূর্ণ delivery ZIP-এর public link দরকার: হ্যাঁ / না
- Public upload-এর অনুমতি আছে: হ্যাঁ / না / sensitive content হলে আবার জিজ্ঞেস করবে
- Approved hosting বা connected publishing tool:
- Exact executed render command log দরকার: হ্যাঁ

## ১১. QA ও অনুমোদন

- কে final content অনুমোদন করবে:
- কে brand অনুমোদন করবে:
- প্রমাণ ফ্রেম দরকার: প্রতি দৃশ্যের শুরু, মাঝ, শেষ এবং প্রতিটি dialogue SVG-এর আলাদা শুরু, মাঝ, শেষ / অন্যান্য
- Dialogue SVG map ও visual uniqueness review দরকার: হ্যাঁ
- Keyword echo timing ও stable layout review, প্রযোজ্য হলে: হ্যাঁ
- Progress rail-এর beginning, middle ও end encoded proof, প্রযোজ্য হলে: হ্যাঁ
- Watermark permission ও safe-area review, প্রযোজ্য হলে: হ্যাঁ
- Automated probe দরকার: হ্যাঁ / না
- Word timing table দরকার: হ্যাঁ / না
- Effect map দরকার: হ্যাঁ / না
- Reusable recipe documentation দরকার: হ্যাঁ / না

## ১২. AI-এর জন্য অতিরিক্ত নির্দেশ

এখানে শুধু এই প্রজেক্টের বিশেষ নির্দেশ লিখুন। পুরোনো ভিডিওর নির্দেশ অনুলিপি করে অপ্রাসঙ্গিক নিয়ম যোগ করবেন না।


## AI পূরণ করবে: নেওয়া default

| বিষয় | নেওয়া default | কারণ | ব্যবহারকারীর অনুমোদন দরকার? |
|---|---|---|---|
|  |  |  |  |
