# Premium Motion Prompt System 2.5.0

এটি একটি **reference-free, reusable motion design prompt এবং validation toolkit**। এখানে কোনো reference video, sample scene, visual proof sheet বা অনুকরণযোগ্য motion template নেই।

উদ্দেশ্য হলো AI যেন কোনো তৈরি করা নমুনা অনুসরণ না করে বর্তমান brief, source content, audio, brand এবং platform থেকে মৌলিক সিদ্ধান্ত নেয়।

## Autonomous Bengali workflow

1. AI প্রথম উত্তরে বাংলায় শুধু voice-over ও SRT চাইবে। একটি ফাইল দেওয়া থাকলে শুধু অন্যটি চাইবে।
2. ফাইল দুটি পেলে actual audio timing বিশ্লেষণ করে নিজে scene, প্রতিটি semantic dialogue-এর আলাদা original SVG, animation, transition ও sound নির্বাচন করবে।
3. News, documentary বা real-world প্রসঙ্গে প্রয়োজনীয় photo ও short video clip খুঁজবে, তবে relevance, license ও attribution verified না হলে ব্যবহার করবে না।
4. Generic বা archival media-কে actual event footage বলবে না। Verified relevant media না পেলে মৌলিক SVG fallback ব্যবহার করবে।
5. প্রকৃত executed install, render, QC ও packaging commands `delivery-report.json`-এ লিখবে।
6. প্রকৃত hosting থাকলে playable public preview, direct MP4 এবং সম্পূর্ণ delivery ZIP-এর আলাদা verified link দেবে।
7. Hosting বা playback verification না থাকলে সত্যটি বাংলায় বলবে, fabricated public link দেবে না।

পূর্ণ নিয়ম `20_AUTONOMOUS_MEDIA_AND_PUBLIC_DELIVERY.md`-এ আছে।

## Premium subtitle default

- Caption bottom-center এবং responsive safe area-এর মধ্যে থাকবে।
- Base text `#F5F7FA`, বর্তমানে উচ্চারিত word teal-green `#2ED3A6`।
- প্রতিটি shaped word সূক্ষ্ম mask, opacity, offset ও blur দিয়ে reveal হবে, অক্ষর আলাদা করে নয়।
- Word reveal-এর পরে actual speech timing-এ highlight আসবে। Previous word base color-এ ফিরবে এবং line layout লাফাবে না।
- Default alternate highlight মানে base ও active state-এর পরিবর্তন। Optional two-color mode আলাদা config-এ চালু করা যায়।
- বাঁ পাশে vertical bar, pipe, dash, bullet এবং কোনো U+2014 থাকবে না।
- পূর্ণ recipe `21_PREMIUM_SUBTITLE_SYSTEM.md` এবং `project/subtitle-style.json`-এ আছে।

## Dialogue-specific original SVG default

- প্রতিটি semantic dialogue-এর জন্য একটি আলাদা original primary SVG এবং unique asset ID থাকবে। Mechanical SRT cue-কে সবসময় আলাদা dialogue ধরা হবে না।
- SVG-এর design dialogue-এর speech act, semantic focus, emotion, narrative role ও actual timing থেকে আসবে।
- পরপর dialogue-এর primary generator বা geometry এবং composition বা motion-এর অন্তত একটি বদলাতে হবে।
- শুধু color, opacity, position, scale, text বা duration বদলানো clone নতুন SVG নয়।
- Shared secondary motif দিয়ে continuity রাখা যাবে, কিন্তু duplicate primary visual signature নয়।
- Real-media scene-এ ছোট meaningful dialogue-specific SVG annotation ব্যবহার করা যাবে, footage ঢাকা যাবে না।
- Map template `project/dialogue-svg-map.json`, policy `22_DIALOGUE_SPECIFIC_SVG_SYSTEM.md`, এবং validator `validation/src/dialogue-svg.js`-এ আছে।

## Technical explainer default

- Verbatim bottom subtitle এবং composition-এর semantic keyword echo আলাদা layer। Keyword echo কখনো subtitle-এর বিকল্প নয়।
- Keyword phrase আগে shape ও measure করে stable layout-এ ধাপে reveal হয়, accent reveal-এর পরে আসে এবং অক্ষর split হয় না।
- Dialogue-specific SVG-এর base, subject, relationship ও result layer actual speech beat-এ যোগ হয়।
- Optional top-right chapter pill source-supported topic দেখায় এবং নতুন fact যোগ করে না।
- Optional bottom progress rail actual `current_time / actual_duration` ব্যবহার করে, fake loading বা scene-only progress নয়।
- Watermark default disabled। Original PNG বা SVG এবং verified permission ছাড়া import বা extraction নয়।
- পূর্ণ নিয়ম `23_TECHNICAL_EXPLAINER_LANGUAGE.md`, config `project/explainer-style.json`, এবং tests `validation/tests/explainer.test.js`-এ আছে।

## গুরুত্বপূর্ণ নীতি

- Validation output কখনো visual style guide নয়।
- Generic example-এর timing actual audio-এর বিকল্প নয়।
- ক্যাটালগের সব effect এক ভিডিওতে ব্যবহার বাধ্যতামূলক নয়।
- প্রতিটি selection-এর narrative বা functional কারণ থাকতে হবে।
- Complex script-এর অক্ষর split নয়, word, phrase বা line-level shaping ও animation।
- Actual voice-over থাকলে SRT-এর বদলে actual speech timing অগ্রাধিকার পাবে।
- কোনো তথ্য, নাম, সংখ্যা, তারিখ বা দাবি অনুমোদন ছাড়া যোগ করা যাবে না।
- ভিডিওর caption, headline, SVG text, external media-এর visible text ও metadata-সহ কোনো generated file বা filename-এ em dash বা U+2014 নিষিদ্ধ। Encoded video-তেও এটি পরীক্ষা করতে হবে।

## AI-কে দেওয়ার নিয়ম

1. AI-কে এই package, `MASTER_PROMPT.md`, `ROUTER.md` এবং `20_AUTONOMOUS_MEDIA_AND_PUBLIC_DELIVERY.md` দিন।
2. এর প্রথম Bengali intake-এ voice-over ও SRT দিন। আলাদা effect, SVG বা footage list দেওয়ার দরকার নেই।
3. অতিরিক্ত brand বা delivery নির্দেশ দিতে চাইলে `project/PROJECT_BRIEF.md` ব্যবহার করুন, তবে initial intake-এ এটি বাধ্যতামূলক নয়।
4. AI router-এর নির্বাচিত modules পড়ে analysis, creative route, scene plan, media selection, implementation এবং project-specific QA করবে।
5. Public delivery-এর জন্য connected hosting থাকলে সেটি ব্যবহার করবে। না থাকলে local files এবং প্রয়োজনীয় hosting access জানাবে।

ছোট context-এ `PROMPT_COMPACT.md` ব্যবহার করা যায়, তবে hard constraints বাদ দেওয়া যাবে না।

## মূল ফাইল

| File | কাজ |
|---|---|
| `MASTER_PROMPT.md` | পূর্ণাঙ্গ adaptive master prompt |
| `PROMPT_COMPACT.md` | ছোট context-এর prompt |
| `ROUTER.md` | Task ও genre অনুযায়ী module selection |
| `project/PROJECT_BRIEF.md` | নতুন ভিডিওর পূরণযোগ্য brief |
| `01` থেকে `03` | Direction, audio-first timing, motion system |
| `04` থেকে `06` | Typography, text recipes, original SVG system |
| `07` থেকে `11` | Effects, compositing, camera, sound, Node pipeline |
| `12` থেকে `14` | Selection, QA, output contract |
| `15` থেকে `19` | Capability, continuity, failure prevention, performance, scored QA |
| `20_AUTONOMOUS_MEDIA_AND_PUBLIC_DELIVERY.md` | Bengali intake, autonomous web media, command log, public preview ও ZIP delivery |
| `21_PREMIUM_SUBTITLE_SYSTEM.md` | Stable word reveal, actual speech highlight, teal active word এবং no-bar subtitle recipe |
| `22_DIALOGUE_SPECIFIC_SVG_SYSTEM.md` | প্রতিটি semantic dialogue-এর অর্থভেদে আলাদা original SVG, uniqueness ও continuity |
| `23_TECHNICAL_EXPLAINER_LANGUAGE.md` | Stable keyword echo, staged technical graphics, chapter pill, actual progress rail ও watermark permission |

## Machine-readable system

- `schemas/`: Project, scene plan, word-timing, media manifest, delivery report, subtitle style, dialogue SVG map এবং explainer style validation
- `libraries/`: Easings, text, subtitle, vector, dialogue SVG, explainer, transition, sound, selection, capability, media sourcing, public delivery, router, responsive budget, QA এবং versions
- `project/public-preview.template.html`: Relative MP4 ও ZIP path-এর native video preview template
- `project/subtitle-style.json`: Off-white base, teal active word এবং no-decoration subtitle config
- `project/explainer-style.json`: Stable keyword echo, actual timeline rail এবং disabled-by-default authorized watermark config
- `project/dialogue-svg-map.json`: প্রতিটি dialogue-এর unique SVG source, timing ও visual signature-এর template
- `examples/`: Political, product promo ও documentary workflow
- `examples/machine-readable/`: Generic structure examples, rendered reference নয়
- `validation/`: Generic technical tests, bundled test fonts এবং synthetic audio

## Validation commands

এই package নিজে video render করে না। তাই এখানে `npm run render` command ইচ্ছাকৃতভাবে নেই।

```bash
npm install
npm run preflight
npm run benchmark:fonts
npm run benchmark:audio
npm run test:rules
npm run test:delivery
npm run test:text
npm run test:subtitle
npm run test:dialogue-svg
npm run test:explainer
npm run test:tmix
```

Optional local font diagnostics:

```bash
npm run benchmark:fonts -- --write-proof
```

Diagnostic images package-এ দেওয়া নেই। Command চালালে স্থানীয় `validation/proof/` তৈরি হবে এবং visual review আলাদা করতে হবে।

সর্বশেষ generic validation ফল `validation/reports/validation-summary.md`-এ আছে।

Synthetic benchmark audio পুনরায় তৈরি করতে:

```bash
npm run generate:benchmark
```

## 25 MB size policy

ZIP-এ নিচের জিনিস রাখা হয় না:

- Reference বা rendered video
- Video scene source ও visual proof frames
- `node_modules`, cache বা build output
- অনুকরণযোগ্য sample composition
- অপ্রয়োজনীয় footage, imagery বা large audio

শুধু prompt, reusable libraries, compact examples এবং generic validation assets থাকে। `MANIFEST.json`-এ final file hashes, individual sizes এবং hashed payload size থাকে।

## নতুন ভিডিওর delivery

নতুন প্রজেক্টে AI-কে তার নিজের source, scene plan, assets এবং renderer তৈরি করতে হবে। Node-only brief হলে `11_NODE_RENDER_PIPELINE.md` অনুসারে project-specific `npm install` ও `npm run render` তৈরি করতে হবে। এই prompt package-এর validation scripts সেই renderer-এর বিকল্প নয়।

Final production project-এ actual proof frames, প্রতিটি dialogue-এর আলাদা SVG source ও start, mid, end proof, dialogue SVG map validation, encoded QC, measured duration, resolution, fps, codecs, exact command log, media manifest এবং known limitations দিতে হবে। প্রকৃত hosting থাকলে `index.html`, direct MP4 ও delivery ZIP publish করে public access যাচাই করতে হবে। Playback দেখা না গেলে HTTP availability এবং playback observation আলাদা রাখতে হবে। এই package-এর generic test pass-কে সেই ভিডিওর final QC বলা যাবে না।
