# 15. Effect Capability Matrix

## উদ্দেশ্য

একই effect-এর নাম শুনলে ধরে নেওয়া যায় না যে প্রতিটি tool-এ একই মানের ফল পাওয়া যাবে। নির্বাচনের আগে capability, fallback, performance এবং project-specific verification দেখতে হবে।

এই package prompt-only। এখানে কোনো visual effect rendered বা verified বলে চিহ্নিত নয়। Generic validation tests শুধু নির্দিষ্ট technical scope প্রমাণ করে।

## Status-এর অর্থ

- `native`: নির্বাচিত tool-এর built-in নির্ভরযোগ্য feature
- `equivalent`: আলাদা পদ্ধতি, কিন্তু project proof-এ একই দৃশ্যগত উদ্দেশ্য পূরণ করে
- `custom`: নিজের geometry, math, shader বা compositing লাগবে
- `partial`: কিছু অংশ সম্ভব, সীমাবদ্ধতা document করতে হবে
- `untested`: এই প্রজেক্টে প্রমাণিত নয়
- `unsupported`: নির্বাচিত runtime-এ বাস্তবায়নযোগ্য নয়, creative route বা engine বদলাতে হবে

`untested` কখনো `pass` নয়। `equivalent` লিখতে হলে project-specific proof frame বা measurable result লাগবে।

## ১. Core selection matrix

| Required result | After Effects route | Node বা vector equivalent | সাধারণ cost | Project-এর আগে status |
|---|---|---|---|---|
| Bengali shaping | Native text engine | Pango-HarfBuzz বা verified shaped glyph paths | Low | Font benchmark ছাড়া untested |
| Whole-word transform | Text animator | Shaped word, phrase বা line group | Low | Project proof দরকার |
| Mask reveal | Mask and track matte | SVG mask বা alpha matte | Medium | Project proof দরকার |
| Soft mask | Feathered mask | Filtered matte, expanded bounds | Medium to high | Project proof দরকার |
| Gradient text | Gradient Overlay | User-space gradient clipped to text | Low | Project proof দরকার |
| Text shimmer | Track matte | Animated gradient clipped to shaped text | Low to medium | Project proof দরকার |
| Entry blur | Gaussian Blur | Native filter বা separable convolution | High on large regions | Project proof দরকার |
| Glow pulse | Thresholded Glow | Event-specific blurred accent and light | High if persistent | Project proof দরকার |
| Trim Paths | Shape operator | Analytic endpoints, dash offset, path sampling | Low to medium | Project proof দরকার |
| Repeater | Shape operator | Deterministic instances or vector pattern | Low to medium | Project proof দরকার |
| Merge Paths | Shape operator | Shared geometry or vector Boolean | Medium to high | Project proof দরকার |
| Offset Paths | Shape operator | Geometric contour offset | High for complex paths | Project proof দরকার |
| Text particles | Particle simulator | Shaped alpha sampling with deterministic points | Medium to high | Project proof দরকার |
| Bokeh | Camera Lens Blur | Radial discs or depth-scaled particles | Medium | Optical DOF বলা যাবে না |
| Camera push | 3D camera | Documented 2.5D transform or real 3D engine | Low to high | 2.5D এবং 3D আলাদা লিখতে হবে |
| Parallax | 3D layers | Independent depth-layer transforms | Medium | Project proof দরকার |
| Motion blur | Layer and camera shutter | Temporal sub-samples with documented shutter | High | Visual and frame-count proof দরকার |
| Film grain | Add Grain | Deterministic final-resolution noise | Low to medium | Encoded proof দরকার |
| Vignette | Mask and gradient | Radial gradient or color operation | Low | Project proof দরকার |
| Chromatic effect | Channel effects | Offset channels or palette-safe copies | Medium | Tone এবং proof দরকার |
| Element morph | Shape and matte animation | Shared geometry and interpolated operators | Medium to high | Midpoint proof দরকার |
| Sound synthesis | Audio effects or external | Deterministic PCM oscillators and filtered noise | Low | Actual audio analysis দরকার |
| AAC mux | Adobe Media Encoder | Bundled FFmpeg | Medium | ffprobe and decode দরকার |

## ২. Advanced effects

| Effect | Capability decision | প্রয়োজন | সতর্কতা |
|---|---|---|---|
| True 3D camera solve | Specialist 3D engine | Feature tracking and projection solve | SVG transform দিয়ে দাবি নয় |
| Depth-aware DOF | Custom or specialist engine | Depth buffer or per-layer depth blur | Simple bokeh-কে optical DOF বলা নয় |
| Liquify | Custom mesh | Weighted deformation | Glyph readability QA |
| Displacement Map | Custom pixel or mesh | UV remap and interpolation | Full-frame cost high |
| Turbulent Displace | Custom field | Coherent noise and UV sampling | Fixed seed and motion proof |
| Keylight | Native or custom matte | Chroma distance and spill suppression | Provided footage only |
| Rotoscoping | Specialist tool | Temporal matte propagation | Manual proof needed |
| Warp Stabilizer | Specialist tool | Feature tracking and smoothing | Generic SVG operation নয় |
| Timewarp | Native or optical flow | Motion estimation | Voice timing conflict check |
| Shatter | Custom particles | Source alpha or polygon fragments | Narrative justification |
| True volumetric 3D | Dedicated 3D engine | Volumetric renderer | SVG-তে unsupported |
| Cryptomatte | Multi-pass 3D pipeline | Object ID buffers | 3D source pipeline দরকার |
| HDR workflows | Color-managed engine | Linear buffers and output transform | Rec.709 workflow-এর বাইরে |

## ৩. Fallback approval

### Level A: সাধারণ equivalent

- Line draw instead of Trim Paths
- Instances instead of Repeater
- Gradient text instead of Gradient Overlay
- Offset duplicate instead of simple shadow
- Deterministic particles instead of simple emitter

শর্ত: Project proof-এ একই দৃশ্যগত উদ্দেশ্য পূরণ করতে হবে।

### Level B: Technical director review

- Full-screen displacement
- Depth-aware DOF
- Complex path offset and Boolean
- Matte edge refinement
- New renderer-এ multiword shaping
- Exact duration with unusual frame rate

Proof এবং performance report ছাড়া final নয়।

### Level C: User approval বা creative route change

- True 3D বা camera tracking না পারা
- Footage removal, stabilization বা advanced keying না পারা
- Licensed plugin-এর নির্দিষ্ট look না পারা
- Required effect runtime-এ unsupported হওয়া

নিঃশব্দে সহজ বিকল্প দেওয়া যাবে না।

## ৪. Generic validation scope

| Tool | যা প্রমাণ করে | যা প্রমাণ করে না |
|---|---|---|
| `npm run benchmark:fonts` | Glyph coverage and shaped ink clipping | Motion quality, final typography, visual style |
| `npm run benchmark:audio` | Synthetic envelope alignment method | Human speech alignment or final soundtrack QC |
| `npm run test:rules` | Responsive and continuity logic | Rendered composition quality |
| `npm run test:tmix` | Specific frame-count regression | Motion blur quality or final video duration |

## ৫. Project capability report

| Required result | Chosen tool | Status | Method | Proof | Cost | Limitation |
|---|---|---|---|---|---|---|
|  |  | untested |  |  |  |  |

`equivalent` এবং `pass` এক বিষয় নয়। Implementation proof এবং final QA আলাদা রাখো।
