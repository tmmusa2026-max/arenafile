# 07. After Effects-ধাঁচের Effects ও Techniques Catalog

## কীভাবে পড়বে

এটি একটি বিস্তৃত toolbox। After Effects সংস্করণ, bundled Cycore effect এবং install করা plugin অনুযায়ী কিছু নাম বা উপলভ্যতা বদলাতে পারে। এখানে native effect families, classic bundled effects, layer techniques এবং তাদের code-based equivalent অন্তর্ভুক্ত করা হয়েছে।

কোনো ভিডিওতে সব effect ব্যবহার করতে হবে না। নির্বাচনের শর্ত:

1. Narrative বা functional purpose আছে।
2. Effect-এর ফল proof frame-এ দেখা যায়।
3. Typography ও palette অক্ষুণ্ণ থাকে।
4. আরেকটি সরল পদ্ধতিতে একই ফল ভালো হয় না।
5. Effect map-এ parameter ও সময় লেখা যায়।

Effect সরাসরি unavailable হলে শুধু নাম বাদ দিয়ে সহজ বিকল্প নয়। একই দৃশ্যগত ফল তৈরির equivalent পদ্ধতি ব্যবহার করো। তবে effect-টির প্রয়োজনই না থাকলে বাদ দেওয়াই সঠিক।

## ১. Core compositing ও layer craft

| Technique | ব্যবহার | Equivalent বা implementation note |
|---|---|---|
| Mask paths | Reveal, isolate, shape transition | Animated vector clip with softened edge |
| Track matte, alpha | Text shimmer, shaped reveal | Source alpha multiplied with target |
| Track matte, luma | Light-based reveal, organic transition | Luminance threshold ও smooth matte |
| Set Matte | আলাদা layer দিয়ে matte | Matte transform mapping ও channel select |
| Precomposing | Independent time, effect stack, rig | Nested scene graph or offscreen composition |
| Parenting ও null | Shared transform, camera rig | Matrix hierarchy with stable anchor |
| Anchor point control | Natural rotation ও scale pivot | Local-to-world transform around semantic pivot |
| Time remapping | Speed change, held pose | Piecewise named easing, no accidental frame hold |
| Graph Editor | Velocity ও value control | Sample cubic curves, inspect derivatives |
| Motion sketch | Organic path, reference gesture | Capture then smooth with intentional easing |
| Roto Brush equivalent | Isolate provided footage | Matte propagation, only if footage allowed |
| Content-Aware Fill equivalent | Remove provided footage element | Advanced inpainting, require proof and permission |
| Puppet pins | Organic deformation | Weighted mesh or cage deformation |
| Motion tracking | Attach graphic to footage | Feature tracking and transform solve |
| 3D Camera Tracker | Place graphic in real scene | Camera solve, point cloud, orientation |
| Stabilization | Remove unwanted shake | Transform or optical-flow stabilization |
| Blend modes | Light, texture, depth | Porter-Duff plus screen, multiply, overlay, add where safe |
| Preserve transparency | Local texture or grade | Alpha-clamped composite |
| Adjustment layers | Shared grade or effect | Scene-level post stack |
| Guide layers | Non-rendering alignment | Debug-only hidden layer |
| Layer styles | Inner depth, stroke, glow | Dedicated compositing operations |

## ২. Shape layer operators

- Trim Paths
- Repeater
- Merge Paths
- Offset Paths
- Pucker & Bloat
- Round Corners
- Twist
- Wiggle Paths
- Wiggle Transform
- Zig Zag
- Gradient Fill
- Gradient Stroke
- Fill
- Stroke
- Group transforms

ব্যবহারের বিস্তারিত `06_SVG_AND_SHAPE_SYSTEM.md`-এ আছে। Repeater-এর transform accumulation যেন হারিয়ে যায় না এবং Trim Paths-এর leading point সঠিক path length থেকে আসে।

## ৩. Text animator system

After Effects-এর text animator-এর equivalent properties:

- Anchor Point
- Position
- Scale
- Skew
- Rotation
- Opacity
- Fill Color
- Stroke Color
- Stroke Width
- Tracking, শুধু shaping-safe script ও অনুমতিতে
- Line Anchor
- Blur
- Per-character 3D, শুধু appropriate Latin বা নিরাপদ unit-এ

Selector equivalents:

- Range Selector
- Wiggly Selector
- Expression Selector
- Start, end, offset
- Based on characters, words, lines
- Smoothness
- Ease high ও ease low
- Randomize order, fixed seed
- Anchor point grouping

Complex script-এ `characters` selector নিষিদ্ধ default। Word বা line selector ব্যবহার করো। Range Selector-এর মতো progressive reveal করতে হলে precomputed word timing ও overlapping eased envelopes ব্যবহার করো।

## ৪. Expression ও controller behaviors

| Behavior | ব্যবহার | সীমা |
|---|---|---|
| Wiggle | সূক্ষ্ম জীবন্ততা | Low frequency, 1 থেকে 2 px for text |
| LoopIn ও LoopOut | breathing, repeated cycle | Visible loop seam নয় |
| Overshoot | rhetorical pop | Tone না মিললে বাদ |
| Damped spring | settle | Fixed timestep, limited bounce |
| Inertia বা follow-through | Secondary motion | Main information late হবে না |
| Index-based delay | Stagger | Decreasing delay preferred |
| Linear interpolation | Technical mapping only | Visible motion-এর easing নয় |
| Ease ও smooth interpolation | Value mapping | Named project curve-এর সঙ্গে সামঞ্জস্য |
| Audio amplitude conversion | Audio-reactive graphic | Voice clear থাকবে, fake response নয় |
| Marker-driven event | Sync | Master audio timing থেকে marker |
| Slider control | Global intensity | Controller ranges documented |
| Checkbox control | Optional layer | QA both states |
| Color control | Shared palette | Restricted colors enforced |
| Point control | Spatial target | Coordinate space documented |
| Layer control | Shared source | Avoid circular dependency |
| Dropdown control | Style variant | Variant নাম ব্রিফে মেলে |

## ৫. 3D Channel effects

Effects: 3D Channel Extract, Depth Matte, Depth of Field, EXtractoR, Fog 3D, ID Matte, IDentifier, Cryptomatte workflow যখন সমর্থিত।

ব্যবহার:

- Depth-based fog, selective blur, object isolation
- Multi-pass render compositing
- 3D object বা scene-এর depth integration

Equivalent: depth buffer render, object ID buffer, depth-driven blur ও fog compositing। 3D source না থাকলে fake depth pass দিয়ে বাস্তব 3D render দাবি করবে না।

## ৬. Audio effects

Effects: Backwards, Bass & Treble, Delay, Flange & Chorus, High-Low Pass, Modulator, Parametric EQ, Reverb, Stereo Mixer, Tone।

ব্যবহার:

- Voice cleanup বা approved sound design
- Tone synthesis
- Channel balancing

সতর্কতা: Brief-এ অডিও অপরিবর্তিত রাখার নিয়ম থাকলে মূল voice-এ EQ, reverb, delay বা অন্য audible processing নয়। Analysis-only filtering final audio বদলায় না।

## ৭. Blur & Sharpen

Effects: Bilateral Blur, Camera Lens Blur, Channel Blur, Compound Blur, Directional Blur, Fast Box Blur, Gaussian Blur, Lens Blur, Radial Blur, Reduce Interlace Flicker, Sharpen, Smart Blur, Unsharp Mask, CC Cross Blur যখন উপলব্ধ।

| প্রয়োজন | পছন্দ | Equivalent |
|---|---|---|
| Text entry | Gaussian বা Fast Box | Separable Gaussian convolution |
| Camera DOF | Camera Lens Blur | Depth-driven variable radius convolution |
| Speed | Directional Blur | Velocity vector sampling |
| Spin বা zoom | Radial Blur | Polar or radial multi-sample |
| Texture-preserving blur | Bilateral | Edge-aware spatial filtering |
| Channel softness | Channel Blur | Independent channel filtering |
| Detail recovery | Unsharp Mask | Original minus blur, limited amount |
| Compression flicker control | Reduce Interlace Flicker | Only appropriate source, not general denoise |

Blur radius resolution-aware হবে। Blur দিয়ে অপূর্ণ shaping ঢাকা যাবে না।

## ৮. Channel effects

Effects: Arithmetic, Blend, Calculations, Channel Combiner, Compound Arithmetic, Invert, Minimax, Remove Color Matting, Set Channels, Set Matte, Shift Channels, Solid Composite।

ব্যবহার:

- Matte refinement
- Channel-based chromatic split
- Alpha reconstruction
- Depth ও ID buffer combination
- Premultiplication correction

Equivalent: explicit per-pixel channel operations। Chromatic aberration 1 থেকে 2 px, 2 থেকে 3 frame spike হিসেবে সীমিত রাখো, restricted palette যাচাই করো।

## ৯. Color Correction

Effects: Auto Color, Auto Contrast, Auto Levels, Black & White, Brightness & Contrast, Broadcast Colors, Change Color, Change to Color, Channel Mixer, Color Balance, Color Balance HLS, Color Curves, Curves, Color Link, Color Stabilizer, Colorama, Equalize, Exposure, Gamma/Pedestal/Gain, Hue/Saturation, Leave Color, Levels, Levels Individual Controls, Lumetri Color, Photo Filter, PS Arbitrary Map, Selective Color, Shadow/Highlight, Tint, Tritone, Vibrance, CC Color Neutralizer, CC Color Offset, CC Toner।

ব্যবহারের নিয়ম:

- LUT-মানের look: color matrix, 1D curves বা 3D LUT equivalent
- Warm documentary grade: highlights ও shadows-এ controlled temperature shift
- Product color: source color বদলে brand mismatch করবে না
- Alert red restriction: selective hue shift যেন অন্য element red না বানায়
- Auto correction final look-এর স্থির ভিত্তি নয়, shot-ভেদে বদলে যেতে পারে
- Skin tone থাকলে separately protect করো, footage অনুমোদিত হলে

## ১০. Distort

Effects: Bezier Warp, Bulge, Corner Pin, Detail-preserving Upscale, Displacement Map, Liquify, Magnify, Mesh Warp, Mirror, Offset, Optics Compensation, Polar Coordinates, Reshape, Ripple, Rolling Shutter Repair, Smear, Spherize, Transform, Turbulent Displace, Twirl, Warp, Warp Stabilizer, Wave Warp, CC Bend It, CC Bender, CC Blobbylize, CC Flo Motion, CC Griddler, CC Lens, CC Page Turn, CC Power Pin, CC Ripple Pulse, CC Slant, CC Smear, CC Split, CC Split 2, CC Tiler।

| Effect family | উপযুক্ত ব্যবহার | ঝুঁকি |
|---|---|---|
| Displacement Map | Organic text বা light distortion | Glyph readability নষ্ট |
| Turbulent Displace | Heat, fluid, unstable memory | Random wobble |
| Mesh Warp | Product বা illustration deformation | Mesh stretching artifacts |
| Liquify | Small intentional shape correction | Uncanny faces বা logos |
| Wave Warp | Audio, water, signal metaphor | Generic wave overuse |
| Corner Pin | Screen replacement | Perspective ও motion blur mismatch |
| Optics Compensation | Lens match or stylized edge | Text warping at edges |
| Polar Coordinates | Radial motif | Distorted typography |
| Mirror | Symmetry, kaleidoscopic structure | Template psychedelia |
| Detail-preserving Upscale | Provided low-res asset | নতুন detail তৈরি হয়েছে বলে দাবি নয় |
| Rolling Shutter Repair | Provided footage correction | Analysis ও proof দরকার |

## ১১. Expression Controls

Effects: 3D Point Control, Angle Control, Checkbox Control, Color Control, Dropdown Menu Control, Layer Control, Point Control, Slider Control।

এগুলো দৃশ্যগত effect নয়, কিন্তু reusable system-এর মূল। Controller-এর নাম, range, default ও affected properties document করো। এক controller অনেক element চালালেও local exceptions থাকতে পারে।

## ১২. Generate

Effects: 4-Color Gradient, Advanced Lightning, Audio Spectrum, Audio Waveform, Beam, Cell Pattern, Checkerboard, Circle, Ellipse, Eyedropper Fill, Fill, Fractal, Grid, Lens Flare, Paint Bucket, Radio Waves, Ramp, Scribble, Stroke, Vegas, Write-on, CC Glue Gun, CC Light Burst 2.5, CC Light Rays, CC Light Sweep, CC Threads।

ব্যবহার:

- Gradient ramp: background depth, light orb, text fill
- Audio Spectrum বা Waveform: শুধু আসল audio analysis থেকে
- Grid: technical বা spatial support
- Radio Waves: resonance বা signal, memorial ring-এর বিকল্প নয় সবসময়
- Light Sweep: shimmer, একবার, text matte-এর ভেতরে
- Stroke ও Write-on: path reveal, handwriting নয় যদি shaping ভাঙে
- Lens Flare: কেবল physical light source ও tone মিললে
- Lightning, Scribble, Vegas: brief-এ বিশেষ প্রাসঙ্গিকতা ছাড়া নয়

Equivalent: analytic vector generators, audio sampled paths, gradient fields, clipped light band।

## ১৩. Keying

Effects: Advanced Spill Suppressor, Color Difference Key, Color Key, Color Range, Difference Matte, Extract, Inner/Outer Key, Key Cleaner, Keylight, Linear Color Key, CC Simple Wire Removal যখন উপলব্ধ।

ব্যবহার:

- Provided footage থেকে subject isolation
- Green screen, luma বা color matte
- Spill ও edge cleanup

Equivalent: color-space distance matte, chroma key, edge erode, despill, temporal matte cleanup। মূল visual source না থাকলে keying জোর করে ব্যবহারের দরকার নেই।

## ১৪. Matte

Effects: Matte Choker, Simple Choker, Refine Hard Matte, Refine Soft Matte এবং related edge workflow।

ব্যবহার:

- Mask edge refinement
- Text reveal softness
- Alpha fringe correction
- Provided footage-এর matte cleanup

Equivalent: alpha morphology, distance transform, guided edge blur, temporal smoothing। মাত্রা বা ছোট glyph অংশ খর্ব হচ্ছে কি না QA করো।

## ১৫. Noise & Grain

Effects: Add Grain, Dust & Scratches, Fractal Noise, Match Grain, Median, Noise, Noise Alpha, Noise HLS, Noise HLS Auto, Remove Grain, Turbulent Noise।

ব্যবহার:

- Fine film grain: final composite-এ 1 থেকে 3 শতাংশ subtle luminance variation
- Fractal বা Turbulent Noise: fog, displacement, organic matte
- Match Grain: provided footage-এর সঙ্গে composite match
- Remove Grain: source cleanup, detail preservation QA সহ
- Dust & Scratches: কেবল restoration, fake archival damage নয় যদি brief না চায়

Grain monochrome বা controlled chroma হতে পারে। প্রতি frame deterministic seed, কিন্তু একই frozen noise pattern নয়। Compression-এর পরে proof দেখো।

## ১৬. Perspective

Effects: 3D Glasses, Bevel Alpha, Bevel Edges, Drop Shadow, Radial Shadow, Basic 3D legacy, CC Cylinder, CC Environment, CC Sphere, CC Spotlight।

ব্যবহার:

- Card depth, subtle bevel, shadow
- Sphere বা cylinder mapping for abstract 3D object
- Environment reflection, প্রাসঙ্গিক হলে
- Spotlight for guided focus

Premium typography-তে heavy bevel সাধারণত নয়। Perspective মূলত camera ও transform hierarchy দিয়ে তৈরি করো, fake flat skew দিয়ে নয় যদি true depth দরকার হয়।

## ১৭. Simulation

Effects: Card Dance, Caustics, Foam, Particle Playground, Shatter, Wave World, CC Ball Action, CC Bubbles, CC Drizzle, CC Hair, CC Mr. Mercury, CC Particle Systems II, CC Particle World, CC Pixel Polly, CC Rainfall, CC Scatterize, CC Snowfall, CC Star Burst।

| প্রয়োজন | সম্ভাব্য technique | সীমা |
|---|---|---|
| Text disperse | Particle sampler, Pixel Polly equivalent | Shaped alpha থেকে জন্ম |
| Structural break | Shatter equivalent | Violence বা chaos না হলে সংযত |
| Water light | Caustics | Source ও theme না থাকলে বাদ |
| Liquid | Foam, Mr. Mercury equivalent | Physics ও viscosity coherent |
| Weather | Rainfall, Snowfall | Real scene বা metaphor দরকার |
| Celebration | Star Burst, Ball Action | Somber project-এ নিষিদ্ধ tone |
| Organic field | Particle World equivalent | Fixed seed, collision ও drag নিয়ন্ত্রিত |

Simulation-এর ফল deterministic হতে হবে। প্রতি particle-এর birth, life, size, velocity, drag, depth, opacity ও blur recordable হওয়া উচিত।

## ১৮. Stylize

Effects: Brush Strokes, Cartoon, Color Emboss, Emboss, Find Edges, Glow, Mosaic, Motion Tile, Posterize, Roughen Edges, Scatter, Strobe Light, Texturize, Threshold, CC Block Load, CC Burn Film, CC Glass, CC Kaleida, CC Mr Smoothie, CC RepeTile, CC Threshold, CC Threshold RGB।

ব্যবহার:

- Glow: thresholded bloom, premium light treatment
- Motion Tile: background continuation, camera bleed
- Roughen Edges: documentary texture, সামান্য
- Mosaic বা Posterize: explicit digital বা editorial concept
- Find Edges: technical analysis বা contour reveal
- Cartoon বা Brush Strokes: illustration style brief-এ থাকলে
- Strobe Light: photosensitivity ও tone ঝুঁকির কারণে default নয়
- Burn Film: transition cliché, শুধু স্পষ্ট archival concept-এ

## ১৯. Text effects

Effects: Numbers, Timecode এবং legacy Basic Text বা Path Text যখন প্রাসঙ্গিক।

- Numbers: শুধু অনুমোদিত source data
- Timecode: কেবল editing proof বা brief-এর on-screen requirement, final film-এ default নয়
- Path Text: complex script-এ নিরাপদ না হলে বাদ
- Modern pipeline-এ live shaping engine সাধারণত ভালো

## ২০. Time

Effects: Echo, Posterize Time, Time Difference, Time Displacement, Timewarp, CC Force Motion Blur, CC Time Blend, CC Time Blend FX, CC Wide Time।

ব্যবহার:

- Echo: speed trail, memory afterimage
- Time Displacement: slit-scan বা temporal distortion
- Timewarp: provided footage-এর অনুমোদিত retime
- Force Motion Blur: synthetic shutter sampling
- Posterize Time: stop-motion style, শুধু intentional
- Time Difference: analysis বা stylized temporal contour

মূল voice-এর সময় বদলাতে video retime করা যাবে না। Motion blur-এর জন্য actual sub-frame compositing সাধারণত সবচেয়ে নিয়ন্ত্রিত।

## ২১. Transition

Effects: Block Dissolve, Card Wipe, Gradient Wipe, Iris Wipe, Linear Wipe, Radial Wipe, Venetian Blinds, CC Glass Wipe, CC Grid Wipe, CC Image Wipe, CC Jaws, CC Light Wipe, CC Line Sweep, CC Radial ScaleWipe, CC Scale Wipe, CC Twister।

Premium default হলো element-driven transition। Native wipe তখনই ব্যবহার করবে যখন সেটিকে project-specific matte, typography বা geometry-এর সঙ্গে custom করা যায়।

- Linear Wipe: masked structural reveal, soft edge, custom angle
- Gradient Wipe: luminance map from existing motif
- Radial Wipe: circular scene motif
- Card Wipe: product tiles বা card system
- Venetian Blinds: শুধু architectural slat concept
- Twister, Block Dissolve, Jaws: সাধারণত template ঝুঁকি, strong justification দরকার

## ২২. Utility

Effects: Apply Color LUT, Cineon Converter, Color Profile Converter, Grow Bounds, HDR Compander, CC Overbrights।

ব্যবহার:

- LUT: অনুমোদিত creative বা technical color transform
- Color Profile Converter: সঠিক input-output color management
- Grow Bounds: effect clipping ঠিক করা
- HDR Compander: HDR workflow, brief-এ থাকলে
- Overbrights: bloom-only high dynamic range control

Grow Bounds-এর equivalent হলো effect-aware expanded offscreen buffer। এটি glow, blur ও distortion-এর clipping ঠিক করতে গুরুত্বপূর্ণ।

## ২৩. Immersive Video

Effects ও workflows: VR Blur, VR Chromatic Aberrations, VR Color Gradients, VR Converter, VR De-Noise, VR Digital Glitch, VR Fractal Noise, VR Glow, VR Plane to Sphere, VR Rotate Sphere, VR Sharpen, VR Sphere to Plane।

শুধু 360, VR বা immersive brief-এ ব্যবহার করো। সাধারণ 16:9 ভিডিওতে এগুলো বাধ্যতামূলক নয়। Equivalent হলো spherical coordinate-aware filtering ও mapping।

## ২৪. Layer styles

- Drop Shadow
- Inner Shadow
- Outer Glow
- Inner Glow
- Bevel and Emboss
- Satin
- Color Overlay
- Gradient Overlay
- Stroke

প্রিমিয়াম ব্যবহার:

- Text-এ subtle inner glow ও gradient overlay
- Card-এ ছোট drop shadow
- Stroke-এর মাধ্যমে hierarchy
- Heavy bevel, satin ও outer glow একসঙ্গে নয়
- Effect-এর scale final output resolution অনুযায়ী

## ২৫. Common third-party looks, বিকল্প অনুমোদন হলে

Optical flare, advanced particle, 3D element, procedural energy, deep glow, camera shake, film emulation এবং similar plugin-driven looks সব লাইসেন্স ও brief-এর অধীন। Plugin না থাকলে:

- Flare: analytic optical ghosts, thresholded diffraction, restrained
- Particle: custom deterministic particle solver
- 3D: mesh renderer বা layered 2.5D equivalent, ফল ভিন্ন হলে স্পষ্ট বলো
- Energy: animated signed-distance paths, glow, displacement
- Deep glow: multi-scale thresholded bloom
- Camera shake: coherent noise rig, শুধু tone মিললে
- Film emulation: grain, halation, gate weave বা color response, খুব সূক্ষ্ম

কোনো plugin-এর trademarked preset ব্যবহার করে মৌলিকতা দাবি করবে না। ফলকে নিজের scene design-এর সঙ্গে মানিয়ে নাও।

## ২৬. Effect stack order

প্রচলিত starting order, প্রয়োজনে পরিবর্তনযোগ্য:

1. Source interpretation
2. Geometry ও text shaping
3. Local animation
4. Matte ও mask
5. Distortion
6. Depth of field বা local blur
7. Light, glow, shadow
8. Scene compositing
9. Global color grade
10. Chromatic micro-effect
11. Grain, vignette, final output transform

Motion blur সাধারণত geometry transform-এর সময় এবং camera move-এর সঙ্গে sampled হয়। Grain শেষে দিলে text-এর পুরোনো blur-এর সঙ্গে অপ্রয়োজনীয়ভাবে না মিশে filmic surface তৈরি করে।

## ২৭. Effect নির্বাচনের দ্রুত সারণি

| দৃশ্যের প্রয়োজন | Primary technique | Supporting technique |
|---|---|---|
| শব্দ প্রকাশ | Mask, position, blur | Shimmer, underline, glow |
| স্মৃতি | DOF, soft orb, rings | Grain, Sine breathing |
| ইতিহাস | Trim Paths, ticks, parallax | Warm grade, vignette |
| Product clarity | UI vectors, callouts | Corner pin, camera push |
| Process | Flow path, repeater | Node signal, annotation |
| Contrast | Match cut, split frame | Word morph |
| ক্ষয় | Particle dispersion | Lens blur, bokeh |
| Digital fault | Channel split, displacement | Brief glitch, low duration |
| Organic system | Mesh warp, fractal noise | Caustics or fluid if relevant |
| Archival source | Matte, stabilization, grain match | Color grade, frame treatment |
| শেষ স্থিরতা | Quint Out settle | Ambient light, restrained vignette |

## ২৮. অপ্রয়োজনীয় stacking থেকে বাঁচার নিয়ম

একই element-এ নিচের combination গুলো সাধারণত এড়াও:

- Heavy bevel + outer glow + chromatic aberration + drop shadow
- Camera shake + glitch + particle shatter + rapid zoom
- Strong DOF + tiny caption + grain over text
- Lens flare + shimmer + light rays + high bloom
- Multiple distortions with unrelated frequencies
- Red alert + warm amber dominance + unrelated magenta chroma

Effect কমানোর আগে ভাবো কোনটি মূল অর্থ বহন করছে। বাকিগুলো তার সেবায় সীমিত করো।
