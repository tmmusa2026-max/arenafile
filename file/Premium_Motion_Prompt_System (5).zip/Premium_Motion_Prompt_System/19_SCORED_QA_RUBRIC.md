# 19. Scored QA Rubric

## উদ্দেশ্য

QA যেন শুধু `ভালো লাগছে` না হয়। Score আছে, কিন্তু critical failure কম score দিয়ে ঢাকা যাবে না। Visual inspection এবং automated probe আলাদা evidence হিসেবে থাকবে।

## ১. Weight

| Area | Weight | Evidence |
|---|---:|---|
| Content ও source fidelity | 15 | Text comparison, asset license, no new facts |
| Timing ও audio sync | 15 | Actual audio analysis, sound event map, duration |
| Typography | 20 | Font benchmark, shaping, clipping, stable caption |
| Motion ও transitions | 15 | Named curves, motion blur, continuity proof |
| Compositing ও art direction | 10 | Full-size proof, palette, hierarchy, dialogue-specific SVG uniqueness, finishing |
| Technical delivery | 15 | ffprobe, decode, codecs, frame count, fresh install |
| Documentation ও reproducibility | 10 | Config, recipes, seed, reports, lockfile |
| Total | 100 |  |

## ২. Score per area

- 100 শতাংশ evidence pass: full weight
- 75 শতাংশ pass: weight গুণ 0.75
- 50 শতাংশ pass: weight গুণ 0.5
- 25 শতাংশ pass: weight গুণ 0.25
- 0: evidence নেই বা fail

`not_tested` কখনো pass নয়। Critical area untested হলে final status incomplete, যত score-ই হোক।

## ৩. Automatic fail

নিচের যেকোনোটি হলে score-এর বাইরেও final fail:

- Source text বা তথ্য অনুমোদন ছাড়া বদলেছে
- Bengali যুক্তাক্ষর ভেঙেছে
- Required audio কাটা, stretch বা অনুমোদনহীন processing
- Target duration মেলেনি এবং ব্যবহারকারীর approved tolerance নেই
- Required on-screen text বাদ পড়েছে
- HTML canvas ব্যবহার, brief-এ নিষিদ্ধ থাকলে
- System FFmpeg, Python বা font dependency, brief-এ নিষিদ্ধ থাকলে
- Decode error বা output file খুলছে না
- কোনো required proof নেই এবং visual status `pass` লেখা
- কোনো semantic dialogue-এর original primary SVG নেই, duplicate asset বা visual signature আছে, অথবা নতুন SVG বলে শুধু color, opacity, position, scale, text বা duration-এর clone দেওয়া হয়েছে
- পরপর dialogue SVG-তে primary generator বা geometry এবং composition বা motion-এর required পার্থক্য নেই
- Public link বা completed file-এর মিথ্যা দাবি
- Unlicensed, irrelevant বা বিভ্রান্তিকর news media ব্যবহার
- Public preview বা playback যাচাই না করে verified বলার দাবি
- Subtitle-এর highlighted word actual speech-এর সঙ্গে না মেলা, reveal-এর আগে color আসা বা leading bar ও dash থাকা
- Keyword echo দিয়ে required verbatim subtitle replace করা, source-এর বাইরের phrase যোগ করা বা previous phrase-এর layout নড়ানো
- Progress rail-এ fake loading, scene-only value-কে global progress বলা বা actual duration-এর সঙ্গে mismatch
- Permission অস্পষ্ট বা unverified watermark import, extraction, redraw বা trace
- Em dash বা U+2014, ভিডিওর visible text, external media text, metadata, generated file বা filename-এ থাকলে

## ৪. Recommended acceptance

- 95 থেকে 100: master delivery quality, critical check সব pass
- 90 থেকে 94.99: delivery candidate, minor documented correction
- 80 থেকে 89.99: আরও review দরকার, final হিসেবে দেওয়া যাবে না
- 80-এর নিচে: fail
- যেকোনো automatic fail: score নির্বিশেষে fail

## ৫. Evidence levels

- `A`: Final encoded file-এর automated proof
- `B`: Final renderer-এর visual proof, সত্যিকারে inspected
- `C`: Source configuration বা code inspection
- `D`: অনুমান বা untested, score পাবে না

Visual typography pass দিতে অন্তত B evidence দরকার। Codec ও duration-এর জন্য A evidence দরকার। Dialogue SVG-এর structural uniqueness-এর জন্য map validation C evidence, কিন্তু দৃশ্যগত originality ও relevance-এর full pass-এর জন্য প্রতিটি dialogue-এর inspected start, mid ও end proof দরকার। Keyword echo-এর stable layout এবং accent order-এর জন্য inspected motion proof দরকার। Progress rail-এর জন্য beginning, middle ও end-এর measured time এবং encoded frame evidence দরকার। Enabled watermark-এর জন্য original asset এবং verified permission record বাধ্যতামূলক।

## ৬. Project scorecard

| Area | Project-specific evidence | Score |
|---|---|---:|
| Content | Approved source comparison and asset manifest |  |
| Timing | Actual audio analysis, event map and duration |  |
| Typography | Project font benchmark and inspected proof |  |
| Motion | Named curves, sampling config and continuity proof |  |
| Compositing | Full-size proofs, palette, overlap review and per-dialogue SVG uniqueness |  |
| Technical | Encoded probe, decode, frame count and duration |  |
| Documentation | Source, recipes, lockfile, dialogue SVG map, effect map and performance |  |

Final score সেই project-এর measured evidence থেকে হিসাব করবে। Visual review status manually লেখা থাকলেও proof না থাকলে typography ও compositing-এর full score দেওয়া যাবে না। এই prompt package-এর generic validation score কোনো ভিডিওর final score নয়।

## ৭. Nonverbal adjustment

কোনো project-এ voice-over না থাকলে:

- Word-level spoken timing `not_applicable`
- Voice-to-effect 12 dB ratio `not_applicable`
- Spoken caption check `not_applicable`
- কোনো dialogue বা semantic spoken unit না থাকলে dialogue SVG map `not_applicable`; অর্থপূর্ণ dialogue থাকলে voice না থাকলেও unique SVG policy প্রযোজ্য
- Sound event to visual sync এবং original audio duration বাধ্যতামূলক

`not_applicable` এবং `not_tested` এক নয়। Content mode বদলে score-এর তুলনাও সতর্কতার সঙ্গে করতে হবে, তাই report-এ content mode লিখতে হবে।

## ৮. QC report fields

```text
content_mode
automatic_failures
em_dash_compliance
area_scores
total_score
acceptance_band
technical_probe
visual_review_status
benchmark_status
media_manifest_status
dialogue_svg_map_status
dialogue_svg_visual_review_status
subtitle_highlight_sync_status
keyword_echo_timing_and_layout_status
progress_rail_encoded_status
watermark_permission_status
executed_command_log_status
public_url_verification
playback_observed
limitations
final_status
```

Final status মান:

- `pass`
- `pass_with_warnings`
- `incomplete`
- `fail`
