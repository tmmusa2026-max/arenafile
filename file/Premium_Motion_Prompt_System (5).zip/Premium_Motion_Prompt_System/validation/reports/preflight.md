# Preflight Report

Prompt and validation toolkit only. No reference video or visual style template.

Overall: pass

| Check | Status | Expected | Measured |
|---|---|---|---|
| project_example_schema | pass | valid generic project example | valid |
| machine_project_example_schema | pass | valid machine-readable project example | valid |
| scene_plan_example_schema | pass | valid generic scene plan example | valid |
| word_timing_example_schema | pass | valid synthetic word timing example | valid |
| media_manifest_schema | pass | valid empty media manifest template | valid |
| delivery_report_schema | pass | valid unpublished delivery report template | valid |
| subtitle_style_schema | pass | valid premium subtitle style template | valid |
| dialogue_svg_map_schema | pass | valid empty dialogue SVG map template | valid |
| explainer_style_schema | pass | valid technical explainer style template | valid |
| file_package.json | pass | file exists | package.json |
| file_package-lock.json | pass | file exists | package-lock.json |
| file_README.md | pass | file exists | README.md |
| file_MASTER_PROMPT.md | pass | file exists | MASTER_PROMPT.md |
| file_PROMPT_COMPACT.md | pass | file exists | PROMPT_COMPACT.md |
| file_ROUTER.md | pass | file exists | ROUTER.md |
| file_validation/src/benchmark-fonts.js | pass | file exists | validation/src/benchmark-fonts.js |
| file_validation/src/benchmark-audio.js | pass | file exists | validation/src/benchmark-audio.js |
| file_validation/src/responsive.js | pass | file exists | validation/src/responsive.js |
| file_validation/src/text-policy.js | pass | file exists | validation/src/text-policy.js |
| file_validation/tests/rules.test.js | pass | file exists | validation/tests/rules.test.js |
| file_validation/tests/delivery.test.js | pass | file exists | validation/tests/delivery.test.js |
| file_validation/tests/text-policy.test.js | pass | file exists | validation/tests/text-policy.test.js |
| file_validation/tests/tmix.test.js | pass | file exists | validation/tests/tmix.test.js |
| file_libraries/media-sourcing.json | pass | file exists | libraries/media-sourcing.json |
| file_libraries/public-delivery.json | pass | file exists | libraries/public-delivery.json |
| file_libraries/subtitle-recipes.json | pass | file exists | libraries/subtitle-recipes.json |
| file_libraries/dialogue-svg-recipes.json | pass | file exists | libraries/dialogue-svg-recipes.json |
| file_libraries/explainer-recipes.json | pass | file exists | libraries/explainer-recipes.json |
| file_project/media-manifest.json | pass | file exists | project/media-manifest.json |
| file_project/delivery-report.json | pass | file exists | project/delivery-report.json |
| file_project/public-preview.template.html | pass | file exists | project/public-preview.template.html |
| file_project/subtitle-style.json | pass | file exists | project/subtitle-style.json |
| file_project/dialogue-svg-map.json | pass | file exists | project/dialogue-svg-map.json |
| file_project/explainer-style.json | pass | file exists | project/explainer-style.json |
| file_schemas/subtitle-style.schema.json | pass | file exists | schemas/subtitle-style.schema.json |
| file_schemas/dialogue-svg-map.schema.json | pass | file exists | schemas/dialogue-svg-map.schema.json |
| file_schemas/explainer-style.schema.json | pass | file exists | schemas/explainer-style.schema.json |
| file_validation/src/subtitle-timing.js | pass | file exists | validation/src/subtitle-timing.js |
| file_validation/src/dialogue-svg.js | pass | file exists | validation/src/dialogue-svg.js |
| file_validation/src/explainer-timing.js | pass | file exists | validation/src/explainer-timing.js |
| file_validation/tests/subtitle.test.js | pass | file exists | validation/tests/subtitle.test.js |
| file_validation/tests/dialogue-svg.test.js | pass | file exists | validation/tests/dialogue-svg.test.js |
| file_validation/tests/explainer.test.js | pass | file exists | validation/tests/explainer.test.js |
| file_validation/assets/audio/audio-alignment-benchmark.wav | pass | file exists | validation/assets/audio/audio-alignment-benchmark.wav |
| file_validation/assets/fonts/anek-bangla/AnekBangla-700.ttf | pass | file exists | validation/assets/fonts/anek-bangla/AnekBangla-700.ttf |
| file_validation/assets/fonts/hind-siliguri/HindSiliguri-Medium.ttf | pass | file exists | validation/assets/fonts/hind-siliguri/HindSiliguri-Medium.ttf |
| file_validation/assets/fonts/anek-bangla/OFL.txt | pass | file exists | validation/assets/fonts/anek-bangla/OFL.txt |
| file_validation/assets/fonts/hind-siliguri/OFL.txt | pass | file exists | validation/assets/fonts/hind-siliguri/OFL.txt |
| bundled_ffmpeg | pass | npm bundled FFmpeg executable | /home/user/Premium_Motion_Prompt_System/node_modules/ffmpeg-static/ffmpeg |
| bundled_ffprobe | pass | npm bundled ffprobe executable | /home/user/Premium_Motion_Prompt_System/node_modules/ffprobe-static/bin/linux/x64/ffprobe |
| router_targets | pass | all source router targets exist; generated reports excluded | all source targets exist |
| glyphs_validation/assets/fonts/anek-bangla/AnekBangla-700.ttf | pass | all benchmark Bengali codepoints covered | Anek Bangla, complete corpus |
| glyphs_validation/assets/fonts/hind-siliguri/HindSiliguri-Medium.ttf | pass | all benchmark Bengali codepoints covered | Hind Siliguri Medium, complete corpus |
| benchmark_audio_duration | pass | 4 second synthetic benchmark | 4 seconds |
| benchmark_audio_format | pass | 48 kHz stereo PCM | 48000 Hz, 2 channels |
| reference_video_removed | pass | no reference video, legacy reference folder or visual reference proof | none |
| source_payload_under_25mb | pass | source payload below 25,000,000 bytes before ZIP compression | 3629017 bytes |
| no_reference_render_command | pass | no reference renderer or render command | preflight, generate:benchmark, benchmark:fonts, benchmark:audio, test:rules, test:delivery, test:text, test:subtitle, test:dialogue-svg, test:explainer, test:tmix |
| public_preview_video_controls | pass | native video controls and relative MP4 source | template checked |
| public_preview_download_links | pass | direct MP4 and delivery ZIP links | template checked |
| public_preview_relative_assets | pass | no remote asset dependency in preview template | relative paths only |
| public_preview_self_contained | pass | inline styling and no script dependency | self-contained template |
| delivery_template_unpublished | pass | template contains no fake published URLs | not_started, all public URLs null |
| subtitle_no_leading_decoration | pass | no leading bar, pipe, dash, bullet or card; distinct active color | #F5F7FA, #2ED3A6 |
| subtitle_actual_audio_highlight | pass | actual audio, color after reveal, one active word | {"source":"actual_audio","color_after_reveal":true,"single_active_word":true,"hold_last_word_until_cue_end":true} |
| subtitle_complex_script_layout | pass | whole shaped words and stable pre-shaped layout | {"split_characters":false,"pre_shape_full_line":true,"reserve_layout_before_reveal":true} |
| dialogue_svg_uniqueness_policy | pass | one unique primary SVG per semantic dialogue; color-only clones rejected | {"unit":"semantic_dialogue","unique":true} |
| dialogue_svg_template_and_validator | pass | empty map template accepted by generic validator | {"pass":true,"errors":[],"dialogue_count":0,"unique_svg_count":0,"unique_source_file_count":0,"unique_visual_signature_count":0} |
| explainer_style_policy | pass | stable phrase echo, actual timeline and authorized watermark policy | valid |
| explainer_actual_progress_utility | pass | actual global timeline produces deterministic progress | midpoint=0.5 |
| explainer_reference_free_policy | pass | no reference assets, subtitle replacement or unapproved watermark import | {"actual_audio_timing_primary":true,"keyword_echo_replaces_verbatim_subtitles":false,"whole_shaped_phrase_animation_only":true,"new_facts_allowed":false,"original_svg_per_semantic_dialogue":true,"color_or_position_only_clone_allowed":false,"third_party_watermark_import_without_permission":false,"fake_progress_allowed":false} |
| package_version_alignment | pass | package, README, router and recipe registry versions match | {"package":"2.5.0","recipes":"2.5.0","router":"2.5.0","readme":"2.5.0"} |
| no_em_dash | pass | no U+2014 in text, SVG, subtitle, metadata and code files | none |
| no_em_dash_in_filenames | pass | no U+2014 in file or directory names | none |
| no_accidental_mixed_script | pass | no immediate Bengali-Latin mixed-script tokens | none |
