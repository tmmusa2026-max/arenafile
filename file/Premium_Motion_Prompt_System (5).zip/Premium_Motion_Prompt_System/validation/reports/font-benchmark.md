# Bengali Font Benchmark

Capability validation only, not a visual style reference.

Overall: pass

Renderer: sharp with bundled librsvg and Pango using custom fontconfig

Proof generated: false

| Family | Word | Ink width | Ink height | Clipped | Status |
|---|---|---:|---:|---|---|
| Anek Bangla | স্মৃতি | 145 | 93 | false | pass |
| Anek Bangla | ইতিহাস | 217 | 69 | false | pass |
| Anek Bangla | মায়া | 134 | 54 | false | pass |
| Anek Bangla | আগামী | 223 | 67 | false | pass |
| Anek Bangla | ক্ষুধা | 144 | 67 | false | pass |
| Anek Bangla | জ্ঞান | 135 | 44 | false | pass |
| Anek Bangla | শ্রদ্ধা | 137 | 58 | false | pass |
| Anek Bangla | উদ্ভিদ | 165 | 79 | false | pass |
| Anek Bangla | ব্যাখ্যা | 170 | 45 | false | pass |
| Anek Bangla | সংকল্প | 196 | 63 | false | pass |
| Anek Bangla | দৃঢ়তা | 161 | 69 | false | pass |
| Anek Bangla | গণঅভ্যুত্থানে | 372 | 67 | false | pass |
| Anek Bangla | ছুঁয়েছে | 189 | 96 | false | pass |
| Anek Bangla | পোলার | 202 | 54 | false | pass |
| Hind Siliguri | স্মৃতি | 124 | 78 | false | pass |
| Hind Siliguri | ইতিহাস | 188 | 62 | false | pass |
| Hind Siliguri | মায়া | 120 | 57 | false | pass |
| Hind Siliguri | আগামী | 200 | 65 | false | pass |
| Hind Siliguri | ক্ষুধা | 132 | 67 | false | pass |
| Hind Siliguri | জ্ঞান | 126 | 51 | false | pass |
| Hind Siliguri | শ্রদ্ধা | 116 | 55 | false | pass |
| Hind Siliguri | উদ্ভিদ | 146 | 73 | false | pass |
| Hind Siliguri | ব্যাখ্যা | 160 | 50 | false | pass |
| Hind Siliguri | সংকল্প | 174 | 57 | false | pass |
| Hind Siliguri | দৃঢ়তা | 140 | 68 | false | pass |
| Hind Siliguri | গণঅভ্যুত্থানে | 336 | 69 | false | pass |
| Hind Siliguri | ছুঁয়েছে | 164 | 85 | false | pass |
| Hind Siliguri | পোলার | 180 | 53 | false | pass |
