# Validation Summary

Scope: reference-free prompt toolkit and generic capability validation only.

| Check | Result | Evidence |
|---|---|---|
| Fresh dependency install | Pass | `npm ci --no-audit --no-fund`, five direct dependencies |
| Preflight | 75/75 pass | `preflight.json` |
| Font glyph and ink bounds | 28 combinations pass | `font-benchmark.json` |
| Synthetic audio alignment | 4 regions pass | Maximum start error 0 ms, maximum end error 5 ms |
| Responsive and continuity rules | 6 tests pass | `rules-test.json` |
| Intake and public delivery rules | 7 tests pass | `delivery-test.json` |
| Em dash and U+2014 text policy | 6 tests pass | `text-policy-test.json` |
| Premium subtitle timing and style | 13 tests pass | `subtitle-test.json` |
| Dialogue-specific SVG structure | 18 tests pass | Unique IDs, source files and visual signatures; non-structural clones rejected; `dialogue-svg-test.json` |
| Technical explainer timing and policy | 22 tests pass | Stable phrase reveal, post-reveal accent, actual progress and watermark permission; `explainer-test.json` |
| Temporal frame-count regression | 240 frames pass | 1,927 input samples, 7 terminal flush samples, 8.000 seconds |
| JSON parsing | Pass | All package JSON files parsed |
| Text policy | Pass | No U+2014 or accidental mixed-script tokens |
| Reference artifact scan | Pass | No forbidden video or rendered proof artifact |

## Limits

- Font results are glyph coverage and ink-bounds checks, not final typography approval.
- `multiword_visual_status` remains `not_tested` because no visual proof is bundled or inspected.
- Audio results use synthetic bursts, not human speech or a final soundtrack.
- The temporal test checks frame-count behavior, not motion-blur aesthetics.
- No web media or reference asset is bundled in this prompt package.
- No video was rendered or publicly uploaded during toolkit validation, so encoded visual em dash review is not applicable to this package.
- Preview structure was tested, not actual hosted playback.
- Subtitle timing, palette and contrast logic were tested, but no final subtitle animation was rendered or visually approved in this package.
- Dialogue SVG structural uniqueness and rejection logic were tested, but no final dialogue-specific SVG animation was rendered or visually approved in this package.
- Keyword echo timing, progress calculation and watermark permission logic were tested, but no final explainer animation was rendered or visually approved in this package.
- No final video quality score is claimed.
