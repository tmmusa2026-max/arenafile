# Audio Alignment Benchmark

Synthetic harmonic bursts for envelope alignment testing, not human speech and not a reference soundtrack

Overall: pass

| Token | Expected start | Measured start | Start error | Expected end | Measured end | End error | Status |
|---|---:|---:|---:|---:|---:|---:|---|
| ক | 0.300 | 0.300 | 0 ms | 0.750 | 0.750 | 0 ms | pass |
| খ | 1.100 | 1.100 | 0 ms | 1.550 | 1.555 | 5 ms | pass |
| গ | 2.150 | 2.150 | 0 ms | 2.750 | 2.750 | 0 ms | pass |
| ঘ | 3.200 | 3.200 | 0 ms | 3.650 | 3.650 | 0 ms | pass |
