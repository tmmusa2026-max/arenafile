# Validation Tools

এই folder-এর tools শুধু technical capability যাচাই করে। এখানে কোনো reference video, scene renderer, style template, visual composition বা অনুকরণযোগ্য motion example নেই।

## Scripts

Package root থেকে:

```bash
npm install
npm run preflight
npm run benchmark:fonts
npm run benchmark:audio
npm run test:rules
npm run test:delivery
npm run test:text
npm run test:subtitle
npm run test:dialogue-svg
npm run test:explainer
npm run test:tmix
```

Optional local font diagnostic images:

```bash
npm run benchmark:fonts -- --write-proof
```

Diagnostic images package-এ bundled নয়। Command চালালে `validation/proof/` তৈরি হবে এবং সেই ছবি নিজে পরীক্ষা করতে হবে। Automated ink-bounds pass-কে visual pass বলা যাবে না।

Synthetic audio আবার তৈরি করতে:

```bash
npm run generate:benchmark
```

## Scope

- Font benchmark: glyph coverage, shaped ink bounds, clipping
- Audio benchmark: synthetic harmonic bursts-এর envelope alignment
- Rules tests: responsive fit, short-scene conflict solver, continuity graph
- Delivery tests: two-file intake policy, fake-link safeguards, schema rejection, preview structure
- Text policy tests: U+2014 detection in caption, headline, SVG text, video metadata এবং generated text
- Subtitle tests: reveal-after timing, active highlight sequence, default teal palette, no leading bar, stable complex-script layout এবং color contrast
- Dialogue SVG tests: unique dialogue ও asset IDs, original source paths, actual timing, visual signatures, meaningful primary ও secondary differences, color-only clone rejection এবং shared secondary motif support
- Explainer tests: stable phrase reveal, post-reveal accent, actual global progress, subtitle preservation, chapter source policy এবং authorized watermark enforcement
- Temporal test: `tmix` ব্যবহারের একটি frame-count regression
- Preflight: package structure, JSON, schemas, router targets, fonts, audio, forbidden character, নিষিদ্ধ reference artifacts এবং source size
- Public delivery checks: media ও delivery schemas, native video controls, relative MP4 ও ZIP paths, self-contained preview এবং unpublished template defaults

Dialogue SVG map validation structural uniqueness যাচাই করে, কিন্তু দৃশ্যগত originality বা semantic relevance প্রমাণ করে না। Final production-এ প্রতিটি dialogue-এর start, mid ও end proof আলাদা করে চোখে দেখতে হবে। Explainer utility ও policy tests actual timeline এবং config rejection যাচাই করে, কিন্তু final keyword animation, progress rail বা watermark-এর visual proof-এর বিকল্প নয়।

## যা নেই

- Reference MP4 বা অন্য video
- Sample scene plan বা অনুকরণযোগ্য composition
- Video renderer বা `npm run render` command
- Visual proof sheet
- অনুকরণযোগ্য color, timing বা transition template

নতুন ভিডিওর style, timing, content ও composition সবসময় active brief এবং source থেকে তৈরি করতে হবে।
