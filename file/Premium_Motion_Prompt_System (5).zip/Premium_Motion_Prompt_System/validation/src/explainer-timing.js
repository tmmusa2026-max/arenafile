'use strict';

function timelineProgress(currentTime, duration) {
  if (!Number.isFinite(duration) || duration <= 0) throw new Error('Invalid actual duration');
  if (!Number.isFinite(currentTime)) throw new Error('Invalid current time');
  return Math.min(1, Math.max(0, currentTime / duration));
}

function buildKeywordEchoTimeline(options) {
  const {
    dialogueStart,
    dialogueEnd,
    phrases,
    fps = 30,
    preSpeechRevealMs = 120,
    emphasisDelayFrames = 1
  } = options;
  if (!Number.isFinite(dialogueStart) || !Number.isFinite(dialogueEnd) || dialogueEnd <= dialogueStart) throw new Error('Invalid dialogue range');
  if (!Array.isArray(phrases) || phrases.length === 0) throw new Error('At least one shaped phrase is required');
  if (!Number.isFinite(fps) || fps <= 0) throw new Error('Invalid frame rate');
  if (!Number.isFinite(preSpeechRevealMs) || preSpeechRevealMs < 0) throw new Error('Invalid reveal lead');
  if (!Number.isFinite(emphasisDelayFrames) || emphasisDelayFrames <= 0) throw new Error('Emphasis delay must be positive');

  const lead = preSpeechRevealMs / 1000;
  const delay = emphasisDelayFrames / fps;
  return phrases.map((phrase, index) => {
    if (!phrase || typeof phrase.text !== 'string' || !phrase.text.trim()) throw new Error(`Invalid phrase at index ${index}`);
    if (!Number.isFinite(phrase.start) || !Number.isFinite(phrase.end) || phrase.end <= phrase.start) throw new Error(`Invalid phrase timing at index ${index}`);
    if (phrase.start < dialogueStart || phrase.end > dialogueEnd) throw new Error(`Phrase outside dialogue at index ${index}`);
    if (index > 0 && phrase.start < phrases[index - 1].end) throw new Error(`Overlapping phrase timing at index ${index}`);
    const accent = phrase.accent !== false;
    const revealStart = Math.max(dialogueStart, phrase.start - lead);
    return {
      index,
      text: phrase.text,
      start: phrase.start,
      end: phrase.end,
      reveal_start: revealStart,
      reveal_end: phrase.start,
      emphasis_start: accent ? Math.min(phrase.start + delay, phrase.start + (phrase.end - phrase.start) / 2) : null,
      accent,
      emphasis_after_reveal: accent ? true : null,
      animation_unit: 'whole_shaped_phrase',
      layout_mode: 'pre_shaped_stable'
    };
  });
}

function safeWatermarkPath(value) {
  return typeof value === 'string' && value.length > 0 && /\.(png|svg)$/i.test(value) && !value.startsWith('/') && !value.includes('\\') && !/^[a-z][a-z0-9+.-]*:/i.test(value) && !value.split('/').includes('..');
}

function validateExplainerStyle(style) {
  const errors = [];
  if (!style || typeof style !== 'object') return {pass: false, errors: ['Style object is required']};
  const keyword = style.keyword_echo || {};
  const staged = style.staged_build || {};
  const chapter = style.chapter_pill || {};
  const progress = style.progress_rail || {};
  const watermark = style.authorized_watermark || {};
  const background = style.background || {};

  if (keyword.source !== 'approved_spoken_text') errors.push('Keyword echo must use approved spoken text');
  if (keyword.timing_source !== 'actual_audio_word_timing') errors.push('Keyword echo requires actual audio word timing');
  if (keyword.animation_unit !== 'whole_shaped_phrase' || keyword.split_characters !== false) errors.push('Keyword echo must preserve whole shaped phrases');
  if (keyword.pre_shape_full_line !== true || keyword.reserve_layout_before_reveal !== true || keyword.previous_phrases_remain_stable !== true) errors.push('Keyword echo layout must remain pre-shaped and stable');
  if (keyword.emphasis_after_reveal !== true) errors.push('Keyword emphasis must follow reveal');
  if (keyword.replaces_verbatim_subtitles !== false) errors.push('Keyword echo cannot replace verbatim subtitles');
  if (staged.timing_source !== 'actual_dialogue' || staged.entry_before_or_at_related_speech !== true) errors.push('Staged visuals must align before or at related speech');
  if (staged.readable_hold_required !== true) errors.push('Staged visuals require a readable hold');
  if (chapter.safe_area !== true || chapter.new_facts_allowed !== false) errors.push('Chapter labels require safe areas and approved facts');
  if (progress.value_source !== 'actual_global_timeline' || progress.scene_progress_only !== false || progress.fake_loading !== false) errors.push('Progress must use the actual global timeline');
  if (progress.subtitle_collision_allowed !== false) errors.push('Progress rail cannot collide with subtitles');
  if (![progress.min_height_px, progress.height_px_at_1080, progress.max_height_px].every(Number.isFinite) || progress.min_height_px > progress.height_px_at_1080 || progress.height_px_at_1080 > progress.max_height_px) errors.push('Progress rail heights are inconsistent');
  if (watermark.third_party_extraction_allowed !== false) errors.push('Third-party watermark extraction is forbidden');
  if (watermark.enabled) {
    if (watermark.permission_status !== 'verified') errors.push('Enabled watermark requires verified permission');
    if (!safeWatermarkPath(watermark.asset_file)) errors.push('Enabled watermark requires a safe local PNG or SVG path');
  } else if (watermark.asset_file !== null) {
    errors.push('Disabled watermark cannot reference an imported asset');
  }
  if (!Number.isFinite(background.text_contrast_min) || background.text_contrast_min < 4.5) errors.push('Technical background requires readable text contrast');
  return {pass: errors.length === 0, errors};
}

module.exports = {timelineProgress, buildKeywordEchoTimeline, validateExplainerStyle, safeWatermarkPath};
