'use strict';

const fs = require('fs');
const path = require('path');

const SIGNATURE_FIELDS = [
  'primary_generator',
  'geometry_signature',
  'composition_signature',
  'motion_signature'
];

function createVisualSignature(svg) {
  return SIGNATURE_FIELDS.map(field => svg && svg[field]).join('|');
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

function normalizedSvgSource(value) {
  if (!isNonEmptyString(value) || value.includes('\\') || !value.endsWith('.svg')) return null;
  if (value.startsWith('/') || /^[A-Za-z]:/.test(value) || /^[a-z][a-z0-9+.-]*:/i.test(value)) return null;
  const normalized = path.posix.normalize(value);
  if (normalized === '..' || normalized.startsWith('../') || normalized.includes('/../')) return null;
  return normalized;
}

function validateDialogueSvgMap(map, options = {}) {
  const {
    allowEmpty = true,
    requireProof = false,
    rootDir = null
  } = options;
  const errors = [];
  const dialogues = map && Array.isArray(map.dialogues) ? map.dialogues : [];
  if (!map || !Array.isArray(map.dialogues)) errors.push('dialogues must be an array');
  if (!allowEmpty && dialogues.length === 0) errors.push('at least one dialogue is required');
  if (rootDir !== null && !isNonEmptyString(rootDir)) errors.push('rootDir must be a non-empty path when supplied');

  const dialogueIds = new Set();
  const assetIds = new Set();
  const sourceFiles = new Set();
  const signatures = new Set();
  let uniqueSignatures = 0;

  dialogues.forEach((dialogue, index) => {
    const label = isNonEmptyString(dialogue.dialogue_id) ? dialogue.dialogue_id : `index_${index}`;
    if (!isNonEmptyString(dialogue.dialogue_id)) errors.push(`${label}: missing dialogue_id`);
    if (dialogueIds.has(dialogue.dialogue_id)) errors.push(`${label}: duplicate dialogue_id`);
    if (isNonEmptyString(dialogue.dialogue_id)) dialogueIds.add(dialogue.dialogue_id);

    for (const field of ['source_text', 'speech_act', 'semantic_focus', 'emotion', 'narrative_role']) {
      if (!isNonEmptyString(dialogue[field])) errors.push(`${label}: missing ${field}`);
    }
    if (!Number.isFinite(dialogue.start) || !Number.isFinite(dialogue.end) || dialogue.start < 0 || dialogue.end <= dialogue.start) {
      errors.push(`${label}: invalid actual timing`);
    }
    if (index > 0 && Number.isFinite(dialogue.start) && Number.isFinite(dialogues[index - 1].end) && dialogue.start < dialogues[index - 1].end) {
      errors.push(`${label}: overlapping dialogue timing`);
    }

    const svg = dialogue.svg && typeof dialogue.svg === 'object' ? dialogue.svg : {};
    if (!dialogue.svg || typeof dialogue.svg !== 'object') errors.push(`${label}: missing SVG object`);
    if (!isNonEmptyString(svg.asset_id)) errors.push(`${label}: missing SVG asset_id`);
    if (assetIds.has(svg.asset_id)) errors.push(`${label}: duplicate SVG asset_id ${svg.asset_id}`);
    if (isNonEmptyString(svg.asset_id)) assetIds.add(svg.asset_id);
    if (!isNonEmptyString(svg.concept)) errors.push(`${label}: missing SVG concept`);
    if (svg.original !== true) errors.push(`${label}: SVG must be original`);

    const normalizedSource = normalizedSvgSource(svg.source_file);
    if (!normalizedSource) {
      errors.push(`${label}: source_file must be a safe relative SVG path`);
    } else {
      if (sourceFiles.has(normalizedSource)) errors.push(`${label}: duplicate SVG source_file ${normalizedSource}`);
      sourceFiles.add(normalizedSource);
      if (rootDir) {
        const resolvedRoot = path.resolve(rootDir);
        const resolvedSource = path.resolve(resolvedRoot, normalizedSource);
        const insideRoot = resolvedSource === resolvedRoot || resolvedSource.startsWith(resolvedRoot + path.sep);
        if (!insideRoot || !fs.existsSync(resolvedSource) || !fs.statSync(resolvedSource).isFile()) {
          errors.push(`${label}: SVG source_file does not exist inside rootDir`);
        }
      }
    }

    const missingSignatureFields = SIGNATURE_FIELDS.filter(field => !isNonEmptyString(svg[field]));
    if (missingSignatureFields.length) errors.push(`${label}: missing signature components ${missingSignatureFields.join(', ')}`);
    const expectedSignature = createVisualSignature(svg);
    if (!isNonEmptyString(svg.visual_signature) || svg.visual_signature !== expectedSignature) {
      errors.push(`${label}: visual_signature does not match its components`);
    } else if (missingSignatureFields.length === 0) {
      if (signatures.has(svg.visual_signature)) errors.push(`${label}: duplicate visual_signature`);
      else uniqueSignatures++;
      signatures.add(svg.visual_signature);
    }

    if (svg.continuity_from !== null && svg.continuity_from !== undefined) {
      if (!isNonEmptyString(svg.continuity_from)) errors.push(`${label}: continuity_from must be an asset ID or null`);
      else if (!assetIds.has(svg.continuity_from) || svg.continuity_from === svg.asset_id) {
        errors.push(`${label}: continuity_from must reference an earlier dialogue SVG`);
      }
    }
    if (svg.shared_motif !== null && svg.shared_motif !== undefined && typeof svg.shared_motif !== 'string') {
      errors.push(`${label}: shared_motif must be a string or null`);
    }

    if (index > 0) {
      const previous = dialogues[index - 1].svg || {};
      if (!isNonEmptyString(svg.difference_from_previous)) errors.push(`${label}: difference_from_previous is required`);
      const primaryChanged = svg.primary_generator !== previous.primary_generator || svg.geometry_signature !== previous.geometry_signature;
      const secondaryChanged = svg.composition_signature !== previous.composition_signature || svg.motion_signature !== previous.motion_signature;
      if (!primaryChanged) errors.push(`${label}: primary generator or geometry must differ from previous dialogue`);
      if (!secondaryChanged) errors.push(`${label}: composition or motion must differ from previous dialogue`);
    }

    if (requireProof) {
      if (!Array.isArray(dialogue.proof_frames) || dialogue.proof_frames.length < 3 || dialogue.proof_frames.some(frame => !isNonEmptyString(frame))) {
        errors.push(`${label}: at least three dialogue-specific proof frames are required`);
      } else if (new Set(dialogue.proof_frames).size !== dialogue.proof_frames.length) {
        errors.push(`${label}: dialogue-specific proof frame paths must be unique`);
      }
    }
  });

  return {
    pass: errors.length === 0,
    errors,
    dialogue_count: dialogues.length,
    unique_svg_count: assetIds.size,
    unique_source_file_count: sourceFiles.size,
    unique_visual_signature_count: uniqueSignatures
  };
}

module.exports = {createVisualSignature, validateDialogueSvgMap, normalizedSvgSource};
