'use strict';

const fs = require('fs');
const path = require('path');
const fontkit = require('fontkit');
const {configureFonts} = require('./renderer-options');
configureFonts();
const sharp = require('sharp');

const root = path.resolve(__dirname, '../..');
const proofDir = path.join(__dirname, '../proof');
const reportDir = path.join(__dirname, '../reports');
const writeProof = process.argv.includes('--write-proof');
fs.mkdirSync(reportDir, {recursive: true});
if (writeProof) fs.mkdirSync(proofDir, {recursive: true});
const words = ['স্মৃতি', 'ইতিহাস', 'মায়া', 'আগামী', 'ক্ষুধা', 'জ্ঞান', 'শ্রদ্ধা', 'উদ্ভিদ', 'ব্যাখ্যা', 'সংকল্প', 'দৃঢ়তা', 'গণঅভ্যুত্থানে', 'ছুঁয়েছে', 'পোলার'];
const fonts = [
  {family: 'Anek Bangla', label: 'Anek Bangla 700', file: 'validation/assets/fonts/anek-bangla/AnekBangla-700.ttf', weight: 700, color: '#9AE600'},
  {family: 'Hind Siliguri', label: 'Hind Siliguri Medium', file: 'validation/assets/fonts/hind-siliguri/HindSiliguri-Medium.ttf', weight: 500, color: '#F5F7FA'}
];

async function boundsFor(word, font) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="520" height="230"><rect width="520" height="230" fill="#0B1220"/><text x="260" y="140" text-anchor="middle" font-family="${font.family}" font-size="68" font-weight="${font.weight}" fill="#fff">${word}</text></svg>`;
  const {data} = await sharp(Buffer.from(svg)).ensureAlpha().raw().toBuffer({resolveWithObject: true});
  let minX = 520, minY = 230, maxX = -1, maxY = -1;
  for (let y = 0; y < 230; y++) {
    for (let x = 0; x < 520; x++) {
      const i = (y * 520 + x) * 4;
      const brightness = data[i] + data[i + 1] + data[i + 2];
      if (brightness > 90) {
        minX = Math.min(minX, x); minY = Math.min(minY, y);
        maxX = Math.max(maxX, x); maxY = Math.max(maxY, y);
      }
    }
  }
  const bounds = {x: minX, y: minY, width: maxX - minX + 1, height: maxY - minY + 1};
  return {...bounds, clipped: minX <= 1 || minY <= 1 || maxX >= 518 || maxY >= 228};
}

async function writeDiagnosticProofs() {
  const cellW = 440, cellH = 140;
  const elements = [];
  fonts.forEach((font, row) => {
    const y0 = 90 + row * 560;
    elements.push(`<text x="70" y="${y0}" font-family="${font.family}" font-size="30" font-weight="${font.weight}" fill="${font.color}">${font.label}</text>`);
    words.forEach((word, i) => {
      const col = i % 4;
      const r = Math.floor(i / 4);
      const x = 70 + col * cellW + cellW / 2;
      const y = y0 + 105 + r * cellH;
      elements.push(`<text x="${x}" y="${y}" text-anchor="middle" font-family="${font.family}" font-size="54" font-weight="${font.weight}" fill="${font.color}">${word}</text>`);
    });
  });
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1280"><rect width="1920" height="1280" fill="#0B1220"/>${elements.join('')}</svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path.join(proofDir, 'font-benchmark.png'));
  const multiword = `<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="360"><rect width="1600" height="360" fill="#0B1220"/><text x="800" y="210" text-anchor="middle" font-family="Anek Bangla" font-size="82" font-weight="700" fill="#F5F7FA">ইতিহাস মায়া আগামী</text></svg>`;
  await sharp(Buffer.from(multiword)).png().toFile(path.join(proofDir, 'font-multiword-smoke.png'));
}

async function main() {
  const results = [];
  for (const font of fonts) {
    const opened = fontkit.openSync(path.join(root, font.file));
    const row = {family: font.family, file: font.file, font_version: opened.version, words: []};
    for (const word of words) {
      const bounds = await boundsFor(word, font);
      row.words.push({word, ...bounds, pass: !bounds.clipped});
    }
    results.push(row);
  }
  if (writeProof) await writeDiagnosticProofs();
  const report = {
    purpose: 'Capability validation only, not a visual style reference',
    renderer: 'sharp with bundled librsvg and Pango using custom fontconfig',
    system_fonts: false,
    proof_generated: writeProof,
    proof_policy: 'No proof images are bundled. Use npm run benchmark:fonts -- --write-proof to generate local diagnostics.',
    multiword_visual_status: writeProof ? 'image_generated_requires_visual_review' : 'not_tested',
    results,
    pass: results.every(r => r.words.every(w => w.pass))
  };
  fs.writeFileSync(path.join(reportDir, 'font-benchmark.json'), JSON.stringify(report, null, 2) + '\n');
  const lines = ['# Bengali Font Benchmark', '', 'Capability validation only, not a visual style reference.', '', `Overall: ${report.pass ? 'pass' : 'fail'}`, '', `Renderer: ${report.renderer}`, '', `Proof generated: ${writeProof}`, '', '| Family | Word | Ink width | Ink height | Clipped | Status |', '|---|---|---:|---:|---|---|'];
  for (const r of results) for (const w of r.words) lines.push(`| ${r.family} | ${w.word} | ${w.width} | ${w.height} | ${w.clipped} | ${w.pass ? 'pass' : 'fail'} |`);
  fs.writeFileSync(path.join(reportDir, 'font-benchmark.md'), lines.join('\n') + '\n');
  console.log(`Font benchmark: ${report.pass ? 'pass' : 'fail'}, ${words.length * fonts.length} word and font combinations`);
  if (!report.pass) process.exitCode = 1;
}

main().catch(error => {console.error(error);process.exitCode = 1;});
