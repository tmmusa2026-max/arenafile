'use strict';

const fs = require('fs');
const path = require('path');
const {readWav, analyzeSpeechLikeRegions} = require('./audio-utils');
const audioPath = path.join(__dirname, '../assets/audio/audio-alignment-benchmark.wav');
const truthPath = path.join(__dirname, '../config/audio-benchmark-ground-truth.json');
const reportDir = path.join(__dirname, '../reports');
fs.mkdirSync(reportDir, {recursive: true});
const truth = JSON.parse(fs.readFileSync(truthPath, 'utf8'));
const audio = readWav(audioPath);
const analysis = analyzeSpeechLikeRegions(audio);
const matches = truth.events.map((event, index) => {
  const measured = analysis.regions[index];
  if (!measured) return {...event, measured: null, pass: false, error: 'Missing region'};
  const startError = measured.start - event.start;
  const endError = measured.end - event.end;
  return {...event, measured, start_error_ms: Math.round(startError * 1000), end_error_ms: Math.round(endError * 1000), pass: Math.abs(startError) <= 0.06 && Math.abs(endError) <= 0.08};
});
const report = {
  purpose: 'Synthetic envelope alignment validation only, not a reference soundtrack',
  benchmark: truth.description,
  source_audio: truth.source_audio,
  duration_seconds: audio.duration,
  sample_rate: audio.sampleRate,
  method: 'Adaptive RMS envelope with hysteresis, 10 ms window and 5 ms hop',
  thresholds: analysis.thresholds,
  tolerance: {start_ms: 60, end_ms: 80},
  matches,
  pass: matches.every(m => m.pass)
};
fs.writeFileSync(path.join(reportDir, 'audio-benchmark.json'), JSON.stringify(report, null, 2) + '\n');
const lines = ['# Audio Alignment Benchmark', '', truth.description, '', `Overall: ${report.pass ? 'pass' : 'fail'}`, '', '| Token | Expected start | Measured start | Start error | Expected end | Measured end | End error | Status |', '|---|---:|---:|---:|---:|---:|---:|---|'];
for (const m of matches) lines.push(`| ${m.token} | ${m.start.toFixed(3)} | ${m.measured ? m.measured.start.toFixed(3) : 'missing'} | ${m.start_error_ms} ms | ${m.end.toFixed(3)} | ${m.measured ? m.measured.end.toFixed(3) : 'missing'} | ${m.end_error_ms} ms | ${m.pass ? 'pass' : 'fail'} |`);
fs.writeFileSync(path.join(reportDir, 'audio-benchmark.md'), lines.join('\n') + '\n');
console.log(JSON.stringify({pass: report.pass, regions: analysis.regions.length, matches}, null, 2));
if (!report.pass) process.exitCode = 1;
