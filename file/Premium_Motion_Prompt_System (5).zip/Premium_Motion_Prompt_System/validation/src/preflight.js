'use strict';

const fs = require('fs');
const path = require('path');
const Ajv = require('ajv/dist/2020');
const fontkit = require('fontkit');
const ffmpegPath = require('ffmpeg-static');
const ffprobe = require('ffprobe-static');
const {readWav} = require('./audio-utils');
const {findEmDash, TEXT_FILE_EXTENSIONS} = require('./text-policy');
const {validateDialogueSvgMap} = require('./dialogue-svg');
const {validateExplainerStyle, timelineProgress} = require('./explainer-timing');

const root = path.resolve(__dirname, '../..');
const reportDir = path.join(__dirname, '../reports');
fs.mkdirSync(reportDir, {recursive: true});
const checks = [];
const add = (id, pass, expected, measured, severity = 'error') => checks.push({id, status: pass ? 'pass' : severity === 'warning' ? 'warning' : 'fail', expected, measured});
const readJson = rel => JSON.parse(fs.readFileSync(path.join(root, rel), 'utf8'));

function validateSchemas() {
  const cases = [
    ['project_example_schema', 'schemas/project.schema.json', 'project/project.example.json', 'generic project example'],
    ['machine_project_example_schema', 'schemas/project.schema.json', 'examples/machine-readable/project.example.json', 'machine-readable project example'],
    ['scene_plan_example_schema', 'schemas/scene-plan.schema.json', 'examples/machine-readable/scene-plan.example.json', 'generic scene plan example'],
    ['word_timing_example_schema', 'schemas/word-timing.schema.json', 'examples/machine-readable/word-timing.example.json', 'synthetic word timing example'],
    ['media_manifest_schema', 'schemas/media-manifest.schema.json', 'project/media-manifest.json', 'empty media manifest template'],
    ['delivery_report_schema', 'schemas/delivery-report.schema.json', 'project/delivery-report.json', 'unpublished delivery report template'],
    ['subtitle_style_schema', 'schemas/subtitle-style.schema.json', 'project/subtitle-style.json', 'premium subtitle style template'],
    ['dialogue_svg_map_schema', 'schemas/dialogue-svg-map.schema.json', 'project/dialogue-svg-map.json', 'empty dialogue SVG map template'],
    ['explainer_style_schema', 'schemas/explainer-style.schema.json', 'project/explainer-style.json', 'technical explainer style template']
  ];
  for (const [id, schemaFile, dataFile, label] of cases) {
    const ajv = new Ajv({allErrors: true, strict: false});
    const valid = ajv.validate(readJson(schemaFile), readJson(dataFile));
    add(id, valid, `valid ${label}`, valid ? 'valid' : ajv.errorsText(ajv.errors));
    ajv.errors = null;
  }
}

function validateFiles() {
  const required = [
    'package.json', 'package-lock.json', 'README.md', 'MASTER_PROMPT.md', 'PROMPT_COMPACT.md', 'ROUTER.md',
    'validation/src/benchmark-fonts.js', 'validation/src/benchmark-audio.js', 'validation/src/responsive.js', 'validation/src/text-policy.js',
    'validation/tests/rules.test.js', 'validation/tests/delivery.test.js', 'validation/tests/text-policy.test.js', 'validation/tests/tmix.test.js',
    'libraries/media-sourcing.json', 'libraries/public-delivery.json', 'libraries/subtitle-recipes.json', 'libraries/dialogue-svg-recipes.json', 'libraries/explainer-recipes.json',
    'project/media-manifest.json', 'project/delivery-report.json', 'project/public-preview.template.html', 'project/subtitle-style.json', 'project/dialogue-svg-map.json', 'project/explainer-style.json',
    'schemas/subtitle-style.schema.json', 'schemas/dialogue-svg-map.schema.json', 'schemas/explainer-style.schema.json',
    'validation/src/subtitle-timing.js', 'validation/src/dialogue-svg.js', 'validation/src/explainer-timing.js', 'validation/tests/subtitle.test.js', 'validation/tests/dialogue-svg.test.js', 'validation/tests/explainer.test.js',
    'validation/assets/audio/audio-alignment-benchmark.wav',
    'validation/assets/fonts/anek-bangla/AnekBangla-700.ttf',
    'validation/assets/fonts/hind-siliguri/HindSiliguri-Medium.ttf',
    'validation/assets/fonts/anek-bangla/OFL.txt',
    'validation/assets/fonts/hind-siliguri/OFL.txt'
  ];
  for (let i = 1; i <= 23; i++) {
    const prefix = String(i).padStart(2, '0') + '_';
    if (!fs.readdirSync(root).some(name => name.startsWith(prefix) && name.endsWith('.md'))) required.push(`missing_${prefix}document`);
  }
  for (const rel of required) add(`file_${rel}`, fs.existsSync(path.join(root, rel)), 'file exists', rel);
  add('bundled_ffmpeg', fs.existsSync(ffmpegPath), 'npm bundled FFmpeg executable', ffmpegPath);
  add('bundled_ffprobe', fs.existsSync(ffprobe.path), 'npm bundled ffprobe executable', ffprobe.path);
}

function validateRouter() {
  const router = readJson('libraries/router-rules.json');
  const missing = [];
  const check = value => {
    const rel = value.split('#')[0];
    if (rel.startsWith('validation/reports/')) return;
    if (/\.(md|json)$/.test(rel) && !fs.existsSync(path.join(root, rel))) missing.push(value);
  };
  router.always_load.forEach(check);
  Object.values(router.task_modules).forEach(group => group.forEach(check));
  Object.values(router.genre_modules).forEach(group => group.forEach(check));
  add('router_targets', missing.length === 0, 'all source router targets exist; generated reports excluded', missing.length ? missing.join(', ') : 'all source targets exist');
}

function validateFonts() {
  const corpus = ['স্মৃতি', 'ইতিহাস', 'মায়া', 'আগামী', 'ক্ষুধা', 'জ্ঞান', 'শ্রদ্ধা', 'উদ্ভিদ', 'ব্যাখ্যা', 'সংকল্প', 'দৃঢ়তা', 'গণঅভ্যুত্থানে', 'ছুঁয়েছে', 'পোলার'];
  const files = ['validation/assets/fonts/anek-bangla/AnekBangla-700.ttf', 'validation/assets/fonts/hind-siliguri/HindSiliguri-Medium.ttf'];
  for (const rel of files) {
    const font = fontkit.openSync(path.join(root, rel));
    const missing = new Set();
    for (const text of corpus) for (const ch of text) {
      if (!/\s/.test(ch) && !font.hasGlyphForCodePoint(ch.codePointAt(0))) missing.add(ch);
    }
    add(`glyphs_${rel}`, missing.size === 0, 'all benchmark Bengali codepoints covered', missing.size ? [...missing].join('') : `${font.familyName}, complete corpus`);
  }
}

function validateAudio() {
  const audio = readWav(path.join(root, 'validation/assets/audio/audio-alignment-benchmark.wav'));
  add('benchmark_audio_duration', Math.abs(audio.duration - 4) <= 1 / audio.sampleRate, '4 second synthetic benchmark', `${audio.duration} seconds`);
  add('benchmark_audio_format', audio.channels === 2 && audio.sampleRate === 48000, '48 kHz stereo PCM', `${audio.sampleRate} Hz, ${audio.channels} channels`);
}

function validateNoReferenceArtifacts() {
  const forbidden = [];
  let sourceBytes = 0;
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, {withFileTypes: true})) {
      if (['node_modules', '.cache', '.git', '__pycache__'].includes(entry.name)) continue;
      const full = path.join(dir, entry.name);
      const rel = path.relative(root, full);
      if (entry.isDirectory()) walk(full);
      else {
        sourceBytes += fs.statSync(full).size;
        if (/\.(mp4|mov|webm|avi)$/i.test(entry.name) || /proof-sheet|encoded_S0|golden-reference/i.test(rel)) forbidden.push(rel);
      }
    }
  }
  walk(root);
  add('reference_video_removed', forbidden.length === 0, 'no reference video, legacy reference folder or visual reference proof', forbidden.length ? forbidden.join(', ') : 'none');
  add('source_payload_under_25mb', sourceBytes < 25000000, 'source payload below 25,000,000 bytes before ZIP compression', `${sourceBytes} bytes`);
  const scripts = readJson('package.json').scripts || {};
  add('no_reference_render_command', !scripts.render && !scripts.proof && !scripts.qc, 'no reference renderer or render command', Object.keys(scripts).join(', '));
}

function validatePublicDeliveryTemplate() {
  const html = fs.readFileSync(path.join(root, 'project/public-preview.template.html'), 'utf8');
  add('public_preview_video_controls', /<video\b[^>]*\bcontrols\b/i.test(html) && html.includes('src="media/final.mp4"'), 'native video controls and relative MP4 source', 'template checked');
  add('public_preview_download_links', html.includes('href="media/final.mp4"') && html.includes('href="delivery.zip"'), 'direct MP4 and delivery ZIP links', 'template checked');
  add('public_preview_relative_assets', !/(?:src|href)="https?:\/\//i.test(html), 'no remote asset dependency in preview template', 'relative paths only');
  add('public_preview_self_contained', !/<script\b/i.test(html) && !/<link\b[^>]*rel="stylesheet"/i.test(html), 'inline styling and no script dependency', 'self-contained template');
  const delivery = readJson('project/delivery-report.json');
  const urls = [delivery.artifacts.public_preview_url, delivery.artifacts.public_video_url, delivery.artifacts.public_archive_url];
  add('delivery_template_unpublished', delivery.status === 'not_started' && urls.every(value => value === null), 'template contains no fake published URLs', `${delivery.status}, all public URLs null`);
}

function validateSubtitleStyle() {
  const style = readJson('project/subtitle-style.json');
  const decorations = style.decorations;
  const noLeadingDecoration = ['leading_vertical_bar', 'leading_dash', 'leading_pipe', 'leading_bullet', 'background_card'].every(key => decorations[key] === false);
  add('subtitle_no_leading_decoration', noLeadingDecoration && style.base_color !== style.active_colors[0], 'no leading bar, pipe, dash, bullet or card; distinct active color', `${style.base_color}, ${style.active_colors.join(', ')}`);
  add('subtitle_actual_audio_highlight', style.timing.source === 'actual_audio' && style.timing.color_after_reveal === true && style.timing.single_active_word === true, 'actual audio, color after reveal, one active word', JSON.stringify(style.timing));
  add('subtitle_complex_script_layout', style.complex_script.split_characters === false && style.complex_script.pre_shape_full_line === true && style.complex_script.reserve_layout_before_reveal === true && style.animation.active_scale <= 1.02, 'whole shaped words and stable pre-shaped layout', JSON.stringify(style.complex_script));
}

function validateDialogueSvgPolicy() {
  const policy = readJson('libraries/dialogue-svg-recipes.json');
  const rules = policy.uniqueness_rules;
  const pass = policy.unit === 'semantic_dialogue' && policy.one_unique_primary_svg_per_dialogue === true && policy.srt_cue_equals_dialogue === false && policy.actual_audio_timing_primary === true && rules.unique_dialogue_id === true && rules.unique_asset_id === true && rules.unique_source_file === true && rules.safe_relative_source_path === true && rules.unique_visual_signature === true && rules.primary_generator_or_geometry_change_required === true && rules.composition_or_motion_change_required === true && rules.difference_from_previous_required === true && rules.color_only_variation_counts_as_new === false && rules.position_only_variation_counts_as_new === false && rules.scale_only_variation_counts_as_new === false && rules.opacity_only_variation_counts_as_new === false && rules.text_only_variation_counts_as_new === false && rules.duration_only_variation_counts_as_new === false && rules.path_length_only_variation_counts_as_new === false && rules.shared_secondary_motif_allowed === true;
  add('dialogue_svg_uniqueness_policy', pass, 'one unique primary SVG per semantic dialogue; color-only clones rejected', JSON.stringify({unit: policy.unit, unique: policy.one_unique_primary_svg_per_dialogue}));
  const template = readJson('project/dialogue-svg-map.json');
  const result = validateDialogueSvgMap(template);
  add('dialogue_svg_template_and_validator', Array.isArray(template.dialogues) && result.pass, 'empty map template accepted by generic validator', JSON.stringify(result));
}

function validateExplainerPolicy() {
  const style = readJson('project/explainer-style.json');
  const result = validateExplainerStyle(style);
  add('explainer_style_policy', result.pass, 'stable phrase echo, actual timeline and authorized watermark policy', result.pass ? 'valid' : result.errors.join(', '));
  const midpoint = timelineProgress(60, 120);
  add('explainer_actual_progress_utility', midpoint === 0.5 && style.progress_rail.value_source === 'actual_global_timeline' && style.progress_rail.fake_loading === false, 'actual global timeline produces deterministic progress', `midpoint=${midpoint}`);
  const recipes = readJson('libraries/explainer-recipes.json');
  add('explainer_reference_free_policy', recipes.reference_assets_included === false && recipes.global_rules.keyword_echo_replaces_verbatim_subtitles === false && recipes.global_rules.third_party_watermark_import_without_permission === false, 'no reference assets, subtitle replacement or unapproved watermark import', JSON.stringify(recipes.global_rules));
}

function validateVersionAlignment() {
  const version = readJson('package.json').version;
  const recipeVersion = readJson('libraries/recipe-versions.json').package_version;
  const routerVersion = readJson('libraries/router-rules.json').schema_version;
  const readmeVersion = fs.readFileSync(path.join(root, 'README.md'), 'utf8').match(/^# Premium Motion Prompt System (.+)$/m);
  const measured = {package: version, recipes: recipeVersion, router: routerVersion, readme: readmeVersion && readmeVersion[1]};
  add('package_version_alignment', recipeVersion === version && routerVersion === version && readmeVersion && readmeVersion[1] === version, 'package, README, router and recipe registry versions match', JSON.stringify(measured));
}

function validateTextFiles() {
  const violations = [];
  const filenameViolations = [];
  const mixed = [];
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, {withFileTypes: true})) {
      if (['node_modules', '.cache', '.git', 'proof'].includes(entry.name)) continue;
      const full = path.join(dir, entry.name);
      const rel = path.relative(root, full);
      if (findEmDash(entry.name).length) filenameViolations.push(rel);
      if (entry.isDirectory()) walk(full);
      else if (TEXT_FILE_EXTENSIONS.includes(path.extname(entry.name).toLowerCase())) {
        const text = fs.readFileSync(full, 'utf8');
        if (findEmDash(text).length) violations.push(rel);
        text.split(/\r?\n/).forEach((line, index) => {
          if (/[\u0980-\u09ff][A-Za-z]|[A-Za-z][\u0980-\u09ff]/.test(line)) mixed.push(`${rel}:${index + 1}`);
        });
      }
    }
  }
  walk(root);
  add('no_em_dash', violations.length === 0, 'no U+2014 in text, SVG, subtitle, metadata and code files', violations.length ? violations.join(', ') : 'none');
  add('no_em_dash_in_filenames', filenameViolations.length === 0, 'no U+2014 in file or directory names', filenameViolations.length ? filenameViolations.join(', ') : 'none');
  add('no_accidental_mixed_script', mixed.length === 0, 'no immediate Bengali-Latin mixed-script tokens', mixed.length ? mixed.join(', ') : 'none');
}

function main() {
  validateSchemas();
  validateFiles();
  validateRouter();
  validateFonts();
  validateAudio();
  validateNoReferenceArtifacts();
  validatePublicDeliveryTemplate();
  validateSubtitleStyle();
  validateDialogueSvgPolicy();
  validateExplainerPolicy();
  validateVersionAlignment();
  validateTextFiles();
  const failed = checks.filter(c => c.status === 'fail');
  const warnings = checks.filter(c => c.status === 'warning');
  const report = {
    purpose: 'Prompt and validation toolkit only, no reference video or visual style template',
    pass: failed.length === 0,
    checks,
    summary: {total: checks.length, passed: checks.filter(c => c.status === 'pass').length, failed: failed.length, warnings: warnings.length}
  };
  fs.writeFileSync(path.join(reportDir, 'preflight.json'), JSON.stringify(report, null, 2) + '\n');
  const lines = ['# Preflight Report', '', 'Prompt and validation toolkit only. No reference video or visual style template.', '', `Overall: ${report.pass ? 'pass' : 'fail'}`, '', '| Check | Status | Expected | Measured |', '|---|---|---|---|'];
  for (const c of checks) lines.push(`| ${c.id} | ${c.status} | ${String(c.expected).replaceAll('|', '\\|')} | ${String(c.measured).replaceAll('|', '\\|')} |`);
  fs.writeFileSync(path.join(reportDir, 'preflight.md'), lines.join('\n') + '\n');
  console.log(`Preflight: ${report.summary.passed}/${report.summary.total} passed, ${failed.length} failed, ${warnings.length} warnings`);
  if (failed.length) {
    console.error(failed);
    process.exitCode = 1;
  }
}

main();
