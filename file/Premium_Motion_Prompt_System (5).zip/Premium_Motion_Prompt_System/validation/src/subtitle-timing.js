'use strict';

function buildSubtitleTimeline(options) {
  const {
    cueStart,
    cueEnd,
    words,
    fps = 30,
    preSpeechRevealMs = 160,
    colorDelayFrames = 1,
    activeColors = ['#2ED3A6'],
    alternateActiveColors = false
  } = options;
  if (!Number.isFinite(cueStart) || !Number.isFinite(cueEnd) || cueEnd <= cueStart) throw new Error('Invalid cue range');
  if (!Array.isArray(words) || words.length === 0) throw new Error('At least one shaped word is required');
  if (!Number.isFinite(fps) || fps <= 0) throw new Error('Invalid frame rate');
  if (!Number.isFinite(colorDelayFrames) || colorDelayFrames <= 0) throw new Error('Color delay must be positive');
  if (!Array.isArray(activeColors) || activeColors.length === 0) throw new Error('At least one active color is required');
  if (alternateActiveColors && activeColors.length < 2) throw new Error('Alternate mode requires two active colors');

  const revealLead = preSpeechRevealMs / 1000;
  const colorDelay = colorDelayFrames / fps;
  const timeline = words.map((word, index) => {
    if (!word || typeof word.text !== 'string' || !word.text.trim()) throw new Error(`Invalid word at index ${index}`);
    if (!Number.isFinite(word.start) || !Number.isFinite(word.end) || word.end <= word.start) throw new Error(`Invalid timing at index ${index}`);
    if (word.start < cueStart || word.end > cueEnd) throw new Error(`Word outside cue at index ${index}`);
    if (index > 0 && word.start < words[index - 1].end) throw new Error(`Overlapping word timing at index ${index}`);
    const duration = word.end - word.start;
    return {
      index,
      text: word.text,
      start: word.start,
      end: word.end,
      reveal_start: Math.max(cueStart, word.start - revealLead),
      reveal_end: word.start,
      highlight_start: Math.min(word.start + colorDelay, word.start + duration / 2),
      accent_color: activeColors[alternateActiveColors ? index % activeColors.length : 0]
    };
  });

  return timeline.map((word, index) => ({
    ...word,
    highlight_end: index < timeline.length - 1 ? timeline[index + 1].highlight_start : cueEnd,
    color_after_reveal: true
  }));
}

module.exports = {buildSubtitleTimeline};
