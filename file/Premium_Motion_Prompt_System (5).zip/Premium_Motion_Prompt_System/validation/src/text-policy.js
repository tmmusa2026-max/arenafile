'use strict';

const FORBIDDEN_CODE_POINT = 0x2014;
const FORBIDDEN_CHARACTER = String.fromCodePoint(FORBIDDEN_CODE_POINT);
const TEXT_FILE_EXTENSIONS = ['.md', '.json', '.js', '.csv', '.txt', '.html', '.svg', '.srt', '.vtt', '.ass', '.ssa', '.xml', '.yaml', '.yml'];

function hasEmDash(text) {
  return String(text).includes(FORBIDDEN_CHARACTER);
}

function findEmDash(text) {
  const value = String(text);
  const matches = [];
  let line = 1;
  let column = 1;
  for (let index = 0; index < value.length; index++) {
    const character = value[index];
    if (character === FORBIDDEN_CHARACTER) matches.push({index, line, column, code_point: 'U+2014'});
    if (character === '\n') {
      line++;
      column = 1;
    } else {
      column++;
    }
  }
  return matches;
}

function assertNoEmDash(text, label = 'text') {
  const matches = findEmDash(text);
  if (matches.length) {
    const locations = matches.map(match => `line ${match.line}, column ${match.column}`).join('; ');
    throw new Error(`${label} contains forbidden U+2014 at ${locations}`);
  }
  return true;
}

module.exports = {FORBIDDEN_CODE_POINT, FORBIDDEN_CHARACTER, TEXT_FILE_EXTENSIONS, hasEmDash, findEmDash, assertNoEmDash};
