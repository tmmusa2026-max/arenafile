'use strict';

const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const mix = (a, b, t) => a + (b - a) * t;
const smoothstep = (a, b, v) => {
  const t = clamp((v - a) / (b - a || 1));
  return t * t * (3 - 2 * t);
};

function cubicBezier(x1, y1, x2, y2) {
  const ax = 3 * x1 - 3 * x2 + 1;
  const bx = 3 * x2 - 6 * x1;
  const cx = 3 * x1;
  const ay = 3 * y1 - 3 * y2 + 1;
  const by = 3 * y2 - 6 * y1;
  const cy = 3 * y1;
  const sampleX = t => ((ax * t + bx) * t + cx) * t;
  const sampleY = t => ((ay * t + by) * t + cy) * t;
  const dx = t => (3 * ax * t + 2 * bx) * t + cx;
  return x => {
    const u = clamp(x);
    let t = u;
    for (let i = 0; i < 8; i++) {
      const err = sampleX(t) - u;
      if (Math.abs(err) < 1e-6) return sampleY(t);
      const d = dx(t);
      if (Math.abs(d) > 1e-6) t -= err / d;
    }
    let lo = 0, hi = 1;
    t = u;
    for (let i = 0; i < 20; i++) {
      const err = sampleX(t) - u;
      if (Math.abs(err) < 1e-6) break;
      if (err > 0) hi = t; else lo = t;
      t = (lo + hi) / 2;
    }
    return sampleY(t);
  };
}

const curves = {
  expoOut: cubicBezier(0.16, 1, 0.3, 1),
  quintOut: cubicBezier(0.22, 1, 0.36, 1),
  expoInOut: cubicBezier(0.87, 0, 0.13, 1),
  backOut: cubicBezier(0.34, 1.56, 0.64, 1),
  sineInOut: cubicBezier(0.37, 0, 0.63, 1),
  exitAccelerate: cubicBezier(0.7, 0, 0.84, 0),
  emphasisSoft: cubicBezier(0.2, 0.8, 0.2, 1),
  circOut: cubicBezier(0.075, 0.82, 0.165, 1),
  quartInOut: cubicBezier(0.76, 0, 0.24, 1)
};

const phase = (t, start, duration, curve = curves.expoOut) => curve(clamp((t - start) / duration));

function hash32(x) {
  let h = x | 0;
  h = Math.imul(h ^ (h >>> 16), 0x45d9f3b);
  h = Math.imul(h ^ (h >>> 16), 0x45d9f3b);
  h = h ^ (h >>> 16);
  return h >>> 0;
}

function random01(seed, index) {
  return hash32(seed + Math.imul(index + 1, 0x9e3779b1)) / 4294967295;
}

function decreasingStagger(count, start = 0.1, end = 0.06) {
  const out = [];
  let time = 0;
  for (let i = 0; i < count; i++) {
    out.push(time);
    const u = count <= 1 ? 0 : i / (count - 1);
    time += mix(start, end, smoothstep(0, 1, u));
  }
  return out;
}

module.exports = {clamp, mix, smoothstep, cubicBezier, curves, phase, hash32, random01, decreasingStagger};
