'use strict';

const fs = require('fs');

function writeWav(filePath, samples, sampleRate = 48000, channels = 2) {
  const frames = Math.floor(samples.length / channels);
  const dataSize = frames * channels * 2;
  const buffer = Buffer.alloc(44 + dataSize);
  buffer.write('RIFF', 0);
  buffer.writeUInt32LE(36 + dataSize, 4);
  buffer.write('WAVE', 8);
  buffer.write('fmt ', 12);
  buffer.writeUInt32LE(16, 16);
  buffer.writeUInt16LE(1, 20);
  buffer.writeUInt16LE(channels, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(sampleRate * channels * 2, 28);
  buffer.writeUInt16LE(channels * 2, 32);
  buffer.writeUInt16LE(16, 34);
  buffer.write('data', 36);
  buffer.writeUInt32LE(dataSize, 40);
  for (let i = 0; i < frames * channels; i++) {
    const v = Math.max(-1, Math.min(1, samples[i]));
    buffer.writeInt16LE(Math.round(v < 0 ? v * 32768 : v * 32767), 44 + i * 2);
  }
  fs.writeFileSync(filePath, buffer);
}

function readWav(filePath) {
  const buffer = fs.readFileSync(filePath);
  if (buffer.toString('ascii', 0, 4) !== 'RIFF' || buffer.toString('ascii', 8, 12) !== 'WAVE') {
    throw new Error(`Unsupported WAV file: ${filePath}`);
  }
  let offset = 12;
  let fmt = null;
  let data = null;
  while (offset + 8 <= buffer.length) {
    const id = buffer.toString('ascii', offset, offset + 4);
    const size = buffer.readUInt32LE(offset + 4);
    const start = offset + 8;
    if (id === 'fmt ') {
      fmt = {
        format: buffer.readUInt16LE(start),
        channels: buffer.readUInt16LE(start + 2),
        sampleRate: buffer.readUInt32LE(start + 4),
        bits: buffer.readUInt16LE(start + 14)
      };
    } else if (id === 'data') {
      data = buffer.subarray(start, start + size);
    }
    offset = start + size + (size % 2);
  }
  if (!fmt || !data || fmt.format !== 1 || fmt.bits !== 16) {
    throw new Error(`Only 16 bit PCM WAV is supported: ${filePath}`);
  }
  const count = Math.floor(data.length / 2);
  const samples = new Float32Array(count);
  for (let i = 0; i < count; i++) samples[i] = data.readInt16LE(i * 2) / 32768;
  return {...fmt, samples, duration: count / fmt.channels / fmt.sampleRate};
}

function monoFromInterleaved(audio) {
  const frames = Math.floor(audio.samples.length / audio.channels);
  const mono = new Float32Array(frames);
  for (let i = 0; i < frames; i++) {
    let sum = 0;
    for (let c = 0; c < audio.channels; c++) sum += audio.samples[i * audio.channels + c];
    mono[i] = sum / audio.channels;
  }
  return mono;
}

function analyzeSpeechLikeRegions(audio, options = {}) {
  const mono = monoFromInterleaved(audio);
  const sr = audio.sampleRate;
  const windowSeconds = options.windowSeconds || 0.01;
  const hopSeconds = options.hopSeconds || 0.005;
  const window = Math.max(1, Math.round(sr * windowSeconds));
  const hop = Math.max(1, Math.round(sr * hopSeconds));
  const rms = [];
  const times = [];
  for (let start = 0; start + window <= mono.length; start += hop) {
    let sum = 0;
    for (let i = 0; i < window; i++) {
      const v = mono[start + i];
      sum += v * v;
    }
    rms.push(Math.sqrt(sum / window));
    times.push((start + window / 2) / sr);
  }
  const sorted = [...rms].sort((a, b) => a - b);
  const noise = sorted[Math.floor(sorted.length * 0.2)] || 0;
  const peak = sorted[Math.floor(sorted.length * 0.98)] || 1;
  const startThreshold = Math.max(noise * 3.2, peak * 0.075, 0.004);
  const endThreshold = Math.max(noise * 2.0, peak * 0.04, 0.0025);
  const minDuration = options.minDuration || 0.08;
  const mergeGap = options.mergeGap || 0.06;
  const regions = [];
  let active = null;
  for (let i = 0; i < rms.length; i++) {
    if (!active && rms[i] >= startThreshold) active = {start: times[i] - windowSeconds / 2, end: times[i]};
    if (active && rms[i] >= endThreshold) active.end = times[i] + windowSeconds / 2;
    if (active && rms[i] < endThreshold && times[i] - active.end > 0.035) {
      if (active.end - active.start >= minDuration) regions.push(active);
      active = null;
    }
  }
  if (active && active.end - active.start >= minDuration) regions.push(active);
  const merged = [];
  for (const region of regions) {
    const last = merged[merged.length - 1];
    if (last && region.start - last.end <= mergeGap) last.end = region.end;
    else merged.push({...region});
  }
  return {
    regions: merged.map(r => ({start: Math.max(0, r.start), end: Math.min(audio.duration, r.end)})),
    envelope: {times, rms},
    thresholds: {noise, peak, startThreshold, endThreshold},
    windowSeconds,
    hopSeconds
  };
}

module.exports = {writeWav, readWav, monoFromInterleaved, analyzeSpeechLikeRegions};
