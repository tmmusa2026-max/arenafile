'use strict';

const path = require('path');
const root = path.resolve(__dirname, '../..');
const fontFiles = [
  path.join(root, 'validation/assets/fonts/anek-bangla/AnekBangla-700.ttf'),
  path.join(root, 'validation/assets/fonts/anek-bangla/AnekBangla-400.ttf'),
  path.join(root, 'validation/assets/fonts/hind-siliguri/HindSiliguri-Medium.ttf')
];
let configured = false;
function configureFonts() {
  if (configured) return;
  const fs = require('fs');
  const configDir = path.join(root, 'validation/.cache/fontconfig');
  const cacheDir = path.join(configDir, 'cache');
  fs.mkdirSync(cacheDir, {recursive: true});
  const configFile = path.join(configDir, 'fonts.conf');
  const xml = `<?xml version="1.0"?>\n<!DOCTYPE fontconfig SYSTEM "fonts.dtd">\n<fontconfig>\n  <dir>${path.join(root, 'validation/assets/fonts')}</dir>\n  <cachedir>${cacheDir}</cachedir>\n</fontconfig>\n`;
  fs.writeFileSync(configFile, xml);
  process.env.FONTCONFIG_FILE = configFile;
  process.env.FONTCONFIG_PATH = configDir;
  configured = true;
}
module.exports = {root, fontFiles, configureFonts};
