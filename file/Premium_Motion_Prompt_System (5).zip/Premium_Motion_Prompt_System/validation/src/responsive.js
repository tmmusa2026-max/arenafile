'use strict';

const profiles = require('../../libraries/responsive-performance.json').responsive_profiles;

function fitHeadline({profile = 'wide_1920_1080', inkWidth, inkHeight, maxFontSize = 220, maxHeightRatio = 0.34, blurPadding = 24}) {
  const p = profiles[profile];
  if (!p) throw new Error(`Unknown responsive profile: ${profile}`);
  if (![inkWidth, inkHeight, maxFontSize].every(value => Number.isFinite(value) && value > 0)) {
    throw new Error('Headline ink dimensions and maximum font size must be positive finite numbers');
  }
  const width = profile.startsWith('wide') ? 1920 : 1080;
  const height = profile.startsWith('vertical') ? 1920 : 1080;
  const availableWidth = Math.min(p.hero_max_width_px, width - p.safe_side_px * 2);
  const availableHeight = height * maxHeightRatio;
  const scale = Math.min(1, availableWidth / inkWidth, availableHeight / inkHeight);
  const fontSize = maxFontSize * scale;
  return {
    profile,
    canvas: {width, height},
    safe_area: {side: p.safe_side_px, top: p.safe_top_px, bottom: p.safe_bottom_px},
    font_size: fontSize,
    scale,
    ink_width: inkWidth * scale,
    ink_height: inkHeight * scale,
    mask: {
      x: (width - inkWidth * scale) / 2 - blurPadding,
      y: (height - inkHeight * scale) / 2 - blurPadding,
      width: inkWidth * scale + blurPadding * 2,
      height: inkHeight * scale + blurPadding * 2
    },
    camera_travel_scale: p.camera_travel_scale,
    particle_scale: p.particle_scale
  };
}

function resolveShortScene({duration, readingTime, audioHold = 0, transitionOverlap = 0, entry = 0.46, exit = 0.26, layers = ['mask', 'position', 'blur', 'scale', 'shimmer', 'particles']}) {
  const usable = duration - transitionOverlap;
  const minimumHold = readingTime + audioHold;
  let motionBudget = usable - minimumHold;
  const removed = [];
  const layerCostAssumption = 0.06;
  const optional = ['particles', 'ambient', 'shimmer', 'chromatic', 'scale'];
  const remaining = [...layers];
  while (motionBudget < entry + exit && remaining.length > 3) {
    const candidate = optional.find(name => remaining.includes(name));
    if (!candidate) break;
    remaining.splice(remaining.indexOf(candidate), 1);
    removed.push(candidate);
    motionBudget += layerCostAssumption;
  }
  const compression = Math.min(1, Math.max(0.45, motionBudget / (entry + exit)));
  const adjustedEntry = Math.max(0.24, entry * compression);
  const adjustedExit = Math.max(0.16, exit * compression);
  const hold = usable - adjustedEntry - adjustedExit;
  return {
    usable_time: usable,
    minimum_hold: minimumHold,
    layer_cost_assumption_seconds: layerCostAssumption,
    motion_budget: motionBudget,
    entry: adjustedEntry,
    exit: adjustedExit,
    estimated_hold: hold,
    remaining_layers: remaining,
    removed_layers: removed,
    requires_brief_change: hold < minimumHold * 0.55,
    rule: 'Reduce decoration before increasing speed. Never edit source audio or copy to solve the conflict.'
  };
}

function validateContinuity(graph) {
  if (!graph || !Array.isArray(graph.transitions)) {
    return {pass: false, errors: ['Continuity graph must contain a transitions array']};
  }
  const errors = [];
  const seen = new Set();
  for (const edge of graph.transitions) {
    const id = `${edge.from_scene}->${edge.to_scene}`;
    if (seen.has(id)) errors.push(`Duplicate transition ${id}`);
    seen.add(id);
    if (!edge.shared_element_id) errors.push(`${id} has no shared element`);
    if (edge.previous_text_exit_end > edge.new_text_entry_start) {
      errors.push(`${id} has readable headline overlap from ${edge.new_text_entry_start} to ${edge.previous_text_exit_end}`);
    }
    if (!edge.semantic_handoff) errors.push(`${id} has no semantic handoff`);
    if (!edge.proof_frame) errors.push(`${id} has no proof frame`);
  }
  return {pass: errors.length === 0, errors};
}

module.exports = {profiles, fitHeadline, resolveShortScene, validateContinuity};
