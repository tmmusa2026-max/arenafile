'use strict';

const fs = require('fs');
const path = require('path');
const {writeWav} = require('./audio-utils');
const {random01} = require('./easings');
const outDir = path.join(__dirname, '../assets/audio');
const configDir = path.join(__dirname, '../config');
fs.mkdirSync(outDir, {recursive: true});
fs.mkdirSync(configDir, {recursive: true});

function addBenchmarkBurst(samples, sr, start, end, baseFrequency, seed) {
  const first = Math.round(start * sr);
  const last = Math.round(end * sr);
  let smoothNoise = 0;
  for (let n = first; n < last; n++) {
    const t = (n - first) / sr;
    const duration = end - start;
    const attack = Math.min(1, t / 0.035);
    const release = Math.max(0, Math.min(1, (duration - t) / 0.06));
    const syllable = 0.72 + 0.28 * Math.sin(2 * Math.PI * 5.2 * t + 0.4);
    const env = Math.max(0, attack * release * syllable);
    const glottal = Math.sin(2 * Math.PI * baseFrequency * t) * 0.28 + Math.sin(2 * Math.PI * baseFrequency * 2.7 * t) * 0.17 + Math.sin(2 * Math.PI * baseFrequency * 5.1 * t) * 0.08;
    const raw = random01(seed, n - first) * 2 - 1;
    smoothNoise += 0.09 * (raw - smoothNoise);
    const value = env * (glottal + smoothNoise * 0.35) * 0.55;
    samples[n * 2] += value;
    samples[n * 2 + 1] += value;
  }
}

const sr = 48000;
const samples = new Float32Array(4 * sr * 2);
const groundTruth = [
  {token: 'ক', start: 0.3, end: 0.75, frequency: 116},
  {token: 'খ', start: 1.1, end: 1.55, frequency: 132},
  {token: 'গ', start: 2.15, end: 2.75, frequency: 108},
  {token: 'ঘ', start: 3.2, end: 3.65, frequency: 124}
];
groundTruth.forEach((b, i) => addBenchmarkBurst(samples, sr, b.start, b.end, b.frequency, 700 + i));
writeWav(path.join(outDir, 'audio-alignment-benchmark.wav'), samples, sr, 2);
fs.writeFileSync(path.join(configDir, 'audio-benchmark-ground-truth.json'), JSON.stringify({
  description: 'Synthetic harmonic bursts for envelope alignment testing, not human speech and not a reference soundtrack',
  source_audio: 'validation/assets/audio/audio-alignment-benchmark.wav',
  events: groundTruth.map(({token, start, end}) => ({token, start, end}))
}, null, 2) + '\n');
console.log('Synthetic audio benchmark regenerated');
