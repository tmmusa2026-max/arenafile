'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const Ajv = require('ajv/dist/2020');

const root = path.resolve(__dirname, '../..');
const readJson = rel => JSON.parse(fs.readFileSync(path.join(root, rel), 'utf8'));
const clone = value => JSON.parse(JSON.stringify(value));
const ajv = new Ajv({allErrors: true, strict: false});
const checks = {};

const deliverySchema = readJson('schemas/delivery-report.schema.json');
const deliveryTemplate = readJson('project/delivery-report.json');
checks.unpublished_template_valid = ajv.validate(deliverySchema, deliveryTemplate);
assert.strictEqual(checks.unpublished_template_valid, true, ajv.errorsText(ajv.errors));

const invalidPublished = clone(deliveryTemplate);
invalidPublished.status = 'published';
checks.published_without_urls_rejected = !ajv.validate(deliverySchema, invalidPublished);
assert.strictEqual(checks.published_without_urls_rejected, true, 'Published status must require public URLs and verification');

const renderedLocal = clone(deliveryTemplate);
renderedLocal.status = 'rendered_local';
renderedLocal.commands.push({command: 'npm run render', cwd: '.', status: 'completed', exit_code: 0, log_file: 'reports/render.log'});
renderedLocal.artifacts.local_video = 'output/final.mp4';
checks.rendered_local_valid = ajv.validate(deliverySchema, renderedLocal);
assert.strictEqual(checks.rendered_local_valid, true, ajv.errorsText(ajv.errors));

const mediaSchema = readJson('schemas/media-manifest.schema.json');
const invalidMedia = {
  schema_version: '1.0.0',
  project_name: 'Validation only',
  assets: [{
    asset_id: 'invalid_test_asset',
    scene_id: 'S01',
    kind: 'photo',
    status: 'candidate',
    semantic_role: 'Schema rejection test',
    source_page_url: 'https://test.invalid/source',
    direct_file_url: null,
    local_file: null,
    creator: 'Test fixture',
    license_or_permission: 'Test fixture',
    license_url: null,
    attribution: '',
    accessed_at: 'Test fixture',
    news_usage: 'illustrative',
    editorial_relevance: 'Schema rejection test',
    verification_status: 'unverified',
    allowed_use: 'Test fixture',
    watermark_removed: true,
    source_audio_used: false
  }]
};
checks.watermark_removal_rejected = !ajv.validate(mediaSchema, invalidMedia);
assert.strictEqual(checks.watermark_removal_rejected, true, 'Watermark removal must be rejected');

const mediaPolicy = readJson('libraries/media-sourcing.json');
assert.deepStrictEqual(mediaPolicy.intake.required_initial_files, ['voice_over', 'srt']);
assert.strictEqual(mediaPolicy.intake.language, 'bn');
assert.strictEqual(mediaPolicy.intake.ask_for_effect_list, false);
assert.strictEqual(mediaPolicy.intake.ask_for_svg_list, false);
checks.bengali_two_file_intake = true;

const publicPolicy = readJson('libraries/public-delivery.json');
assert.strictEqual(publicPolicy.rules.never_fabricate_public_url, true);
assert.strictEqual(publicPolicy.rules.separate_http_availability_from_observed_playback, true);
checks.honest_public_delivery_policy = true;

const preview = fs.readFileSync(path.join(root, 'project/public-preview.template.html'), 'utf8');
assert(/<video\b[^>]*\bcontrols\b/i.test(preview));
assert(preview.includes('src="media/final.mp4"'));
assert(preview.includes('href="delivery.zip"'));
checks.playable_preview_structure = true;

const report = {pass: true, tests: Object.keys(checks).length, checks};
fs.writeFileSync(path.join(__dirname, '../reports/delivery-test.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
