'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const {createVisualSignature, validateDialogueSvgMap} = require('../src/dialogue-svg');

const checks = {};
const clone = value => JSON.parse(JSON.stringify(value));
function makeSvg(config) {
  const svg = {
    concept: config.concept,
    primary_generator: config.primary_generator,
    geometry_signature: config.geometry_signature,
    composition_signature: config.composition_signature,
    motion_signature: config.motion_signature,
    difference_from_previous: config.difference_from_previous,
    continuity_from: config.continuity_from,
    shared_motif: 'small_signal_dot',
    source_file: config.source_file,
    original: true,
    color_palette: ['#F5F7FA', '#2ED3A6'],
    asset_id: config.asset_id
  };
  return {...svg, visual_signature: createVisualSignature(svg)};
}
const map = {
  schema_version: '1.0.0',
  project_name: 'Validation only',
  dialogues: [
    {
      dialogue_id: 'D001', source_text: 'প্রথম নমুনা উক্তি', start: 0, end: 1,
      speech_act: 'statement', semantic_focus: 'স্থির বক্তব্য', emotion: 'calm', narrative_role: 'context',
      svg: makeSvg({asset_id: 'SVG_D001', concept: 'স্থির কাঠামো', primary_generator: 'anchored_structure', geometry_signature: 'three_supported_columns', composition_signature: 'horizontal_foundation', motion_signature: 'quiet_settle', difference_from_previous: null, continuity_from: null, source_file: 'assets/dialogue/D001.svg'})
    },
    {
      dialogue_id: 'D002', source_text: 'দ্বিতীয় নমুনা প্রশ্ন', start: 1.2, end: 2.2,
      speech_act: 'question', semantic_focus: 'অনুসন্ধান', emotion: 'curious', narrative_role: 'turn',
      svg: makeSvg({asset_id: 'SVG_D002', concept: 'উন্মুক্ত পথ', primary_generator: 'open_path', geometry_signature: 'arc_with_unresolved_endpoint', composition_signature: 'radial_open_space', motion_signature: 'endpoint_search', difference_from_previous: 'New generator, geometry, composition and motion', continuity_from: 'SVG_D001', source_file: 'assets/dialogue/D002.svg'})
    },
    {
      dialogue_id: 'D003', source_text: 'তৃতীয় নমুনা তুলনা', start: 2.4, end: 3.4,
      speech_act: 'comparison', semantic_focus: 'দুই পক্ষের পার্থক্য', emotion: 'confident', narrative_role: 'evidence',
      svg: makeSvg({asset_id: 'SVG_D003', concept: 'অসম দুটি রূপ', primary_generator: 'asymmetric_dual_forms', geometry_signature: 'two_unequal_interlocking_paths', composition_signature: 'opposed_vertical_frames', motion_signature: 'counter_translate', difference_from_previous: 'Dual asymmetric forms replace the open arc with opposed composition', continuity_from: 'SVG_D002', source_file: 'assets/dialogue/D003.svg'})
    }
  ]
};

const valid = validateDialogueSvgMap(map, {allowEmpty: false});
assert.strictEqual(valid.pass, true, valid.errors.join('\n'));
assert.strictEqual(valid.dialogue_count, 3);
assert.strictEqual(valid.unique_svg_count, 3);
assert.strictEqual(valid.unique_visual_signature_count, 3);
checks.unique_svg_per_dialogue = true;
checks.shared_secondary_motif_allowed = true;

const colorClone = clone(map);
colorClone.dialogues[2].svg = clone(colorClone.dialogues[1].svg);
colorClone.dialogues[2].svg.asset_id = 'SVG_D003';
colorClone.dialogues[2].svg.source_file = 'assets/dialogue/D003.svg';
colorClone.dialogues[2].svg.color_palette = ['#FFFFFF'];
const colorCloneResult = validateDialogueSvgMap(colorClone, {allowEmpty: false});
assert.strictEqual(colorCloneResult.pass, false);
assert(colorCloneResult.errors.some(error => error.includes('duplicate visual_signature')));
checks.color_only_clone_rejected = true;

const nonStructuralVariants = [
  ['color_palette', ['#FFFFFF']],
  ['opacity', 0.4],
  ['position', {x: 120, y: 80}],
  ['scale', 1.3],
  ['display_text', 'শুধু লেখা বদল'],
  ['duration', 0.8],
  ['path_length', 420]
];
for (const [field, value] of nonStructuralVariants) {
  const variant = clone(map);
  variant.dialogues[2].svg = clone(variant.dialogues[1].svg);
  variant.dialogues[2].svg.asset_id = 'SVG_D003';
  variant.dialogues[2].svg.source_file = 'assets/dialogue/D003.svg';
  variant.dialogues[2].svg[field] = value;
  const result = validateDialogueSvgMap(variant, {allowEmpty: false});
  assert.strictEqual(result.pass, false, `${field} must not create a new dialogue SVG`);
  assert(result.errors.some(error => error.includes('duplicate visual_signature')));
}
checks.non_structural_variations_rejected = true;

const duplicateAsset = clone(map);
duplicateAsset.dialogues[2].svg.asset_id = duplicateAsset.dialogues[1].svg.asset_id;
const duplicateAssetResult = validateDialogueSvgMap(duplicateAsset, {allowEmpty: false});
assert.strictEqual(duplicateAssetResult.pass, false);
assert(duplicateAssetResult.errors.some(error => error.includes('duplicate SVG asset_id')));
checks.duplicate_asset_id_rejected = true;

const duplicateDialogue = clone(map);
duplicateDialogue.dialogues[2].dialogue_id = duplicateDialogue.dialogues[1].dialogue_id;
const duplicateDialogueResult = validateDialogueSvgMap(duplicateDialogue, {allowEmpty: false});
assert.strictEqual(duplicateDialogueResult.pass, false);
assert(duplicateDialogueResult.errors.some(error => error.includes('duplicate dialogue_id')));
checks.duplicate_dialogue_id_rejected = true;

const duplicateSource = clone(map);
duplicateSource.dialogues[2].svg.source_file = duplicateSource.dialogues[1].svg.source_file;
const duplicateSourceResult = validateDialogueSvgMap(duplicateSource, {allowEmpty: false});
assert.strictEqual(duplicateSourceResult.pass, false);
assert(duplicateSourceResult.errors.some(error => error.includes('duplicate SVG source_file')));
checks.duplicate_source_file_rejected = true;

const unsafeSource = clone(map);
unsafeSource.dialogues[2].svg.source_file = '../D003.svg';
const unsafeSourceResult = validateDialogueSvgMap(unsafeSource, {allowEmpty: false});
assert.strictEqual(unsafeSourceResult.pass, false);
assert(unsafeSourceResult.errors.some(error => error.includes('safe relative SVG path')));
checks.unsafe_source_path_rejected = true;

const missingDifference = clone(map);
missingDifference.dialogues[2].svg.difference_from_previous = '';
const missingDifferenceResult = validateDialogueSvgMap(missingDifference, {allowEmpty: false});
assert.strictEqual(missingDifferenceResult.pass, false);
assert(missingDifferenceResult.errors.some(error => error.includes('difference_from_previous is required')));
checks.missing_difference_rejected = true;

const nonOriginal = clone(map);
nonOriginal.dialogues[2].svg.original = false;
const nonOriginalResult = validateDialogueSvgMap(nonOriginal, {allowEmpty: false});
assert.strictEqual(nonOriginalResult.pass, false);
assert(nonOriginalResult.errors.some(error => error.includes('must be original')));
checks.non_original_rejected = true;

const wrongSource = clone(map);
wrongSource.dialogues[2].svg.source_file = 'assets/dialogue/D003.png';
const wrongSourceResult = validateDialogueSvgMap(wrongSource, {allowEmpty: false});
assert.strictEqual(wrongSourceResult.pass, false);
assert(wrongSourceResult.errors.some(error => error.includes('safe relative SVG path')));
checks.svg_source_required = true;

const overlap = clone(map);
overlap.dialogues[2].start = 2.1;
const overlapResult = validateDialogueSvgMap(overlap, {allowEmpty: false});
assert.strictEqual(overlapResult.pass, false);
assert(overlapResult.errors.some(error => error.includes('overlapping dialogue timing')));
checks.dialogue_timing_validated = true;

const staleSignature = clone(map);
staleSignature.dialogues[2].svg.geometry_signature = 'changed_without_signature_update';
const staleSignatureResult = validateDialogueSvgMap(staleSignature, {allowEmpty: false});
assert.strictEqual(staleSignatureResult.pass, false);
assert(staleSignatureResult.errors.some(error => error.includes('does not match its components')));
checks.stale_signature_rejected = true;

const noPrimaryChange = clone(map);
noPrimaryChange.dialogues[2].svg.primary_generator = noPrimaryChange.dialogues[1].svg.primary_generator;
noPrimaryChange.dialogues[2].svg.geometry_signature = noPrimaryChange.dialogues[1].svg.geometry_signature;
noPrimaryChange.dialogues[2].svg.visual_signature = createVisualSignature(noPrimaryChange.dialogues[2].svg);
const noPrimaryResult = validateDialogueSvgMap(noPrimaryChange, {allowEmpty: false});
assert.strictEqual(noPrimaryResult.pass, false);
assert(noPrimaryResult.errors.some(error => error.includes('primary generator or geometry must differ')));
checks.primary_change_required = true;

const noSecondaryChange = clone(map);
noSecondaryChange.dialogues[2].svg.composition_signature = noSecondaryChange.dialogues[1].svg.composition_signature;
noSecondaryChange.dialogues[2].svg.motion_signature = noSecondaryChange.dialogues[1].svg.motion_signature;
noSecondaryChange.dialogues[2].svg.visual_signature = createVisualSignature(noSecondaryChange.dialogues[2].svg);
const noSecondaryResult = validateDialogueSvgMap(noSecondaryChange, {allowEmpty: false});
assert.strictEqual(noSecondaryResult.pass, false);
assert(noSecondaryResult.errors.some(error => error.includes('composition or motion must differ')));
checks.secondary_change_required = true;

const proofRequired = validateDialogueSvgMap(map, {allowEmpty: false, requireProof: true});
assert.strictEqual(proofRequired.pass, false);
assert(proofRequired.errors.some(error => error.includes('at least three dialogue-specific proof frames')));
const withProof = clone(map);
withProof.dialogues.forEach(dialogue => {
  dialogue.proof_frames = [
    `proof/${dialogue.dialogue_id}_start.png`,
    `proof/${dialogue.dialogue_id}_mid.png`,
    `proof/${dialogue.dialogue_id}_end.png`
  ];
});
assert.strictEqual(validateDialogueSvgMap(withProof, {allowEmpty: false, requireProof: true}).pass, true);
checks.dialogue_proof_requirement_enforced = true;

const missingFiles = validateDialogueSvgMap(map, {allowEmpty: false, rootDir: __dirname});
assert.strictEqual(missingFiles.pass, false);
assert(missingFiles.errors.some(error => error.includes('does not exist inside rootDir')));
checks.optional_source_file_existence_check = true;

assert.strictEqual(validateDialogueSvgMap({dialogues: []}, {allowEmpty: false}).pass, false);
assert.strictEqual(validateDialogueSvgMap({dialogues: []}).pass, true);
checks.empty_template_and_completed_map_distinguished = true;

const report = {
  pass: true,
  tests: Object.keys(checks).length,
  dialogue_count: valid.dialogue_count,
  unique_svg_count: valid.unique_svg_count,
  unique_source_file_count: valid.unique_source_file_count,
  unique_visual_signature_count: valid.unique_visual_signature_count,
  color_only_variation_counts_as_new: false,
  shared_secondary_motif_allowed: true,
  checks
};
fs.writeFileSync(path.join(__dirname, '../reports/dialogue-svg-test.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
