'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const {timelineProgress, buildKeywordEchoTimeline, validateExplainerStyle, safeWatermarkPath} = require('../src/explainer-timing');

const root = path.resolve(__dirname, '../..');
const style = JSON.parse(fs.readFileSync(path.join(root, 'project/explainer-style.json'), 'utf8'));
const checks = {};

assert.strictEqual(validateExplainerStyle(style).pass, true);
checks.default_style_policy = true;

assert.strictEqual(timelineProgress(0, 120), 0);
checks.progress_starts_empty = true;

assert.strictEqual(timelineProgress(30, 120), 0.25);
checks.progress_matches_actual_time = true;

assert.strictEqual(timelineProgress(120, 120), 1);
checks.progress_ends_full = true;

assert.strictEqual(timelineProgress(-2, 120), 0);
assert.strictEqual(timelineProgress(150, 120), 1);
assert(timelineProgress(20, 120) < timelineProgress(40, 120));
checks.progress_clamped_and_monotonic = true;

assert.throws(() => timelineProgress(10, 0), /Invalid actual duration/);
assert.throws(() => timelineProgress(Number.NaN, 120), /Invalid current time/);
checks.invalid_progress_rejected = true;

const input = {
  dialogueStart: 0.2,
  dialogueEnd: 2.4,
  fps: 30,
  phrases: [
    {text: 'অনেক কষ্টে', start: 0.3, end: 0.8},
    {text: 'বানানো', start: 0.85, end: 1.25},
    {text: 'ওয়েবসাইট', start: 1.3, end: 1.9, accent: true},
    {text: 'প্রস্তুত', start: 1.95, end: 2.2, accent: false}
  ]
};
const timeline = buildKeywordEchoTimeline(input);
assert(timeline.every(item => item.reveal_start <= item.reveal_end));
assert(timeline.every(item => item.reveal_end === item.start));
checks.phrase_reveal_matches_speech = true;

assert(timeline.filter(item => item.accent).every(item => item.emphasis_start > item.reveal_end));
assert(timeline.filter(item => item.accent).every(item => item.emphasis_after_reveal === true));
checks.emphasis_follows_reveal = true;

assert.strictEqual(timeline[3].emphasis_start, null);
checks.unaccented_phrase_has_no_emphasis = true;

assert(timeline.every(item => item.animation_unit === 'whole_shaped_phrase' && item.layout_mode === 'pre_shaped_stable'));
checks.stable_shaped_phrase_units = true;

const overlapping = JSON.parse(JSON.stringify(input));
overlapping.phrases[1].start = 0.7;
assert.throws(() => buildKeywordEchoTimeline(overlapping), /Overlapping phrase timing/);
checks.overlapping_phrases_rejected = true;

const outside = JSON.parse(JSON.stringify(input));
outside.phrases[3].end = 2.5;
assert.throws(() => buildKeywordEchoTimeline(outside), /Phrase outside dialogue/);
checks.outside_dialogue_rejected = true;

const unverified = JSON.parse(JSON.stringify(style));
unverified.authorized_watermark.enabled = true;
unverified.authorized_watermark.asset_file = 'assets/brand/logo.svg';
assert.strictEqual(validateExplainerStyle(unverified).pass, false);
checks.unverified_watermark_rejected = true;

const missingAsset = JSON.parse(JSON.stringify(unverified));
missingAsset.authorized_watermark.permission_status = 'verified';
missingAsset.authorized_watermark.asset_file = '';
assert.strictEqual(validateExplainerStyle(missingAsset).pass, false);
checks.missing_watermark_asset_rejected = true;

const authorized = JSON.parse(JSON.stringify(unverified));
authorized.authorized_watermark.permission_status = 'verified';
assert.strictEqual(validateExplainerStyle(authorized).pass, true);
checks.authorized_watermark_accepted = true;

const unsafeAsset = JSON.parse(JSON.stringify(authorized));
unsafeAsset.authorized_watermark.asset_file = '../logo.svg';
assert.strictEqual(validateExplainerStyle(unsafeAsset).pass, false);
assert.strictEqual(safeWatermarkPath('https://example.com/logo.svg'), false);
checks.unsafe_watermark_paths_rejected = true;

const splitCharacters = JSON.parse(JSON.stringify(style));
splitCharacters.keyword_echo.split_characters = true;
assert.strictEqual(validateExplainerStyle(splitCharacters).pass, false);
checks.character_split_rejected = true;

const replacedSubtitles = JSON.parse(JSON.stringify(style));
replacedSubtitles.keyword_echo.replaces_verbatim_subtitles = true;
assert.strictEqual(validateExplainerStyle(replacedSubtitles).pass, false);
checks.subtitle_replacement_rejected = true;

const fakeProgress = JSON.parse(JSON.stringify(style));
fakeProgress.progress_rail.fake_loading = true;
assert.strictEqual(validateExplainerStyle(fakeProgress).pass, false);
checks.fake_progress_rejected = true;

const sceneProgress = JSON.parse(JSON.stringify(style));
sceneProgress.progress_rail.scene_progress_only = true;
assert.strictEqual(validateExplainerStyle(sceneProgress).pass, false);
checks.scene_only_progress_rejected = true;

const inventedChapter = JSON.parse(JSON.stringify(style));
inventedChapter.chapter_pill.new_facts_allowed = true;
assert.strictEqual(validateExplainerStyle(inventedChapter).pass, false);
checks.invented_chapter_facts_rejected = true;

const lateVisual = JSON.parse(JSON.stringify(style));
lateVisual.staged_build.entry_before_or_at_related_speech = false;
assert.strictEqual(validateExplainerStyle(lateVisual).pass, false);
checks.late_staged_visual_rejected = true;

const report = {
  pass: true,
  tests: Object.keys(checks).length,
  recipe: style.recipe_id,
  keyword_echo_unit: style.keyword_echo.animation_unit,
  progress_source: style.progress_rail.value_source,
  watermark_enabled_by_default: style.authorized_watermark.enabled,
  checks
};
fs.writeFileSync(path.join(__dirname, '../reports/explainer-test.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
