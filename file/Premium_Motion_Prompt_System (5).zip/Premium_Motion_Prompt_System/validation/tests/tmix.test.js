'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const {spawn} = require('child_process');
const ffmpeg = require('ffmpeg-static');
const ffprobe = require('ffprobe-static');

function run(command, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {stdio: ['ignore', 'pipe', 'pipe']});
    let stdout = '', stderr = '';
    child.stdout.on('data', d => {stdout += d;});
    child.stderr.on('data', d => {stderr += d;});
    child.on('error', reject);
    child.on('close', code => code === 0 ? resolve({stdout, stderr}) : reject(new Error(stderr)));
  });
}

async function main() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'premium-tmix-'));
  const file = path.join(dir, 'frame-test.mp4');
  const samples = 8;
  const fps = 30;
  const outputFrames = 240;
  const inputFrames = outputFrames * samples + samples - 1;
  const inputRate = fps * samples;
  const inputDuration = inputFrames / inputRate;
  const filter = `tmix=frames=${samples},trim=start_frame=${samples - 1},setpts=PTS-STARTPTS,fps=${fps}`;
  try {
    await run(ffmpeg, [
      '-y', '-v', 'error', '-f', 'lavfi', '-i', `testsrc2=size=16x16:rate=${inputRate}:duration=${inputDuration}`,
      '-vf', filter, '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-frames:v', String(outputFrames), '-t', '8', file
    ]);
    const {stdout} = await run(ffprobe.path, ['-v', 'error', '-count_frames', '-show_entries', 'stream=nb_frames,nb_read_frames,duration,r_frame_rate', '-of', 'json', file]);
    const probe = JSON.parse(stdout).streams[0];
    const pass = Number(probe.nb_read_frames) === outputFrames && Number(probe.nb_frames) === outputFrames && probe.r_frame_rate === '30/1';
    const report = {pass, input_frames: inputFrames, output_frames_expected: outputFrames, temporal_flush_samples: samples - 1, probe};
    fs.writeFileSync(path.join(__dirname, '../reports/tmix-test.json'), JSON.stringify(report, null, 2) + '\n');
    console.log(JSON.stringify(report, null, 2));
    if (!pass) process.exitCode = 1;
  } finally {
    fs.rmSync(dir, {recursive: true, force: true});
  }
}

main().catch(error => {console.error(error.stack || error.message);process.exitCode = 1;});
