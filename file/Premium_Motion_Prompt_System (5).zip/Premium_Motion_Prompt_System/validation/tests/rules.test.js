'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const {fitHeadline, resolveShortScene, validateContinuity} = require('../src/responsive');
const wide = fitHeadline({profile: 'wide_1920_1080', inkWidth: 900, inkHeight: 260});
assert.strictEqual(wide.scale, 1);
const vertical = fitHeadline({profile: 'vertical_1080_1920', inkWidth: 1400, inkHeight: 260});
assert(vertical.scale < 1);
assert(vertical.ink_width <= 900.001);
assert(vertical.mask.width > vertical.ink_width);
const solved = resolveShortScene({duration: 1.1, readingTime: 0.5, transitionOverlap: 0.1, entry: 0.46, exit: 0.26});
assert(solved.removed_layers.includes('particles'));
assert(!solved.remaining_layers.includes('shimmer'));
assert(solved.entry >= 0.24 && solved.exit >= 0.16);
const graph = {transitions: [
  {from_scene: 'S01', to_scene: 'S02', shared_element_id: 'underline', semantic_handoff: 'Statement becomes process', previous_text_exit_end: 2.0, new_text_entry_start: 2.02, proof_frame: 'future_project_proof/S01_S02.png'},
  {from_scene: 'S02', to_scene: 'S03', shared_element_id: 'connector', semantic_handoff: 'Process becomes resolution', previous_text_exit_end: 4.0, new_text_entry_start: 4.02, proof_frame: 'future_project_proof/S02_S03.png'}
]};
const result = validateContinuity(graph);
assert.strictEqual(result.pass, true, result.errors.join('\n'));
const bad = validateContinuity({transitions: [{from_scene: 'A', to_scene: 'B', shared_element_id: 'x', semantic_handoff: 'test', previous_text_exit_end: 2.2, new_text_entry_start: 2.0, proof_frame: 'proof.png'}]});
assert.strictEqual(bad.pass, false);
const report = {pass: true, tests: 6, responsive: {wide, vertical}, short_scene: solved, continuity: result};
fs.writeFileSync(path.join(__dirname, '../reports/rules-test.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
