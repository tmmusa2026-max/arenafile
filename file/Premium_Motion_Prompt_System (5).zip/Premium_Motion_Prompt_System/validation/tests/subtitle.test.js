'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const {buildSubtitleTimeline} = require('../src/subtitle-timing');

const root = path.resolve(__dirname, '../..');
const style = JSON.parse(fs.readFileSync(path.join(root, 'project/subtitle-style.json'), 'utf8'));
const checks = {};
const input = {
  cueStart: 0.2,
  cueEnd: 2.2,
  fps: 30,
  preSpeechRevealMs: 160,
  activeColors: ['#2ED3A6'],
  words: [
    {text: 'আমরা', start: 0.3, end: 0.6},
    {text: 'আজ', start: 0.65, end: 0.85},
    {text: 'নতুন', start: 0.9, end: 1.25},
    {text: 'পথে', start: 1.3, end: 1.75}
  ]
};
const timeline = buildSubtitleTimeline(input);

assert(timeline.every(word => word.reveal_end === word.start));
assert(timeline.every(word => word.reveal_start <= word.reveal_end));
checks.actual_word_reveal = true;

assert(timeline.every(word => word.highlight_start > word.reveal_end));
assert(timeline.every(word => word.color_after_reveal === true));
checks.highlight_after_reveal = true;

assert(timeline.every(word => word.highlight_start <= (word.start + word.end) / 2));
checks.highlight_by_word_midpoint = true;

for (let index = 0; index < timeline.length - 1; index++) {
  assert.strictEqual(timeline[index].highlight_end, timeline[index + 1].highlight_start);
}
assert(timeline.every(word => word.highlight_end > word.highlight_start));
checks.single_active_sequence = true;

assert(timeline.every(word => word.accent_color === '#2ED3A6'));
assert.strictEqual(style.base_color, '#F5F7FA');
checks.default_teal_highlight = true;

const alternating = buildSubtitleTimeline({...input, activeColors: ['#2ED3A6', '#7CE7C4'], alternateActiveColors: true});
assert.deepStrictEqual(alternating.map(word => word.accent_color), ['#2ED3A6', '#7CE7C4', '#2ED3A6', '#7CE7C4']);
checks.optional_alternate_palette = true;

assert.strictEqual(style.decorations.leading_vertical_bar, false);
assert.strictEqual(style.decorations.leading_pipe, false);
assert.strictEqual(style.decorations.leading_dash, false);
assert.strictEqual(style.decorations.leading_bullet, false);
checks.no_leading_decorations = true;

assert.strictEqual(style.complex_script.split_characters, false);
assert.strictEqual(style.complex_script.pre_shape_full_line, true);
assert.strictEqual(style.complex_script.reserve_layout_before_reveal, true);
assert.strictEqual(style.animation.active_scale, 1.0);
checks.complex_script_layout_stable = true;

assert.strictEqual(timeline[timeline.length - 1].highlight_end, input.cueEnd);
checks.last_word_hold = true;

const overlapping = JSON.parse(JSON.stringify(input));
overlapping.words[1].start = 0.55;
assert.throws(() => buildSubtitleTimeline(overlapping), /Overlapping word timing/);
checks.invalid_overlap_rejected = true;

assert.throws(() => buildSubtitleTimeline({...input, alternateActiveColors: true, activeColors: ['#2ED3A6']}), /requires two active colors/);
checks.alternate_requires_two_colors = true;

const delayed = buildSubtitleTimeline({...input, colorDelayFrames: 2});
assert(Math.abs(delayed[0].highlight_start - (input.words[0].start + 2 / input.fps)) < 1e-9);
checks.configurable_color_delay = true;

function luminance(hex) {
  const channels = [1, 3, 5].map(index => parseInt(hex.slice(index, index + 2), 16) / 255);
  const linear = channels.map(value => value <= 0.04045 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4));
  return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2];
}
function contrastRatio(first, second) {
  const a = luminance(first);
  const b = luminance(second);
  return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
}
const darkBackground = '#0B1220';
const baseContrast = contrastRatio(style.base_color, darkBackground);
const activeContrast = contrastRatio(style.active_colors[0], darkBackground);
assert(baseContrast >= 4.5 && activeContrast >= 4.5);
checks.default_colors_contrast_on_dark = true;

const report = {
  pass: true,
  tests: Object.keys(checks).length,
  recipe: style.recipe_id,
  base_color: style.base_color,
  default_active_color: style.active_colors[0],
  timing_source: style.timing.source,
  default_dark_contrast: {
    background: darkBackground,
    base_ratio: Number(baseContrast.toFixed(2)),
    active_ratio: Number(activeContrast.toFixed(2))
  },
  leading_vertical_bar: style.decorations.leading_vertical_bar,
  checks
};
fs.writeFileSync(path.join(__dirname, '../reports/subtitle-test.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
