'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const {FORBIDDEN_CHARACTER, findEmDash, assertNoEmDash} = require('../src/text-policy');

const checks = {};
const samples = {
  caption: `কথা${FORBIDDEN_CHARACTER}পরের কথা`,
  headline: `শিরোনাম${FORBIDDEN_CHARACTER}উপশিরোনাম`,
  svg_text: `<text>তথ্য${FORBIDDEN_CHARACTER}ব্যাখ্যা</text>`,
  video_metadata: `title=প্রকল্প${FORBIDDEN_CHARACTER}সংস্করণ`
};

for (const [name, text] of Object.entries(samples)) {
  assert.strictEqual(findEmDash(text).length, 1);
  assert.throws(() => assertNoEmDash(text, name), /U\+2014/);
  checks[`${name}_rejected`] = true;
}

const multiline = [`ক${FORBIDDEN_CHARACTER}খ`, `গ${FORBIDDEN_CHARACTER}ঘ`].join('\n');
const locations = findEmDash(multiline);
assert.deepStrictEqual(locations.map(match => [match.line, match.column]), [[1, 2], [2, 2]]);
checks.line_and_column_reporting = true;

const allowed = [
  'কথা, পরের কথা',
  'কথা: পরের কথা',
  'কথা; পরের কথা',
  'কথা। পরের কথা',
  'সাধারণ hyphen - প্রয়োজন হলে'
];
for (const text of allowed) assert.strictEqual(assertNoEmDash(text), true);
checks.contextual_punctuation_alternatives_allowed = true;

const report = {
  pass: true,
  tests: Object.keys(checks).length,
  forbidden_code_point: 'U+2014',
  scope: ['caption', 'headline', 'SVG text', 'video metadata', 'generated text files'],
  checks
};
fs.writeFileSync(path.join(__dirname, '../reports/text-policy-test.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
