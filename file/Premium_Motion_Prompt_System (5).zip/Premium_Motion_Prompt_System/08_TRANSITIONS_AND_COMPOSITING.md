# 08. Transitions, Compositing ও Finishing

## ১. Transition-এর মূল নীতি

Transition আগের দৃশ্য শেষ করে পরেরটি শুরু করার আলাদা decoration নয়। আগের দৃশ্যের একটি element পরের দৃশ্যের element-এ দায়িত্ব দেবে। এই handoff-এর কারণে দর্শক বুঝবে কেন দৃশ্য বদলালো।

সস্তা dissolve, random zoom, generic whip বা preset glitch default নয়। Straight cut কখনো কখনো সবচেয়ে ভালো হতে পারে, বিশেষ করে narration-এর কঠিন rhetorical break-এ। Cut-টিও একটি নামকরা সিদ্ধান্ত হিসেবে লিখতে হবে।

## ২. Element-led transition library

### X01: Particle To Timeline

- আগের element: text-derived particles
- পরের element: timeline rule বা tick field
- Handoff: particles একটি common path-এ converge করে, path তাদের trailing motion থেকে আঁকা হয়
- Duration: 0.50 থেকে 0.90 s
- Easing: release Expo Out, convergence Expo InOut, timeline settle Quint Out
- ব্যবহার: ক্ষয় থেকে ইতিহাস, memory থেকে evidence
- QA: convergence random magnet effect না লাগে

### X02: Ring To Line

- আগের element: concentric rings
- পরের element: single horizontal বা vertical rule
- Handoff: rings inward scale হয়, একই center-এ collapse, একটি line-এ resolve
- Duration: 0.42 থেকে 0.70 s
- Easing: Expo InOut
- ব্যবহার: emotional thought থেকে final statement
- QA: collapse-এর সময় line বা ring clipping নয়

### X03: Underline Handoff

- আগের element: headline underline
- পরের element: connector, divider, chart baseline বা product edge
- Handoff: একই stroke length, position ও tangent ধরে রেখে নতুন semantic role
- Duration: 0.30 থেকে 0.50 s
- Easing: Expo InOut
- ব্যবহার: প্রায় সব editorial বা product video
- QA: stroke cap ও width continuity

### X04: Mask Wipe From Ink

- আগের element: headline-এর shaped ink alpha
- পরের element: scene reveal matte
- Handoff: text ink প্রসারিত হয়ে পরের frame reveal করে
- Duration: 0.35 থেকে 0.60 s
- Easing: Expo InOut
- ব্যবহার: strong title থেকে scene
- QA: যুক্তাক্ষর পড়ার আগে নষ্ট হচ্ছে না, matte expansion optical

### X05: Match Cut Geometry

- আগের element: circle, card, dot বা bracket
- পরের element: একই silhouette-এর নতুন object
- Handoff: matched screen position, scale ও color
- Duration: 1 থেকে 3 frame cut বা 0.20 s morph
- Easing: Cut হলে motion continuity, morph হলে Quart InOut
- ব্যবহার: comparison, product feature, symbolic evolution
- QA: shape match আসলেই চোখে মেলে

### X06: Camera Push Through

- আগের element: card, frame, portal বা negative space
- পরের element: নতুন scene plane
- Handoff: camera পুরোনো plane-এর মধ্য দিয়ে যায়, পরের scene আগে থেকে depth-এ প্রস্তুত
- Duration: 0.45 থেকে 0.75 s
- Easing: Expo InOut
- Motion blur: 12 থেকে 16 sub-sample দ্রুত অংশে
- ব্যবহার: product depth, documentary layer
- QA: motion sickness, text blur, perspective continuity

### X07: Focus Handoff

- আগের element: sharp text
- পরের element: background detail বা নতুন text
- Handoff: আগেরটি defocus, পরেরটি focus-এ আসে, একই camera space
- Duration: 0.38 থেকে 0.60 s
- Easing: Sine InOut বা Quint Out
- ব্যবহার: reflection, documentary, memory
- QA: দুই element-এর unreadable overlap খুব বেশি নয়

### X08: Path Continuation

- আগের element: flow line, underline, waveform
- পরের element: নতুন path
- Handoff: shared point ও tangent থেকে পরের path grow
- Duration: 0.35 থেকে 0.65 s
- Easing: Expo Out বা Circ Out
- ব্যবহার: process, explainer, journey
- QA: leading dot-এর গতি path draw-এর সঙ্গে মেলে

### X09: Product Layer Explode

- আগের element: assembled UI বা product
- পরের element: আলাদা feature layers
- Handoff: depth-এ সামান্য separation, camera reframing
- Duration: 0.45 থেকে 0.70 s
- Easing: Quint Out
- ব্যবহার: feature explanation
- QA: explosion নয়, controlled separation, feature সম্পর্ক বোঝা যায়

### X10: Grid Reconfiguration

- আগের element: dots বা cards
- পরের element: নতুন ordered layout
- Handoff: প্রতিটি instance আলাদা কিন্তু coordinated path-এ যায়
- Duration: 0.40 থেকে 0.65 s
- Stagger: 0.06 থেকে 0.04 s decreasing
- Easing: Expo InOut
- ব্যবহার: chapter change, system organization
- QA: সব element একসঙ্গে থামে না, কিন্তু কোনোটিও পিছিয়ে থাকে না

### X11: Light Motif Handoff

- আগের element: glow orb বা highlight
- পরের element: product highlight, sunrise abstraction বা headline glow
- Handoff: আলোর position ও intensity একই থাকে, আকার বদলায়
- Duration: 0.45 থেকে 0.80 s
- Easing: Sine InOut বা Expo InOut
- ব্যবহার: emotional continuity
- QA: bloom clipping ও অতিরিক্ত flare নয়

### X12: Intentional Cut

- আগের element: stable final composition
- পরের element: শক্তিশালী new composition
- Handoff: word, sound accent, matched direction বা color continuity
- Timing: natural pause বা rhetorical break
- ব্যবহার: urgency, statement, editorial rhythm
- QA: cut-এর আগে exit animation জোর করে যোগ করা হয়নি

## ৩. Transition নির্বাচন

| আগের scene | পরের scene | ভালো handoff |
|---|---|---|
| Text | Text | Underline, ink mask, word morph |
| Text | Timeline | Particle convergence, underline extension |
| Emotion | Resolution | Ring to line, focus settle |
| Product overview | Feature | Camera push, layer separation, callout |
| Process A | Process B | Path continuation |
| Context | Evidence | Structural frame, focus handoff |
| Comparison A | Comparison B | Match cut, grid reconfiguration |
| Loud or dense | Quiet | Controlled cut to negative space |

## ৪. Compositing stack

প্রতি scene-এর জন্য আলাদা করে document করো:

1. Background gradient ও depth field
2. Distant ambient vector
3. Midground motif
4. Primary object বা typography
5. Supporting vector
6. Caption
7. Local light ও matte
8. Camera composite
9. Global grade
10. Film grain, vignette ও output transform

Caption সাধারণত global camera blur-এর বাইরে রাখো, যদি না caption নিজে 3D scene-এর অংশ হওয়ার বিশেষ কারণ থাকে।

## ৫. Background depth

Flat background এড়াতে:

- Center-এ সামান্য হালকা radial gradient
- Edge-এ 5 থেকে 15 শতাংশ luminance reduction
- Distant dot বা noise layer খুব কম contrast-এ
- Scene-specific warm বা cool grade
- Soft vignette, কিন্তু কোণে কালো heavy band নয়
- Gradient banding কমাতে subtle dither বা grain

Background-এর কেন্দ্র text-এর পেছনে অপ্রয়োজনীয় halo তৈরি করবে না।

## ৬. Bloom ও glow

Premium bloom:

1. Scene-এর linear বা perceptually appropriate luminance থেকে bright pass নাও।
2. Threshold text-এর midtones যেন glow-তে না যায়।
3. 2 থেকে 4 scale-এ blur করো।
4. কম opacity-তে combine করো।
5. Final gamma বা output transform-এর আগে-পরে behavior পরীক্ষা করো।
6. Text counter, মাত্রা ও ছোট stroke-এর readability proof করো।

Glow pulse-এর peak 0.4 s-এর মধ্যে নরম হতে পারে। Continuous glow animation-এর amplitude কম রাখো।

## ৭. Chromatic micro-effect

- মূল ব্যবহার: stamp impact বা lens character
- Channel offset: 1 থেকে 2 px
- Duration: 2 থেকে 3 frame
- Whole-video persistent aberration: খুব কম, সাধারণত 0.2 থেকে 0.5 px edge-weighted
- Restricted red palette থাকলে red channel separation এড়িয়ে luminance-safe cyan বা neutral split বেছে নাও
- Caption-এ spike দেবে না

## ৮. Film grain ও texture

- Grain final resolution-এ generate করো।
- Fine luminance grain default, coarse color noise নয়।
- Amount সাধারণত 1 থেকে 3 শতাংশ, project অনুযায়ী।
- Grain text-এর readability নষ্ট করবে না।
- Noise প্রতি frame বদলাবে, কিন্তু deterministic seed থাকবে।
- Freeze frame-এ grain চলবে কি না তা style সিদ্ধান্ত, হঠাৎ boil নয়।
- Heavy grain দিয়ে low-quality asset লুকানোর চেষ্টা নয়।

## ৯. Vignette

- Elliptical বা scene-aware radial mask
- Soft falloff
- Subject ও caption-কে গাঢ় করে না
- Documentary scene-এ ধীরে বাড়তে পারে
- Intensity animation Sine InOut বা Quint Out
- Mobile crop-এ কোণ অন্ধকার হয়ে যাচ্ছে কি পরীক্ষা

## ১০. Color grade

Grade-এর আগে palette lock করো। LUT-equivalent look তৈরি করতে পারো:

- Shadow lift বা toe
- Highlight roll-off
- Saturation curve
- Selective warm-cool balance
- Very subtle color matrix
- Output Rec.709 transform, প্রযোজ্য হলে

Grade-এর পরে accent colors আবার মাপো। Lime যেন হলুদ না হয়, amber যেন লাল না হয়, alert red যেন অন্য জায়গায় না ছড়ায়।

## ১১. Shadows ও depth

- Drop shadow-এর direction scene-এর light source-এর সঙ্গে মিলবে।
- Floating card-এর shadow distance depth বোঝাবে।
- Text shadow decoration নয়, separation।
- Ambient occlusion-এর 2.5D equivalent হিসেবে contact shadow ব্যবহার করা যায়।
- Heavy black shadow নয়, tinted navy shadow প্রায়ই ভালো।

## ১২. Finishing QA

- Highlight clipping আছে কি?
- Gradient banding দেখা যাচ্ছে কি?
- Blur বা glow layer bounds-এ কাটা পড়েছে কি?
- Matte edge-এ হালকা বা গাঢ় fringe আছে কি?
- Premultiplied alpha double-dark হচ্ছে কি?
- Grain compression-এর পরে blocky হচ্ছে কি?
- Vignette caption-এর contrast কমাচ্ছে কি?
- Transition-এর মাঝের frame-এ কোনো geometry self-intersect করছে কি?
- সব scene-এ একই আলোর দিক ও palette logic আছে কি?
