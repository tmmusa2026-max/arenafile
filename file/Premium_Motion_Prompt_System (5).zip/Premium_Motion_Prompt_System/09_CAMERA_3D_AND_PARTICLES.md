# 09. Camera, 3D, Depth of Field ও Particles

## ১. 3D-এর উদ্দেশ্য

3D ব্যবহার হবে spatial relationship, depth, focus বা transition বোঝাতে। শুধু effect দেখানোর জন্য text-কে অকারণে ঘোরানো যাবে না। 2.5D layered planes অনেক ক্ষেত্রে full 3D-এর চেয়ে পরিষ্কার ও নিয়ন্ত্রিত ফল দেয়।

## ২. Camera rig

একটি reusable rig:

```text
CAMERA_MASTER
  position
  target
  focal_length_equivalent
  aperture_equivalent
  focus_distance
  roll
  drift_amount
  push_amount

SCENE_NULL
  global scene transform

DEPTH_PLANES
  background
  motif
  subject
  foreground
  caption, সাধারণত camera-stable
```

- Camera target সবসময় meaningful focal point-এ থাকবে।
- Parenting hierarchy-এর coordinate space document করো।
- Text-এর perspective distortion পড়ার সময় কম রাখো।
- Caption-কে আলাদা stable composite plane-এ রাখা যায়।
- Push-in-এর সময় layout-এর safe area আবার হিসাব করো।

## ৩. Camera recipes

### C01: Quiet Push

- Scale equivalent: 1.00 থেকে 1.02 বা 1.04
- Duration: পুরো scene
- Easing: Sine InOut
- Drift: 0 থেকে 0.5 শতাংশ
- ব্যবহার: almost সব restrained scene

### C02: Editorial Reframe

- Position: একটি focal point থেকে অন্যটিতে ছোট shift
- Duration: 0.55 থেকে 0.90 s
- Easing: Quint Out
- Depth: supporting layer-এ 10 থেকে 30 শতাংশ আলাদা travel
- ব্যবহার: তথ্যের hierarchy বদল

### C03: Depth Reveal

- Foreground mask বা card সরে গিয়ে subject আসে
- Duration: 0.45 থেকে 0.75 s
- Easing: Expo InOut
- Motion blur: adaptive
- ব্যবহার: product, chapter transition

### C04: Handheld Breath

- Position noise: 0.5 থেকে 1.5 px at 1080p
- Rotation noise: 0.02 degree পর্যন্ত
- Frequency: খুব কম, coherent
- Easing: continuous noise, loop seam নয়
- ব্যবহার: documentary realism, কেবল subtle
- Avoid: memorial stillness, tiny UI, motion sensitivity

### C05: Focus Transfer

- Focus distance: আগের subject থেকে পরের subject
- Blur radius: depth difference অনুযায়ী
- Duration: 0.38 থেকে 0.60 s
- Easing: Sine InOut
- ব্যবহার: memory, evidence, narrative turn

### C06: Structural Orbit

- Camera yaw: 3 থেকে 10 degree, প্রয়োজনে তার বেশি
- Duration: 0.60 থেকে 1.20 s
- Easing: Expo InOut
- ব্যবহার: 3D product বা spatial system
- Avoid: typography-centric flat scene

## ৪. Parallax

- Depth plane অনুযায়ী displacement ratio ঠিক করো।
- Background camera-এর তুলনায় কম নড়ে, foreground বেশি নড়ে।
- Text-এর পেছনে dot grid ঘুরলে angular velocity খুব কম হবে।
- Parallax-এর দিক scene-এর narrative direction-এর সঙ্গে মিলবে।
- Repeated background assets-এ Motion Tile equivalent ব্যবহার করলে seam দেখা যাবে না।
- Parallax-এর কারণে edge ফাঁকা হলে bleed বাড়াও।

## ৫. Perspective ও 3D text

- RotateX 8 degree-এর মতো ছোট flip card-like feel দেয়।
- Perspective 800 থেকে 1200 px equivalent শুরু করার মান, scene scale অনুযায়ী বদলাবে।
- Rotation-এর center word-এর optical center বা baseline-near pivot হতে পারে।
- Extruded Bengali text-এর side faces যুক্তাক্ষর ও মাত্রা নষ্ট করতে পারে, প্রয়োজন না হলে বাদ।
- 3D text-এর পরে আলাদা sharp 2D pass রাখা যায়, কিন্তু alignment নিখুঁত হতে হবে।
- DOF চলাকালে caption ঝাপসা হবে না।

## ৬. Depth of Field

Optical DOF-এর কাছাকাছি ফল পেতে:

1. প্রতিটি element-এর depth value রাখো।
2. Focus plane নির্ধারণ করো।
3. Depth difference থেকে circle of confusion বা blur radius হিসাব করো।
4. Near ও far field-এর blur behavior আলাদা রাখো, সম্ভব হলে।
5. Bokeh disc-এর center ও edge softness নিয়ন্ত্রণ করো।
6. Highlight bloom-এর আগে বা পরে DOF-এর ক্রম proof দিয়ে ঠিক করো।
7. Subject sharp হলে তাকে আবার global blur দেবে না।

Text dissolve-এর particles যত দূরে যায়, তাদের bokeh radius ও softness বাড়তে পারে। এটি শুধু opacity কমানোর চেয়ে বেশি depth তৈরি করে।

## ৭. Particle system data model

প্রতিটি particle-এর জন্য:

```text
id
seed
birth_time
life
origin
position
velocity
acceleration
drag
size
rotation
color
opacity
depth
blur_radius
source_uv
target, transition হলে
```

Global controls:

```text
emission_shape
density
gravity
turbulence
noise_scale
noise_strength
wind
drag
fade_curve
depth_range
bokeh_amount
seed
```

## ৮. Text-derived particles

শুধু random dots-এর মেঘ নয়। প্রক্রিয়া:

1. Final shaped headline-কে high-resolution alpha-তে render করো।
2. Ink area থেকে rejection sampling, blue-noise sampling বা weighted grid sampling করো।
3. প্রতিটি point-এর source_uv ও initial color ধরে রাখো।
4. Text opacity কমানোর সঙ্গে particles-এর opacity বাড়াও যাতে visual mass হঠাৎ বদলে না যায়।
5. Release-এর প্রথম মুহূর্তে displacement কম, তারপর drift বাড়ে।
6. Coherent noise ব্যবহার করো, প্রতি particle সম্পূর্ণ unrelated random নয়।
7. Depth অনুযায়ী size, blur ও velocity সামান্য বদলাবে।
8. Transition target থাকলে target-এ আকর্ষণ শেষ অংশে বাড়ে, শুরু থেকে নয়।

## ৯. Particle recipes

### P01: Memory Dispersion

- Count: text size অনুযায়ী, visual density নিয়ন্ত্রিত
- Initial velocity: 2 থেকে 12 px/s equivalent
- Turbulence: low
- Drag: মাঝারি
- Opacity: delayed smooth fade
- Blur: depth-এর সঙ্গে 0 থেকে 8 px
- Easing: release Expo Out, drift Sine InOut

### P02: Converge To Rule

- Start: dispersed particles
- Target: sampled points on path
- Attraction: শেষ 60 শতাংশে বাড়ে
- Arrival stagger: path parameter অনুযায়ী
- Final: particles মিলে continuous line বা ticks হয়
- Easing: Expo InOut

### P03: Ambient Dust

- Count: অল্প
- Size: 1 থেকে 3 px
- Opacity: 0.03 থেকে 0.12
- Velocity: খুব কম
- Depth: varied
- ব্যবহার: documentary atmosphere, text-এর ওপর নয়

### P04: Product Data Stream

- Form: ছোট rectangles বা dots
- Path: UI বা connector-এর actual path
- Speed: eased, constant robotic speed নয়
- ব্যবহার: data flow, network, processing
- QA: fake data claim নয়

### P05: Bokeh Release

- Start: small sharp dots
- Growth: depth-এর সঙ্গে disc radius বাড়ে
- Opacity: radius বাড়লে কমে
- Color: project palette
- ব্যবহার: memory, reflection, gentle resolution

## ১০. Physics ও determinism

- Fixed simulation timestep ব্যবহার করো।
- Render sub-sample-এর জন্য analytic বা interpolated position নাও।
- Random seed project ও scene ID থেকে derive করো।
- Frame order বদলালে particle ফল যেন না বদলায়।
- Collision থাকলে spatial partitioning ব্যবহার করা যায়, কিন্তু decorative scene-এ অপ্রয়োজনীয় physics নয়।
- Motion blur-এর জন্য particle-এর আগের ও পরের sub-frame position একই simulation থেকে আসবে।

## ১১. Lighting

2.5D scene-এও আলোর নিয়ম থাকবে:

- Key light direction
- Fill level
- Rim বা accent
- Ambient background
- Shadow softness
- Bloom threshold

Light orb, headline glow ও card shadow যেন একই scene-এর আলোর মতো লাগে। অসংগত একাধিক light direction এড়াও।

## ১২. 3D ও particle QA

- Camera move-এর কারণে কি গুরুত্বপূর্ণ text কাটছে?
- DOF কি মূল শব্দ ঝাপসা করছে?
- Particles কি shaped text-এর ink থেকে আসছে?
- Bokeh কি শুধু বড় সাদা circle-এর clutter?
- Parallax কি text-এর পড়ার স্থিরতা নষ্ট করছে?
- Random seed বদলে render হচ্ছে কি?
- Particle density ছোট screen-এ অতিরিক্ত কি?
- Perspective-এ font কি অন্য font-এর মতো বিকৃত দেখাচ্ছে?
- Motion blur কি দ্রুত particle-এর trail স্বাভাবিক করছে?
- 3D effect বাদ দিলে অর্থ হারায় কি? না হারালে সরল 2.5D বিবেচনা করো।
