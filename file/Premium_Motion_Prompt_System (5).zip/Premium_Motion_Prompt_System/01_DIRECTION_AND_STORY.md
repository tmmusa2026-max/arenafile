# 01. Direction, Story ও Visual Language

## উদ্দেশ্য

এই মডিউল সিদ্ধান্ত দেয় ভিডিওটি কেন এমন দেখাবে এবং প্রতিটি দৃশ্য কেন আছে। Effect নির্বাচনের আগে narrative ও visual thesis স্থির করতে হবে।

## ১. Creative thesis

একটি ভালো thesis তিনটি বিষয়ে উত্তর দেয়:

1. দর্শক কী বুঝবে?
2. দর্শক কী অনুভব করবে?
3. এই অনুভূতি ও বোঝাপড়া কোন visual behavior দিয়ে তৈরি হবে?

সুতরাং শুধু `minimal dark typography` না লিখে লিখো: `তথ্যের ওজন ধীরে প্রকাশ পাবে, সরু রেখা ও controlled depth শ্রোতার মনোযোগ মূল শব্দে ফিরিয়ে আনবে।`

## ২. Narrative ভূমিকা

একটি ভিডিওতে সব ভূমিকা লাগবে না। প্রয়োজন অনুযায়ী বেছে নাও।

| Scene role | কাজ | উপযুক্ত দৃশ্যগত আচরণ |
|---|---|---|
| Hook | মনোযোগ ধরা | অসম্পূর্ণ আকার, প্রশ্নমূলক ফ্রেমিং, দ্রুত কিন্তু নিয়ন্ত্রিত reveal |
| Context | পরিস্থিতি বোঝানো | spatial layout, timeline, layered background |
| Thesis | মূল বার্তা স্থির করা | বড় typography, কম visual competition |
| Evidence | তথ্য বা উদাহরণ দেওয়া | অনুমোদিত data, annotation, source-based visual |
| Demonstration | পণ্য বা প্রক্রিয়া দেখানো | নিজে আঁকা UI, callout, guided camera |
| Contrast | পার্থক্য বোঝানো | match cut, split composition, shape transformation |
| Turn | দিক বা আবেগ বদলানো | camera reframe, motif inversion, controlled color shift |
| Emotional peak | আবেগের কেন্দ্র | restraint, scale, light, silence-এর সঙ্গে সমন্বয় |
| Resolution | শেষ অর্থ স্থির করা | motif settle, ধীর focus, পরিষ্কার শেষ composition |
| CTA | পরবর্তী কাজ বোঝানো | কেবল brief-এ CTA থাকলে, স্পষ্ট hierarchy ও যথেষ্ট hold |

## ৩. Topic থেকে visual metaphor

আক্ষরিক চিত্রের বদলে আগে abstract visual function ভাবো।

| অর্থ বা আবেগ | সম্ভাব্য motif | Motion behavior | সতর্কতা |
|---|---|---|---|
| স্মৃতি | ring, afterimage, soft orb | breathing, slow focus | sentimental oversaturation নয় |
| ইতিহাস | timeline, layered frame, archival grid | sequential draw, gentle parallax | অনুমোদনহীন তারিখ নয় |
| প্রতিরোধ | opposing lines, compressed space | pressure, release, controlled tension | আক্রমণাত্মক চিত্র নয় |
| ঐক্য | node, converging path | converge, merge paths | party symbol নয়, যদি না অনুমোদিত |
| ভুল বা ক্ষয় | fading trace, dispersed points | blur, dissolve, drift | readability অকালে নষ্ট নয় |
| উদ্ভাবন | grid থেকে নতুন path | construct, refine, align | generic tech cliché সীমিত |
| গতি | trajectory, flowing line | eased travel, leading edge | অতিরিক্ত speed line নয় |
| নির্ভুলতা | snapped grid, measured spacing | soft snap, micro settle | rigid robotic feel নয় |
| সরলতা | negative space, এক আকার | remove layers, quiet settle | খালি ও অর্থহীন নয় |
| বিশ্বাস | stable base, balanced frame | low amplitude motion | artificial handshake imagery নয় |
| জটিলতা | layered network | staged reveal, selective focus | একসঙ্গে সব দেখানো নয় |
| পরিবর্তন | morphing silhouette | match shape, path interpolation | random morph নয় |
| উষ্ণতা | amber light, rounded form | slow glow, sine breathing | অতিরিক্ত lens flare নয় |
| জরুরি অবস্থা | clipped rhythm, alert accent | shorter duration, firm settle | constant shake বা red wash নয় |

## ৪. Composition system

### Grid

- Base grid: 8 point
- বড় layout gap: 16, 24, 32, 48, 64, 96
- ছোট optical adjustment: grid ভাঙতে পারে, কিন্তু কারণ থাকতে হবে
- Stroke: একই family-তে সামঞ্জস্যপূর্ণ, সাধারণত 2, 4 বা 8 px equivalent
- Corner radius: প্রতি design system-এ সর্বোচ্চ 2 থেকে 3 মান
- Safe area: delivery platform অনুযায়ী, default title safe 10 শতাংশের মধ্যে গুরুত্বপূর্ণ text

### Hierarchy

প্রতিটি মুহূর্তে একটি primary focal point থাকবে। Secondary element কম contrast, কম scale, কম গতি বা বেশি depth-এ থাকবে। Caption ও headline একই সময়ে জোরে মনোযোগ চাইবে না।

### Negative space

খালি জায়গা আবর্জনা নয়। Text block, light source ও transition direction-এর জন্য জায়গা রাখো। UI বা social overlay যেখানে বসবে, সেখানে গুরুত্বপূর্ণ তথ্য রাখবে না।

### Aspect ratio

Vertical বা square বানাতে গেলে center crop যথেষ্ট নয়। নতুনভাবে নির্ধারণ করো:

- text block-এর সর্বোচ্চ প্রস্থ
- line break
- caption অবস্থান
- motif scale
- camera travel
- safe zone

## ৫. Color direction

Default অনুপাত 70 শতাংশ background, 20 শতাংশ text ও neutral, 10 শতাংশ accent হতে পারে। এটি কঠিন পরিমাপ নয়, visual dominance নির্দেশনা।

- Background: গভীর, subtle radial gradient, কিনারায় সামান্য vignette
- Primary text: উচ্চ contrast, কিন্তু clipping white নয়
- Accent: semantic ও সীমিত
- Alert red: শুধু brief-এ অনুমোদিত সতর্কতা বা শব্দে
- Warm grade: documentary বা emotional scene-এ আস্তে আসতে পারে
- Product color: অনুমোদিত brand source থেকে নিতে হবে

Color যতক্ষণ না নিজে তথ্য বহন করছে, ততক্ষণ শুধু decoration হিসেবে নতুন accent যোগ করবে না।

## ৬. Visual continuity

ভিডিও জুড়ে অন্তত তিনটি ধ্রুবক রাখো:

1. একটি recurring geometry, যেমন সরু রেখা বা বৃত্ত
2. একটি motion family, যেমন Expo Out entry ও Quint Out settle
3. একটি light বা texture behavior, যেমন soft bloom ও fine grain

দৃশ্য ভেদে motif-এর অবস্থা বদলাবে। এটি template repetition নয়, controlled evolution। Recurring geometry কেবল secondary continuity motif হিসেবে থাকতে পারে। প্রতিটি semantic dialogue-এর primary SVG আলাদা generator বা geometry এবং আলাদা composition বা motion পাবে। বিস্তারিত `22_DIALOGUE_SPECIFIC_SVG_SYSTEM.md`-এ।

## ৭. Complexity budget

প্রতি দৃশ্যে প্রাথমিক budget:

- 1 hero typographic বা product action
- 1 supporting graphic action
- 1 ambient layer
- 1 transition handoff
- 1 sound accent, প্রয়োজন হলে

অতিরিক্ত layer যোগ করার আগে লিখো: এটি কোন তথ্য, আবেগ বা depth যোগ করছে? উত্তর না থাকলে বাদ দাও।

## ৮. Tone-specific restraint

### রাজনৈতিক বা স্মরণীয়

- মর্যাদাপূর্ণ scale ও পরিষ্কার typography
- abstract ও symbolic visual
- কঠিন bounce, comedy, celebratory confetti ও random glitch নয়
- বাস্তব দাবি, ছবি বা symbol কেবল অনুমোদিত হলে

### Product promo

- পণ্যের functionality ও hierarchy প্রধান
- নিজে আঁকা UI frame, callout ও guided motion
- feature-এর সংখ্যা যত বেশি নয়, তত ভালো
- decorative 3D যেন ব্যবহার বোঝানোকে ঢাকে না

### Documentary

- source-এর মর্যাদা, textural restraint, সময় ও স্থানের বোধ
- archival treatment কেবল অনুমোদিত asset-এ
- dates বা facts hallucinate নয়
- grain ও grade content-কে ঢেকে ফেলবে না

### Explainer

- একটি ধারণা থেকে পরের ধারণায় visual handoff
- diagram চালু হবে narration-এর ক্রমে
- একসঙ্গে অতিরিক্ত node, arrow বা label নয়

## ৯. দৃশ্য পরিকল্পনার কার্ড

প্রতিটি দৃশ্যের জন্য পূরণ করো:

```text
Scene ID:
Source range:
Dialogue IDs:
Narrative role:
Speech act per dialogue:
Exact spoken text:
On-screen text:
Primary focal word বা object:
Emotional intensity, 0 থেকে 1:
Creative metaphor:
Composition:
প্রতি dialogue-এর unique SVG asset ID ও source file:
Primary generator, geometry, composition ও motion signature:
আগের dialogue থেকে পার্থক্য ও shared secondary motif:
Primary text recipe:
Supporting motion:
Camera:
Transition in:
Transition out:
Color ও light:
Sound accent:
Easing family:
Duration ও stagger:
Rejected alternatives ও কারণ:
QA risk:
Reuse note:
```

## ১০. Template ভাব দূর করার নিয়ম

- প্রতি দৃশ্যে একই centered headline ও একই underline নয়
- stagger duration, crop, baseline, negative space ও camera motivation content থেকে আসবে
- এলিমেন্টের আকার text-এর দৈর্ঘ্য ও গুরুত্ব অনুযায়ী optical হবে
- একই effect নতুন scene-এ হলেও তার role বা state বদলাবে
- Dialogue বদলালে একই primary SVG-এর color-only, position-only বা scale-only clone ব্যবহার করবে না
- অন্তত একটি secondary motif scene boundary অতিক্রম করে morph বা handoff করতে পারে, যদি narrative উপযুক্ত হয় এবং primary SVG সত্যিকারে নতুন থাকে
- ornamental loop দিয়ে সময় পূরণ করা যাবে না
- reference-এর আবেগ ও নীতি নেওয়া যাবে, সুরক্ষিত composition হুবহু নকল করা যাবে না
