# 04. Typography, Bengali Shaping ও Caption Design

## ১. Font নির্বাচন

ব্রিফে font না থাকলে Bengali project-এ নিচের ওপেন লাইসেন্স পরিবারগুলো পরীক্ষা করা যায়:

- আধুনিক headline: Anek Bangla, উপযুক্ত weight 600 থেকে 800
- সাহিত্যিক বা editorial headline: Noto Serif Bengali বা Tiro Bangla
- Caption ও body: Hind Siliguri বা Noto Sans Bengali
- Latin-only technical accent: brief-এর language নীতি মিললে আলাদা পরীক্ষা, কিন্তু মোট দুই family-এর মধ্যে রাখো

সর্বোচ্চ দুটি font family। ওজন, width বা style দিয়ে বৈচিত্র্য আনো, অতিরিক্ত family দিয়ে নয়।

Font চূড়ান্ত করার আগে আসল script-এর সবচেয়ে কঠিন word ও line দিয়ে পরীক্ষা করো। পরীক্ষায় অন্তত থাকবে:

- যুক্তাক্ষর
- কার ও মাত্রা
- রেফ ও ফলা
- সংক্ষিপ্ত ও দীর্ঘ শব্দ
- punctuation
- সংখ্যা, প্রয়োজন হলে
- final headline size
- caption size
- bold ও light weight
- motion blur-এর মাঝের sample

Diagnostic word set হিসেবে `ক্ষুধা`, `জ্ঞান`, `শ্রদ্ধা`, `উদ্ভিদ`, `ব্যাখ্যা`, `সংকল্প`, `দৃঢ়তা` ব্যবহার করা যায়। এগুলো পরীক্ষার জন্য, ভিডিওতে যোগ করার নির্দেশ নয়।

## ২. Shaping engine

- HarfBuzz-সমতুল্য complex text shaping বাধ্যতামূলক।
- Glyph shaping, positioning, substitution, mark attachment ও script-specific rules সমর্থন করতে হবে।
- UTF-8 byte, UTF-16 code unit বা code point ধরে অক্ষর ভাগ করা যাবে না।
- Grapheme cluster segmentation-ও animation unit করার অর্থ এই নয় যে অক্ষর আলাদা animate করা নিরাপদ। Bengali-তে default animation unit word, phrase বা line।
- Font fallback যেন একই শব্দের মাঝে unnoticed family বদল না করে।
- প্রয়োজনীয় glyph font-এ না থাকলে আগে font বদলাও বা সমস্যা জানাও।
- Shaping-এর পরে glyph bounding box, ink overflow ও line metrics মাপো।
- Rendered text-কে reference shaped output-এর সঙ্গে তুলনা করার automated snapshot test রাখা ভালো।

## ৩. Typography roles

| Role | সাধারণ আচরণ |
|---|---|
| Hero headline | বড়, সংক্ষিপ্ত, মূল semantic শব্দ বা phrase |
| Editorial headline | Serif বা light weight, reflective tone |
| Supporting line | ছোট, কম contrast, hero-কে চ্যালেঞ্জ করে না |
| Caption | স্থির, স্পষ্ট, দ্রুত পড়ার উপযোগী |
| Data label | কেবল অনুমোদিত data, alignment ও precision গুরুত্বপূর্ণ |
| Callout | লক্ষ্যের সঙ্গে connector দিয়ে যুক্ত |
| Quote | উদ্ধৃতি চিহ্ন বা spacing, কিন্তু সোর্সে quote না থাকলে নতুন quote তৈরি নয় |

## ৪. Layout নিয়ম

- Line height Bengali headline-এর জন্য সাধারণত 1.4 থেকে 1.6। ফন্টের metrics অনুযায়ী optical adjustment করো।
- Line break শব্দের অর্থ ও phrase বজায় রেখে দাও।
- Headline-এর আকার শুধু available width ভর্তি করার জন্য বাড়াবে না।
- দীর্ঘ word-এর জন্য আগে থেকে responsive scale map তৈরি করো।
- Caption ও headline-এর মধ্যে পর্যাপ্ত আলাদা zone রাখো।
- Stroke, shadow ও glow যেন matra বা যুক্তাক্ষর ঢেকে না দেয়।
- Text bounds-এর সঙ্গে visual ink bounds আলাদা হতে পারে। Mask তৈরি করতে ink overflow যুক্ত করো।
- 8 point layout grid ব্যবহার করো, কিন্তু baseline ও optical centering-এ ছোট সংশোধন করা যায়।

## ৫. Word-level rendering

Complex script-এ text layer আলাদা করার নিরাপদ সীমা:

1. সম্পূর্ণ লাইন
2. স্থির phrase
3. সম্পূর্ণ শব্দ
4. Font ও shaping engine দিয়ে যাচাই করা independent orthographic segment

নিষিদ্ধ default:

- যুক্তাক্ষরের ভেতরে split
- mark বা কার আলাদা layer
- প্রতি অক্ষরে stagger
- letter-spacing বা tracking animation
- path-এর ওপর Bengali glyph বসানো, যদি না shaping ও readability আলাদাভাবে প্রমাণিত হয়
- ভিন্ন font fallback মেশানো এক word

## ৬. Text surface treatment

Premium text সাধারণত flat fill-এর চেয়ে সামান্য বেশি নিয়ন্ত্রিত, কিন্তু effect স্পষ্ট হওয়া উচিত নয়।

### Subtle gradient

- Top বা upper-left সামান্য হালকা
- Bottom সামান্য গাঢ়
- একই hue family
- Perceptual luminance পার্থক্য সাধারণত 3 থেকে 8 শতাংশ
- Gradient text-এর ভেতরে shaped word-এর alpha দিয়ে clip

### Inner glow

- খুব কম opacity
- ছোট radius
- উজ্জ্বল accent text-এ সীমিত
- Glyph interior নষ্ট করবে না

### Drop shadow

- Soft, ছোট offset
- Background থেকে আলাদা করার জন্য যথেষ্ট
- কালো hard shadow নয়
- Caption-এর outline বা shadow মূল ভূমিকা readability

### Bloom

- Threshold দিয়ে শুধু উজ্জ্বল অংশ ধরো
- পুরো frame blur করে glow বানাবে না
- Text-এর ছোট counter ও মাত্রা বজায় রাখো

## ৭. Variable font

Weight animation করা যায় শুধু যখন:

- একই variable font file-এর interpolation stable
- প্রতি sample-এ shaping ও advance width পরীক্ষা করা হয়েছে
- Word-এর line break বা surrounding layout লাফাচ্ছে না
- গতি whole word-এ প্রয়োগ হচ্ছে
- Tone-এর সঙ্গে মিল আছে

ঝুঁকি থাকলে weight animation-এর বদলে scale, opacity, blur বা gradient position ব্যবহার করো। Font weight 600 থেকে 800-এর headline contrast এবং light 300 থেকে 400 supporting text-এর মধ্যে ভারসাম্য রাখো।

## ৮. Caption design

Default:

- Font: Hind Siliguri Medium বা SemiBold, অথবা project-এর অনুমোদিত sans
- Fill: `#F5F7FA`
- Active spoken word: teal-green, default `#2ED3A6`
- Active scale: 1.00, optional 1.02 শুধু stable layout ও collision test pass করলে
- Color change: reveal-এর পরে actual word onset-এর কাছাকাছি, 0.06 থেকে 0.10 s transition
- Easing: Emphasis Soft
- Box বা chip: নয়
- Leading vertical bar, pipe, dash বা bullet: নয়
- Em dash বা U+2014: নয়
- Outline: গাঢ়, মসৃণ, ছোট
- Shadow: subtle
- Maximum words per line: 7
- Layout: phrase-aware, stable, সম্পূর্ণ cue আগে shape করে word space reserve

পূর্ণ progressive reveal ও highlight timing `21_PREMIUM_SUBTITLE_SYSTEM.md` এবং `project/subtitle-style.json`-এ আছে। Default alternate highlight মানে active word teal এবং বাকি text off-white, পরের word-এ highlight সরে গেলে আগেরটি base color-এ ফিরবে।

Restricted alert color কেবল brief-এর নির্দিষ্ট word বা semantic alert-এ ব্যবহার করো। অন্য কোথাও glow, particle বা chromatic channel-এর মাধ্যমে সেই restricted color ফুটে উঠছে কি না পরীক্ষা করো। Chromatic aberration-এর জন্য আলাদা low-saturation channel offset ব্যবহার করা যায়, কিন্তু restricted palette ভঙ্গ করলে effect বদলাও।

## ৯. Punctuation ও সংখ্যা

- সোর্সের punctuation বদলাবে না, শুধু U+2014-এর ক্ষেত্রে `14_OUTPUT_CONTRACT.md`-এর নিষেধ ও contextual replacement policy প্রযোজ্য।
- বাংলা সংখ্যা প্রয়োজন হলে locale-এর নিয়ম মেনে দাও।
- SRT-এর sequence number বা timecode ভিডিওতে দেখাবে না।
- কোনো নতুন তথ্য, তারিখ, counter বা percentage সাজানো যাবে না।
- Animated counter কেবল অনুমোদিত source value-এর জন্য এবং প্রয়োজন হলে।

## ১০. Readability ও accessibility

- ছোট screen preview-এ caption পড়া যাচ্ছে কি পরীক্ষা করো।
- Text ও background-এর contrast পর্যাপ্ত রাখো।
- Blur entry-এর পরে পর্যাপ্ত sharp hold দাও।
- দ্রুত flashing, strobing বা বড় amplitude shake এড়াও।
- Reduced-motion version চাইলে typography ও information hierarchy অক্ষুণ্ণ রেখে amplitude কমাও।
- Caption-কে কেবল রং দিয়ে active বোঝালে scale বা weight-এর subtle সহায়তা থাকতে পারে।

## ১১. Font delivery

- ব্যবহারের অনুমতিসম্পন্ন font bundle করো।
- License file রাখো।
- System font-এর ওপর নির্ভর করবে না।
- Font file-এর নাম ও version রিপোর্ট করো।
- Render environment-এ একই font loaded হয়েছে কি না যাচাই করো।
- Font subsetting করলে প্রয়োজনীয় সব glyph, feature ও language system যেন থাকে।
