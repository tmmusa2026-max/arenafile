# 16. Continuity Graph ও Short-scene Conflict Solver

## ১. Continuity graph

প্রতিটি scene আলাদা করে সুন্দর হলেও ভিডিও ভালো নাও লাগতে পারে। Scene-এর মধ্যে কোন element, আলো, গতি বা অর্থ টিকে থাকবে তার graph তৈরি করো।

```text
Scene S01
  outgoing_element: text_alpha_particles
  outgoing_motion: downward_release
  outgoing_color: lime
       |
       | X01 convergence
       v
Scene S02
  incoming_element: timeline_points
  shared_geometry: point_to_line
  outgoing_element: final_light_dot
       |
       | X11 light handoff
       v
Scene S03
  incoming_element: warm_orb
  outgoing_element: concentric_rings
       |
       | X02 ring_to_line
       v
Scene S04
  incoming_element: resolved_lime_line
  final_state: quiet_hold
```

## ২. Graph fields

প্রতিটি সংযোগে লিখো:

| Field | অর্থ |
|---|---|
| `from_scene` | আগের দৃশ্য |
| `to_scene` | পরের দৃশ্য |
| `shared_element_id` | একই বা রূপান্তরিত secondary element, primary dialogue SVG নয় |
| `from_dialogue` ও `to_dialogue` | সংশ্লিষ্ট semantic dialogue ID, প্রযোজ্য হলে |
| `semantic_handoff` | অর্থ কীভাবে এগোয় |
| `geometry_handoff` | Point, line, ring, card, mask |
| `motion_handoff` | Direction ও velocity continuity |
| `color_handoff` | কোন রং টিকে থাকে বা বদলায় |
| `audio_window` | কোন pause-এ বদল ঘটে |
| `proof_frame` | Midpoint যাচাই |

`shared_element_id` একই থাকলে শুধু আকার নয়, তার visual behavior-ও পরিচয় বহন করবে। Dialogue-specific SVG-এর ক্ষেত্রে shared element কেবল secondary motif বা handoff fragment হবে। পরের dialogue-এর primary SVG একই asset বা visual signature পাবে না; নতুন generator বা geometry এবং নতুন composition বা motion প্রয়োজন।

## ৩. Generic continuity structure

এটি rendered reference নয়, শুধু graph-এর গঠন।

| From | To | Shared element | Handoff | Future project proof |
|---|---|---|---|---|
| S01 | S02 | `previous_underline` | Underline পরের scene-এর connector হয় | `future_project/S01_S02.png` |
| S02 | S03 | `connector_endpoint` | Connector-এর endpoint নতুন focal shape তৈরি করে | `future_project/S02_S03.png` |
| S03 | End | `resolved_motif` | আগের motif-এর simplified final state | `future_project/S03_end.png` |

## ৪. Continuity failure

- শুধু একই রং ব্যবহার করা, কিন্তু element-এর কোনো সম্পর্ক নেই
- আগের scene-এর গতি ডানে, পরের scene হঠাৎ বামে কারণ ছাড়া
- আগের scene-এর আলো বামে, পরের scene-এর shadow ডানে
- দুই scene-এর exiting ও entering text একই জায়গায় অপঠনযোগ্য ghost তৈরি করে
- Transition-এর midpoint-এ দুইটি primary focal point সমান শক্তিতে থাকে
- Background motif হঠাৎ বদলে যায়, handoff নেই
- শেষ scene-এ নতুন motif এসে যায়, যা আগে প্রস্তুত করা হয়নি

## ৫. Text overlap solver

দুই headline-এর transition-এ নিয়ম:

1. আগের text-এর optical opacity পরের text-এর readable opacity-এর সঙ্গে cross করবে না।
2. আগের text-এর blur exit এবং পরের text-এর blur entry একই স্থানে হলে আগেরটির exit আগে শেষ করো।
3. Handoff-এর জন্য particles, underline, orb বা অন্য supporting element থাকতে পারে, কিন্তু দুই headline একই স্পষ্টতায় থাকবে না।
4. পরের headline আসার আগে আগের headline-এর মাত্রা ও যুক্তাক্ষর আর পড়ার প্রয়োজন নেই কি না নিশ্চিত হও।
5. Proof-এ `previous_text_ghost`, `new_text_blur`, `particle_overlap` আলাদা পরীক্ষা করো।

প্রতিটি project-এ previous text exit এবং new text entry-এর measured time লিখে midpoint proof পরীক্ষা করো। Generic example-এর সময় কপি করবে না।

## ৬. Short-scene conflict solver

দৃশ্যের সময় কম হলে সব motion দ্রুত করবে না। নিচের ক্রমে সরাও:

| অগ্রাধিকার | কী রাখবে | কী কমাবে বা বাদ দেবে |
|---|---|---|
| 1 | মূল text বা product এবং readable hold | Decorative particles |
| 2 | Audio sync | Secondary ambient motion |
| 3 | Primary mask, position ও blur | Shimmer, chromatic spike |
| 4 | Meaningful transition | Extra supporting rule বা tick |
| 5 | One clear camera state | Continuous camera travel |
| 6 | Essential sound accent | Repeated ticks |

### Time budget

প্রতিটি scene-এর জন্য:

```text
usable_time = scene_duration - required_transition_overlap
minimum_hold = reading_time + audio_hold
motion_budget = usable_time - minimum_hold
```

`motion_budget` negative হলে:

- Text কেটে নতুন copy বানাবে না
- Audio বদলাবে না
- Effect layers কমাও
- Transition-এর overlap কমাও
- Camera move সরল করো
- দরকার হলে একই scene-এর আগের বা পরের অংশে visual prepare করো, content reveal অকালে নয়

`resolveShortScene()` planning heuristic হিসেবে বাদ দেওয়া প্রতিটি optional layer-এর জন্য 0.06 second complexity credit ধরে। এটি measured render time নয়। বাস্তব audio, reading need এবং proof-এর আগে এই credit দিয়ে duration পরিবর্তন করা যাবে না।

## ৭. Reading time heuristic

এটি acoustic timing-এর বিকল্প নয়, শুধু layout sanity check:

- এক শব্দের headline: কমপক্ষে 0.45 থেকে 0.8 s clear hold
- ছোট phrase: কমপক্ষে 0.8 থেকে 1.4 s
- Caption: প্রকৃত speech duration এবং দর্শকের পড়ার প্রয়োজন
- Product feature: narration-এর সঙ্গে সম্পর্কিত action দেখার অতিরিক্ত সময়
- Data: label, unit ও comparison বোঝার জন্য আরও hold

Complex Bengali headline দীর্ঘ হলে hold বাড়াও। Motion-এর মাঝে পড়ার সময় ধরে নেবে না, sharp state লাগবে।

## ৮. Conflict decision table

| Conflict | সমাধান |
|---|---|
| 0.8 s scene, 0.6 s entry, 0.3 s exit | Entry সরল করে 0.32 s, exit 0.18 s, decoration বাদ, sharp hold যাচাই |
| Voice pause নেই, transition 0.7 s | Shared underline বা 0.25 s handoff, audio বদল নয় |
| Vertical frame, wide callout | Callout নিচে, camera travel কম, নতুন layout |
| Bengali long word, narrow mask | Mask আগে বাড়াও, font ছোট করার আগে layout বদলাও |
| Particle handoff, next text entry | Particle supporting opacity, next text blur শেষ হওয়ার পরে dominant |
| Warm orb, final quiet text | Orb ও rings আগে fade, line রেখে handoff |
| পরের dialogue-এ একই motif দরকার | Secondary fragment রাখো, কিন্তু নতুন primary geometry ও composition তৈরি করো |
| High information density, high energy | Energy-এর amplitude নয়, motion-এর সংখ্যা কমাও |
| Required exact duration, extra hold দরকার | Visual prepare আগে করো, padding নয় |

## ৯. Graph QA

- প্রতিটি scene-এর incoming state কি আগের scene প্রস্তুত করেছে?
- প্রতিটি outgoing element-এর পরিবর্তন কি midpoint-এ দৃশ্যমান?
- দুই headline-এর ghost কি শুধু এক frame-এও ত্রুটির মতো লাগছে?
- কোনো নতুন color বা motif কি হঠাৎ এসেছে?
- Transition কি speech-এর ওপর চড়ছে?
- Final line, motif বা camera কি আগের কোনো element থেকে এসেছে?
- Short scene-এ effects কমানোর পরেও মূল recipe-এর পরিচয় আছে কি?
- Continuity handoff কি পরের dialogue-এর primary SVG-কে আগেরটির duplicate বা color-only clone বানিয়েছে?
