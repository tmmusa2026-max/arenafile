# Changelog

## 2.5.0

### Added

- Technical explainer language with separate verbatim subtitles and semantic keyword echo
- Stable pre-shaped phrase reveal with post-reveal accent and actual audio timing
- Base, subject, relationship and result build beats for dialogue-specific technical SVGs
- Six vector directions for container anatomy, API conversation, code handoff, terminal results, playback states and data transformation
- Optional source-supported chapter pill and deterministic actual-global-timeline progress rail
- Authorized watermark slot with safe local asset paths and verified-permission enforcement
- Explainer style config, JSON schema, recipe registry, timing utility and 22-check regression suite
- Scene-plan fields for keyword echo, staged SVG beats and chapter labels
- QA rules for subtitle replacement, fake progress and unapproved watermark import

### Changed

- Technical reference observations are now abstract reusable techniques, never copied compositions or bundled reference assets
- Watermark placement analysis no longer implies permission to extract or import a third-party mark
- Explainer router now loads the new module, recipes and config only when relevant
- Master and compact prompts now preserve bottom subtitles while adding optional technical keyword treatments

## 2.4.0

### Added

- Dialogue-specific original SVG system for semantic utterances rather than mechanical SRT cues
- One unique primary SVG, asset ID, source file and visual signature per dialogue
- Speech-act, semantic-focus, emotion, narrative-role and actual-timing analysis
- Dialogue SVG recipe library, map schema, project template and scene-plan links
- Structural validator with safe source-path, uniqueness, timing, continuity and optional proof checks
- Regression tests for color-only clones, duplicate IDs, duplicate source files, stale signatures and missing meaningful differences
- Per-dialogue start, middle and end proof requirements
- Small dialogue-specific SVG annotations for real-media scenes

### Changed

- Consecutive dialogue SVGs must change primary generator or geometry plus composition or motion
- Color, opacity, position, scale, text or duration changes alone no longer count as a new dialogue SVG
- Shared secondary motifs remain allowed for continuity, but duplicate primary visual signatures fail
- Master and compact prompts, router, project schema, output contract, scored QA and delivery workflow now enforce dialogue-specific SVGs
- Vector recipes are directions for original assets, not finished templates to recolor or reposition

## 2.3.0

### Added

- Premium bottom-center Bengali subtitle recipe
- Off-white base text and teal-green active spoken word
- Whole shaped-word mask, opacity, offset and blur reveal
- Actual speech-driven highlight after word reveal
- Stable pre-shaped cue layout with reserved word positions
- Optional two-color alternating active palette
- Subtitle style schema, project config, timing utility and regression tests
- Explicit prohibition of leading vertical bars, pipes, dashes and bullets

### Changed

- Caption default active color is now `#2ED3A6`
- Caption default active scale is now 1.00 to prevent layout shifts
- Previous active word returns to the off-white base color
- Subtitle QA now requires encoded comparison of spoken and highlighted words

## 2.2.1

### Added

- Dedicated U+2014 detection utility and text-policy regression test
- Scans for SVG, SRT, VTT, ASS, SSA, XML, YAML, HTML and other generated text files
- File and directory name checks for U+2014
- Encoded video and external media visual review requirements
- Contextual punctuation replacement log when source text contains U+2014

### Changed

- Em dash prohibition now explicitly covers captions, headlines, SVG text, external media text, video metadata and filenames
- Text scanning alone is no longer treated as sufficient for baked-in footage text

## 2.2.0

### Added

- Bengali two-file intake for voice-over and SRT
- Autonomous scene, SVG, animation and media selection after intake
- Rights-verified web photo and short video clip workflow
- News and documentary safeguards for archival and illustrative media
- Media manifest schema and reusable sourcing policy
- Exact executed command log requirements
- Public delivery report schema and hosting capability fallback
- Native HTML video preview template with relative MP4 and ZIP paths
- Public preview, direct MP4 and delivery ZIP verification rules
- QA checks for media provenance, honest links and playback evidence

### Changed

- Master and compact prompts now start with the two-file Bengali workflow
- Router now loads media research and public delivery modules when needed
- Output contract now requires media provenance and actual command logs
- Public upload and playback claims require evidence, never fabricated URLs

## 2.1.0

### Changed

- Removed the reference MP4 and every rendered visual proof asset
- Removed the reference scene renderer, scene plan, composition, timing map and production report
- Removed all machine-readable examples copied from that reference
- Reframed the package as a reference-free prompt and validation toolkit
- Kept reusable motion, typography, SVG, effects, sound, QA and Node delivery guidance
- Kept generic font, audio, responsive, continuity and temporal validation tools
- Added an explicit policy that validation output is not a visual style guide
- Added package checks that forbid reference artifacts and enforce the 25 MB source budget
- Removed the video render, proof and QC commands from this prompt-only package
- Reduced the package to compact documents, libraries, examples and validation assets

### Validation scope

- Font tests cover glyph coverage and shaped ink clipping
- Audio tests cover synthetic envelope alignment only
- Rules tests cover generic responsive and continuity logic
- Temporal test covers a frame-count regression only
- None of these tests is a final video quality claim

## 2.0.0

- Added executable production-system improvements and validation prototypes
- The rendered reference from that iteration has been intentionally removed in 2.1.0

## 1.0.0

- Initial adaptive prompt system
- Motion, typography, SVG, effects, sound, render and QA libraries
- Political, product promo and documentary prose examples
