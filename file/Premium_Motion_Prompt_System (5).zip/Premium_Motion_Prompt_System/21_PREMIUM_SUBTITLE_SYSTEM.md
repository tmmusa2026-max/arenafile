# 21. Premium Subtitle System

## উদ্দেশ্য

ভিডিওর নিচে পরিষ্কার, শুদ্ধ Bengali subtitle থাকবে। প্রতিটি word সুন্দরভাবে reveal হবে এবং actual speech-এর সঙ্গে active color সরবে। ব্যবহারকারীর দেওয়া visual reference-এর মূল বৈশিষ্ট্য হলো off-white text এবং teal-green active word, তবে বাঁ পাশের vertical accent bar বাদ।

এই module-এ কোনো screenshot, reference frame বা video bundled নয়। নীতি ও reusable timing recipe ব্যবহার করে প্রতিটি project-এর নিজের typography তৈরি করতে হবে।

## ১. Default visual style

| Property | Default |
|---|---|
| Position | Bottom center, responsive safe area-এর ভেতরে |
| Font | Hind Siliguri Medium বা project-এর verified Bengali sans |
| Base color | `#F5F7FA` |
| Active spoken word | `#2ED3A6`, teal-green |
| Maximum lines | 2 |
| Default words per line | সর্বোচ্চ 7, phrase এবং screen width অনুযায়ী কম হতে পারে |
| Font size | Frame height-এর প্রায় 5.2 শতাংশ, তারপর optical fit |
| Line height | 1.35 |
| Bottom safe area | Frame height-এর প্রায় 9 শতাংশ, platform UI অনুযায়ী বেশি |
| Horizontal safe area | Frame width-এর প্রায় 8 শতাংশ |
| Backing card বা chip | নয় |
| Readability | Subtle shadow এবং প্রয়োজন হলে soft bottom scrim |
| Leading vertical bar, pipe, dash বা bullet | নিষিদ্ধ |
| Em dash বা U+2014 | নিষিদ্ধ |

Teal-green হলো এই recipe-এর default active color। Brand brief-এ ভিন্ন অনুমোদিত color থাকলে contrast যাচাই করে সেটি ব্যবহার করা যায়। Random rainbow color নয়।

## ২. Alternate highlight-এর অর্থ

Default alternate highlight মানে প্রতিটি word-এ আলাদা রং নয়। এটি base এবং active state-এর নিয়ন্ত্রিত পরিবর্তন:

- মূল revealed text `#F5F7FA`
- বর্তমানে উচ্চারিত word `#2ED3A6`
- পরের word active হলে আগের word আবার `#F5F7FA`
- একই সময়ে একটি primary active word
- শেষ word-এর highlight cue-এর readable hold পর্যন্ত থাকতে পারে

Brief-এ সত্যিকারের two-color alternating mode চাইলে `alternate_active_colors: true` এবং দুটি approved active colors ব্যবহার করা যায়। Default হিসেবে এটি চালু নয়। Optional second teal tint হিসেবে `#7CE7C4` যাচাই করা যায়, তবে contrast ও tone মিলতে হবে।

## ৩. Stable Bengali layout

1. সম্পূর্ণ cue আগে shape ও measure করো।
2. প্রতিটি word-এর জায়গা আগে থেকে reserve করো।
3. Upcoming word invisible থাকলেও তার layout space অপরিবর্তিত থাকবে।
4. Word reveal-এর সময় পুরো line center থেকে সরে যাবে না।
5. Active color বদলালে font, width, tracking বা baseline বদলাবে না।
6. Default active scale 1.00। Optional scale সর্বোচ্চ 1.02 এবং শুধু collision test pass করলে।
7. Bengali যুক্তাক্ষর, কার, রেফ, ফলা বা vowel mark ভেঙে অক্ষর আলাদা করবে না।
8. Animation unit হবে সম্পূর্ণ shaped word, phrase বা line, অক্ষর নয়।

## ৪. Word reveal animation

প্রতিটি shaped word-এর জন্য:

- Mask বা opacity reveal
- Y offset প্রায় 0.15 em থেকে 0
- Blur প্রায় 3 px থেকে 0, renderer ও font size অনুযায়ী
- Expo Out বা অনুরূপ নিয়ন্ত্রিত easing
- Reveal সাধারণত word onset-এর 120 থেকে 180 ms আগে শুরু
- Word onset-এর মধ্যে reveal শেষ
- দ্রুত speech-এ lead time কমাও, কিন্তু fixed delay দিয়ে word late করবে না
- Overshoot, bounce, glitch, typewriter character reveal এবং random rotation নয়

একই cue-এর সব word-এর animation actual word timing থেকে আসবে। কৃত্রিম fixed stagger দিয়ে speech-এর natural rhythm বদলাবে না।

## ৫. Highlight timing

`validation/src/subtitle-timing.js`-এর নিয়ম:

```text
reveal_start = max(cue_start, word_start - pre_speech_reveal)
reveal_end = word_start
highlight_start = min(word_start + configured positive frame delay, word_midpoint)
highlight_end = next_word_highlight_start
last_highlight_end = cue_end
```

Default color delay 1 output frame। Config-এ 1 থেকে 4 frame রাখা যায়, তবে 0 frame নয়, কারণ color অবশ্যই reveal-এর পরে আসবে। খুব ছোট word-এ midpoint cap delay-কে সীমিত করে।

ফল:

- Word আগে reveal হয়
- Color reveal-এর পরে এবং speech onset-এর কাছাকাছি আসে
- খুব ছোট word-এও color word-এর মাঝের আগে আসে
- পরের active word শুরু হলে আগের active state শেষ হয়
- Highlight random time বা SRT cue-এর average timing থেকে আসে না

Color transition 60 থেকে 100 ms নরম হতে পারে, তবে timing logic-এর `highlight_start` বদলাবে না। Transition-এর সময় দুটি word-এর full-highlight overlap থাকবে না। Actual word timing না থাকলে `estimated` চিহ্নিত fallback ব্যবহার করো এবং সেটিকে acoustic timing বলবে না।

## ৬. Cue entry, hold ও exit

- Cue-এর প্রথম word reveal দিয়ে subtitle শুরু হবে, আলাদা decorative bar দিয়ে নয়।
- পুরো line-এর pre-shaped layout প্রথম থেকেই stable থাকবে।
- শেষ word-এর পরে যতটা natural pause আছে ততটা readable hold রাখো।
- Audio বা cue duration বাড়িয়ে hold তৈরি করবে না।
- পরের cue দ্রুত এলে আগের cue-কে অগ্রাধিকার দিয়ে overlap নয়, phrase-aware timing correction করো।
- Exit হলে সম্পূর্ণ cue-এর জন্য 120 থেকে 180 ms soft opacity বা mask transition ব্যবহার করা যায়, last word পড়ার সময় নষ্ট না করে।

## ৭. Decorative restrictions

Subtitle-এর শুরুতে নিচের কোনো decorative element যোগ করবে না:

- Vertical accent bar
- Pipe বা `|`
- En dash, em dash বা hyphen bullet
- Arrow, dot বা অন্য leading marker, source-এর প্রকৃত অংশ না হলে
- Unnecessary quote mark বা bracket
- U+2014 কোনো caption, metadata বা generated file-এ

Source-এর প্রকৃত punctuation থাকলে তা typography-এর অংশ। Decorative marker এবং source punctuation এক বিষয় নয়। Source-এ U+2014 থাকলে `14_OUTPUT_CONTRACT.md`-এর punctuation replacement ও log policy প্রয়োগ করো।

## ৮. Contrast ও footage integration

- Dark footage-এ off-white এবং teal সরাসরি ব্যবহার করা যায়, contrast measured হলে।
- Busy বা bright footage-এ subtle bottom scrim, soft shadow বা অন্য composition নাও।
- Readability-এর জন্য কঠিন opaque card default নয়।
- Text যেন মূল subject-এর মুখ, product detail বা গুরুত্বপূর্ণ evidence ঢাকে না।
- External footage-এর নিজের subtitle বা baked-in text থাকলে collision ও U+2014 পরীক্ষা করো।
- Caption background-এর color যেন active teal-এর সাথে কম contrast তৈরি না করে।

## ৯. Responsive behavior

### Wide

- Bottom center, এক বা দুই line
- দীর্ঘ sentence phrase boundary-তে ভাগ
- Text width safe area-এর মধ্যে

### Vertical

- Font size এবং line width আলাদাভাবে fit
- Platform UI-এর জন্য bottom safe area বাড়াও
- Wide caption center crop নয়
- প্রয়োজনে বেশি cue break, কিন্তু word বা phrase ভাঙা নয়

### Square

- Wide ও vertical-এর মধ্যবর্তী text width
- Caption-এর নিচে UI বা CTA থাকলে আলাদা zone

## ১০. Configuration

- Style: `project/subtitle-style.json`
- Schema: `schemas/subtitle-style.schema.json`
- Recipe metadata: `libraries/subtitle-recipes.json`
- Timing utility: `validation/src/subtitle-timing.js`
- Regression test: `validation/tests/subtitle.test.js`

Project-specific color, font বা safe area বদলালে config-এ লিখো এবং proof দাও। Generic default-কে brand brief-এর ওপর চাপাবে না।

## ১১. Subtitle QA

- প্রতিটি word কি সম্পূর্ণ shaped unit হিসেবে reveal হয়েছে?
- Reveal কি actual word onset-এর পরে late নয়?
- Active color কি reveal-এর পরে এসেছে?
- বর্তমানে শোনা word এবং teal-highlighted word একই কি?
- Previous word কি base color-এ ফিরেছে?
- একই সময়ে একাধিক full-active word আছে কি?
- Color বদলালে line, baseline বা word position নড়ছে কি?
- দীর্ঘ Bengali word, যুক্তাক্ষর, রেফ, ফলা ও vowel mark সঠিক কি?
- Caption-এর বাঁ পাশে vertical bar, pipe, dash বা bullet নেই তো?
- Caption, external media text ও metadata-তে U+2014 নেই তো?
- Bright ও dark দুই ধরনের footage-এ contrast পড়ার উপযোগী কি?
- Final encoded video-তে এই checks আবার দেখা হয়েছে কি?

Text timing report এবং visual playback review দুটিই দরকার। শুধু config দেখে subtitle pass দেওয়া যাবে না।

## ১২. Semantic keyword echo-এর সঙ্গে সম্পর্ক

Technical explainer-এ composition-এর ভেতরে বড় keyword text থাকতে পারে। সেটি এই module-এর verbatim bottom subtitle নয় এবং সেটির বিকল্পও নয়।

- Bottom subtitle অনুমোদিত spoken words, off-white base এবং teal active word-এর এই contract অনুসরণ করবে।
- Keyword echo source-এর নির্বাচিত phrase, আলাদা hierarchy এবং composition-aware position ব্যবহার করবে।
- দুটি layer-ই whole shaped word বা phrase এবং stable reserved layout ব্যবহার করবে।
- Echo-র accent তার reveal-এর পরে আসবে, কিন্তু subtitle-এর active teal timing বদলাবে না।
- দুই layer-এর text, scrim, chapter pill, watermark ও progress rail-এর collision পরীক্ষা করো।
- Reference-এ আলাদা bottom subtitle না দেখলে সেটি অনুপস্থিত বলে document করো, বড় keyword text-কে subtitle বলে ধরে নেবে না।

Echo-এর timing, policy ও validation `23_TECHNICAL_EXPLAINER_LANGUAGE.md`, `project/explainer-style.json` এবং `validation/src/explainer-timing.js`-এ আছে।
