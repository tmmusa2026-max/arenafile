# 02. Timing, Speech Analysis ও Caption Sync

## মূল নীতি

ভয়েস-ওভার থাকলে শ্রোতা যা শুনছেন, সেটিই master clock। SRT, script বা আনুমানিক scene duration কেবল guide। Visual, caption, sound accent এবং transition একই সময়ের উৎস থেকে চলবে।

## ১. Audio inventory

বিশ্লেষণের আগে রেকর্ড করো:

- ফাইলের নাম ও checksum, পাইপলাইন সমর্থন করলে
- duration
- sample rate
- channel count
- codec
- leading ও trailing silence
- clipping বা অস্বাভাবিক noise
- SRT থাকলে তার cue count ও সময়

মূল audio file overwrite করবে না। Analysis-এর জন্য PCM decode আলাদা cache-এ রাখো।

## ২. Volume envelope ও speech region

প্রাথমিক পদ্ধতি:

1. Mono analysis mix তৈরি করো, মূল stereo file বদলাবে না।
2. 10 ms window ও 5 ms hop-এ short-time RMS বের করো।
3. Noise floor ধরতে নীচের amplitude percentile এবং প্রাথমিক silence ব্যবহার করো।
4. Speech threshold noise floor-এর ওপরে adaptive রাখো। একটি fixed dB মান সব recording-এ কাজ করবে না।
5. Hysteresis ব্যবহার করো: শুরু করার threshold একটু বেশি, শেষ করার threshold একটু কম।
6. খুব ছোট spike বা breath যেন আলাদা শব্দ না হয়, minimum duration ও smoothing দাও।
7. Plosive, fricative ও nasal onset যেন হারায় না, RMS-এর সঙ্গে spectral flux বা high-frequency energy পরীক্ষা করা যায়।
8. সম্ভব হলে VAD বা forced alignment ফলকে দ্বিতীয় প্রমাণ হিসেবে ব্যবহার করো।

প্রতিটি utterance-এর জন্য সংরক্ষণ করো:

```text
utterance_id
dialogue_id
speech_start
speech_end
leading_pause
following_pause
confidence
aligned_srt_cue
alignment_note
```

## ৩. SRT alignment

SRT cue-এর সময় আসল অডিওতে না মিললে cue-এর text বদলাবে না। Text-কে সঠিক utterance-এর সঙ্গে মিলিয়ে নতুন visual timing তৈরি করো।

- Cue-এর ক্রম সাধারণত অপরিবর্তিত থাকবে।
- এক cue-এ একাধিক utterance থাকলে word group ভাগ করো।
- একাধিক cue-এ একটানা utterance থাকলে boundary শুধু silence-এ রাখো।
- Low-confidence alignment থাকলে waveform, onset এবং শুনে যাচাইয়ের জন্য flag দাও।
- সামঞ্জস্য করতে গিয়ে অডিও time-stretch করবে না।

Aligned utterance ও cue-কে এরপর semantic dialogue unit-এ group করো। Mechanical cue count-কে dialogue count ধরবে না। সম্পর্কিত fragments একই উক্তি চালিয়ে গেলে একই `dialogue_id` পাবে; প্রশ্ন, উত্তর, অর্থ, speaker বা narrative role বদলালে নতুন ID পাবে। প্রতিটি dialogue-এর actual start ও end `project/dialogue-svg-map.json`-এ লিখো।

Constrained dynamic time warping বা monotonic alignment ব্যবহার করা যায়, কিন্তু এটি cue-কে ভুল utterance-এ যেতে দেবে না। Boundary সবসময় আসল speech evidence দিয়ে পরীক্ষা করবে।

## ৪. Word-level timing

পছন্দের ক্রম:

1. বিশ্বস্ত forced alignment
2. Acoustic onset, phoneme boundary ও transcript-এর মিল
3. Manual listening ও waveform যাচাই
4. Linguistically weighted fallback

Fallback-এর নিয়ম:

- প্রথমে utterance-কে সঠিক শব্দে tokenize করো।
- Punctuation আলাদা শব্দ নয়।
- Grapheme cluster ধরো, code point বা byte ধরে ভাগ করবে না।
- শব্দের আপেক্ষিক weight তার spoken length-এর কাছাকাছি হবে। Grapheme count, syllable estimate এবং স্বাভাবিক function word-এর সংকোচন ব্যবহার করা যায়।
- Pause punctuation-এর জন্য আলাদা সময় রাখো, কিন্তু acoustic pause-এর বাইরে কাল্পনিক বিরতি বসাবে না।
- Fallback timing-এ `confidence: estimated` লিখো এবং এটিকে আসল acoustic detection বলে দাবি করবে না।

সরল fallback সূত্র:

```text
weight(word) = 0.35 + 0.65 * normalized_grapheme_weight + syllable_adjustment
available_time = utterance_end - utterance_start - measured_internal_pauses
word_duration = available_time * weight(word) / sum(all_weights)
```

এটি কেবল শেষ বিকল্প। বাস্তবে শব্দের onset পরবর্তী detected onset-এর সঙ্গে মিলিয়ে নিতে হবে, যখন নির্ভরযোগ্য boundary পাওয়া যায়।

## ৫. Visual placement

- Word highlight: word onset-এর 0 থেকে 2 frame আগে শুরু করা যায়, কখনো শব্দ শেষ হওয়ার পরে নয়।
- Headline: মূল শব্দের onset-এর সামান্য আগে প্রস্তুত হতে পারে, কিন্তু আগের তথ্য অকালে প্রকাশ করে অর্থ নষ্ট করবে না।
- Dialogue SVG: সেই dialogue-এর actual speech start-এর আগে বা সঙ্গে meaningful entry শুরু হবে, পরে নয়। পরের dialogue-এর আলাদা SVG-এর সঙ্গে overlap কেবল documented handoff-এ এবং readable state রক্ষা করে হবে।
- Stamp sound: headline-এর optical settle বা impact frame-এ বসবে, word onset-এর পরে অযাচিত দেরি নয়।
- Exit: পরবর্তী শব্দ বা দৃশ্যের আগে readability শেষ না করে।
- Transition: দীর্ঘ natural pause-এ বসানো ভালো। Pause না থাকলে ছোট element-led overlap ব্যবহার করো।
- শেষ শব্দ: caption ও headline-এর hold শব্দের acoustic end এবং বাক্যের অর্থ অনুযায়ী ঠিক হবে। Audio বাড়ানো যাবে না।

## ৬. Scene timing model

প্রতিটি scene-এর জন্য এই সময়গুলো আলাদা রাখো:

| সময় | অর্থ |
|---|---|
| `content_start` | আসল utterance শুরু |
| `visual_prepare` | প্রবেশের প্রস্তুতি, content_start-এর আগে হতে পারে |
| `visual_in` | প্রধান reveal শুরু |
| `visual_settle` | প্রধান গতি স্থির হয় |
| `active_start` | পুরোপুরি পড়ার উপযোগী |
| `exit_prepare` | পরের ধাপের প্রস্তুতি |
| `visual_out` | exit শুরু |
| `content_end` | আসল utterance শেষ |
| `handoff` | পরের scene-এর element দায়িত্ব নেয় |

সবকিছু একই frame-এ শুরু বা শেষ করবে না। তবে overlap যেন caption-এর sync নষ্ট না করে।

## ৭. Caption rules

- Caption-এর বাংলা বা অন্য text transcript-এর সঙ্গে হুবহু মিলবে।
- Brief-এ সংশোধনের অনুমতি না থাকলে spelling নিজে বদলাবে না। অসঙ্গতি থাকলে জানাবে।
- প্রতি লাইনে default সর্বোচ্চ 7 শব্দ। ছোট screen-এ 2 লাইনের বেশি নয়, যদি না অন্য নির্দেশ থাকে।
- Line break linguistic phrase-এর সীমায় হবে।
- Box বা chip default নয়। উচ্চ contrast outline বা shadow দিয়ে readability তৈরি করো।
- Active word-এর color reveal-এর পরে actual onset-এর কাছাকাছি বদলাবে। Default active color `#2ED3A6`, base `#F5F7FA`, color transition 0.06 থেকে 0.10 second। Default scale 1.00, optional সর্বোচ্চ 1.02 এবং optical collision পরীক্ষা সাপেক্ষে।
- আগের active word নরমভাবে base color-এ ফিরবে এবং একই সময়ে একটি primary active word থাকবে।
- Caption-এর বাঁ পাশে decorative vertical bar, pipe, dash বা bullet নয়। U+2014 নিষেধ প্রযোজ্য।
- পূর্ণ timing formula `21_PREMIUM_SUBTITLE_SYSTEM.md` ও `validation/src/subtitle-timing.js`-এ আছে।
- Caption নিজে একটি stable layout-এ থাকবে। প্রতি শব্দে পুরো লাইন লাফাবে না। প্রস্থের পরিবর্তন আগে থেকে reserve করো বা word-local transform ব্যবহার করো।
- শব্দভিত্তিক active color-এর জন্য আলাদা shaped word layer ব্যবহার করা যায়, কিন্তু যুক্তাক্ষরের ভেতরে ভাগ করা যাবে না।
- Caption-এর baseline ও line gap সব scene-এ সামঞ্জস্যপূর্ণ থাকবে।

## ৮. Frame quantization ও duration

Timeline-এর অভ্যন্তরীণ হিসাব seconds বা rational time-এ রাখো। শুধু render-এর সময় frame-এ quantize করো। প্রতিটি event-এর ideal time ও rendered frame আলাদা log করা ভালো।

অডিওর duration fps-এর পূর্ণ frame-এ না পড়লে:

- Audio কাটবে না বা বাড়াবে না।
- Video track-এর শেষ sample duration ও container duration যাথাযথ timebase-এ target duration-এর সঙ্গে মেলানোর চেষ্টা করো।
- Container, video track ও audio track-এর duration আলাদা করে probe করো।
- কোনো প্লেয়ারে অর্ধেক frame-এর মধ্যে ছোট পার্থক্য অনিবার্য হলে তা লুকাবে না। Brief-এর exact-duration শর্ত ও বাস্তব measured result রিপোর্ট করো।
- অনুমোদনহীন freeze frame, black frame বা silence padding দেবে না।

## ৯. Word timing table

চূড়ান্ত তালিকায় অন্তত থাকবে:

| Field | বিবরণ |
|---|---|
| Scene | দৃশ্যের ID |
| Dialogue ID | Semantic utterance-এর ID, mechanical SRT cue ID নয় |
| Word index | উচ্চারণের ক্রম |
| Exact word | সোর্সের শব্দ |
| Start | সেকেন্ডে, মিলিসেকেন্ড নির্ভুলতা |
| End | সেকেন্ডে |
| Render frame | প্রথম প্রাসঙ্গিক frame |
| Method | acoustic, forced alignment, manual, estimated |
| Confidence | high, medium, low বা numeric |
| Caption cue | কোন cue-তে আছে |
| Note | pause, overlap বা uncertainty |

## ১০. Timing QA

- Caption-এর active word শোনার শব্দের সঙ্গে মিলছে কি?
- কোনো scene change কি শব্দের মাঝখানে কষ্ট দিচ্ছে?
- কোনো headline কি বলার পরে আসছে?
- কোনো ছোট pause-এ কি অতিরিক্ত transition চাপানো হয়েছে?
- শেষ frame পর্যন্ত কি অননুমোদিত কালো পর্দা এসেছে?
- Original audio decode এবং final audio-এর মধ্যে duration ও সময় অক্ষুণ্ণ আছে কি?
- Rendered event-এর frame error কি এক frame-এর মধ্যে?
- প্রতিটি dialogue-এর unique SVG কি তার actual start-এর আগে বা সঙ্গে এসেছে এবং map-এর nonoverlapping timing-এর সঙ্গে মেলে?
