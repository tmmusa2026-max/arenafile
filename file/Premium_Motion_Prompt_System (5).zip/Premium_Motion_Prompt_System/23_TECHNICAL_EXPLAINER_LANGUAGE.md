# 23. Technical Explainer Language

## উদ্দেশ্য

Technical explainer-এ কথা, keyword text এবং dialogue-specific SVG যেন একই semantic timeline-এ ধাপে ধাপে তৈরি হয়। দর্শক যেন শুধু সুন্দর আইকন নয়, বক্তব্যের সম্পর্ক, কারণ ও ফল বুঝতে পারে।

এই module-এ reusable কৌশল আছে, কোনো reference frame, copied composition, downloaded logo বা imitation template নেই। প্রতিটি project-এর মূল SVG ও layout নতুনভাবে তৈরি করতে হবে এবং `22_DIALOGUE_SPECIFIC_SVG_SYSTEM.md`-এর uniqueness contract মানতে হবে।

## ১. Reference থেকে কৌশল নেওয়ার সীমা

Reference দিলে নিচের বিষয়গুলো বিশ্লেষণ করা যায়:

- Text কোন speech beat-এ আসছে
- একটি graphic-এর ভেতরে কোন layer কখন যোগ হচ্ছে
- প্রশ্ন, তুলনা, সমস্যা ও সমাধানের composition কীভাবে বদলাচ্ছে
- Chapter label, progress indication ও branding কোথায় আছে
- কোন অংশ subtitle এবং কোন অংশ editorial keyword treatment

Reference-এর exact layout, path geometry, logo, watermark, font spacing বা frame sequence কপি করবে না। Observed duration-কে fixed preset বানাবে না। নতুন project-এর actual audio ও source text-ই timing ও content নির্ধারণ করবে।

## ২. Subtitle এবং keyword echo আলাদা layer

কোনো ভিডিওতে বড় keyword text দেখা মানেই সেটি conventional subtitle নয়। দুটি layer-এর কাজ আলাদা:

| Layer | Content | সাধারণ অবস্থান | Timing | কাজ |
|---|---|---|---|---|
| Verbatim subtitle | অনুমোদিত spoken words | Bottom center | প্রতিটি shaped word | পূর্ণ বক্তব্য পড়া |
| Semantic keyword echo | Source-এর নির্বাচিত word বা phrase | Composition-এর ভেতরে | Speech phrase বা semantic beat | মূল অর্থ ও hierarchy বোঝানো |

- Caption চালু থাকলে keyword echo সেটির বিকল্প নয়।
- Keyword echo-তে নতুন fact, claim, number, name বা phrasing যোগ করা যাবে না।
- Source-এর exact phrase নির্বাচন করো। সংক্ষেপণের অর্থ বদলে গেলে echo বাদ দাও।
- দুটি layer একই অর্থ দিলেও আকার, অবস্থান ও emphasis hierarchy আলাদা রাখো।
- Keyword echo না থাকলে bottom subtitle-এর প্রয়োজনীয়তা বা timing বদলাবে না।

## ৩. Progressive keyword reveal

একটি বাক্যের বড় keyword treatment এই ক্রমে আসতে পারে:

1. সম্পূর্ণ phrase আগে shape ও measure করো।
2. সব phrase-এর final position আগে reserve করো।
3. প্রথম phrase তার actual speech onset-এর কাছে reveal করো।
4. পরের phrase এলে আগের phrase-এর অবস্থান, baseline ও shaping অপরিবর্তিত রাখো।
5. নির্বাচিত phrase-এর accent color reveal-এর পরে দাও।
6. Sentence শেষে সম্পূর্ণ keyword group-এর readable hold রাখো।
7. পরের dialogue-এর নতুন SVG বা composition-এর সঙ্গে group exit করো।

Animation unit হবে whole shaped phrase বা word। Bengali অক্ষর, যুক্তাক্ষর, কার, রেফ, ফলা বা vowel mark আলাদা করবে না। প্রতিটি নতুন phrase যোগ হলে line কেন্দ্র থেকে লাফাবে না।

Default timing utility `validation/src/explainer-timing.js` ব্যবহার করো:

```text
reveal_start = max(dialogue_start, phrase_start - pre_speech_reveal)
reveal_end = phrase_start
emphasis_start = min(phrase_start + one_frame, phrase_midpoint)
```

দ্রুত speech-এ lead time কমাও। Fixed stagger দিয়ে phrase-কে speech-এর পরে ঠেলে দেবে না। Estimated timing ব্যবহার করলে তা report-এ `estimated` লিখো এবং acoustic alignment বলে দাবি করবে না।

## ৪. Staged dialogue SVG build

একটি dialogue-এর primary SVG এক frame-এ সম্পূর্ণ হওয়া বাধ্যতামূলক নয়। অর্থের সঙ্গে layer যোগ করো:

| Beat | Visual কাজ | Speech alignment |
|---|---|---|
| Base | Frame, workspace বা context প্রস্তুত করে | Dialogue শুরুর আগে বা প্রথম phrase-এ |
| Subject | মূল device, file, person, node বা object আসে | Subject উচ্চারিত হওয়ার আগে বা সঙ্গে |
| Relationship | Connector, comparison, code path বা data flow যোগ হয় | সম্পর্ক বা প্রক্রিয়ার phrase-এ |
| Result | Success, error, resolution বা state change দেখায় | ফলের phrase-এ, আগে ফল উল্টে দেওয়া নয় |

ছোট dialogue-এ base ও subject একত্র হতে পারে। দীর্ঘ dialogue-এ relationship-এর একাধিক meaningful state থাকতে পারে। Layer যোগ করার সময় আগের semantic object স্থির রাখো, কেবল নতুন অর্থ প্রকাশ করো। শুধু opacity, color বা scale বদলে পরের dialogue-এর নতুন SVG বানানো যাবে না।

প্রতিটি beat-এর `start`, `source_phrase`, `visual_change` ও `purpose` scene plan-এ লিখো। Decorative delay-এর জন্য কথার গুরুত্বপূর্ণ visual পরে আনবে না।

## ৫. Technical composition directions

নিচের directions reusable semantic starting point, finished template নয়:

| ID | Dialogue need | Original geometry direction | Motion direction |
|---|---|---|---|
| E01 | Keyword hierarchy | Pre-shaped phrase group এবং reserved emphasis zone | Stable phrase additions |
| E02 | Playback বা browser state | Original browser frame, media aperture ও state indicator | Screen reveal, play state, restrained status settle |
| E03 | Device বা platform comparison | ভিন্ন device silhouette বা asymmetric dual viewport | Matched entry, separate outcome |
| E04 | Container বা codec anatomy | Custom enclosure, media track ও compression geometry | Open enclosure, track reveal, relationship draw |
| E05 | API conversation | দুটি আলাদা endpoint, request bubble ও response structure | Request travel, response resolve, error state |
| E06 | Frontend ও backend flow | Interface frame, service node ও directional topology | Sequential connection, signal handoff |
| E07 | Code থেকে interface | Original code window এবং linked output geometry | Approved line reveal, connector, output handoff |
| E08 | Terminal থেকে result | Command line, execution path ও result panel | Whole-line reveal, execution settle, result proof |
| E09 | Error থেকে resolution | Broken path বা restricted state এবং নতুন resolved geometry | Isolate cause, repair path, stable outcome |
| E10 | Data cleanup বা transformation | Source field, filtering geometry ও clean output structure | Selective extraction, clutter reduction, output reveal |

প্রতিটি dialogue-এর জন্য আলাদা source SVG, unique visual signature ও meaningful difference বাধ্যতামূলক। একই E-ID দুবার ব্যবহার হলেও geometry এবং composition নতুন হতে হবে। `V29` থেকে `V34` vector directions এবং `libraries/explainer-recipes.json` সহায়ক registry।

Code, command, API response বা data text শুধু approved source থেকে নেওয়া যাবে। পাঠযোগ্যতার জন্য nonessential code কমানো যায়, কিন্তু সেটিকে বদলে নতুন technical claim তৈরি করা যাবে না।

## ৬. Chapter pill

ছোট top-right chapter pill technical explainer-এর জন্য optional:

- Position: responsive safe area-এর ভেতরে `top_right`
- Text: source-supported সংক্ষিপ্ত topic label
- দৈর্ঘ্য: সাধারণত 42 অক্ষরের মধ্যে, optical fit অনুযায়ী কম
- Visual: ছোট dot বা marker থাকতে পারে, কিন্তু bottom subtitle-এ leading marker নয়
- Timing: chapter বা semantic topic বদলালে বদলাও, প্রতি word-এ নয়
- Content: নতুন claim, version, number বা feature নয়
- Collision: watermark, platform UI, headline এবং subtitle থেকে আলাদা zone

Chapter pill না থাকলে narrative ক্ষতি হয় না। প্রতিটি scene-এ pill বসানো বাধ্যতামূলক নয়।

## ৭. Actual timeline progress rail

পাতলা bottom progress rail ব্যবহার করলে সেটি সত্যিকারের global timeline দেখাবে:

```text
progress = clamp(current_time / actual_duration, 0, 1)
rail_width = available_width * progress
```

- Value source: final audio-driven actual duration এবং current render time
- Scene-only progress-কে full-video progress হিসেবে দেখাবেন না
- Fake loading, decorative random fill বা looping animation নয়
- Frame synchronization: progress calculation subframe time থেকে, motion blur থাকলে একই sample time ব্যবহার
- Default height: 1080 pixel frame-এ 4 pixel, responsive minimum 2 ও maximum 8 pixel
- Bottom subtitle-এর safe area ও readable background আলাদা রাখো
- Vertical platform-এ UI ঢাকলে rail সরাও বা বাদ দাও
- Rail-এর অর্থ loading নয়, playback position

`timelineProgress` utility clamped deterministic value দেয়। Invalid বা zero duration reject করে। Final encoded proof-এ beginning, middle ও end-এর measured fill পরীক্ষা করো।

## ৮. Authorized watermark slot

Watermark বা brand mark ব্যবহারের আগে original PNG বা SVG এবং usage permission দরকার। Permission অস্পষ্ট থাকলে asset import, crop, extraction, redraw বা trace করবে না।

Reference-এ upper-left mark দেখা গেলে শুধু behavior বিশ্লেষণ করো। Authorized project-এর starting placement হিসেবে:

- Position: `top_left`, safe area-এর ভেতরে
- Horizontal inset: frame width-এর প্রায় 2.5 থেকে 4 শতাংশ
- Vertical inset: frame height-এর প্রায় 4 থেকে 6 শতাংশ
- Width: frame width-এর প্রায় 9 থেকে 12 শতাংশ, original aspect ratio অক্ষুণ্ণ
- Behavior: content scene-এ স্থির, intro বা outro-তে brand system অনুযায়ী আলাদা treatment
- Opacity: default 1, readability ও brand guideline ব্যতীত random fade নয়
- Collision: chapter pill, central graphic, subtitle এবং platform UI থেকে আলাদা

এই সংখ্যাগুলো observed starting range, কোনো third-party brand specification নয়। নিজের authorized asset-এর optical bounds দেখে fit করো। Default config-এ watermark disabled এবং `permission_status: required` থাকবে। `verified` permission ও safe local asset path ছাড়া validation pass পাবে না।

Watermark মুছে ফেলা, অন্য ভিডিও থেকে তোলা বা আধাস্বচ্ছ করে লুকানো অনুমোদিত নয়। Media policy-এর `watermark_removed: false` contract অপরিবর্তিত থাকবে।

## ৯. Dark technical canvas

Dark technical explainer-এর জন্য reusable direction:

- Low-frequency background glow, খুব সীমিত texture এবং পর্যাপ্ত negative space
- Primary text-এর contrast কমপক্ষে 4.5:1
- Accent color source emphasis, state ও connector-এ সীমিত
- Background code, bracket বা interface motif low opacity-তে, কথার সঙ্গে সম্পর্ক থাকলে
- একই scene-এ বড় headline, subtitle, chapter pill, watermark এবং decorative texture সবকিছু প্রতিযোগিতা করবে না
- Error red শুধু source-supported error বা warning-এ
- Glow ও blur দিয়ে illegible geometry ঢাকবে না

Reference-এর palette হুবহু নেওয়ার বদলে active brief-এর approved colors ব্যবহার করো। Dark canvas সব genre-এর default নয়।

## ১০. Configuration ও implementation

- Style config: `project/explainer-style.json`
- Schema: `schemas/explainer-style.schema.json`
- Recipe registry: `libraries/explainer-recipes.json`
- Timing ও policy utility: `validation/src/explainer-timing.js`
- Regression suite: `validation/tests/explainer.test.js`

`project.json`-এর style বা constraints-এ এই config-এর path লিখতে পারো। Technical explainer route ছাড়া অন্য genre-এ সব layer জোর করে প্রয়োগ করবে না।

## ১১. Explainer QA

- Keyword echo এবং verbatim subtitle কি আলাদা layer হিসেবে পরিচিত?
- Keyword echo কি source-এর exact phrase এবং actual timing ব্যবহার করছে?
- Phrase যোগ হলে আগের text কি স্থির থাকে?
- Accent কি phrase reveal-এর পরে আসে?
- প্রতিটি dialogue-এর SVG কি নতুন geometry বা generator এবং composition বা motion বদলায়?
- Base, subject, relationship ও result layer কি সঠিক speech beat-এ আসে?
- Code, command, API label ও technical claim কি source-supported?
- Chapter pill কি সংক্ষিপ্ত, safe এবং watermark থেকে আলাদা?
- Progress rail কি actual global duration-এর সঙ্গে মেলে এবং fake loading নয়?
- Watermark-এর original asset ও verified permission আছে কি? Permission না থাকলে import বাদ আছে কি?
- Bottom subtitle, keyword echo, chapter pill ও watermark-এর collision নেই কি?
- Beginning, middle ও end proof এবং encoded playback review করা হয়েছে কি?
- সব visible text, metadata, source file ও filename-এ U+2014 নেই কি?
