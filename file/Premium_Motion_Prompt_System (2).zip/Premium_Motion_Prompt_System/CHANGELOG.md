# Changelog

## 2.2.0

### Added

- Bengali two-file intake for voice-over and SRT
- Autonomous scene, SVG, animation and media selection after intake
- Rights-verified web photo and short video clip workflow
- News and documentary safeguards for archival and illustrative media
- Media manifest schema and reusable sourcing policy
- Exact executed command log requirements
- Public delivery report schema and hosting capability fallback
- Native HTML video preview template with relative MP4 and ZIP paths
- Public preview, direct MP4 and delivery ZIP verification rules
- QA checks for media provenance, honest links and playback evidence

### Changed

- Master and compact prompts now start with the two-file Bengali workflow
- Router now loads media research and public delivery modules when needed
- Output contract now requires media provenance and actual command logs
- Public upload and playback claims require evidence, never fabricated URLs

## 2.1.0

### Changed

- Removed the reference MP4 and every rendered visual proof asset
- Removed the reference scene renderer, scene plan, composition, timing map and production report
- Removed all machine-readable examples copied from that reference
- Reframed the package as a reference-free prompt and validation toolkit
- Kept reusable motion, typography, SVG, effects, sound, QA and Node delivery guidance
- Kept generic font, audio, responsive, continuity and temporal validation tools
- Added an explicit policy that validation output is not a visual style guide
- Added package checks that forbid reference artifacts and enforce the 25 MB source budget
- Removed the video render, proof and QC commands from this prompt-only package
- Reduced the package to compact documents, libraries, examples and validation assets

### Validation scope

- Font tests cover glyph coverage and shaped ink clipping
- Audio tests cover synthetic envelope alignment only
- Rules tests cover generic responsive and continuity logic
- Temporal test covers a frame-count regression only
- None of these tests is a final video quality claim

## 2.0.0

- Added executable production-system improvements and validation prototypes
- The rendered reference from that iteration has been intentionally removed in 2.1.0

## 1.0.0

- Initial adaptive prompt system
- Motion, typography, SVG, effects, sound, render and QA libraries
- Political, product promo and documentary prose examples
