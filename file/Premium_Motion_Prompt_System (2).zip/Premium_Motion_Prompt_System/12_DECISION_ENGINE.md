# 12. Adaptive Decision Engine

## উদ্দেশ্য

এই মডিউল AI-কে সাহায্য করবে সিদ্ধান্ত নিতে কোন ভিডিওতে কোন SVG, text animation, transition, camera move, effect ও sound লাগবে। এটি effect-এর তালিকা থেকে random নির্বাচন করবে না। প্রথমে visual problem লিখবে, তারপর সমাধান নির্বাচন করবে।

## ১. Input feature map

প্রতিটি scene-এর জন্য নিচের মান বের করো:

```text
narrative_role: hook, context, thesis, evidence, demo, contrast, turn, peak, resolve, cta
emotion: grave, warm, hopeful, urgent, confident, curious, calm, celebratory
energy: 0 থেকে 1
information_density: 0 থেকে 1
text_density: 0 থেকে 1
scene_duration: seconds
speech_confidence: high, medium, low
primary_content: word, phrase, product, process, data, footage, person, place, abstract
spatial_need: flat, layered, 2.5D, full_3D
aspect_ratio: wide, vertical, square, other
brand_constraints: list
restricted_elements: list
required_elements: list
previous_motif: asset বা null
next_motif: asset বা null
```

অনুমান করে emotional বা narrative মান নিলে সেটি script-এর প্রমাণ থেকে লিখো।

## ২. প্রথমে visual problem লিখো

ভালো:

- `দীর্ঘ মূল শব্দটি 1.2 সেকেন্ডের মধ্যে পড়া এবং মনে রাখা দরকার।`
- `আগের দৃশ্যের ক্ষয়ের ধারণা পরের দৃশ্যের সময়রেখায় রূপ নেবে।`
- `পণ্যের একটি নির্দিষ্ট অংশে মনোযোগ দরকার, পুরো UI একসঙ্গে নয়।`
- `শেষ বাক্যের মর্যাদা বজায় রেখে আগের উষ্ণ motif স্থির করতে হবে।`

খারাপ:

- `এখানে cool particle effect দরকার।`
- `এই scene-এ glitch দিলে premium লাগবে।`
- `সব scene-এ একই template ব্যবহার করব।`

## ৩. Candidate generation

প্রতি scene-এর জন্য 2 থেকে 3টি candidate stack তৈরি করো। Stack-এ থাকবে:

- 1 primary text বা object recipe
- 0 থেকে 1 SVG generator, প্রয়োজনে বেশি কিন্তু justification সহ
- 1 primary motion curve family
- 0 থেকে 1 camera recipe
- 0 থেকে 2 supporting effects
- 1 transition in বা out
- 0 থেকে 1 sound accent

প্রথম candidate সরলতম উপযুক্ত সমাধান হবে। অন্য candidate গভীরতা বা ভিন্ন metaphor দেবে, শুধু বেশি effect নয়।

## ৪. Scoring

প্রতিটি candidate-কে 0 থেকে 1 মান দাও:

```text
score = 0.28 * narrative_fit
      + 0.18 * readability
      + 0.14 * timing_fit
      + 0.12 * emotional_fit
      + 0.10 * brand_fit
      + 0.08 * continuity
      + 0.06 * technical_feasibility
      + 0.04 * originality
      - complexity_penalty
      - constraint_penalty
```

- `complexity_penalty`: অপ্রয়োজনীয় layer, simultaneous focal point, অতিরিক্ত motion
- `constraint_penalty`: shaping, palette, audio, license, runtime বা user rule ভঙ্গ
- কোনো hard constraint ভঙ্গ করলে candidate বাতিল, score দিয়ে ঠিক করা যাবে না
- Tie হলে সরল candidate জিতবে
- Originality মানে অদ্ভুত effect নয়, content-specific composition ও handoff

## ৫. Text recipe নির্বাচন

| শর্ত | নির্বাচন | বাদ দাও |
|---|---|---|
| Grave, শেষ বাক্য | T07, T20 | Back Out, glitch, chromatic spike |
| Warm, reflective | T06, T03 | Hard stamp, slice |
| Strong thesis | T01, T02 | অতিরিক্ত ambient drift |
| Editorial line | T17, T05 | Per-word dance |
| Memory decay | T08, T04 | Confetti-like particles |
| Product feature | T15, T10 | Heavy DOF on UI |
| Contrast | T12, matched composition | Random word replacement |
| Data, source approved | T18 | Fake count-up |
| Caption | T13 | Character stagger |

দুই পরপর scene-এ একই primary recipe হলে অন্তত composition, mask direction, scale বা supporting motif অর্থপূর্ণভাবে বদলাও। শুধু রং বদলালে নতুন scene design হয় না।

## ৬. SVG generator নির্বাচন

| Semantic need | Primary generator | Motion operator |
|---|---|---|
| সময় বা ইতিহাস | V03 Timeline | Trim Paths + Repeater |
| স্মৃতি বা resonance | V04 Rings বা V05 Orb | Sine breathing + gradient |
| সংযোগ | V07 Nodes বা V09 Convergence | Merge Paths + signal travel |
| প্রক্রিয়া | V08 Flow Path | Trim Paths + leading dot |
| পণ্য | V11 UI Card বা V12 Device | Masked assembly + callout |
| Feature detail | V13 Callout | Path draw + T15 |
| তুলনা | V14 Split | Match cut + shared divider |
| Source data | V15, V16, V17 | Accurate scale + reveal |
| Audio | V18 Waveform | Actual amplitude mapping |
| ক্ষয় | V19 Text Particles | Alpha sampling + DOF |
| জটিলতা | V21 Contours | Coherent displacement |
| Transition | V26 Mask Ribbon | Track matte + path travel |
| Precision | V27 Calibration | Grid settle |
| Abstract জনসমষ্টি | V28 Human Scale | Gather + negative space |

কোনো generator-এর semantic need না থাকলে decorative background হিসেবেও সীমিত opacity-তে কারণ লিখতে হবে। একাধিক generator একই কাজ করলে একটি বেছে নাও।

## ৬ক. SVG বনাম web media

| Scene evidence ও প্রয়োজন | নির্বাচন | বাদ দাও |
|---|---|---|
| Real event, place, person, news context | Rights-verified relevant photo বা short clip | unrelated atmospheric footage |
| Abstract relation, process, emotion | মৌলিক SVG ও typography | অর্থহীন stock montage |
| Approved data | Source-driven SVG chart | অনুমোদনহীন number বা label |
| Product detail | Approved product asset বা original vector | ভুল model বা generic product |
| Archival memory | Verified archival media বা স্পষ্ট abstract treatment | অন্য ঘটনার footage |
| Relevant verified media নেই | Original SVG fallback | unlicensed বা misleading media |

প্রতিটি external asset-এর source, creator, license, attribution, editorial relevance ও local file লিখো। Generic বা archival media-কে actual event footage হিসেবে উপস্থাপন করবে না। Web access না থাকলে media সংগ্রহের দাবি নয়। পূর্ণ policy `20_AUTONOMOUS_MEDIA_AND_PUBLIC_DELIVERY.md`-এ আছে।

## ৭. Effect নির্বাচন

Effect-এর নাম থেকে নয়, প্রয়োজনীয় ফল থেকে শুরু করো:

| প্রয়োজনীয় ফল | Primary effect | Supporting |
|---|---|---|
| নিচ থেকে শব্দ উঠছে | Mask + transform | Blur, scale |
| Text-এর ভেতরে আলো | Track matte + light sweep | Thresholded glow |
| Depth | Camera + parallax | DOF |
| দূরে সরে যাওয়া particles | Particle depth + lens blur | Opacity fade |
| পুরোনো তথ্য মুছে নতুন তথ্য | Word morph + matte | Focus handoff |
| Documentary surface | Fine grain + warm grade | Vignette |
| দ্রুত stamp | Expo Out + motion blur | Micro chromatic pulse |
| Organic motion | Mesh বা displacement | Coherent noise |
| Screen integration | Corner pin + tracking | Light match, grain match |
| Path আঁকা | Trim Paths equivalent | Leading dot |

প্রতিটি supporting effect-এর আলাদা কাজ লিখো। একই কাজ দুই effect করলে একটি বাদ দাও।

## ৮. Transition নির্বাচন

নিচের প্রশ্নের উত্তর দাও:

1. আগের scene-এর কোন element সবচেয়ে বেশি অর্থ ধরে রেখেছে?
2. পরের scene-এর কোন element সেই অর্থ এগিয়ে নিতে পারে?
3. দুটির shared geometry, color, motion direction বা depth আছে কি?
4. Natural pause কত বড়?
5. Transition-এর সময় caption কি স্থির থাকবে নাকি scene-এর সঙ্গে বদলাবে?

উত্তর না থাকলে intentional cut বিবেচনা করো। Handoff তৈরি করতে কৃত্রিম particle বা zoom যোগ করবে না।

## ৯. Camera নির্বাচন

- Typography only: C01 Quiet Push বা কোনো camera move নয়
- Editorial hierarchy change: C02 Reframe
- Product depth: C03 Depth Reveal বা C06 Orbit
- Memory: C05 Focus Transfer
- Documentary realism: খুব সামান্য C04, source মিললে
- Vertical small screen: কম travel, কম DOF, বড় focal subject
- Motion sensitivity: drift ও orbit বাদ বা reduced-motion version

## ১০. Sound নির্বাচন

| Visual event | Sound | শর্ত |
|---|---|---|
| Hero stamp | S02 | Voice mask নয়, brief অনুমোদন |
| Small annotation | S01 | সব item-এ নয় |
| Quiet final resolve | S03 | Brief tonal sound অনুমোদন করলে |
| Editorial frame | S04 | Material metaphor মিললে |
| UI confirmation | S05 | Actual UI state change |
| Caption word | সাধারণত কোনো sound নয় | Voice clarity অগ্রাধিকার |
| Particle drift | সাধারণত কোনো sound নয় | Whoosh default নয় |

## ১১. Genre adaptation

### রাজনৈতিক

- প্রথমে dignity, clarity ও factual accuracy
- Abstract geometry, typography, controlled rhythm
- Required symbol বা portrait কেবল অনুমোদিত asset
- Red, glitch, shake ও aggressive sound সীমিত ও উদ্দেশ্যপূর্ণ
- Reuse: thesis, quote, timeline, resolve recipes

### Product promo

- প্রথমে product comprehension ও hierarchy
- Vector UI, feature callout, camera push, layer separation
- প্রতিটি feature-এর readable hold
- UI-এর fake functionality নয়
- Reuse: demo, annotation, comparison, CTA recipes

### Documentary

- প্রথমে source, atmosphere ও editorial trust
- Timeline, archival frame, focus handoff, fine grain
- অনুমোদনহীন date, map, archive texture বা soundscape নয়
- Reuse: context, evidence, quote, reflection recipes

### Explainer

- প্রথমে sequence ও causality
- Flow paths, nodes, progressive annotation
- একই সময়ে একটির বেশি নতুন ধারণা নয়
- Reuse: path continuation, list cascade, match morph

### Celebratory বা launch

- Energy বাড়ানো যায়, কিন্তু brand ও audience মিলতে হবে
- Back Out, brighter accent, particle release অনুমোদিত হতে পারে
- Voice ও product information তবুও অগ্রাধিকার

## ১২. Complexity controller

Global `energy` বাড়ালে সব parameter একসঙ্গে বাড়াবে না।

| Energy | Duration | Amplitude | Stagger | Overshoot | Ambient |
|---|---|---|---|---|---|
| Low, 0 থেকে 0.3 | একটু দীর্ঘ | কম | কম element | প্রায় নেই | খুব সূক্ষ্ম |
| Medium, 0.3 থেকে 0.7 | মাঝারি | নিয়ন্ত্রিত | decreasing | ছোট, ঐচ্ছিক | সূক্ষ্ম |
| High, 0.7 থেকে 1 | ছোট কিন্তু readable | বড় হতে পারে | বেশি element হলে | সীমিত | তবুও hierarchy-safe |

Information density বেশি হলে energy বাড়ালেও simultaneous motion কমাও। Scene duration ছোট হলে recipe-এর layer সংখ্যা কমাও, গতি অতিরিক্ত তাড়াহুড়ো নয়।

## ১৩. Conflict resolution

- Caption বনাম headline: মূল শব্দ বলার সময় headline, বাকি সময় caption-এর readability অগ্রাধিকার।
- Brand color বনাম emotional color: brand hard constraint আগে, emotion আলো ও motion দিয়ে আনো।
- Duration বনাম readability: effect কমাও, text কেটে নতুন বাক্য বানাবে না।
- DOF বনাম text: text sharp রাখো।
- Particle বনাম exact shape: text-derived sampling ও lower turbulence।
- Exact audio বনাম longer transition: transition ছোট করো, audio বদলাবে না।
- Vertical layout বনাম wide composition: আলাদা layout, center crop নয়।
- Plugin look বনাম Node runtime: equivalent implementation, না পারলে সত্যি জানিয়ে ভিন্ন creative route।
- User required effect বনাম tone conflict: কারণ জানিয়ে restrained সংস্করণ প্রস্তাব করো।

## ১৪. Scene blueprint output

নির্বাচনের পরে প্রতি scene-এর জন্য এই JSON-সদৃশ পরিকল্পনা দাও:

```text
scene_id
source_range
narrative_role
visual_problem
focal_content
composition
text_recipe
svg_generators
primary_curve
secondary_curve
camera_recipe
effects
transition_in
transition_out
sound_event
duration
stagger
rejected_candidate
constraint_notes
proof_frames
reuse_note
```

`schemas/scene-plan.schema.json`-এর সঙ্গে সামঞ্জস্য রাখো।

## ১৫. Final selection test

নির্বাচিত stack-এর প্রতিটি অংশ সরিয়ে ভাবো:

- এটি সরালে কি তথ্য, আবেগ, depth বা continuity হারায়?
- না হারালে এটি কেবল decoration, সরিয়ে দেওয়া যায় কি?
- Decoration রাখলে সেটি কি সত্যিই premium surface যোগ করে, নাকি distraction?
- একই কাজ আরও সরলভাবে করা যায় কি?
- এই scene-এর সিদ্ধান্ত কি আগের scene থেকে অর্থপূর্ণভাবে বেড়েছে?

এই পরীক্ষার পরেই implementation শুরু করো।
