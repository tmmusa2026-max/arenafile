# 11. Node.js Render Pipeline

## ১. Delivery লক্ষ্য

Brief-এ Node-only delivery নির্বাচন করলে ব্যবহারকারীর পিসিতে fresh checkout-এর পরে এই দুটি command যথেষ্ট হওয়া উচিত:

```bash
npm install
npm run render
```

System FFmpeg, system Python, manually installed font, global npm CLI বা আলাদা After Effects installation-এর ওপর নির্ভর করা যাবে না। Development machine-এর absolute path hardcode করা যাবে না।

## ২. Allowed architecture

Node.js ভিত্তিক নিচের ধরনের pipeline নির্বাচন করা যায়:

- Node scene graph + native vector rasterizer
- Node scene graph + Skia-equivalent native binding with prebuilt binaries
- Node + GPU command renderer, platform support verified হলে
- Node-generated vector geometry + native raster compositing
- WASM বা prebuilt native HarfBuzz-equivalent text shaping
- npm package থেকে আসা bundled FFmpeg ও ffprobe executable

Brief-এ HTML canvas নিষিদ্ধ থাকলে browser canvas, HTML canvas screenshot বা canvas-dependent renderer ব্যবহার করা যাবে না। SVG source তৈরি করা যায়, কিন্তু তার text shaping ও rasterization নিচের নিয়ম মানতে হবে।

## ৩. Dependency rules

- FFmpeg `ffmpeg-static`, `@ffmpeg-installer/ffmpeg` বা সমতুল্য npm package থেকে আসতে পারে।
- ffprobe প্রয়োজন হলে `@ffprobe-installer/ffprobe` বা সমতুল্য bundled solution।
- Native npm dependency-এর prebuilt binary থাকতে হবে, যাতে ব্যবহারকারীর Python, compiler বা node-gyp toolchain লাগে না।
- কোনো package install-এর সময় undocumented global tool চাইলে সেটি গ্রহণযোগ্য নয়।
- Package version lock করো এবং lockfile দাও।
- Platform-specific package হলে Windows, macOS বা Linux target ব্রিফে স্পষ্ট করো।
- Offline install দরকার হলে আলাদা offline cache বা bundled artifact প্রয়োজন, সেটি অনুমান করবে না।
- Font ও license package-এর ভেতরে রাখো।

## ৪. Recommended project structure

```text
project-root/
  package.json
  package-lock.json
  src/
    render.js
    timeline.js
    scene-graph.js
    text/
      shape.js
      layout.js
    motion/
      easings.js
      springs.js
      sampling.js
    vector/
      paths.js
      generators.js
    effects/
      blur.js
      bloom.js
      particles.js
      grade.js
    audio/
      analyze.js
      synthesize.js
    scenes/
  assets/
    audio/
    fonts/
    images/
    data/
  config/
    project.json
    scene-plan.json
    word-timing.json
  scripts/
    qc.js
  output/
  proof/
```

এটি উদাহরণ, বাধ্যতামূলক folder নাম নয়। গুরুত্বপূর্ণ বিষয় হলো content, design tokens, scene plan ও render logic আলাদা থাকবে।

## ৫. Text shaping pipeline

1. Font file local path থেকে load করো।
2. Unicode normalization প্রয়োজন অনুযায়ী করো, source text-এর অর্থ বা spelling বদলাবে না।
3. Language ও script সঠিকভাবে নির্দেশ করো।
4. HarfBuzz-equivalent shaping দিয়ে glyph ID, advance, offset ও cluster পাও।
5. Word, phrase বা line-এর shaped run cache করো।
6. Glyph path বা glyph raster বানাও।
7. Ink bounds ও logical bounds আলাদা রাখো।
8. Mask, gradient, glow ও motion পুরো run-এ প্রয়োগ করো।
9. Word-level color বা scale দরকার হলে সম্পূর্ণ shaped word cache ব্যবহার করো।
10. Proof snapshot দিয়ে যুক্তাক্ষর, কার, রেফ ও ফলা যাচাই করো।

SVG renderer-এর `<text>` ব্যবহার করলে তার shaping সত্যিকারের HarfBuzz-equivalent কি না যাচাই করতে হবে। না হলে text আগে shaped glyph paths-এ রূপান্তর করো। Shaped path-এর পরেও logical text আলাদা metadata-তে রাখো, যাতে QA ও caption matching করা যায়।

## ৬. Scene graph

প্রতিটি node-এর জন্য:

```text
id
type
parent
local_transform
world_transform
anchor
opacity
blend_mode
matte
effects
start_time
end_time
motion_recipe
depth
motion_blur_policy
```

- Parent transform deterministic hierarchy-তে evaluate হবে।
- Anchor point pixel বা normalized coordinate-এ স্পষ্ট থাকবে।
- Matte ও effects-এর order documented থাকবে।
- Blur, glow ও distortion-এর জন্য expanded offscreen bounds হিসাব হবে।
- Offscreen buffer-এর resolution output ও effect radius অনুযায়ী যথেষ্ট হবে।

## ৭. Time model

- Master time seconds বা rational tick-এ থাকবে।
- Audio duration থেকে target timeline duration নেওয়া হবে, brief-এ অন্য নির্দেশ না থাকলে।
- Animation function arbitrary time `t`-এর মান দিতে পারবে, শুধু integer frame-এর ওপর নির্ভর করবে না।
- প্রতি output frame-এর shutter interval হিসাব হবে।
- কমপক্ষে 8 sub-sample `t + shutter_offset` থেকে আসবে।
- প্রতি sub-sample-এ transforms, paths, particles, camera ও opacity evaluate হবে।
- Text shaping cache reuse করা যায়, কিন্তু animated transform আলাদা হবে।
- Temporal samples accumulate করে 180 degree shutter equivalent motion blur তৈরি হবে।
- দ্রুত গতিতে adaptive sample count বাড়ানো যায়।

## ৮. Sampling example

```text
frame_time = frame_index / fps
shutter_duration = (1 / fps) * (180 / 360)
sample_time(i) = frame_time - shutter_duration / 2 + (i + 0.5) / sample_count * shutter_duration
```

প্রতিটি sample-এর contribution সমান হতে পারে, অথবা documented shutter profile ব্যবহার করা যায়। Timeline-এর শুরু ও শেষের বাইরে sample গেলে scene state deterministic ভাবে clamp বা extend হবে, অপ্রত্যাশিত black frame আসবে না। Native `tmix` এর পরে `trim` ও `fps` ব্যবহার করলে end-of-stream-এ একটি output frame কম হতে পারে। ছোট synthetic regression test দিয়ে frame count যাচাই করো এবং প্রয়োজন হলে documented terminal flush samples দাও, arbitrary freeze padding নয়।

## ৯. Vector ও effect implementation

- Path length, tangent, trim ও point sampling নিজের geometry module-এ রাখো।
- Merge ও offset paths-এর জন্য robust vector Boolean library ব্যবহার করা যায়, prebuilt runtime ছাড়া।
- Gaussian blur separable convolution বা equivalent native filter।
- DOF depth-aware blur।
- Bloom thresholded multi-scale blur।
- Displacement per-pixel বা mesh-based map।
- Particles fixed timestep ও fixed seed।
- Grain final resolution-এ generated noise।
- Grade color matrix, curves বা LUT-equivalent operation।
- Chromatic split channel transform, সীমিত এবং brief-safe।

কোনো effect native renderer-এ না থাকলে frame compositing বা math দিয়ে একই দৃশ্যগত ফল তৈরি করো। ফল ভিন্ন হলে effect map-এ সত্যি লিখো।

## ১০. Encoding

Default starting point:

- Container: MP4
- Video: H.264
- Pixel format: `yuv420p`, widest compatibility
- Profile: High, source ও level compatible হলে
- Quality: visually lossless-এর কাছাকাছি high quality, CRF 15 থেকে 18 starting range অথবা brief-এর high bitrate
- Color: সঠিক Rec.709 metadata, প্রযোজ্য হলে
- Audio: AAC, 192 kbps বা তার বেশি, voice-এর জন্য 256 kbps ভালো starting point
- Fast start: web playback দরকার হলে
- Frame rate: brief অনুযায়ী
- Duration: source target-এর সঙ্গে মিলিয়ে verify

CRF-এর সংখ্যা একাই মানের নিশ্চয়তা নয়। Proof frame ও encoded preview দেখতে হবে। Tiny text, grain, glow এবং particles-এর জন্য bitrate যথেষ্ট কি না পরীক্ষা করো।

মূল audio MP3 হলে AAC encode একটি অনুমোদিত delivery conversion হতে পারে। এতে audio content কাটা, time-stretch বা remix করা যাবে না। Source audio-এর start offset ও duration ঠিক রাখো।

## ১১. Package scripts

প্রস্তাবিত:

```json
{
  "scripts": {
    "render": "node src/render.js",
    "proof": "node src/render.js --proof",
    "qc": "node scripts/qc.js"
  }
}
```

`npm run render` যেন প্রয়োজনীয় analysis, shaping, render ও encode একই ক্রমে চালায় এবং output stream সফলভাবে close হয় নিশ্চিত করে। User-কে আলাদা undocumented command দিতে হবে না। Documented commands হিসেবে proof ও পূর্ণাঙ্গ qc থাকতে পারে।

## ১২. Render cache

- Audio analysis cache: source checksum দিয়ে invalidate
- Font shaping cache: font version, text, size, features দিয়ে key
- Vector cache: generator parameters ও seed দিয়ে key
- Frame cache: global render hash দিয়ে key
- Final render-এর আগে stale cache ব্যবহার হচ্ছে না যাচাই করো
- Cache ব্যর্থ হলে clean rebuild-এর নথিভুক্ত command থাকতে পারে, কিন্তু সাধারণ render-এর জন্য বাধ্যতামূলক নয়

## ১৩. Error handling

নিঃশব্দে fallback নয়। স্পষ্ট error দাও যখন:

- Font load বা glyph missing
- Audio file missing বা decode ব্যর্থ
- FFmpeg binary missing
- SRT parse ব্যর্থ
- Duration mismatch
- Unsupported color বা blend operation
- Output write ব্যর্থ
- Memory limit
- Shaping proof mismatch

ব্যবহারকারীর কাছে error message সংক্ষিপ্ত, actionable এবং file path-সহ হবে।

## ১৪. Reproducibility

চূড়ান্ত ডেলিভারিতে রাখো:

- `project.json`
- `scene-plan.json`
- `word-timing.json`
- easing ও recipe versions
- random seed
- font names ও versions
- dependency lockfile
- render command
- encoder settings
- measured QC report

একই input ও একই config থেকে একই visual output পাওয়ার লক্ষ্য রাখো। GPU floating-point পার্থক্য থাকলে সম্ভাব্য সীমা উল্লেখ করো।

## ১৫. Pipeline QA

- Fresh directory-তে `npm install` ও `npm run render` পরীক্ষা করা হয়েছে কি?
- System PATH-এ FFmpeg না থাকলেও চলে কি?
- Python unavailable হলেও চলে কি?
- Font system-এ installed না থাকলেও সঠিক render হয় কি?
- Output duration, fps, resolution, codec ও audio probe সঠিক কি?
- Proof frames final renderer দিয়েই তৈরি কি?
- Final encoded file আবার decode করে দেখা হয়েছে কি?

## ১৬. Command log ও public playback

প্রতিটি প্রকৃত executed command-এর `command`, working directory, status, exit code ও log path `project/delivery-report.json`-এ রাখো। Planned command-কে executed বলবে না। Install, render, QC, archive এবং publishing command আলাদা ধাপ হলে সবগুলো সংরক্ষণ করো।

Web preview-এর MP4 তৈরির সময়:

- H.264 video ও AAC audio, brief-এ ভিন্ন requirement না থাকলে
- `yuv420p` pixel format, compatibility প্রয়োজন হলে
- MP4 fast start, যাতে metadata download-এর শুরুতেই পাওয়া যায়
- Final file-এর duration, frame count, decode ও audio-video sync যাচাই
- `project/public-preview.template.html`-এর relative `media/final.mp4` path অক্ষুণ্ণ

Public preview, direct MP4 ও delivery ZIP-এর unauthenticated URL verification আলাদা করো। HTTP success মানে actual visual playback দেখা হয়েছে নয়। Playback observation ও URL availability আলাদা fields-এ লিখো।
