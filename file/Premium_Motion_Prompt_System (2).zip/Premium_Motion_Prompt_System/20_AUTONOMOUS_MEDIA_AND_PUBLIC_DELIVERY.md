# 20. Autonomous Media and Public Delivery

## উদ্দেশ্য

ব্যবহারকারী শুধু ভয়েস-ওভার ও SRT দিলেই AI যেন বাংলায় কাজ শুরু করে, actual audio থেকে timing বোঝে, নিজে scene, SVG, animation, প্রয়োজনীয় web media, render ও QA সিদ্ধান্ত নেয়। শেষে প্রকৃত hosting সুবিধা থাকলে playable public preview, direct MP4 এবং সম্পূর্ণ delivery ZIP দেয়।

এই নির্দেশনা কোনো AI-কে অস্তিত্বহীন web, render, upload বা preview capability দাবি করার অনুমতি দেয় না। যা সত্যিকারে সম্পন্ন হয়নি তা `not_completed` বা `not_tested` হিসেবে লিখতে হবে।

## ১. প্রথম Bengali intake

ভয়েস-ওভার ও SRT ইতিমধ্যে না দেওয়া থাকলে প্রথম উত্তর বাংলায় হবে এবং শুধু এই দুটি ফাইল চাইবে:

```text
ভিডিওটি শুরু করতে নিচের দুটি ফাইল দিন:

১. ভয়েস-ওভার ফাইল: WAV, MP3 বা M4A
২. একই ভয়েস-ওভারের SRT ফাইল

ফাইল দুটি পেলে আমি audio timing বিশ্লেষণ করে দৃশ্য, SVG, animation, প্রয়োজনীয় photo বা video clip, render ও QA পরিকল্পনা নিজে তৈরি করব।
```

- একটি ফাইল দেওয়া থাকলে শুধু অনুপস্থিত ফাইল চাও।
- দুটি ফাইলই থাকলে আবার চাইবে না।
- প্রথম উত্তরে effect list, SVG list, storyboard, footage list, render command বা hosting provider চাইবে না।
- দুটি ফাইল পাওয়ার পরে নিরাপদ default দিয়ে কাজ এগিয়ে নাও। শুধু content mismatch, অস্পষ্ট তথ্য, rights, sensitive public release বা প্রকৃত technical blocker-এ সংক্ষিপ্ত Bengali প্রশ্ন করবে।
- ব্যবহারকারী অন্য ভাষায় লিখলেও এই intake ও delivery status বাংলায় দাও, যদি না ব্যবহারকারী স্পষ্টভাবে অন্য ভাষা চান।

## ২. ফাইল পাওয়ার পরে স্বয়ংক্রিয় বিশ্লেষণ

1. Audio decode, channel, sample rate, duration ও start offset পরীক্ষা করো।
2. SRT parse করে cue text, cue timing, spelling ও sequence যাচাই করো।
3. Actual speech envelope, onset, pause ও সম্ভব হলে word-level alignment বের করো।
4. Actual audio-কে final timing-এর ভিত্তি করো। SRT-কে alignment guide হিসেবে ব্যবহার করো।
5. SRT ও spoken content-এর পার্থক্য লিখো। শব্দ, তথ্য বা অর্থ বদলে এমন mismatch হলে নিজে থেকে script সংশোধন করবে না।
6. Audio duration-ই final duration হবে, brief-এ অন্য নির্দেশ না থাকলে।
7. Content-কে semantic scene-এ ভাগ করে প্রতিটি scene-এর উদ্দেশ্য, focal phrase, visual problem ও transition লিখো।

Speech recognition tool থাকলে actual voice-over থেকে transcript তৈরি করে SRT-এর সঙ্গে তুলনা করো। Tool না থাকলে SRT text-কে semantic guide এবং acoustic analysis-কে timing guide হিসেবে ব্যবহার করো, কিন্তু নিজে থেকে transcription সম্পন্ন হয়েছে বলবে না। Aligned text-এর পুরো sentence context থেকে বিষয়, ব্যক্তি, স্থান, ঘটনা, প্রশ্ন, দাবি ও আবেগ বোঝার চেষ্টা করো। শুধু আলাদা keyword দিয়ে scene বা media নির্বাচন করবে না।

## ৩. AI নিজে যা সিদ্ধান্ত নেবে

- Scene সংখ্যা ও তাদের narrative role
- Headline, caption ও word-level emphasis
- কোথায় মৌলিক SVG বা shape system দরকার
- কোথায় photo, short video clip বা approved user asset দরকার
- Text animation, camera, transition, compositing ও effect selection
- Color, typography, spacing, motion blur ও responsive layout
- Sound accent, শুধু brief ও voice-first policy অনুসারে
- Render pipeline, exact commands, proof frames ও QC
- Public preview ও download structure, hosting capability থাকলে

ব্যবহারকারীকে এই নির্বাচনগুলোর তালিকা আলাদা করে দিতে বলবে না। সিদ্ধান্ত ও কারণ project documentation-এ লিখবে।

## ৪. SVG বনাম real media নির্বাচন

| Spoken content বা scene need | প্রথম পছন্দ | কারণ |
|---|---|---|
| Abstract emotion, connection, process, rhythm | মৌলিক SVG ও typography | অর্থ নিয়ন্ত্রণ ও original motion সহজ |
| Approved numeric data | Source-driven SVG chart বা diagram | তথ্য সঠিক ও পাঠযোগ্য রাখা যায় |
| Real event, place, person বা news context | Rights-verified editorial photo বা clip | বাস্তব প্রসঙ্গ প্রয়োজন হতে পারে |
| Product feature | Approved product asset বা মৌলিক product vector | Actual detail ও brand fidelity |
| Historical memory | Verified archival media বা abstract treatment | সময় ও উৎস স্পষ্ট রাখা যায় |
| Generic atmosphere | SVG বা স্পষ্টভাবে illustrative stock | ভুল real-event দাবি এড়ানো যায় |
| Verified media পাওয়া যায়নি | মৌলিক SVG fallback | ভুল বা unlicensed media ব্যবহার প্রয়োজন নেই |

প্রতি scene-এ web media বাধ্যতামূলক নয়। News-like ভিডিওতে real media প্রায়ই উপযোগী, তবে text, data, transition ও abstract explanation-এর জন্য SVG ভালো হতে পারে। ছবি বা clip দিয়ে সব জায়গা ভরাট করবে না।

## ৫. Web media research workflow

Web access ও download tool থাকলে:

1. Scene-এর exact spoken phrase থেকে সংক্ষিপ্ত search query তৈরি করো।
2. প্রথমে user-supplied assets, official source, verified editorial archive বা reusable media library পরীক্ষা করো।
3. প্রতিটি candidate-এর বিষয়, ব্যক্তি, স্থান, সময় ও scene relevance মিলিয়ে দেখো।
4. Asset-level license, permission বা public-domain status যাচাই করো। শুধু website-এর সাধারণ নাম দেখে license অনুমান করবে না।
5. Source page, direct file URL, creator, license URL, attribution, access time ও allowed use সংরক্ষণ করো।
6. অনুমতি না থাকলে asset বাদ দাও। Paywall, login, access control, copyright protection বা download restriction bypass করবে না।
7. Watermark সরাবে না এবং unrestricted streaming rip করবে না।
8. Downloaded file local project assets-এ রাখো। Final render-এর জন্য remote hotlink-এর ওপর নির্ভর করবে না।
9. File decode, dimensions, duration, codec, color orientation ও actual content পরীক্ষা করো।
10. `project/media-manifest.json` পূরণ করো। ব্যবহৃত ও বাদ দেওয়া গুরুত্বপূর্ণ candidate-এর সিদ্ধান্ত লিখো।

Web search snippet-ই sufficient visual evidence নয়। Actual downloaded frame বা clip দেখে relevance যাচাই করতে হবে।

## ৬. News ও documentary safeguard

- Generic footage-কে সেই নির্দিষ্ট ঘটনার actual footage বলে উপস্থাপন করবে না।
- Archival, illustrative বা generic media হলে প্রয়োজন অনুযায়ী on-screen বা documentation label দাও।
- অন্য সময়, স্থান, ব্যক্তি বা ঘটনার media ব্যবহার করে নতুন দাবি তৈরি করবে না।
- Media-তে দেখা text, logo, number, date বা caption source-এ অনুমোদিত না হলে সেটিকে নতুন তথ্য হিসেবে যোগ করবে না।
- AI-generated বা manipulated visual-কে real documentary evidence হিসেবে ব্যবহার করবে না।
- Victim, minor, tragedy বা সংবেদনশীল ব্যক্তির ক্ষেত্রে dignity, privacy ও অপ্রয়োজনীয় graphic content বিবেচনা করো।
- অস্পষ্ট identity বা event match হলে asset বাদ দাও অথবা Bengali-তে নির্দিষ্ট প্রশ্ন করো।

## ৭. Clip ও photo integration

- প্রতিটি clip-এর একটি semantic কাজ থাকবে: context, evidence, location, person, process বা contrast।
- শুধু প্রয়োজনীয় অংশ নাও এবং visual entry actual phrase-এর আগে বা সঙ্গে রাখো।
- কঠিন random montage নয়। Shot length voice cadence, readable hold ও narrative clarity অনুসারে নির্বাচন করো।
- Crop, scale ও reframing subject রক্ষা করে এবং responsive safe area মেনে করো।
- Color, contrast, grain, sharpness ও motion continuity সামঞ্জস্য করো, source-এর গুরুত্বপূর্ণ detail নষ্ট না করে।
- Clip-এর original audio default-ভাবে mute রাখো, ব্যবহার প্রয়োজন ও অনুমতি না থাকলে। Voice-over সবসময় প্রধান থাকবে।
- Photo-তে subtle pan, scale, parallax বা masked reveal ব্যবহার করা যায়, কিন্তু motion-এর কারণ থাকতে হবে।
- Photo বা clip-এর ওপর text দিলে contrast, safe area ও language shaping যাচাই করো।
- কোনো asset দুর্বল হলে আরও effects দিয়ে ঢাকার বদলে ভালো asset বা SVG নির্বাচন করো।

## ৮. Media manifest

প্রতিটি ব্যবহৃত web asset-এর জন্য অন্তত:

```text
asset_id
scene_id
kind
semantic_role
source_page_url
direct_file_url
local_file
creator
license_or_permission
license_url
attribution
accessed_at
news_usage
editorial_relevance
verification_status
allowed_use
watermark_removed
source_audio_used
```

`watermark_removed` সবসময় `false` থাকবে। `verification_status: verified` ছাড়া final scene-এ external media ব্যবহার করবে না। `news_usage` মান হবে `actual_event`, `archival`, `illustrative` বা `not_applicable`।

## ৯. Exact render command log

শুধু generic command লিখে দায়িত্ব শেষ নয়। যে command সত্যিকারে চালানো হয়েছে তার log রাখো:

| Field | Requirement |
|---|---|
| `command` | Exact executed command |
| `cwd` | Working directory, portable relative description where possible |
| `status` | `completed`, `failed` বা `running` |
| `exit_code` | Process শেষ হলে প্রকৃত exit code |
| `log_file` | stdout ও stderr সংরক্ষিত থাকলে path |

সাধারণ Node delivery-তে প্রধান commands হবে:

```bash
npm install
npm run render
```

QC বা packaging আলাদা command-এ চালালে সেগুলোও log-এ যোগ করো। চালানো হয়নি এমন command-কে executed বলবে না। `project/delivery-report.json`-এর `commands` array ব্যবহার করো।

## ১০. Delivery ZIP

সম্পূর্ণ production ZIP-এ রাখো:

```text
index.html
media/
  final.mp4
source/
assets/
licenses/
proof/
reports/
project.json
scene-plan.json
word-timing.json
media-manifest.json
delivery-report.json
README.md
package.json
package-lock.json
```

প্রযোজ্য নয় এমন folder জোর করে তৈরি করতে হবে না। External media ব্যবহার করলে তাদের license, attribution ও source record বাধ্যতামূলক। ZIP-এর ভেতরে ZIP recursively যোগ করবে না।

## ১১. Public preview structure

Static hosting-এর জন্য এই structure তৈরি করো:

```text
public/
  index.html
  media/
    final.mp4
  delivery.zip
```

`project/public-preview.template.html`-কে `public/index.html` হিসেবে ব্যবহার করো। এতে native video controls, direct MP4 এবং ZIP download link আছে। Relative path রাখা হয়েছে যাতে কোনো approved static host-এ একই structure upload করা যায়।

- MP4 web playback-এর জন্য H.264 video, AAC audio ও fast start ব্যবহার করো, brief-এ ভিন্ন requirement না থাকলে।
- Public URL-এর সাথে local filesystem path মেশাবে না।
- ZIP upload করলেই playable preview হয়ে যায় না। Preview page ও MP4 আলাদা accessible path-এ publish করতে হবে।
- Chat platform inline player support করলে verified preview embed করো। Support না করলে verified public preview link দাও এবং সেটিকে inline playback বলে দাবি করবে না।

## ১২. Hosting ও প্রকাশ

Priority order:

1. ব্যবহারকারীর connected hosting বা publishing tool
2. ব্যবহারকারীর approved cloud বা static hosting destination
3. Current platform-এর প্রকৃত public file-sharing ও preview capability
4. কোনোটি না থাকলে local delivery এবং hosting access-এর Bengali request

- Account তৈরি, paid plan কেনা, credentials পরিবর্তন বা terms accept করবে না, স্পষ্ট অনুমতি ছাড়া।
- Public upload এই brief-এর required delivery হলেও private credentials, sensitive personal data বা confidential source দেখলে publish করার আগে ব্যবহারকারীকে সতর্ক করো।
- Upload API success response-ই final proof নয়। Public URL আলাদা unauthenticated request দিয়ে যাচাই করো।
- Link expiration, login requirement, region restriction বা download limit থাকলে স্পষ্ট লিখো।

## ১৩. Public verification

Publish claim-এর আগে যা যাচাই করবে:

| Check | Evidence |
|---|---|
| Preview page | Unauthenticated HTTP success এবং correct HTML |
| Direct MP4 | Unauthenticated HTTP success এবং `video/mp4` content type বা verified equivalent |
| Delivery ZIP | Unauthenticated HTTP success, file size এবং সুযোগ হলে CRC test |
| Relative paths | Preview-এর MP4 ও ZIP URL একই public host-এ resolve হয় |
| Playback | Actual player বা browser-এ দেখা হলে `playback_observed: true` |
| Link access | Login না লাগলে `public_access_verified: true` |

HTTP check দিয়ে actual visual playback প্রমাণ হয় না। Player-এ playback না দেখলে `playback_observed: false` রাখো এবং শুধু URL availability রিপোর্ট করো।

## ১৪. Bengali final response

সব প্রকাশ ও যাচাই শেষ হলে এই কাঠামো ব্যবহার করো। Placeholder কখনো final response-এ রাখবে না:

```text
সম্পন্ন অবস্থা:
পাবলিক প্রিভিউ: VERIFIED_PUBLIC_PREVIEW_URL
সরাসরি MP4: VERIFIED_PUBLIC_MP4_URL
সম্পূর্ণ ZIP: VERIFIED_PUBLIC_ZIP_URL
ভিডিওর measured specs:
ব্যবহৃত render commands:
Media ও license report:
QA ফল:
Known limitations:
```

Public upload সম্পন্ন না হলে:

```text
ভিডিও ও source package তৈরি হয়েছে, কিন্তু public upload সম্পন্ন হয়নি।
Local preview বা files:
Public hosting access প্রয়োজন:
যা যাচাই করা হয়েছে:
যা সম্পন্ন হয়নি:
```

কখনো fabricated URL, অকার্যকর `example.com` link, local path-কে public link বলা, বা ZIP link-কে playable video বলা যাবে না।

## ১৫. Completion checklist

- Bengali intake-এ শুধু প্রয়োজনীয় দুটি ফাইল চাওয়া হয়েছে
- Actual voice-over ও SRT বিশ্লেষণ করা হয়েছে
- AI নিজে scene, SVG, motion ও media নির্বাচন করেছে
- External media-এর relevance ও rights verified
- Generic বা archival media-র ব্যবহার বিভ্রান্তিকর নয়
- Exact executed commands সংরক্ষিত
- Final MP4 ও delivery ZIP তৈরি
- Public preview, MP4 ও ZIP আলাদা verified URL হিসেবে দেওয়া, hosting থাকলে
- Playback claim-এর evidence level সঠিক
- অনুপস্থিত capability, upload failure ও limitations বাংলায় স্পষ্ট
