# 06. SVG, Vector Illustration ও Shape System

## ১. উদ্দেশ্য

প্রতিটি ভিডিওর জন্য প্রয়োজনীয় graphic নিজে তৈরি করার একটি পরিষ্কার পদ্ধতি এটি। AI-কে আগে বুঝতে হবে আকারটি কোন তথ্য, আবেগ, গতি বা spatial relationship বহন করছে। তারপর primitive, generator ও animation নির্বাচন করতে হবে।

SVG শুধু decorative sticker নয়। একটি ভালো vector element পরের দৃশ্যে রূপ বদলাতে পারে, text-এর motion-কে সাহায্য করতে পারে এবং brand consistency ধরে রাখতে পারে।

## ২. Vector construction standards

- ViewBox ও coordinate system প্রতিটি asset-এ স্পষ্ট থাকবে।
- Base layout grid 8 point।
- Final resolution-এর চেয়ে বড় viewBox ব্যবহার করে rasterization ঝুঁকি কমাও।
- Stroke width, cap, join, corner radius ও opacity token-এ সংজ্ঞায়িত করো।
- Default `stroke-linecap: round` এবং `stroke-linejoin: round`, sharp technical style হলে conscious exception।
- একই পরিবারে একই visual weight বজায় রাখো।
- Geometry যেন output frame-এর বাইরে প্রয়োজনীয় bleed রাখে।
- Mask, clipPath, gradient, filter এবং group-এর semantic ID দাও।
- Unused definition, editor metadata ও raster embed সরাও।
- Complex-script text SVG-এর ভেতরে তখনই রাখবে যখন rasterizer-এর Pango-HarfBuzz বা equivalent shaping benchmark দিয়ে প্রমাণিত হয়। অন্যথায় আলাদা shaping engine বা shaped glyph path ব্যবহার করবে।
- Icon-এর ভেতরে ছোট পাঠ্য নয়।
- Random path নয়, নামকরা anchor ও reusable path data ব্যবহার করো।
- Motion-এর জন্য path-এর point count ও winding compatible রাখো, morph নির্ভরযোগ্য হবে।

## ৩. Design tokens

```text
grid = 8
stroke_hairline = 1.5 equivalent at 1080p
stroke_regular = 2
stroke_emphasis = 4
radius_small = 8
radius_medium = 16
radius_large = 24
dot_small = 4
dot_regular = 8
opacity_ghost = 0.06
opacity_support = 0.18
opacity_active = 1
```

এগুলো starting tokens। Brand ও aspect ratio অনুযায়ী scale করো। Hairline যেন final H.264-এ হারিয়ে না যায়, proof frame-এ পরীক্ষা করো।

## ৪. Shape operator equivalents

After Effects shape layer-এর আচরণ SVG বা custom vector pipeline-এ এইভাবে তৈরি করা যায়:

| Technique | দৃশ্যগত কাজ | Equivalent পদ্ধতি |
|---|---|---|
| Trim Paths | রেখা বা আকার আঁকা | path length sampling, stroke dash array ও dash offset, অথবা geometric path trimming |
| Repeater | একই আকারের নিয়ন্ত্রিত সারি | transform hierarchy সহ instancing, প্রতি instance-এ cumulative transform |
| Merge Paths | আকার একত্রিত বা intersect | boolean union, intersect, subtract, exclude, clipping |
| Offset Paths | আকারের ভেতরে বা বাইরে parallel path | geometric contour offset, stroke expansion, robust join handling |
| Pucker & Bloat | organic radial deformation | polar radius modulation around center |
| Round Corners | sharp point নরম করা | arc insertion বা cubic corner fillet |
| Twist | path-এর ঘূর্ণন deformation | angle varies with radial distance |
| Wiggle Paths | controlled irregular path | coherent low-frequency noise, fixed seed |
| Wiggle Transform | instance transform variation | seeded noise on position, rotation, scale |
| Zig Zag | periodic peaks | regular wave construction with rounded joins |
| Gradient ramp | আলো বা রং-এর পরিবর্তন | linear, radial, conic বা custom sampled ramp |
| Track matte | অন্য layer-এর alpha বা luminance-এ clipping | offscreen mask composite |
| Set Matte | নির্দিষ্ট layer-এর matte নিয়ন্ত্রণ | separate matte channel ও transform mapping |
| Puppet deformation | নিয়ন্ত্রিত organic warp | mesh bones, weighted pins বা cage interpolation |

Trim Paths-এর leading edge-এ উজ্জ্বল বিন্দু দিতে চাইলে path length থেকে প্রতি sub-sample-এ point ও tangent বের করো। Dash animation-এর সঙ্গে dot আলাদা করে guess করবে না।

## ৫. Vector generator library

### V01: Dot Grid Field

- অর্থ: network, space, archive, digital structure
- Construction: rows, columns, jitter, radial falloff, depth layers
- Animation: slow rotation, parallax, local opacity wave
- Curve: Sine InOut
- ব্যবহার: background support, কখনো মূল text-এর contrast নষ্ট নয়

### V02: Poetic Rule Lines

- অর্থ: লেখা, উদ্ধৃতি, চিন্তার স্তর
- Construction: 2 থেকে 4 সরু রেখা, ভিন্ন কিন্তু সামঞ্জস্যপূর্ণ length
- Animation: Trim Paths, leading edge glow, decreasing stagger
- ব্যবহার: editorial, literary, reflective scene

### V03: Timeline With Ticks

- অর্থ: ইতিহাস, প্রক্রিয়া, ক্রম
- Construction: main rule, long-short-short-long tick rhythm
- Animation: main path draw, tick repeater stagger
- Restriction: source-এ নেই এমন তারিখ বা year নয়
- Technique: Trim Paths, Repeater, Offset Paths, Merge Paths

### V04: Concentric Memory Rings

- অর্থ: স্মৃতি, resonance, care, continuity
- Construction: 3 থেকে 8 rings, বাইরের দিকে opacity falloff
- Animation: Sine breathing, phase offset, optional converge
- ব্যবহার: emotional বা solemn scene

### V05: Rising Light Orb

- অর্থ: আশা, স্মৃতি, উষ্ণতা, revelation
- Construction: radial gradient circle, bloom-only highlights, soft core
- Animation: slow Y rise, glow ramp, subtle scale breathing
- Avoid: lens flare cliché, অতিরিক্ত saturation

### V06: Quote Field

- অর্থ: সোর্সে থাকা উদ্ধৃতির পরিবেশ
- Construction: বড় quotation geometry, 4 থেকে 10 শতাংশ opacity
- Animation: soft pop বা focus-in, low parallax
- Restriction: quote attribution তৈরি করবে না

### V07: Node Network

- অর্থ: সংযোগ, সম্প্রদায়, system, interoperability
- Construction: nodes, meaningful edges, clustered depth
- Animation: sequential connection, merge, signal dot travel
- Avoid: অসংখ্য random node, generic technology wallpaper

### V08: Flow Path

- অর্থ: process, journey, cause to effect
- Construction: one main cubic path, branches, arrowless directional markers
- Animation: path draw, leading dot, staged labels
- Easing: Expo Out, Expo InOut for long travel

### V09: Convergence Lines

- অর্থ: ঐক্য, সিদ্ধান্ত, সমাধান
- Construction: several paths একটি common point বা line-এ মিলিত হয়
- Animation: independent eased draw, Merge Paths, final settle
- Avoid: forced political symbolism

### V10: Divergence Paths

- অর্থ: পার্থক্য, branching, alternatives
- Construction: shared origin, 2 থেকে 5 branches
- Animation: split at meaningful word, controlled stagger
- ব্যবহার: comparison ও explainer

### V11: Abstract UI Card

- অর্থ: product interface বা feature
- Construction: card, image placeholder নয় বরং অনুমোদিত content, list bars, button geometry
- Animation: masked assemble, cursor-free guided focus, callout lock
- QA: real UI থেকে ভুল feature তৈরি হচ্ছে না

### V12: Browser Or Device Frame

- অর্থ: software, web, mobile product
- Construction: simplified frame, brand-appropriate radius, perspective plane
- Animation: camera push, layer separation, screen reveal
- Avoid: tiny illegible UI, অনুমোদনহীন OS logo

### V13: Feature Callout

- অর্থ: কোনো অংশের নির্দিষ্ট বৈশিষ্ট্য
- Construction: anchor dot, connector, short label zone
- Animation: dot, path, text decreasing overlap
- ব্যবহার: T15 recipe-এর সঙ্গে

### V14: Comparison Split

- অর্থ: before-after, দুটি বিকল্প, contrast
- Construction: দুই zone, shared divider, matched visual weights
- Animation: divider draw, match cut, element handoff
- Avoid: ভুল বা অনুমোদনহীন comparison

### V15: Line Chart

- অর্থ: অনুমোদিত সময়ভিত্তিক data
- Construction: actual data mapping, baseline, path, markers
- Animation: data order-এ path reveal
- QA: axis, scale, unit ও source যাচাই, কোনো data invention নয়

### V16: Bar Or Column Set

- অর্থ: অনুমোদিত তুলনা
- Construction: equal baseline, accurate scale, rounded but precise bars
- Animation: scaleY from baseline, decreasing stagger
- Easing: Quint Out
- Avoid: misleading truncated axis

### V17: Donut Or Radial Meter

- অর্থ: অনুমোদিত proportion বা progress
- Construction: arc paths, actual ratio, accessible label
- Animation: Trim Paths, Circ Out
- Avoid: decorative fake percentage

### V18: Procedural Waveform

- অর্থ: আসল audio, sound, rhythm
- Construction: source audio amplitude বা spectrum থেকে sampled path
- Animation: playhead-linked, না হলে static envelope reveal
- Avoid: ভুয়া waveform যা audio-এর সঙ্গে মেলে না

### V19: Particle Text Sampler

- অর্থ: ক্ষয়, memory, dispersion, morph
- Construction: shaped text alpha থেকে point sampling, density ও size hierarchy
- Animation: seeded release, drag, drift, convergence
- QA: points text-এর আকার থেকেই জন্মায়

### V20: Bokeh Field

- অর্থ: depth, distant memory, soft atmosphere
- Construction: layered discs with optical falloff
- Animation: slow drift, DOF radius growth
- Avoid: celebratory sparkle, excessive brightness

### V21: Contour Topography

- অর্থ: জটিলতা, পরিবেশ, ধাপ, পরিবর্তন
- Construction: nested smooth contours from coherent scalar field
- Animation: slow displacement, selective line reveal
- ব্যবহার: documentary, science, abstract explanation

### V22: Organic Blob

- অর্থ: fluidity, care, living system
- Construction: low-frequency polar radius modulation
- Animation: Sine breathing, morph to related shape
- Avoid: childish wobble, অতিরিক্ত color

### V23: Structural Frame

- অর্থ: focus, archive, evidence, chapter
- Construction: corner brackets, crop marks, rectangular mask
- Animation: corner draw, frame settle, content reveal
- Avoid: footage বা evidence না থাকলে misleading archival claim

### V24: Grid To Product Morph

- অর্থ: concept থেকে বাস্তব product
- Construction: shared points between grid এবং product card
- Animation: point interpolation, Merge Paths, camera settle
- Easing: Expo InOut
- ব্যবহার: promo-র strong transition

### V25: Orbit And Satellite

- অর্থ: ecosystem, dependency, continuous service
- Construction: central object, 1 থেকে 3 orbit paths, limited satellites
- Animation: eased orbital phase, subtle parallax
- Avoid: constant fast spinning, generic space cliché

### V26: Mask Ribbon

- অর্থ: transition, continuity, guided attention
- Construction: narrow curved band with soft edge
- Animation: path travel, reveal next scene, leading light
- Avoid: generic whoosh transition

### V27: Calibration Marks

- অর্থ: precision, measurement, technical craft
- Construction: ticks, small crosshair, alignment rule
- Animation: snap-to-grid with Quint Out settle
- Avoid: অনুমোদনহীন measurements বা technical claims

### V28: Abstract Human Scale

- অর্থ: জনগণ, ব্যক্তি, সমষ্টি, কিন্তু কোনো ব্যক্তির portrait নয়
- Construction: varied dots বা simple heads without identity, respectful spacing
- Animation: gather, disperse, create negative space
- Restriction: stereotype, crowd violence, party icon নয়

## ৬. Generator নির্বাচন

নিচের ক্রমে সিদ্ধান্ত নাও:

1. দৃশ্যের মূল অর্থ কী?
2. সেই অর্থ কি text একাই বহন করতে পারে?
3. Graphic যোগ করলে কোন অতিরিক্ত তথ্য বা আবেগ আসবে?
4. আগের scene-এর কোন element এখানে handoff করতে পারে?
5. Generator-এর motion কি audio-এর rhythm-এ বসবে?
6. এটি background নাকি primary focal?
7. ছোট screen-এ এর আকার ও stroke টিকবে কি?

অতিরিক্ত তথ্য বা আবেগ না এলে generator বাদ দাও।

## ৭. Illustration quality

মৌলিক illustration হলেও এটি যেন stock icon set না লাগে:

- Project-specific proportion ও spacing
- Shared geometry across scenes
- Controlled asymmetry যেখানে দরকার
- সূক্ষ্ম line-weight hierarchy
- Highlight ও shadow-এর একই আলোর দিক
- অপ্রয়োজনীয় detail বাদ
- Text-এর সঙ্গে optical alignment
- Corner, cap ও join consistency
- Icon-এর ভেতরে brand বা interface অনুমোদন ছাড়া নকল নয়

## ৮. Morph readiness

দুই path-এর মধ্যে morph করতে হলে:

- Semantic relationship লিখো
- Same coordinate space ব্যবহার করো
- Point count match বা resample করো
- Winding direction match করো
- Holes ও compound paths আলাদা map করো
- First ও last silhouette proof frame-এ দেখো
- Mid-morph self-intersection পরীক্ষা করো
- Path interpolation-এ Expo InOut ব্যবহার করো
- Morph-এর সময় text readability আলাদা রাখো

## ৯. SVG delivery contract

প্রতিটি generated asset-এর জন্য সংরক্ষণ করো:

```text
asset id
source file
viewBox
semantic role
scene IDs
layer names
path IDs used for animation
animation operators
color tokens
stroke tokens
license: original
rasterization size
QA status
```

SVG source এবং final raster proof দুটিই রাখা ভালো। কোনো renderer SVG filter সমর্থন না করলে equivalent compositing step লিখে বাস্তবায়ন করতে হবে, নিঃশব্দে effect বাদ দেওয়া যাবে না।
