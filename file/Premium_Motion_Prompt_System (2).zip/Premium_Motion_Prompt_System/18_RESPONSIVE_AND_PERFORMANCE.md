# 18. Responsive Composition ও Performance Budget

## ১. Responsive layout

একই scene-এর content, motion ও continuity রেখে composition বদলাতে হবে। শুধু scale বা center crop নয়।

## ২. Layout tokens

| Token | Wide 1920 x 1080 | Vertical 1080 x 1920 | Square 1080 x 1080 |
|---|---:|---:|---:|
| Default safe side | 160 px | 72 px | 72 px |
| Default safe top | 96 px | 144 px | 72 px |
| Default safe bottom | 120 px | 260 px, platform অনুযায়ী | 96 px |
| Hero max width | 1200 px | 900 px | 880 px |
| Caption max width | 1320 px | 900 px | 900 px |
| Caption lines | 1 থেকে 2 | 1 থেকে 2, প্রয়োজনে 3 শুধু অনুমোদনে | 1 থেকে 2 |
| Base grid | 8 | 8 | 8 |
| Headline scale reference | 1.0 | 0.72 থেকে 0.9, word length অনুযায়ী | 0.75 থেকে 0.9 |
| Camera travel reference | 1.0 | 0.55 | 0.7 |
| Particle count reference | 1.0 | 0.65 | 0.75 |

মানগুলো starting profile। Font-এর ink bounds এবং platform UI দেখে সামঞ্জস্য করতে হবে।

## ৩. Responsive rules

### Headline

1. প্রথমে available width নির্ধারণ করো।
2. Shaped word-এর ink width মাপো।
3. Maximum font size হিসাব করো, তারপর optical scale কমাও।
4. Bengali মাত্রা ও descender-এর জন্য top-bottom padding দাও।
5. Vertical-এ দীর্ঘ শব্দ এক লাইনে পড়লে অপ্রয়োজনীয় ছোট করবে না, phrase-aware line break বিবেচনা করো।
6. Mask final font size ও motion blur অনুযায়ী বাড়াও।

### Caption

- Social UI-এর নিচের অংশে caption রাখবে না।
- Active word scale-এর জন্য adjacent spacing যাচাই করো।
- Wide-এর এক লাইন vertical-এ দুই লাইন হতে পারে, কিন্তু শব্দ বা phrase বদলাবে না।
- Caption ও hero headline একই vertical zone-এ আসলে hero-এর অবস্থান বদলাও, caption ছোট করার আগে।

### Callout ও diagram

- Wide: connector পাশে থাকতে পারে।
- Vertical: callout নিচে বা উপরে, connector বাঁকানো কিন্তু ছোট নয়।
- Square: connector-এর দৈর্ঘ্য কমিয়ে label কাছে আনো।
- কোনো connector মূল object-এর গুরুত্বপূর্ণ অংশ ঢাকবে না।

## ৪. Responsive motion

- Vertical-এ camera translation কমানো, focal scale বাড়ানো যায়।
- দীর্ঘ horizontal path vertical-এ angle বা stacking বদলাতে পারে।
- Particle density কমানো যায়, কিন্তু source shape ও target continuity থাকবে।
- Motion duration শুধু screen বদলের কারণে বাড়ানোর দরকার নেই, audio একই থাকলে timing একই।
- DOF ছোট screen-এ কম রাখো, কারণ blur বেশি দৃশ্যমান ও পড়ার বাধা হতে পারে।

## ৫. Performance budgets

Default reference class, 1920 x 1080, 30 fps:

| Resource | Preferred | Hard review threshold |
|---|---:|---:|
| Temporal samples | 8 | 8 নিচে যাবে না যদি brief-এ minimum 8 থাকে |
| Adaptive samples | 12 বা 16 দ্রুত অংশে | 24-এর বেশি হলে cost report |
| Text-derived particles | 150 থেকে 300 | 800-এর বেশি হলে density ও memory proof |
| Ambient particles | 20 থেকে 80 | 200-এর বেশি হলে focal noise review |
| Large simultaneous blur regions | 0 settled, 1 entry | 2-এর বেশি হলে cache বা precomposite |
| Full-frame distortion | 0 | 1-এর বেশি হলে technical review |
| Offscreen RGBA buffer | প্রয়োজন অনুযায়ী | মোট estimated memory budget-এর মধ্যে |
| Persistent text glow | Event pulse only | Continuous হলে visual ও cost justification |
| SVG node count per frame | 500-এর নিচে preferred | 2000-এর বেশি হলে pattern বা cache |
| Encoded proof comparison | সব key scenes | Missing হলে QA incomplete |

## ৬. Memory estimate

RGBA buffer:

```text
bytes = width * height * 4
1920 x 1080 RGBA = 8,294,400 bytes, প্রায় 7.91 MiB
```

8 sub-sample একসঙ্গে রাখলে প্রায় 63.3 MiB, accumulation buffer ও encoder memory আলাদা। তাই reference-এ sample একটির পর একটি stream করা হয় এবং averaging native FFmpeg `tmix`-এ হয়। `tmix` ও downstream `fps`-এর শেষ frame ধরে রাখতে `samples - 1` terminal flush sample দেওয়া হয়। এগুলো output duration বাড়ায় না এবং শেষ averaged frame-এর source samples বদলায় না। `npm run test:tmix` এই frame-count নিয়ম পরীক্ষা করে।

## ৭. Cost control without visible simplification

- Persistent blur নয়, event-specific blur
- Static dots-এর হাজারো node নয়, vector pattern
- Text shaping cache, motion transform আলাদা
- Settled scene-এর অপরিবর্তিত layer cache
- Temporal averaging native library-তে
- Particle count কম, কিন্তু source-aware placement
- Large blur region tight bounds
- Proof ও final একই renderer
- Native object memory growth মাপা, leak হলে renderer বদলানো বা process isolation
- Final render-এর আগে 20 sample-এর RSS ও timing benchmark

## ৮. Implementation cost checklist

- Persistent blur নয়, event-specific blur
- Static dots-এর হাজারো node নয়, vector pattern
- Text shaping cache, motion transform আলাদা
- Settled scene-এর অপরিবর্তিত layer cache
- Temporal averaging native library-তে
- Particle count কম, কিন্তু source-aware placement
- Large blur region tight bounds
- Proof এবং final একই project renderer
- Native object memory growth মাপা
- Final render-এর আগে ছোট timing ও memory benchmark

Native `tmix` এবং downstream `fps` ব্যবহার করলে frame-count regression test করো। Generic `npm run test:tmix` একটি technical test, কোনো ভিডিওর motion-blur quality proof নয়।

## ৯. Adaptive quality

Quality কমাতে হলে এই ক্রমে সিদ্ধান্ত নাও:

1. অপ্রয়োজনীয় particles কমাও
2. Blur region ছোট করো
3. Static layer cache করো
4. Ambient SVG node pattern করো
5. Encoding preset সামঞ্জস্য করো, visual resolution একই রেখে
6. Render concurrency hardware অনুযায়ী সীমিত করো

শুধু অনুমোদন নিয়ে:

- Temporal samples 8-এর নিচে নামানো
- Output resolution কমানো
- Required blur বা DOF বাদ দেওয়া
- Required font shaping বদলানো

## ১০. Performance report template

| Metric | Target | Measured | Status |
|---|---|---|---|
| RSS behavior | Stable across a documented window |  |  |
| Average sample time | Hardware-specific |  |  |
| Total render time | Project-specific |  |  |
| Output frames | Exact |  |  |
| Dropped frames | 0 |  |  |
| Decode errors | 0 |  |  |
| Memory measurement method | Continuous or clearly labelled sparse samples |  |  |

Performance-এর জন্য visual quality কমানো হয়েছে কি না আলাদা লিখতে হবে। Sparse memory observation-কে true peak বলা যাবে না।
