# 17. Anti-template ও Failure Library

## উদ্দেশ্য

এই library ভুলের তালিকা নয়, দ্রুত diagnosis ও correction-এর সহায়কা। Proof frame বা preview-এ সমস্যা দেখলে symptom খুঁজে cause ও fix প্রয়োগ করো।

## ১. Layout ও art direction

| Symptom | সম্ভাব্য cause | Fix | Proof |
|---|---|---|---|
| সব scene একই centered title | Recipe-কে composition হিসেবে ব্যবহার | Baseline, scale, negative space ও supporting motif বদলাও | Scene contact sheet |
| Stock icon wall | Semantic selection নেই | প্রতিটি icon-এর কাজ লিখো, অপ্রয়োজনীয় বাদ | Asset purpose map |
| Center crop vertical | Wide layout reuse | নতুন line break, callout ও camera layout | Vertical proof |
| Text সবসময় মাঝখানে, পাশে অর্থহীন ফাঁকা জায়গা | Optical composition নেই | Motif বা focal alignment দিয়ে asymmetry তৈরি করো | Poster-like still review |
| একসঙ্গে ৩টি focal point | Hierarchy নেই | Contrast, scale, motion বা depth কমাও | First-eye test |
| সবকিছু সমান margin | Mechanical grid | Grid রেখে optical adjustment করো | Ink bounds comparison |

## ২. Typography

| Symptom | Cause | Fix | Proof |
|---|---|---|---|
| যুক্তাক্ষর ভাঙা | Character split বা unsafe fallback | Whole word shaping, font change | Font benchmark |
| Multi-word overlap | Renderer-এর text-run bug | Current Pango pipeline এবং renderer-specific multiword test | Multiword smoke |
| Mask-এ মাত্রা কাটা | Logical bounds ব্যবহার, ink bounds নয় | Mask-এ ascent, descent ও blur padding দাও | Entry midpoint |
| Caption লাফায় | Active word-এর advance width বদলায় | Stable line layout, word-local scale | Active word sequence |
| Text blur কখনো শেষ হয় না | Blur duration মূল entry-এর সঙ্গে সমান | Blur প্রথম 60 শতাংশে clear | Settled frame pixel sharpness |
| Text-এ অতিরিক্ত glow | Persistent blur layers | Bright-pass ও event pulse, settled text sharp | Glow on/off comparison |
| Bold headline ও bold caption লড়াই করে | Weight hierarchy নেই | Caption weight, size ও contrast কমাও | Small-screen review |

## ৩. Motion

| Symptom | Cause | Fix | Proof |
|---|---|---|---|
| Robotic stop | Linear বা একই duration-এ সব layer | Named curve, overlap, stagger | Velocity graph ও preview |
| Preset bounce | Back Out সব scene-এ | Tone-based spring, grave scene-এ বাদ | Recipe report |
| হঠাৎ direction reversal | Curve join mismatch | Shared tangent বা intentional cut | Transition midpoint |
| Constant floating text | Ambient amplitude বেশি | 1 থেকে 2 px, দীর্ঘ cycle | Frame difference |
| Motion blur-এর মধ্যেও কাঁপুনি | Position integer rounding | Sub-frame time এবং continuous transforms | 8 sample render |
| Exit আগের entry-এর উল্টো | Reverse keyframes | আলাদা blur-up-fade বা semantic exit | Exit recipe |
| সব element একসঙ্গে শুরু ও থামে | Follow-through নেই | Decreasing stagger, 70 থেকে 90 শতাংশে overlap | Timeline chart |

## ৪. Transition

| Symptom | Cause | Fix | Proof |
|---|---|---|---|
| Generic dissolve | Shared element নেই | Underline, ink, dot, ring বা card handoff | Transition map |
| Previous word ghost | Exit ও entry overlap ভুল | আগের text-এর exit আগিয়ে দাও | Full-size overlap frame |
| Particles random glitter | Source alpha ও target নেই | Text-derived origin, semantic target | Particle birth এবং arrival |
| Zoom শুধু zoom-এর জন্য | Spatial motivation নেই | Camera target, next plane ও focus যোগ করো | Depth storyboard |
| Match cut মেলে না | Silhouette ও screen position আলাদা | Matched bounds, tangent ও color | First, mid, last frame |
| Rings final text-এর ওপর clutter | Supporting layer দেরিতে fade | Readability-এর আগে rings fade | S04 entry proof |

## ৫. Compositing

| Symptom | Cause | Fix | Proof |
|---|---|---|---|
| Flat background | Solid fill only | Subtle radial depth, low-contrast pattern, vignette | Histogram ও still |
| Banding | Low bit depth gradient, insufficient dither | Fine deterministic grain, high-quality encoding | Encoded frame |
| Matte fringe | Premultiplication বা color contamination | Correct alpha, edge color cleanup | High contrast inspection |
| Effect rectangle দেখা যায় | Filter bounds ছোট | Expanded offscreen bounds | Blur and glow edges |
| Grain text নষ্ট করে | Grain খুব শক্ত বা আগে বসানো | Final low-amplitude grain, text protect | Encoded small text |
| Red restriction ভঙ্গ | Chromatic split বা grade | Palette-safe channels, selective grade | Pixel color audit |
| Shadow আলোর দিক মেলে না | Layer styles আলাদা আলাদা | Shared light direction token | Scene light map |

## ৬. Audio

| Symptom | Cause | Fix | Proof |
|---|---|---|---|
| Caption শব্দের পরে আসে | SRT সরাসরি ব্যবহার | Actual onset alignment | Word timing report |
| Tick বিরক্তিকর | প্রতি word বা item-এ tick | শুধু structural event | Sound event density |
| Stamp voice ঢাকে | Level ও frequency masking | কমপক্ষে 12 dB নিচে, spectrum adjust | Voice-on measurement |
| Transition whoosh অপ্রয়োজনীয় | Preset sound | Element-led visual, sound বাদ | Brief and sound map |
| শেষে হঠাৎ sound cut | Envelope release নেই | Natural decay, audio padding নয় | Last second waveform |
| Mono-তে sound হারায় | Phase inversion | Phase-safe stereo বা center | Mono fold-down |

## ৭. Technical ও honesty

| Symptom | Cause | Fix | Proof |
|---|---|---|---|
| Fresh install-এ font বদলে যায় | System font fallback | Bundled fontconfig ও font license | Fresh environment test |
| FFmpeg missing | System PATH dependency | npm bundled binary | PATH-isolated test |
| Python চাই | Native module build | Prebuilt package | Clean install log |
| Duration আধা frame বেশি | Frame quantization লুকানো | Probe tracks, last sample timing | ffprobe report |
| `pass` লেখা, কিন্তু proof নেই | Automated status অনুমান | `not_tested` ব্যবহার, proof সংযুক্ত করো | QC evidence |
| Effect map-এ অনেক effect, দৃশ্যে নেই | Documentation inflation | শুধু observed effect map | Frame-linked effect proof |
| Memory বাড়তে থাকে | Native object lifecycle | Stable renderer, buffer profiling | RSS benchmark |
| Render খুব ধীর | Persistent filters, অপ্রয়োজনীয় sub-samples | Event-specific filters, native tmix | Performance report |

## ৮. Correction log template

প্রতিটি project-এ আলাদা correction log রাখো। পুরনো project-এর fix-কে নতুন ভিডিওর proof বলা যাবে না।

| সমস্যা | প্রথমে যা পরীক্ষা করবে | Correction | নতুন project proof |
|---|---|---|---|
| Text ghost overlap | Previous exit end এবং new entry start | Timing, mask বা focal weight ঠিক করো | Transition midpoint |
| Multiword spacing | Renderer-specific shaped run | Verified shaping engine বা glyph paths | Multiword diagnostic |
| Persistent filter cost | Settled frame-এ filter-এর visible contribution | Cache, tighten bounds বা event-specific filter | Performance report |
| ভুল proof time | Actual transition midpoint | Proof frame সঠিক সময়ে সরাও | Updated proof frame |
| Frame count mismatch | End-of-stream behavior এবং timestamps | Documented sampling correction, arbitrary padding নয় | ffprobe frame count |

Correction-এর পরে একই project-এর নতুন render ও নতুন proof দিতে হবে।
