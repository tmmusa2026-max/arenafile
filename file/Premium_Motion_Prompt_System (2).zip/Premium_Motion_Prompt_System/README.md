# Premium Motion Prompt System 2.2

এটি একটি **reference-free, reusable motion design prompt এবং validation toolkit**। এখানে কোনো reference video, sample scene, visual proof sheet বা অনুকরণযোগ্য motion template নেই।

উদ্দেশ্য হলো AI যেন কোনো তৈরি করা নমুনা অনুসরণ না করে বর্তমান brief, source content, audio, brand এবং platform থেকে মৌলিক সিদ্ধান্ত নেয়।

## Autonomous Bengali workflow

1. AI প্রথম উত্তরে বাংলায় শুধু voice-over ও SRT চাইবে। একটি ফাইল দেওয়া থাকলে শুধু অন্যটি চাইবে।
2. ফাইল দুটি পেলে actual audio timing বিশ্লেষণ করে নিজে scene, SVG, animation, transition ও sound নির্বাচন করবে।
3. News, documentary বা real-world প্রসঙ্গে প্রয়োজনীয় photo ও short video clip খুঁজবে, তবে relevance, license ও attribution verified না হলে ব্যবহার করবে না।
4. Generic বা archival media-কে actual event footage বলবে না। Verified relevant media না পেলে মৌলিক SVG fallback ব্যবহার করবে।
5. প্রকৃত executed install, render, QC ও packaging commands `delivery-report.json`-এ লিখবে।
6. প্রকৃত hosting থাকলে playable public preview, direct MP4 এবং সম্পূর্ণ delivery ZIP-এর আলাদা verified link দেবে।
7. Hosting বা playback verification না থাকলে সত্যটি বাংলায় বলবে, fabricated public link দেবে না।

পূর্ণ নিয়ম `20_AUTONOMOUS_MEDIA_AND_PUBLIC_DELIVERY.md`-এ আছে।

## গুরুত্বপূর্ণ নীতি

- Validation output কখনো visual style guide নয়।
- Generic example-এর timing actual audio-এর বিকল্প নয়।
- ক্যাটালগের সব effect এক ভিডিওতে ব্যবহার বাধ্যতামূলক নয়।
- প্রতিটি selection-এর narrative বা functional কারণ থাকতে হবে।
- Complex script-এর অক্ষর split নয়, word, phrase বা line-level shaping ও animation।
- Actual voice-over থাকলে SRT-এর বদলে actual speech timing অগ্রাধিকার পাবে।
- কোনো তথ্য, নাম, সংখ্যা, তারিখ বা দাবি অনুমোদন ছাড়া যোগ করা যাবে না।
- কোনো ফাইলে em dash ব্যবহার নিষিদ্ধ।

## AI-কে দেওয়ার নিয়ম

1. AI-কে এই package, `MASTER_PROMPT.md`, `ROUTER.md` এবং `20_AUTONOMOUS_MEDIA_AND_PUBLIC_DELIVERY.md` দিন।
2. এর প্রথম Bengali intake-এ voice-over ও SRT দিন। আলাদা effect, SVG বা footage list দেওয়ার দরকার নেই।
3. অতিরিক্ত brand বা delivery নির্দেশ দিতে চাইলে `project/PROJECT_BRIEF.md` ব্যবহার করুন, তবে initial intake-এ এটি বাধ্যতামূলক নয়।
4. AI router-এর নির্বাচিত modules পড়ে analysis, creative route, scene plan, media selection, implementation এবং project-specific QA করবে।
5. Public delivery-এর জন্য connected hosting থাকলে সেটি ব্যবহার করবে। না থাকলে local files এবং প্রয়োজনীয় hosting access জানাবে।

ছোট context-এ `PROMPT_COMPACT.md` ব্যবহার করা যায়, তবে hard constraints বাদ দেওয়া যাবে না।

## মূল ফাইল

| File | কাজ |
|---|---|
| `MASTER_PROMPT.md` | পূর্ণাঙ্গ adaptive master prompt |
| `PROMPT_COMPACT.md` | ছোট context-এর prompt |
| `ROUTER.md` | Task ও genre অনুযায়ী module selection |
| `project/PROJECT_BRIEF.md` | নতুন ভিডিওর পূরণযোগ্য brief |
| `01` থেকে `03` | Direction, audio-first timing, motion system |
| `04` থেকে `06` | Typography, text recipes, original SVG system |
| `07` থেকে `11` | Effects, compositing, camera, sound, Node pipeline |
| `12` থেকে `14` | Selection, QA, output contract |
| `15` থেকে `19` | Capability, continuity, failure prevention, performance, scored QA |
| `20_AUTONOMOUS_MEDIA_AND_PUBLIC_DELIVERY.md` | Bengali intake, autonomous web media, command log, public preview ও ZIP delivery |

## Machine-readable system

- `schemas/`: Project, scene plan, word-timing, media manifest এবং delivery report validation
- `libraries/`: Easings, text, vector, transition, sound, selection, capability, media sourcing, public delivery, router, responsive budget, QA এবং versions
- `project/public-preview.template.html`: Relative MP4 ও ZIP path-এর native video preview template
- `examples/`: Political, product promo ও documentary workflow
- `examples/machine-readable/`: Generic structure examples, rendered reference নয়
- `validation/`: Generic technical tests, bundled test fonts এবং synthetic audio

## Validation commands

এই package নিজে video render করে না। তাই এখানে `npm run render` command ইচ্ছাকৃতভাবে নেই।

```bash
npm install
npm run preflight
npm run benchmark:fonts
npm run benchmark:audio
npm run test:rules
npm run test:delivery
npm run test:tmix
```

Optional local font diagnostics:

```bash
npm run benchmark:fonts -- --write-proof
```

Diagnostic images package-এ দেওয়া নেই। Command চালালে স্থানীয় `validation/proof/` তৈরি হবে এবং visual review আলাদা করতে হবে।

সর্বশেষ generic validation ফল `validation/reports/validation-summary.md`-এ আছে।

Synthetic benchmark audio পুনরায় তৈরি করতে:

```bash
npm run generate:benchmark
```

## 25 MB size policy

ZIP-এ নিচের জিনিস রাখা হয় না:

- Reference বা rendered video
- Video scene source ও visual proof frames
- `node_modules`, cache বা build output
- অনুকরণযোগ্য sample composition
- অপ্রয়োজনীয় footage, imagery বা large audio

শুধু prompt, reusable libraries, compact examples এবং generic validation assets থাকে। `MANIFEST.json`-এ final file hashes, individual sizes এবং hashed payload size থাকে।

## নতুন ভিডিওর delivery

নতুন প্রজেক্টে AI-কে তার নিজের source, scene plan, assets এবং renderer তৈরি করতে হবে। Node-only brief হলে `11_NODE_RENDER_PIPELINE.md` অনুসারে project-specific `npm install` ও `npm run render` তৈরি করতে হবে। এই prompt package-এর validation scripts সেই renderer-এর বিকল্প নয়।

Final production project-এ actual proof frames, encoded QC, measured duration, resolution, fps, codecs, exact command log, media manifest এবং known limitations দিতে হবে। প্রকৃত hosting থাকলে `index.html`, direct MP4 ও delivery ZIP publish করে public access যাচাই করতে হবে। Playback দেখা না গেলে HTTP availability এবং playback observation আলাদা রাখতে হবে। এই package-এর generic test pass-কে সেই ভিডিওর final QC বলা যাবে না।
