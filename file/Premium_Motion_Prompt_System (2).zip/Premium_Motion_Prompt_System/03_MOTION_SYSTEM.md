# 03. Motion System

## উদ্দেশ্য

এই সিস্টেমের লক্ষ্য মসৃণ velocity, নিয়ন্ত্রিত acceleration, readable hold এবং ইচ্ছাকৃত rhythm। কোনো দৃশ্যগত প্রধান গতি linear বা default ease-in-out হবে না। Technical constant rate process, যেমন deterministic sampling clock, এই নিয়মের ব্যতিক্রম।

## ১. নামকরা easing family

| নাম | Cubic Bezier বা মান | প্রধান ব্যবহার |
|---|---|---|
| Expo Out | `(0.16, 1, 0.3, 1)` | দ্রুত শুরু, নরম থামা, মূল text ও graphic entry |
| Quint Out | `(0.22, 1, 0.36, 1)` | বড় element-এর dignified settle, ভারী camera move |
| Expo InOut | `(0.87, 0, 0.13, 1)` | দৃশ্য বদল, match move, দীর্ঘ camera transition |
| Back Out | `(0.34, 1.56, 0.64, 1)` | ছোট playful বা rhetorical pop, শুধু tone মিললে |
| Sine InOut | `(0.37, 0, 0.63, 1)` | breathing, floating, glow, ধীর camera drift |
| Exit Accelerate | `(0.7, 0, 0.84, 0)` | ধীরে শুরু করে দ্রুত exit |
| Emphasis Soft | `(0.2, 0.8, 0.2, 1)` | caption color, scale ও ছোট state change |
| Circ Out | `(0.075, 0.82, 0.165, 1)` | আকার আঁকা বা circular reveal-এর controlled finish |
| Quart InOut | `(0.76, 0, 0.24, 1)` | মাঝারি structural morph, অতিরিক্ত dramatic নয় |
| Damped Spring | stiffness 180, damping 22 | overshoot-এর পরে settle |

প্রতি প্রজেক্টে সাধারণত 2 থেকে 4টি family প্রধান থাকবে। একই ধরনের গতিতে একই family ব্যবহার করো। নতুন curve তৈরি করলে নাম, control point ও ব্যবহার লিখতে হবে।

## ২. Duration vocabulary

দৈর্ঘ্য frame rate ও scene length-এর সঙ্গে মানিয়ে নাও। নিচের মান default, কঠিন আইন নয়।

| Motion | সাধারণ duration | মন্তব্য |
|---|---|---|
| Micro state change | 0.08 থেকে 0.14 s | caption emphasis, tiny dot |
| Small element entry | 0.24 থেকে 0.40 s | tick, underline, icon |
| Headline entry | 0.32 থেকে 0.60 s | শব্দের দৈর্ঘ্য ও tone অনুযায়ী |
| Large object entry | 0.45 থেকে 0.80 s | Quint Out প্রায়ই উপযুক্ত |
| Text exit | 0.20 থেকে 0.30 s | entry-এর উল্টো নয় |
| Element-led transition | 0.30 থেকে 0.65 s | pause-এর মধ্যে ফিট করো |
| Camera push | 1.5 থেকে 6 s বা scene জুড়ে | খুব কম amplitude |
| Ambient breathing | 2.5 থেকে 6 s cycle | Sine InOut, low contrast |
| Glow pulse | 0.30 থেকে 0.50 s decay | উজ্জ্বল অংশে সীমিত |

খুব ছোট scene-এ reveal এবং hold-এর ভারসাম্য রাখো। Animation শেষ হতেই পরের scene চলে গেলে দর্শক পড়তে পায় না।

## ৩. Entry choreography

একটি premium headline entry সাধারণত এই ক্রমে কাজ করে:

1. Mask বা clip আগে প্রস্তুত থাকে।
2. Position দ্রুত শুরু হয়।
3. Blur প্রথম 60 শতাংশে প্রায় শেষ হয়।
4. Scale ও rotateX একই মূল curve-এ আসে।
5. প্রয়োজন হলে ছোট spring settle হয়।
6. Underline বা supporting path আগের element থামার আগে শুরু হয়।
7. Shimmer একবার যায়, বারবার নয়।
8. Glow pulse settle-এর পরে ক্ষীণ হয়।

সব layer-এর duration এক হতে হবে না। একই element-এর ভেতরেও offset থাকবে।

## ৪. Exit choreography

Exit কেবল reverse entry নয়। Default dignified exit:

- Opacity: 1 থেকে 0
- Position Y: বর্তমান অবস্থান থেকে 8 px উপরে
- Blur: 0 থেকে 8 থেকে 14 px
- Duration: 0.20 থেকে 0.30 s
- Easing: Exit Accelerate
- Scale: সাধারণত স্থির বা সর্বোচ্চ 0.99
- Exit-এর মাঝে পরের scene-এর handoff শুরু হতে পারে

Narrative চাইলে particle, mask বা morph exit নেওয়া যাবে। সেটি আলাদা recipe হিসেবে লিখতে হবে।

## ৫. Decreasing stagger

সমান ব্যবধানের বদলে সামান্য কমতে থাকা stagger ব্যবহার করো। একই group-এ 0.06 থেকে 0.10 s ভালো starting range।

```text
u = index / max(1, count - 1)
spacing(index) = 0.10 - 0.04 * smoothstep(0, 1, u)
start(index + 1) = start(index) + spacing(index)
```

এখানে smoothstep কেবল spacing-এর distribution নিয়ন্ত্রণ করে, প্রধান element motion নয়। Group বড় হলে total duration যেন scene-এর readable time না খায়।

## ৬. Follow-through ও overlap

- পরের element শুরু হতে পারে আগেরটির 70 থেকে 90 শতাংশ সম্পন্ন হওয়ার পরে।
- Hero element-এর settle-এর আগে supporting underline শুরু হতে পারে।
- Exit শুরু হতে পারে পরের background motif-এর প্রস্তুতির সঙ্গে।
- Caption, headline ও decoration যেন আলাদা দলের মতো না লাগে, তাদের shared timeline motivation থাকবে।
- সব layer একসঙ্গে থামলে robotic ভাব আসে। তবে random offset দেবে না, hierarchy অনুযায়ী offset দাও।

## ৭. Spring ও overshoot

Damped spring ব্যবহারের শর্ত:

- Tone energetic, rhetorical বা product-positive হলে উপযুক্ত হতে পারে।
- Memorial, grief, serious documentary বা grave political context-এ সাধারণত নয়।
- Default scale 0.92 থেকে 1.00, ছোট overshoot 1.04 পর্যন্ত।
- Restrained scene-এ overshoot 0 থেকে 0.01 বা সম্পূর্ণ বাদ।
- Spring settle-এর পরে opacity বা blur কাঁপবে না।

Spring simulation-এ fixed time step ব্যবহার করো যাতে render deterministic হয়। বাস্তব visual amplitude দিয়ে spring tune করো, শুধু parameter-এর নাম দিয়ে নয়।

## ৮. Ambient life

স্থির মুহূর্তেও সূক্ষ্ম জীবন্ততা থাকতে পারে:

- Whole-word float: 1 থেকে 2 px, দীর্ঘ Sine InOut cycle
- Background parallax: 2 থেকে 8 px scene জুড়ে
- Light intensity: 2 থেকে 5 শতাংশ পরিবর্তন
- Ring breathing: scale 0.995 থেকে 1.005
- Camera drift: 0.5 শতাংশ পর্যন্ত, খুব ধীর

Ambient movement মূল পাঠযোগ্যতা বোঝাতে ব্যবহার করবে না। Text-এর ভেতরের যুক্তাক্ষর না ভেঙে পুরো word বা line-এ transform দাও। Random wiggle-এর বদলে low-frequency coherent noise ভালো।

## ৯. Expression-ধাঁচের controller

একটি master controller অনেক element চালাতে পারে:

```text
MASTER.time
MASTER.scene_progress
MASTER.energy
MASTER.warmth
MASTER.focus_depth
MASTER.grain_amount
MASTER.seed
```

- `energy`: duration, amplitude ও stagger-এর সীমা নিয়ন্ত্রণ করে
- `warmth`: light ও grade নিয়ন্ত্রণ করে, restricted color নয়
- `focus_depth`: DOF ও bokeh নিয়ন্ত্রণ করে
- `seed`: particle ও noise পুনরায় একই ফল দেয়
- Parent/null rig-এর anchor point optical center বা meaningful pivot-এ থাকবে
- Controller বদলালে text shaping বা caption timing যেন না বদলায়

## ১০. Camera behavior

- Push-in: Sine InOut বা Quint Out, scene জুড়ে 1 থেকে 4 শতাংশ scale equivalent
- Drift: সর্বোচ্চ 0.5 শতাংশ, low-frequency
- Handheld ভাব: coherent noise, shake নয়
- Transition camera: Expo InOut, focus ও composition-এর motivation থাকবে
- Parallax: depth অনুযায়ী ভিন্ন displacement, তবে text সাধারণত সবচেয়ে stable plane-এ থাকবে
- Camera move-এর সময় motion blur বসবে, কিন্তু ছোট text পড়ার সময় blur কম রাখা যায়

## ১১. Motion blur

Default shutter angle 180 degree, অর্থাৎ exposure duration frame duration-এর অর্ধেক।

- প্রতি output frame-এ কমপক্ষে 8 temporal sub-sample
- দ্রুত গতি, rotation বা large displacement-এ adaptive 12, 16 বা তার বেশি
- Text-এর sub-sample shaping cache আলাদা রাখো, প্রতি sample-এ shaping বদলাবে না
- Particle-এর deterministic time position ব্যবহার করো
- Blur দিয়ে ভুল animation ঢাকবে না
- শেষ ও প্রথম frame-এ shutter sampling যেন অসম্পূর্ণ motion তৈরি না করে

## ১২. Velocity ও continuity QA

প্রতিটি keyframed move-এর জন্য মানসিক বা প্রকৃত velocity graph পরীক্ষা করো:

- শুরু ও শেষে অপ্রত্যাশিত spike নেই
- দুটি curve-এর সংযোগে হঠাৎ direction reversal নেই
- Scale ও position-এর settle একে অন্যকে বাতিল করছে না
- Overshoot-এর পরে bounce অনন্ত চলছে না
- Exit-এর গতি পরের scene-এর গতিকে সমর্থন করছে
- Frame-এ sample করার পরও curve-এর উদ্দেশ্য অক্ষুণ্ণ আছে
