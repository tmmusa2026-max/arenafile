# 14. Output Contract

## উদ্দেশ্য

AI যেন শুধু একটি ভিডিও নয়, পুনর্ব্যবহারযোগ্য নির্দেশনা ও যাচাইযোগ্য সিদ্ধান্ত দেয়। Brief-এ কোনো রিপোর্ট না চাইলে অভ্যন্তরীণভাবে তৈরি রাখা যায়, কিন্তু full production project-এ নিচের সব অংশ দিতে হবে।

## ১. Executive summary

- এক বাক্যে creative thesis
- ব্যবহৃত tool ও কেন
- Final duration, resolution, fps, codec
- Source audio অপরিবর্তিত কি না
- QA-এর সামগ্রিক অবস্থা
- Known limitation, থাকলে

## ২. দৃশ্যভিত্তিক timing table

| Scene | Audio start | Audio end | Visual in | Settle | Visual out | Exact SRT বা script line | Narrative role | Text recipe | SVG বা template | Primary easing | Duration | Stagger | Transition | Sound |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

সময় সবসময় এককসহ দাও। SRT guide এবং আসল audio time আলাদা হলে দুটিই উল্লেখ করো। `SVG বা template` কলামে template বলতে reusable scene structure বোঝায়, stock template নয়।

## ৩. Word timing table

| Scene | Index | Exact word | Start | End | Render frame | Method | Confidence | Caption cue | Note |
|---|---|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |  |  |

Estimated timing আসল acoustic detection বলে উপস্থাপন করবে না। Pause-এর তালিকা আলাদা দাও:

| Pause start | Pause end | Duration | Used for |
|---|---|---|---|
|  |  |  |  |

## ৪. Font ও color list

### Font

| Role | Family | Weight | File | License | Shaping test |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

### Color

| Role | Hex | Usage | Restriction |
|---|---|---|---|
|  |  |  |  |

Grade-এর পরে accent বদলে গেলে final target color ও creative grade-এর সম্পর্ক লিখো।

## ৫. Sound list

| Event | Scene | Visual sync point | Recipe | Duration | Level relative to voice | Synthesis method | License |
|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  | Original synthesis | Original |

Voice, music ও ambience-এর source আলাদা তালিকাভুক্ত করো। Voice effect level-এর মাপার পদ্ধতি সংক্ষেপে লিখো।

## ৬. Effect map

প্রতিটি ব্যবহৃত technique-এর জন্য:

| Effect বা technique | Scene ও সময় | দৃশ্যগত উদ্দেশ্য | Parameter | Tool বা equivalent পদ্ধতি | Proof frame | Status |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

অন্তত যে categories প্রযোজ্য হয়েছে সেগুলোর মধ্যে পরীক্ষা করো:

- Trim Paths
- Repeater
- Merge Paths
- Offset Paths
- Text range বা word selector equivalent
- Mask reveal
- Track matte
- 3D flip
- Shimmer
- Wiggle বা coherent ambient behavior
- Overshoot বা spring, tone মিললে
- Loop, প্রযোজ্য হলে
- Parent/null controller
- Camera push
- Parallax
- DOF, প্রযোজ্য হলে
- Motion blur
- Gradient ramp
- Bloom
- Drop shadow
- Grain
- Vignette
- Chromatic micro-effect
- LUT-equivalent grade

প্রযোজ্য নয় এমন technique জোর করে বসাবে না। Final production-এ কোনো required technique বাদ পড়লে `বাদ`, কারণ এবং বিকল্প লিখো। ব্যবহারকারী যদি একটি নির্দিষ্ট তালিকার সব technique এক ভিডিওতে চান, তখন সেগুলোর দৃশ্যগত proof বাধ্যতামূলক।

## ৭. Text animation recipe table

প্রতিটি ব্যবহৃত recipe-এর সব layer লিখো:

| Recipe | Layer | Start value | End value | Delay | Duration | Easing | Motion blur | Sound sync |
|---|---|---|---|---|---|---|---|---|
|  | Mask |  |  |  |  |  |  |  |
|  | Position |  |  |  |  |  |  |  |
|  | Blur |  |  |  |  |  |  |  |
|  | Scale |  |  |  |  |  |  |  |
|  | 3D |  |  |  |  |  |  |  |
|  | Shimmer |  |  |  |  |  |  |  |
|  | Chromatic |  |  |  |  |  |  |  |
|  | Underline |  |  |  |  |  |  |  |
|  | Glow |  |  |  |  |  |  |  |

Recipe যেন অন্য প্রজেক্টে parameters বদলে ব্যবহার করা যায়। Content-specific text hardcode করবে না।

## ৮. SVG asset map

| Asset ID | Scene | Semantic role | Generator | Construction | Animation operators | Source file | License |
|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  | Original |

কেন এই SVG নির্বাচন হয়েছে এক লাইনে লিখো। Data-driven asset হলে data source যোগ করো।

## ৯. Transition map

| Transition | From scene | To scene | Shared element | Duration | Easing | Pause used | Midpoint proof |
|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |

## ১০. প্রতি দৃশ্যের reuse note

প্রতিটি scene-এর নিচে ঠিক তিনটি সংক্ষিপ্ত লাইন দাও:

- রাজনৈতিক: এই structure কোন ধরনের বার্তা, quote, timeline বা resolve-এ ব্যবহার হবে এবং কী বদলাতে হবে।
- প্রোমো: কোন product moment, feature, comparison বা CTA-তে ব্যবহার হবে এবং কী বদলাতে হবে।
- ডকুমেন্টারি: কোন context, evidence, memory বা reflection-এ ব্যবহার হবে এবং কী বদলাতে হবে।

কোনো genre-এর সঙ্গে recipe সত্যিই মানানসই নয়, তাহলে জোর করে ব্যবহার লিখবে না। লিখবে কেন উপযুক্ত নয় এবং কোন অংশ আলাদাভাবে reuse করা যায়।

## ১১. Rejected decisions

সংক্ষিপ্ত টেবিল:

| Scene | বাদ দেওয়া effect বা design | কারণ | কী ব্যবহার হয়েছে |
|---|---|---|---|
|  |  |  |  |

এটি project review-কে শেখাবে কেন শুধু বেশি effect ভালো নয়।

## ১২. QA report

| Area | Check | Expected | Measured বা observed | Status | Correction |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

`not_tested` লুকাবে না। Fail ঠিক করে পুনরায় render ও proof দাও। যা এই পরিবেশে যাচাই অসম্ভব, তার স্পষ্ট কারণ দাও।

## ১৩. Executable production evidence

Full production বা Node delivery-তে নিচের ফাইল ও ফল যোগ করো:

| Evidence | Required content |
|---|---|
| Preflight | Schema, required files, content, glyph coverage, audio, dependencies, forbidden characters |
| Capability map | Native, equivalent, custom, partial, untested বা unsupported status |
| Continuity graph | Shared element, semantic handoff, headline overlap, proof frame |
| Font benchmark | Required words, glyph coverage, ink bounds, clipping, representative image |
| Audio benchmark | Actual বা synthetic ground truth, measured start ও end error, tolerance |
| Performance | Sample count, elapsed time, memory behavior, output frames, encoder settings |
| Responsive rules | Profile, safe area, headline fit, mask padding, particle ও camera scaling |
| Scored QC | Weighted area score, evidence level, automatic failure, warning, limitation |
| Recipe registry | Stable ID, version, changed parameters, migration note |

Final MP4 থেকে extracted proof frame আলাদা রাখো। Source proof এবং encoded proof এক ফাইল বলে দাবি করবে না।

## ১৪. Web media manifest

External photo, video clip বা audio ব্যবহার করলে `project/media-manifest.json` দাও। প্রতিটি asset-এর জন্য:

| Field | Requirement |
|---|---|
| Identity | Asset ID, scene ID, kind, semantic role |
| Source | Source page, direct file URL, local file, access time |
| Rights | Creator, license বা permission, license URL, attribution, allowed use |
| Editorial | Actual event, archival, illustrative বা not applicable এবং relevance |
| Use | Crop বা trim, source audio ব্যবহার হয়েছে কি না |
| Verification | Verified, unverified বা rejected এবং কারণ |

`watermark_removed` সবসময় `false` থাকবে। Verified relevant media না থাকলে SVG fallback ও কারণ লিখো। Generic footage-কে actual event footage বলা যাবে না।

## ১৫. Exact command log

`project/delivery-report.json`-এর `commands` array-তে শুধু প্রকৃত executed command লিখো:

| Command | Working directory | Status | Exit code | Log file |
|---|---|---|---|---|
|  |  |  |  |  |

`npm install` ও `npm run render` ছাড়াও QC, packaging বা publish command চালালে সেগুলো যোগ করো। Planned command এবং executed command আলাদা রাখো।

## ১৬. Public preview ও delivery

প্রকাশের জন্য:

- `index.html`: `project/public-preview.template.html` থেকে তৈরি native video preview
- `media/final.mp4`: direct playable MP4
- `delivery.zip`: final video, source, assets, licenses, proof, reports ও command log
- `delivery-report.json`: local paths, public URLs, verification status ও limitations

Connected বা approved hosting থাকলে এই তিনটি public URL আলাদা দাও: preview page, direct MP4 এবং delivery ZIP। Unauthenticated request দিয়ে access যাচাই করো। Actual playback না দেখলে `playback_observed: false` থাকবে। Hosting না থাকলে local delivery দাও এবং বাংলায় public upload অসম্পূর্ণ ও প্রয়োজনীয় access লিখো।

## ১৭. Final response structure

```text
সম্পন্ন বা আংশিক সম্পন্ন অবস্থা
Verified public preview URL, hosting থাকলে
Verified direct MP4 URL, hosting থাকলে
Verified delivery ZIP URL, hosting থাকলে
Local files, public upload না হলে
Exact executed render ও QC commands
Media, source, license ও attribution report
Documentation ও proof frames
Measured technical specs
Toolchain ও QA summary
Known limitations
পরবর্তী প্রজেক্টে কীভাবে ব্যবহার করবে
```

কোনো ফাইল তৈরি হয়নি, তাহলে তার link দেবে না। Public hosting করা হয়নি, তাহলে public link দাবি করবে না।
