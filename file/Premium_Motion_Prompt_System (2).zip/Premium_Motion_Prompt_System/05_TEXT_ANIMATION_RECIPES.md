# 05. Text Animation Recipes

## ব্যবহারের নিয়ম

Recipe হলো নামকরা সিদ্ধান্তের সমষ্টি, fixed template নয়। Text-এর দৈর্ঘ্য, scene duration, tone ও screen ratio অনুযায়ী parameter মানিয়ে নাও। Complex script-এ সব recipe word, phrase বা line level-এ প্রয়োগ হবে।

## ১. Recipe data structure

প্রতিটি নতুন recipe এই আকারে লিখো:

```text
নাম:
উদ্দেশ্য:
উপযুক্ত tone:
Animation unit:
Layer stack:
Start ও end value:
Duration:
Easing:
Stagger:
Motion blur:
Exit:
Sound:
Avoid when:
QA risk:
```

## ২. Nine-layer Master Reveal

এটি full-featured hero headline-এর reference। সব scene-এ সব নয়টি layer জোর করে বসানোর দরকার নেই। কমপক্ষে চারটি সুসংগত layer নাও এবং কোনটি বাদ গেল তার কারণ জানো।

| স্তর | শুরু | শেষ | Duration ও timing | Easing বা পদ্ধতি |
|---|---|---|---|---|
| Mask reveal | নিচের কিনারায় clipped | সম্পূর্ণ শব্দ দৃশ্যমান | 0.34 থেকে 0.52 s | Expo Out, soft mask edge 2 থেকে 6 px |
| Position | Y +12 থেকে +32 px | Y 0 | 0.34 থেকে 0.56 s | Expo Out |
| Blur | 16 px | 0 | মূল entry-এর প্রথম 60 শতাংশ | Expo Out বা custom blur falloff |
| Scale | 0.92 | 1.00 | 0.36 থেকে 0.58 s | Back Out শুধু উপযুক্ত tone-এ |
| Overshoot settle | 1.00 থেকে সর্বোচ্চ 1.04 | 1.00 | 0.16 থেকে 0.28 s | Damped Spring, stiffness 180, damping 22 |
| 3D flip | rotateX 8 degree | 0 | 0.38 থেকে 0.56 s | Quint Out, perspective 800 থেকে 1200 px equivalent |
| Shimmer sweep | বাইরে বাম | বাইরে ডান | 0.22 থেকে 0.36 s, settle-এর কাছে | Sine InOut, text alpha matte-এর ভেতরে |
| Chromatic spike | 0 px | 1 থেকে 2 px channel split, আবার 0 | মোট 2 থেকে 3 frame | Custom fast pulse, শুধু stamp impact-এ |
| Underline draw | trim 0 শতাংশ | trim 100 শতাংশ | 0.28 থেকে 0.45 s, entry overlap | Circ Out বা Expo Out |
| Glow pulse | 0 | ছোট peak, তারপর 0 | decay 0.40 s | Sine InOut peak, Expo Out decay |

Chromatic spike restrained বা palette-sensitive project-এ বাদ যেতে পারে। Scale overshoot grief, memorial বা grave scene-এ বাদ দাও। Shimmer খুব উজ্জ্বল বা বারবার চলবে না।

## ৩. Core recipe library

### T01: Mask Rise Stamp

- ব্যবহার: শক্তিশালী মূল শব্দ, hook, thesis
- Unit: whole word বা নিরাপদ orthographic word segment
- Layers: soft mask, Y rise, blur clear, scale settle, underline, optional shimmer
- Position: 24 px থেকে 0
- Scale: 0.94 থেকে 1.00, উপযুক্ত হলে 1.02 overshoot
- Duration: 0.42 s
- Easing: Expo Out, ছোট spring settle
- Exit: blur 10 px, Y -8 px, opacity 0, 0.24 s, Exit Accelerate
- Sound: soft stamp, settle frame-এ
- Avoid: অতিরিক্ত শোক বা খুব ধীর emotional scene

### T02: Split Phrase Authority

- ব্যবহার: দীর্ঘ headline যেখানে দুটি অর্থগত অংশ আছে
- Unit: সম্পূর্ণ অর্থগত word segment, যুক্তাক্ষরের ভেতরে নয়
- Layers: T01-এর সরল সংস্করণ, দুই segment-এর stagger
- Stagger: 0.08 s, পরেরটি 0.06 s
- Duration: প্রতি segment 0.40 থেকে 0.48 s
- Easing: Expo Out
- Composition: baseline ও optical gap পূর্বনির্ধারিত
- Avoid: segment ভাগ করলে শব্দের বানান বা shaping ভাঙে

### T03: Soft 3D Flip

- ব্যবহার: reflection, memory, ভাবনা, editorial turn
- Layers: perspective rotateX, blur, opacity, mask
- RotateX: 8 degree থেকে 0
- Blur: 12 px থেকে 0
- Opacity: 0 থেকে 1
- Duration: 0.48 s
- Easing: Quint Out
- Overshoot: নয়
- Exit: focus loss বা dignified fade-up
- QA: perspective-এর কারণে মাত্রা clip হচ্ছে না

### T04: Focus Pull In

- ব্যবহার: documentary, premium product detail, emotional reveal
- Layers: Gaussian বা lens blur, scale 1.02 থেকে 1.00, opacity, subtle glow
- Blur: 20 px থেকে 0
- Duration: 0.45 থেকে 0.65 s
- Easing: Quint Out
- Camera: প্রয়োজনে background-এর DOF-এর সঙ্গে সমন্বয়
- Avoid: blur খুব দেরি পর্যন্ত রাখা

### T05: Curtain Line Down

- ব্যবহার: ইতিহাস, তথ্য, editorial section
- Unit: whole line
- Mask: উপরের কিনারা থেকে নিচে reveal
- Position: Y -16 px থেকে 0
- Blur: 8 px থেকে 0
- Duration: 0.42 s
- Easing: Expo Out
- Supporting path: timeline বা rule-এর draw 0.08 s পরে শুরু
- Exit: mask নয়, আলাদা soft lift exit

### T06: Warm Glow Rise

- ব্যবহার: স্মৃতি, মমতা, আশা, human warmth
- Layers: mask, Y 12 px, blur 8 px, warm glow, gentle opacity
- Duration: 0.52 থেকে 0.68 s
- Easing: Quint Out
- Overshoot: নয়
- Ambient: 1 px slow float
- Glow: entry-এর পরে ধীরে জ্বলে, 0.6 থেকে 1.0 s
- Exit: glow কমে এবং text 8 px উপরে মিলিয়ে যায়

### T07: Restrained Mask Settle

- ব্যবহার: গম্ভীর শেষ বাক্য, স্মরণ, sensitive statement
- Layers: soft mask, Y 10 px, blur 6 px, opacity
- Duration: 0.48 থেকে 0.60 s
- Easing: Quint Out
- Scale: 1.00, অথবা 0.995 থেকে 1.00
- Overshoot, chromatic spike, shimmer: সাধারণত নয়
- Hold: শেষ শব্দ পর্যন্ত
- Exit: audio অনুমতি দিলে অত্যন্ত নরম fade, অন্যথায় শেষ frame পর্যন্ত জীবন্ত

### T08: Particle Memory Exit

- ব্যবহার: ভুলে যাওয়া, ক্ষয়, অতীতের অংশ, abstract transition
- Entry: T03 বা T04
- Exit: shaped text-এর alpha থেকে point sample তৈরি, text blur বাড়ে, points disperse
- Duration: 0.55 থেকে 1.20 s, pause ও scene length অনুযায়ী
- Easing: Expo Out for release, Sine InOut for drift
- DOF: দূরের points-এর bokeh radius বাড়ে
- Handoff: points পরের scene-এর path বা grid-এ converge করতে পারে
- Avoid: মূল তথ্য পড়ার আগে ভেঙে দেওয়া, অতিরিক্ত glitter

### T09: Outline To Fill

- ব্যবহার: product name, ব্র্যান্ড statement, technical reveal
- Layers: thin stroke draw, fill opacity, soft mask, subtle scale
- Stroke: shaped glyph outline বা safe vector equivalent
- Fill: 0 থেকে 1
- Duration: 0.55 s
- Easing: Circ Out for outline, Expo Out for fill
- QA: যুক্তাক্ষরের outline gaps ও stroke clipping
- Avoid: ফন্টের ভেতরের counters বন্ধ করে দেওয়া

### T10: Slice Assemble

- ব্যবহার: structural change, energetic promo, mechanical precision
- Unit: whole word-এর 2 থেকে 3 rectangular clip slice
- Offset: প্রতি slice X বা Y 8 থেকে 20 px
- Blur: 6 px থেকে 0
- Stagger: 0.06 থেকে 0.04 s
- Duration: 0.36 s
- Easing: Expo Out
- Final state: সব slice pixel-perfect মিলবে
- Avoid: Bengali glyph-এর অংশ আলাদা logical text layer হিসেবে ভাগ করা, এখানে শুধু visual clip slice

### T11: Variable Weight Resolve

- ব্যবহার: দুর্বল থেকে দৃঢ়, তথ্য থেকে সিদ্ধান্ত, compatible Latin বা Bengali variable font
- Weight: 350 থেকে 700, project অনুযায়ী
- Scale: 0.99 থেকে 1.00
- Blur: 4 px থেকে 0
- Duration: 0.50 s
- Easing: Quint Out
- Layout: advance width পরিবর্তনের জন্য stable anchor ও reserved width
- QA: প্রতি sample-এর shaping ও line break
- Avoid: fallback font, unstable glyph interpolation

### T12: Word Swap Morph

- ব্যবহার: contrast, before-after, দুটি সম্পর্কিত ধারণা
- First exit: blur 8 px, Y -8 px, opacity 0
- Shared mask: আগের word-এর ink বা underline পরের word-এর mask হয়
- Second entry: Y 12 px, blur 8 px, opacity 0 থেকে 1
- Duration: মোট 0.42 থেকে 0.60 s
- Easing: Expo InOut for handoff, Expo Out for second settle
- Avoid: অসংযুক্ত শব্দের forced morph

### T13: Caption Word Emphasis

- ব্যবহার: spoken caption
- Base: stable off-white line
- Active color: project accent
- Scale: 1.00 থেকে 1.05
- Duration: 0.10 s
- Easing: Emphasis Soft
- Previous word: একই curve-এ base state-এ ফিরবে
- Restricted word: brief অনুযায়ী আলাদা color
- Layout: line jump নয়, word-local anchor
- Timing: actual word onset

### T14: Quote Presence

- ব্যবহার: সোর্সে থাকা উদ্ধৃতি
- Quote mark: background large vector, opacity 0 থেকে 0.08
- Quote mark scale: 0.92 থেকে 1.00, tone মিললে ছোট Back Out
- Main line: T03 বা T07
- Parallax: quote mark text-এর তুলনায় 20 থেকে 40 শতাংশ কম নড়ে
- Duration: 0.45 থেকে 0.65 s
- Avoid: সোর্সে quote না থাকলে নতুন quote attribution

### T15: Annotation Lock

- ব্যবহার: product feature, diagram label, documentary source label
- Text: mask rise 12 px, blur 4 px
- Connector: Trim Paths বা path draw
- Anchor dot: scale 0.8 থেকে 1.00, কোনো bounce প্রয়োজন নয়
- Stagger: dot 0, connector +0.04 s, text +0.08 s
- Duration: 0.32 থেকে 0.44 s
- Easing: Expo Out
- Exit: connector retract নয়, আলাদা soft de-emphasis ভালো

### T16: List Cascade

- ব্যবহার: অনুমোদিত সংক্ষিপ্ত তালিকা
- Unit: line বা list item
- Position: Y 16 px
- Opacity: 0 থেকে 1
- Blur: 6 px থেকে 0
- Stagger: 0.10, 0.08, 0.06 s
- Duration: প্রতি item 0.34 s
- Active rule: বক্তার item-এর সঙ্গে সামান্য marker move
- Avoid: 7 শব্দের বেশি দীর্ঘ item ছোট screen-এ, একসঙ্গে অতিরিক্ত list

### T17: Editorial Line Reveal

- ব্যবহার: দীর্ঘ literary বা documentary line
- Unit: phrase-aware line
- Mask: soft rectangle
- Position: Y 18 px
- Blur: 10 px
- Duration: 0.52 s
- Easing: Quint Out
- Supporting: খুব পাতলা baseline rule বা quote motif
- Avoid: প্রতি line-এ oversized motion

### T18: Precision Data Label

- ব্যবহার: কেবল অনুমোদিত numeric বা categorical information
- Unit: সম্পূর্ণ value বা label
- Entry: clip reveal, 8 px rise, blur 4 px
- Duration: 0.28 থেকে 0.38 s
- Easing: Expo Out
- Counter: source value না বদলে interpolation শুধু presentation হিসেবে, brief অনুমোদন করলে
- Alignment: tabular numerals উপলব্ধ হলে
- Avoid: অনুমোদনহীন number, fake counter, অপ্রয়োজনীয় ticking sound

### T19: Kinetic Emphasis Hold

- ব্যবহার: বাক্যের মধ্যে বিশেষ শব্দ পুনরায় জোর দেওয়া
- Entry: ছোট scale 0.98 থেকে 1.00, glow, underline
- Hold: 1 px ambient float
- Emphasis: একবার 1.02 scale, 0.18 s
- Easing: Emphasis Soft
- Avoid: বারবার pulse, caption-এর সাথে দ্বন্দ্ব

### T20: Quiet End Hold

- ব্যবহার: শেষ বাক্য, memorial, unresolved reflection
- Entry: T07
- Hold: text sharp, background-এর motif settle
- Final motion: 0.5 থেকে 1 px drift বা 2 শতাংশ light breathing
- Fade: কেবল audio ও brief অনুমতি দিলে
- Easing: Sine InOut
- Avoid: হঠাৎ black cut, logo যোগ করা, নতুন CTA তৈরি করা

## ৪. Texture ও distortion variants

এগুলো শুধু উপযুক্ত tone-এ আলাদা recipe হিসেবে যোগ করো:

- Liquid displacement: abstract fluid theme, whole-word displacement map
- Roughened editorial edge: documentary texture, glyph readability অক্ষুণ্ণ
- Shatter: ধ্বংস বা বিচ্ছিন্নতার স্পষ্ট narrative থাকলে, violence চিত্রিত নয়
- Glitch: digital fault বা cyber subject হলে, 2 থেকে 4 frame, সংযত
- Wave warp: audio বা wave metaphor হলে, ছোট amplitude
- Echo trail: speed বা memory trail হলে, text পড়ার পরে

কোনো variant মূল 9-layer recipe-এর ওপর automatic add-on নয়। Narrative justification ছাড়া ব্যবহার নয়।

## ৫. Recipe selection quick map

| প্রয়োজন | প্রথম পছন্দ | বিকল্প |
|---|---|---|
| শক্তিশালী শুরু | T01 | T02 |
| গম্ভীর প্রকাশ | T07 | T04 |
| সাহিত্যিক ভাব | T03 | T17 |
| ইতিহাস ও সময় | T05 | T15 |
| উষ্ণ আবেগ | T06 | T20 |
| ক্ষয় বা ভুল | T08 | T04 with soft exit |
| Product precision | T15 | T10 |
| Feature list | T16 | T15 |
| Brand statement | T09 | T01 |
| Contrast | T12 | T10 |
| Caption | T13 | নির্দিষ্ট caption variant |
| শেষ মুহূর্ত | T20 | T07 |

## ৬. Recipe QA

প্রতিটি recipe-এর পরে পরীক্ষা করো:

- Animation unit কি shaping-safe?
- Mask কি ink bounds-এর সব অংশ ধরেছে?
- Blur শেষ হওয়ার পরে text কি পুরোপুরি sharp?
- Scale বা rotation-এ কি কোনো অংশ clip হচ্ছে?
- Shimmer কি text-এর বাইরে ফাঁস হচ্ছে?
- Chromatic split কি restricted color তৈরি করছে?
- Hold কি পড়ার জন্য যথেষ্ট?
- Exit কি entry-এর অর্থহীন reverse?
- Sound কি optical event-এর সঙ্গে মিলছে?
- Recipe কি আগের scene-এর হুবহু পুনরাবৃত্তি?
