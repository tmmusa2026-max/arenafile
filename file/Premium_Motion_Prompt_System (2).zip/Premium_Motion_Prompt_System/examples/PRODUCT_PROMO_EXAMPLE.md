# উদাহরণ: Product Promo

এটি generic নির্বাচন কাঠামো। কোনো বাস্তব পণ্য, feature বা UI দাবি এখানে তৈরি করা হয়নি।

## ধরে নেওয়া brief

- উদ্দেশ্য: একটি অনুমোদিত পণ্যের মূল ব্যবহার দ্রুত বোঝানো
- Tone: clear, confident, precise
- Visual: original vector UI, brand palette, কম decoration
- Audio: voice-over, subtle UI confirmation অনুমোদিত
- Delivery: wide এবং vertical দুই সংস্করণ

## AI-এর creative thesis

`প্রতিটি motion পণ্যের একটি সম্পর্ক বোঝাবে। কার্ড, connector ও camera একই spatial system-এ থাকবে, যাতে feature আলাদা sticker না লাগে।`

## দৃশ্য নির্বাচন

| Scene | Source role | Visual problem | নির্বাচন | কারণ |
|---|---|---|---|---|
| S01 | `[মূল প্রতিশ্রুতি]` | প্রথম মুহূর্তে পণ্য ও বার্তার সম্পর্ক দরকার | T01 Mask Rise + V11 UI Card + X04 Ink Mask | headline থেকে product frame প্রকাশ পায় |
| S02 | `[প্রধান feature]` | পুরো UI নয়, নির্দিষ্ট অংশে মনোযোগ দরকার | T15 Annotation Lock + V13 Callout + C03 Depth Reveal | guided focus, পড়ার স্থিরতা |
| S03 | `[দ্বিতীয় feature বা প্রক্রিয়া]` | আগের feature থেকে পরের ধাপে যেতে হবে | V08 Flow Path + T16 List Cascade + X08 Path Continuation | connector নিজেই transition |
| S04 | `[ফল বা সুবিধা]`, source-approved | feature থেকে outcome-এ অর্থপূর্ণ পরিবর্তন দরকার | V24 Grid To Product Morph + T04 Focus Pull | structure resolve হয় |
| S05 | `[CTA]`, brief-এ থাকলে | স্পষ্ট hold ও পড়ার জায়গা দরকার | T07 বা T01 restrained + stable product frame | অনুমোদিত CTA, নতুন copy নয় |

## Vertical adaptation

- UI card-এর aspect ratio বদলে crop নয়।
- Feature callout পাশের বদলে নিচে আসতে পারে।
- Headline দুই line-এ ভাঙবে, phrase বজায় থাকবে।
- Caption নিচের platform UI-এর ওপরে safe zone-এ থাকবে।
- Camera travel কমানো হবে, feature size বাড়ানো হবে।

## Sound reasoning

- S01-এর hero settle-এ একবার soft stamp, voice mask না করলে।
- S02-এর actual confirmation state-এ S05 UI confirmation।
- List-এর প্রতি item-এ tick নয়।
- Flow transition-এ whoosh নয়।

## বাদ দেওয়া design

| বাদ দেওয়া | কারণ |
|---|---|
| Heavy DOF on UI | feature পড়া কঠিন হয় |
| Fake cursor clicking | অনুমোদিত functionality না থাকলে বিভ্রান্তিকর |
| Particle explosion | product comprehension-এর সঙ্গে সম্পর্ক নেই |
| Full-screen glitch | precision ও trust-এর বিরুদ্ধে |
| একই wide frame center crop | vertical-এ callout ও caption কেটে যায় |

## Reuse

- রাজনৈতিক: callout ও path continuity তথ্য বা quote explanation-এ ব্যবহার করা যায়, product metaphor বাদ।
- প্রোমো: পুরো structure সরাসরি reusable, কিন্তু UI ও feature flow নতুন content থেকে বানাতে হবে।
- ডকুমেন্টারি: device বা process বোঝানোর অংশে V11, V13 ও X08 উপযোগী।
