'use strict';

const fs = require('fs');
const path = require('path');
const Ajv = require('ajv/dist/2020');
const fontkit = require('fontkit');
const ffmpegPath = require('ffmpeg-static');
const ffprobe = require('ffprobe-static');
const {readWav} = require('./audio-utils');

const root = path.resolve(__dirname, '../..');
const reportDir = path.join(__dirname, '../reports');
fs.mkdirSync(reportDir, {recursive: true});
const checks = [];
const add = (id, pass, expected, measured, severity = 'error') => checks.push({id, status: pass ? 'pass' : severity === 'warning' ? 'warning' : 'fail', expected, measured});
const readJson = rel => JSON.parse(fs.readFileSync(path.join(root, rel), 'utf8'));

function validateSchemas() {
  const ajv = new Ajv({allErrors: true, strict: false});
  const cases = [
    ['project_example_schema', 'schemas/project.schema.json', 'project/project.example.json', 'generic project example'],
    ['scene_plan_example_schema', 'schemas/scene-plan.schema.json', 'examples/machine-readable/scene-plan.example.json', 'generic scene plan example'],
    ['word_timing_example_schema', 'schemas/word-timing.schema.json', 'examples/machine-readable/word-timing.example.json', 'synthetic word timing example'],
    ['media_manifest_schema', 'schemas/media-manifest.schema.json', 'project/media-manifest.json', 'empty media manifest template'],
    ['delivery_report_schema', 'schemas/delivery-report.schema.json', 'project/delivery-report.json', 'unpublished delivery report template']
  ];
  for (const [id, schemaFile, dataFile, label] of cases) {
    const valid = ajv.validate(readJson(schemaFile), readJson(dataFile));
    add(id, valid, `valid ${label}`, valid ? 'valid' : ajv.errorsText(ajv.errors));
    ajv.errors = null;
  }
}

function validateFiles() {
  const required = [
    'package.json', 'package-lock.json', 'README.md', 'MASTER_PROMPT.md', 'PROMPT_COMPACT.md', 'ROUTER.md',
    'validation/src/benchmark-fonts.js', 'validation/src/benchmark-audio.js', 'validation/src/responsive.js',
    'validation/tests/rules.test.js', 'validation/tests/delivery.test.js', 'validation/tests/tmix.test.js',
    'libraries/media-sourcing.json', 'libraries/public-delivery.json',
    'project/media-manifest.json', 'project/delivery-report.json', 'project/public-preview.template.html',
    'validation/assets/audio/audio-alignment-benchmark.wav',
    'validation/assets/fonts/anek-bangla/AnekBangla-700.ttf',
    'validation/assets/fonts/hind-siliguri/HindSiliguri-Medium.ttf',
    'validation/assets/fonts/anek-bangla/OFL.txt',
    'validation/assets/fonts/hind-siliguri/OFL.txt'
  ];
  for (let i = 1; i <= 20; i++) {
    const prefix = String(i).padStart(2, '0') + '_';
    if (!fs.readdirSync(root).some(name => name.startsWith(prefix) && name.endsWith('.md'))) required.push(`missing_${prefix}document`);
  }
  for (const rel of required) add(`file_${rel}`, fs.existsSync(path.join(root, rel)), 'file exists', rel);
  add('bundled_ffmpeg', fs.existsSync(ffmpegPath), 'npm bundled FFmpeg executable', ffmpegPath);
  add('bundled_ffprobe', fs.existsSync(ffprobe.path), 'npm bundled ffprobe executable', ffprobe.path);
}

function validateRouter() {
  const router = readJson('libraries/router-rules.json');
  const missing = [];
  const check = value => {
    const rel = value.split('#')[0];
    if (rel.startsWith('validation/reports/')) return;
    if (/\.(md|json)$/.test(rel) && !fs.existsSync(path.join(root, rel))) missing.push(value);
  };
  router.always_load.forEach(check);
  Object.values(router.task_modules).forEach(group => group.forEach(check));
  Object.values(router.genre_modules).forEach(group => group.forEach(check));
  add('router_targets', missing.length === 0, 'all source router targets exist; generated reports excluded', missing.length ? missing.join(', ') : 'all source targets exist');
}

function validateFonts() {
  const corpus = ['স্মৃতি', 'ইতিহাস', 'মায়া', 'আগামী', 'ক্ষুধা', 'জ্ঞান', 'শ্রদ্ধা', 'উদ্ভিদ', 'ব্যাখ্যা', 'সংকল্প', 'দৃঢ়তা', 'গণঅভ্যুত্থানে', 'ছুঁয়েছে', 'পোলার'];
  const files = ['validation/assets/fonts/anek-bangla/AnekBangla-700.ttf', 'validation/assets/fonts/hind-siliguri/HindSiliguri-Medium.ttf'];
  for (const rel of files) {
    const font = fontkit.openSync(path.join(root, rel));
    const missing = new Set();
    for (const text of corpus) for (const ch of text) {
      if (!/\s/.test(ch) && !font.hasGlyphForCodePoint(ch.codePointAt(0))) missing.add(ch);
    }
    add(`glyphs_${rel}`, missing.size === 0, 'all benchmark Bengali codepoints covered', missing.size ? [...missing].join('') : `${font.familyName}, complete corpus`);
  }
}

function validateAudio() {
  const audio = readWav(path.join(root, 'validation/assets/audio/audio-alignment-benchmark.wav'));
  add('benchmark_audio_duration', Math.abs(audio.duration - 4) <= 1 / audio.sampleRate, '4 second synthetic benchmark', `${audio.duration} seconds`);
  add('benchmark_audio_format', audio.channels === 2 && audio.sampleRate === 48000, '48 kHz stereo PCM', `${audio.sampleRate} Hz, ${audio.channels} channels`);
}

function validateNoReferenceArtifacts() {
  const forbidden = [];
  let sourceBytes = 0;
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, {withFileTypes: true})) {
      if (['node_modules', '.cache', '.git', '__pycache__'].includes(entry.name)) continue;
      const full = path.join(dir, entry.name);
      const rel = path.relative(root, full);
      if (entry.isDirectory()) walk(full);
      else {
        sourceBytes += fs.statSync(full).size;
        if (/\.(mp4|mov|webm|avi)$/i.test(entry.name) || /proof-sheet|encoded_S0|golden-reference/i.test(rel)) forbidden.push(rel);
      }
    }
  }
  walk(root);
  add('reference_video_removed', forbidden.length === 0, 'no reference video, legacy reference folder or visual reference proof', forbidden.length ? forbidden.join(', ') : 'none');
  add('source_payload_under_25mb', sourceBytes < 25000000, 'source payload below 25,000,000 bytes before ZIP compression', `${sourceBytes} bytes`);
  const scripts = readJson('package.json').scripts || {};
  add('no_reference_render_command', !scripts.render && !scripts.proof && !scripts.qc, 'no reference renderer or render command', Object.keys(scripts).join(', '));
}

function validatePublicDeliveryTemplate() {
  const html = fs.readFileSync(path.join(root, 'project/public-preview.template.html'), 'utf8');
  add('public_preview_video_controls', /<video\b[^>]*\bcontrols\b/i.test(html) && html.includes('src="media/final.mp4"'), 'native video controls and relative MP4 source', 'template checked');
  add('public_preview_download_links', html.includes('href="media/final.mp4"') && html.includes('href="delivery.zip"'), 'direct MP4 and delivery ZIP links', 'template checked');
  add('public_preview_relative_assets', !/(?:src|href)="https?:\/\//i.test(html), 'no remote asset dependency in preview template', 'relative paths only');
  add('public_preview_self_contained', !/<script\b/i.test(html) && !/<link\b[^>]*rel="stylesheet"/i.test(html), 'inline styling and no script dependency', 'self-contained template');
  const delivery = readJson('project/delivery-report.json');
  const urls = [delivery.artifacts.public_preview_url, delivery.artifacts.public_video_url, delivery.artifacts.public_archive_url];
  add('delivery_template_unpublished', delivery.status === 'not_started' && urls.every(value => value === null), 'template contains no fake published URLs', `${delivery.status}, all public URLs null`);
}

function validateTextFiles() {
  const violations = [];
  const mixed = [];
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, {withFileTypes: true})) {
      if (['node_modules', '.cache', '.git', 'proof'].includes(entry.name)) continue;
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (/\.(md|json|js|csv|txt|html)$/.test(entry.name)) {
        const text = fs.readFileSync(full, 'utf8');
        if (text.includes('\u2014')) violations.push(path.relative(root, full));
        text.split(/\r?\n/).forEach((line, index) => {
          if (/[\u0980-\u09ff][A-Za-z]|[A-Za-z][\u0980-\u09ff]/.test(line)) mixed.push(`${path.relative(root, full)}:${index + 1}`);
        });
      }
    }
  }
  walk(root);
  add('no_em_dash', violations.length === 0, 'no em dash in text deliverables', violations.length ? violations.join(', ') : 'none');
  add('no_accidental_mixed_script', mixed.length === 0, 'no immediate Bengali-Latin mixed-script tokens', mixed.length ? mixed.join(', ') : 'none');
}

function main() {
  validateSchemas();
  validateFiles();
  validateRouter();
  validateFonts();
  validateAudio();
  validateNoReferenceArtifacts();
  validatePublicDeliveryTemplate();
  validateTextFiles();
  const failed = checks.filter(c => c.status === 'fail');
  const warnings = checks.filter(c => c.status === 'warning');
  const report = {
    purpose: 'Prompt and validation toolkit only, no reference video or visual style template',
    pass: failed.length === 0,
    checks,
    summary: {total: checks.length, passed: checks.filter(c => c.status === 'pass').length, failed: failed.length, warnings: warnings.length}
  };
  fs.writeFileSync(path.join(reportDir, 'preflight.json'), JSON.stringify(report, null, 2) + '\n');
  const lines = ['# Preflight Report', '', 'Prompt and validation toolkit only. No reference video or visual style template.', '', `Overall: ${report.pass ? 'pass' : 'fail'}`, '', '| Check | Status | Expected | Measured |', '|---|---|---|---|'];
  for (const c of checks) lines.push(`| ${c.id} | ${c.status} | ${String(c.expected).replaceAll('|', '\\|')} | ${String(c.measured).replaceAll('|', '\\|')} |`);
  fs.writeFileSync(path.join(reportDir, 'preflight.md'), lines.join('\n') + '\n');
  console.log(`Preflight: ${report.summary.passed}/${report.summary.total} passed, ${failed.length} failed, ${warnings.length} warnings`);
  if (failed.length) {
    console.error(failed);
    process.exitCode = 1;
  }
}

main();
