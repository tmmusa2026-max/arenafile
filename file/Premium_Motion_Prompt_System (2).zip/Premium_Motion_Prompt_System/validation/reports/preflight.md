# Preflight Report

Prompt and validation toolkit only. No reference video or visual style template.

Overall: pass

| Check | Status | Expected | Measured |
|---|---|---|---|
| project_example_schema | pass | valid generic project example | valid |
| scene_plan_example_schema | pass | valid generic scene plan example | valid |
| word_timing_example_schema | pass | valid synthetic word timing example | valid |
| media_manifest_schema | pass | valid empty media manifest template | valid |
| delivery_report_schema | pass | valid unpublished delivery report template | valid |
| file_package.json | pass | file exists | package.json |
| file_package-lock.json | pass | file exists | package-lock.json |
| file_README.md | pass | file exists | README.md |
| file_MASTER_PROMPT.md | pass | file exists | MASTER_PROMPT.md |
| file_PROMPT_COMPACT.md | pass | file exists | PROMPT_COMPACT.md |
| file_ROUTER.md | pass | file exists | ROUTER.md |
| file_validation/src/benchmark-fonts.js | pass | file exists | validation/src/benchmark-fonts.js |
| file_validation/src/benchmark-audio.js | pass | file exists | validation/src/benchmark-audio.js |
| file_validation/src/responsive.js | pass | file exists | validation/src/responsive.js |
| file_validation/tests/rules.test.js | pass | file exists | validation/tests/rules.test.js |
| file_validation/tests/delivery.test.js | pass | file exists | validation/tests/delivery.test.js |
| file_validation/tests/tmix.test.js | pass | file exists | validation/tests/tmix.test.js |
| file_libraries/media-sourcing.json | pass | file exists | libraries/media-sourcing.json |
| file_libraries/public-delivery.json | pass | file exists | libraries/public-delivery.json |
| file_project/media-manifest.json | pass | file exists | project/media-manifest.json |
| file_project/delivery-report.json | pass | file exists | project/delivery-report.json |
| file_project/public-preview.template.html | pass | file exists | project/public-preview.template.html |
| file_validation/assets/audio/audio-alignment-benchmark.wav | pass | file exists | validation/assets/audio/audio-alignment-benchmark.wav |
| file_validation/assets/fonts/anek-bangla/AnekBangla-700.ttf | pass | file exists | validation/assets/fonts/anek-bangla/AnekBangla-700.ttf |
| file_validation/assets/fonts/hind-siliguri/HindSiliguri-Medium.ttf | pass | file exists | validation/assets/fonts/hind-siliguri/HindSiliguri-Medium.ttf |
| file_validation/assets/fonts/anek-bangla/OFL.txt | pass | file exists | validation/assets/fonts/anek-bangla/OFL.txt |
| file_validation/assets/fonts/hind-siliguri/OFL.txt | pass | file exists | validation/assets/fonts/hind-siliguri/OFL.txt |
| bundled_ffmpeg | pass | npm bundled FFmpeg executable | /home/user/Premium_Motion_Prompt_System/node_modules/ffmpeg-static/ffmpeg |
| bundled_ffprobe | pass | npm bundled ffprobe executable | /home/user/Premium_Motion_Prompt_System/node_modules/ffprobe-static/bin/linux/x64/ffprobe |
| router_targets | pass | all source router targets exist; generated reports excluded | all source targets exist |
| glyphs_validation/assets/fonts/anek-bangla/AnekBangla-700.ttf | pass | all benchmark Bengali codepoints covered | Anek Bangla, complete corpus |
| glyphs_validation/assets/fonts/hind-siliguri/HindSiliguri-Medium.ttf | pass | all benchmark Bengali codepoints covered | Hind Siliguri Medium, complete corpus |
| benchmark_audio_duration | pass | 4 second synthetic benchmark | 4 seconds |
| benchmark_audio_format | pass | 48 kHz stereo PCM | 48000 Hz, 2 channels |
| reference_video_removed | pass | no reference video, legacy reference folder or visual reference proof | none |
| source_payload_under_25mb | pass | source payload below 25,000,000 bytes before ZIP compression | 3418631 bytes |
| no_reference_render_command | pass | no reference renderer or render command | preflight, generate:benchmark, benchmark:fonts, benchmark:audio, test:rules, test:delivery, test:tmix |
| public_preview_video_controls | pass | native video controls and relative MP4 source | template checked |
| public_preview_download_links | pass | direct MP4 and delivery ZIP links | template checked |
| public_preview_relative_assets | pass | no remote asset dependency in preview template | relative paths only |
| public_preview_self_contained | pass | inline styling and no script dependency | self-contained template |
| delivery_template_unpublished | pass | template contains no fake published URLs | not_started, all public URLs null |
| no_em_dash | pass | no em dash in text deliverables | none |
| no_accidental_mixed_script | pass | no immediate Bengali-Latin mixed-script tokens | none |
