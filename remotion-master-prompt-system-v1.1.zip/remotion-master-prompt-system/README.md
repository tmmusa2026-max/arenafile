# Remotion Motion Graphics Master Prompt System v1.1

এই প্যাকেজটি একটি **সম্পূর্ণ প্রম্পট সিস্টেম** — যেকোনো AI Agent-কে দিলে সে আপনার transcript (TXT/SRT) থেকে প্রফেশনাল, After Effects-মানের Motion Graphics Video তৈরি করবে (সম্পূর্ণ Remotion project + ZIP ডেলিভারি সহ)।

## কী কী আছে

| ফাইল | কী করে |
|---|---|
| **`MASTER-PROMPT.md`** | মূল প্রম্পট — এটিই এজেন্টকে দেবেন। সব নিয়ম, workflow, ইনপুট সিস্টেম, tutorial system, SRT sync, ডেলিভারি |
| **`annexes/A-style-library.md`** | ১৬টি scene স্টাইল + সিলেকশন গাইড |
| **`annexes/B-text-animations.md`** | ২২টি After Effects-মানের টেক্সট অ্যানিমেশন প্রিসেট (spec + বাংলা-সেফটি) |
| **`annexes/C-icon-symbol-system.md`** | Icon/Symbol সিস্টেম (SVG, animation patterns) |
| **`annexes/D-photo-image-pipeline.md`** | ছবি সোর্সিং (stock/AI) + ১৫টি photo treatment + QA |
| **`annexes/E-transitions-post-grade.md`** | ১২টি ট্রানজিশন + background সিস্টেম + post/grade স্ট্যাক |
| **`annexes/F-motion-sound-principles.md`** | Motion principles, camera language, sound timing |
| **`annexes/G-tutorial-interaction-kit.md`** | Tutorial-এর cursor/click/step সিস্টেম + honesty tiers |
| **`annexes/H-component-recipes.md`** | ২০টি কপি-পেস্ট কোড recipe (Remotion component) |
| **`annexes/I-sfx-recipes.md`** | SFX সিন্থেসিস রেসিপি + audio QA |
| **`annexes/J-master-qa-checklist.md`** | ডেলিভারি-পূর্ব সম্পূর্ণ চেকলিস্ট |
| **`annexes/K-word-sync-reveal.md`** | **নতুন (v1.1):** spoken লেখা ধীরে, শব্দ-by-শব্দ, SRT/ভয়েসের গতিতে ওঠার সিস্টেম |
| **`templates/theme.ts`** | থিম টেমপ্লেট (রং/ফন্ট/easing/spring/tokens) |
| **`templates/project-structure.md`** | প্রজেক্ট ফোল্ডার কাঠামো + naming + scripts |

## কীভাবে ব্যবহার করবেন

1. নতুন কোনো video বানাতে চাইলে AI-কে বলুন: **"এই MASTER-PROMPT.md অনুযায়ী কাজ করো"** — সঙ্গে আপনার transcript (TXT এবং/অথবা SRT) দিন।
2. সঙ্গে `annexes/` ও `templates/` ফোল্ডারটি দিন (AI ফাইল পড়তে পারলে) — অথবা প্রয়োজন অনুযায়ী সংশ্লিষ্ট Annex ফাইলের টেক্সট paste করুন।
3. ঐচ্ছিক: লোগো, ছবি, SFX, voiceover (`public/voiceover.mp3`) — থাকলে আরও ভালো ফল।
4. AI শুধু **একটাই প্রশ্ন করবে: কালার স্কিম** (৪–৬টি স্কিম দেখিয়ে)। বাকি সব সে নিজে ঠিক করবে।
5. ডিফল্টে **প্রিভিউ মোড**: আপনি পেবেন সম্পূর্ণ project ZIP + ৩টি PowerShell কমান্ড।
6. ভিডিও রেন্ডার চাইলে বলুন **"রেন্ডার করো"**।

## Windows PowerShell-এ সেটআপ (যে প্রজেক্ট AI দেবে)

```powershell
cd <প্রজেক্ট ফোল্ডার>
npm install
npx remotion studio      # প্রিভিউ
npx remotion render src/index.ts Main out/video.mp4 --codec h264 --crf 17
```
বিস্তারিত নির্দেশনা প্রজেক্টের `README.md`-তে থাকবে।

## নকশার সিদ্ধান্ত (v1.1)

- **ইনপুট:** TXT = content source, SRT = timing source (সঙ্গে থাকলে); দুটোই না থাকলে দেওয়া কোনটি সেটিই ভিত্তি
- **রঙ:** একটাই প্রশ্ন (emerald/lime identity থেকে ৪–৬টি স্কিম); ইউজার আগে রং দিলে প্রশ্ন নেই
- **ছবি:** ইউজারের ছবি > stock (Pexels/Unsplash/Pixabay) > AI-generated > graphic fallback
- **বাংলা টেক্সট:** অক্ষরে কখনো ভাঙবে না — সব অ্যানিমেশন শব্দ/লাইন স্তরে
- **Word-Sync (v1.1):** spoken লেখা কখনো একসঙ্গে ঝটকায় নয় — SRT/ভয়েসের গতিতে একটি একটি শব্দ করে ধীরে ওঠে (word-timestamp থাকলে নিখুঁত; শুধু SRT হলে cue-র ভেতরে অনুপাতিক অনুমান)
- **Tutorial:** থাকলে ধাপে ধাপে দৃশ্যমান demonstration বাধ্যতামূলক (কল্পিত UI নয়)

## লাইসেন্স নোট

- এই প্রম্পট সিস্টেম আপনার নিজের ব্যবহারের জন্য — যেমন চান তেমন সম্পাদনা করতে পারেন।
- প্রজেক্টে ব্যবহৃত icon (Lucide/Feather/Heroicons), stock ফটো (Pexels/Unsplash/Pixabay) ও font-এর নিজ নিজ লাইসেন্স মানতে হবে — AI প্রতিটির source+license `ASSETS.md`-তে লিখবে।
