# Annex F — Motion Principles, Camera Language ও Sound Timing

## ১. Motion Principles (AE → Remotion)

| নীতি | নিয়ম | Remotion-এ |
|---|---|---|
| Anticipation | বড় মুভের আগে ছোট বিপরীত মুভ | ৪–৬f আগে scale/y ছোট offset |
| Staging | এক ফ্রেমে একটিই হিরো মুভ | বাকি স্থির বা sin-wave micro-motion |
| Follow-through | secondary element পরে আসে | delay ৪–৮f |
| Overshoot & Settle | সব থামার আগে সামান্য অতিক্রম | `spring.snappy/bouncy` |
| Ease | linear সম্পূর্ণ নিষিদ্ধ | `theme.ease.out/inOut/in` |
| Exits | এন্ট্রান্সের চেয়ে দ্রুত | ~10f vs ~20f |
| Holds | দ্রুত মুভ → সম্পূর্ণ স্থিরতা → পরবর্তী মুভ | 15–20f still; ধ্রুব মোশন amateur দেখায় |
| Rhythm | HIT → hold → build → HIT | প্রথম 15f-এ মুভ; 90f পর্যন্ত নতুন element ছাড়া নয় |

### Easing নামকরণ (theme.ts)
| নাম | curve | কোথায় |
|---|---|---|
| `ease.out` | bezier(0.16, 1, 0.3, 1) — easeOutExpo | সব এন্ট্রান্স |
| `ease.inOut` | bezier(0.83, 0, 0.17, 1) — easeInOutQuint | মুভ, Ken Burns |
| `ease.in` | bezier(0.7, 0, 0.84, 0) | শুধু exit |
| `spring.snappy` | damping 14, stiffness 160, mass 0.6 | UI pop, শব্দ |
| `spring.smooth` | damping 20, stiffness 90, mass 1 | বড় element |
| `spring.bouncy` | damping 11, stiffness 170, mass 0.7 | খেলোদো অ্যাকসেন্ট, লোগো |

## ২. Camera Language (2.5D — CSS/transform দিয়ে)

| মুভ | কীভাবে | কখন |
|---|---|---|
| Push-in | scale 1→1.05 ধীর + parallax layer ভিন্ন গতিতে | ফোকাস বাড়াতে |
| Pull-out | scale 1.06→1 | বড় চিত্র দেখাতে |
| Orbit | 3D carousel (perspective + rotateY) | একাধিক আইটেম |
| Parallax depth | স্তর 0.3/0.6/1.0 গতিতে (Annex H §13) | depth |
| Micro-shake | sin wave 1–2px | শুধু সিনেমাটিক মুহূর্তে |
| Slow drift | translate 20–40px/scene | idle element (breathe) |

প্রতি সিনে ১টি camera move যথেষ্ট। দ্রুত মুভ (>30px/frame)-এ motion blur (Annex H §15)।

## ৩. Sound Timing (SFX সঙ্গে মোশন sync)

| নিয়ম | মান |
|---|---|
| SFX শুরু হবে | visual ল্যান্ডের **২–৩ frame আগে** (আগে = synced, পরে = broken) |
| টেক্সট/শিরোনাম এন্ট্রি | নরম whoosh বা হালকা pop |
| কার্ড/UI reveal | soft pop |
| বাটন/টিক/চেক | crisp click |
| লোগো reveal | ছোট pluck/chime |
| সিন ট্রানজিশন | ছোট smooth whoosh |
| হুক/মূল বার্তা | খুব হালকা soft thud (সংযত) |
| ট্রানজিশন প্যাটার্ন | riser → cut-এ bass hit (হুক/শেষে) |
| কাউন্টার | soft tick loop (কাউন্টিং চলাকালে) |
| Volume | SFX 0.2–0.35; মিউজিক বেড 0.2–0.3; VO থাকলে সব 6–10dB নিচে (ducking) |
| Peak | ceiling ≈ −1dB; clipping কখনো নয় |
| সীমা | পুরো ভিডিওতে ৫–৭টি সাউন্ডের সেট; একই ইভেন্টে একই সাউন্ড (সামান্য pitch/volume variation) |
| ঘনত্ব | শুধু গুরুত্বপূর্ণ এন্ট্রি/reveal/transition-এ — প্রতি staggered item-এ নয় |

## ৪. Beat Grid (মিউজিক থাকলে)

```
framesPerBeat = fps * 60 / BPM
```
- scene cut ও major hit বিটের গুণিতক frame-এ বসাও
- সম্ভব হলে আগে মিউজিক বেছে নাও, তারপর cut placement
- মিউজিক কখনো VO ঢাকবে না; না থাকলে SFX-ই প্রধান

## ৫. Idle Breathing (২s+ স্ক্রিনে)

```tsx
const breathe = 1 + Math.sin(frame / 22) * 0.015;   // scale
const float   = Math.sin(frame / 30) * 3;            // translateY px
```
সব দীর্ঘ-স্থায়ী element-এ একটি micro-motion — নাহলে frame dead দেখায়। তবে গুরুত্বপূর্ণ পড়ার সময় টেক্সট স্থির রাখো (breathing শুধু চারপাশের element-এ)।
