# Annex J — Master QA Checklist (ডেলিভারির আগে — প্রতিটি ভিডিওতে)

> এই checklist চালাও — প্রতিটি ধাপ বাস্তবে করা হয়েছে মনে হলেই tick। কোনো ধাপ করা হয়নি হলে তা ডেলিভারি নোটে স্পষ্টে লিখবে — সফল দাবি করবে না।

## A. Pre-flight (Setup)
- [ ] Node.js / npm version পরীক্ষিত
- [ ] Dependency compatibility (remotion + react version মিল); `npm install` সফল
- [ ] `package.json` scripts — `render` script সত্যিকারের composition-এ যুক্ত
- [ ] Remotion entry point (`src/index.ts`) ও Composition ID (`Main`) সঠিক
- [ ] Missing imports / syntax errors / missing modules নেই
- [ ] Missing assets নেই; image/audio/font path সঠিক (`staticFile()`)
- [ ] Windows path compatibility (forward slash; drive letter সমস্যা নেই)
- [ ] Font loading — offline bundle/fallback chain; **বাংলা যুক্তাক্ষর/কার/রেফ/baseline rendering** ঠিক (টেস্ট স্ট্রিং still দেখা হয়েছে)
- [ ] Scene timing, fps (30/60), output resolution সঠিক
- [ ] `theme.ts` ছাড়া কোথাও inline hex color/easing নেই

## B. Content Integrity
- [ ] Transcript-এর সম্পূর্ণ অংশ বিশ্লেষিত; কোনো অংশ বাদ পড়েনি
- [ ] Scene plan ↔ transcript consistency (অর্থ/ক্রম অক্ষুণ্ণ)
- [ ] কোনো কল্পিত তথ্য/সংখ্যা/দাবি/slogan/placeholder নেই
- [ ] সম্পূর্ণ transcript subtitle হিসেবে নেই; শুধু headline/keyword/label/visual
- [ ] Watermark/অযাচিত branding নেই
- [ ] 2D cartoon human নেই; emoji-as-icon নেই

## C. টাইমিং ও SRT (থাকলে)
- [ ] SRT start/end → frame conversion নির্ভুল (fps অনুযায়ী, deterministic)
- [ ] কোনো segment-এর লেখা নির্ধারিত start-এর আগে সম্পূর্ণ দেখানো হয়নি (৪–৬f আগেও নয়)
- [ ] cue বদলানোর পর পুরানো লেখা/visual অকারণে স্থির নেই
- [ ] **Word-Sync (Annex K):** spoken লেখা শব্দ-by-শব্দ ধীরে উঠছে; কোনো বাক্য একসঙ্গে ঝটকায় ঢোকেনি
- [ ] প্রতি cue-র ~৩০% ও ~৭০% সময়ে still নিয়ে দেখা হয়েছে — আংশিক লেখা দেখা যাচ্ছে (সব শব্দ একসঙ্গে নেই)
- [ ] প্রথম শব্দ cue-start-এর আগে নয়; শেষ শব্দ cue-end-এর আগে এসেছে; প্রকাশিত শব্দ থেকে যায়
- [ ] শব্দ ওঠার সময় লাইন নড়ছে/reflow করছে না (সব শব্দ আগে থেকে DOM-এ)
- [ ] শব্দ-timing-এর উৎস (word-timestamp/Whisper/SRT-অনুমান) README/ASSETS-এ নথিভুক্ত; অনুমান হলে "নিখুঁত মিল" দাবি নেই
- [ ] timestamp gap/overlap/অমিল শনাক্ত ও নথিভুক্ত
- [ ] শেষে অপ্রয়োজনীয় blank frame/frozen scene নেই; video duration ↔ SRT শেষ timestamp মিল

## D. Visual Frame Inspection (বাধ্যতামূলক — চোখে দেখা)
- [ ] মূল ফ্রেমগুলো `npx remotion still` দিয়ে রেন্ডার করে দেখা হয়েছে
- [ ] Spacing bug নেই (em gap, margin); বড় টেক্সটের পাশে pixel gap
- [ ] টেক্সট frame edge-এ কাটছে না; 9:16 safe zone মানা
- [ ] Element entrance-এর আগে/exit-এর পর দেখা যাচ্ছে না (clamp সঠিক)
- [ ] Layer order সঠিক (mesh → assets → graphics → grade → grain+vignette)
- [ ] প্রতি ফ্রেমে hero color/glow ≤ 1 element; contrast পাঠযোগ্য
- [ ] প্রতি সিনে ৫-লেয়ার স্ট্যাক আছে; ফ্ল্যাট ব্যাকগ্রাউন্ড নেই
- [ ] সব still-এ Ken Burns; দ্রুত মুভে motion blur
- [ ] Exits animated ও এন্ট্রান্সের চেয়ে দ্রুত
- [ ] সমস্যা পেলে ঠিক করে **পুনরায় render → আবার দেখা** হয়েছে

## E. ছবি/অ্যাসেট
- [ ] কোনো broken/missing image নেই; stretch/দুর্বল crop নেই
- [ ] মুখ/লোগো/গুরুত্বপূর্ণ অংশ কাটেনি
- [ ] প্রতিটি ছবির source + license `ASSETS.md`-তে
- [ ] Logo বিকৃত/পুনঃসৃষ্টি করা হয়নি

## F. Tutorial (প্রযোজ্য হলে — Annex G)
- [ ] প্রতিটি ধাপ transcript-এর সঙ্গে মিলে; কোনো ধাপ বাদ পড়েনি
- [ ] সঠিক button/option/field দেখানো হয়েছে (Annex G honesty tier মানা)
- [ ] Cursor সঠিক জায়গায় click করছে; UI state ঠিক সেখানে বদলাচ্ছে
- [ ] UI continuity আছে (আগের ধাপের page/tab/state ধরে রাখা)
- [ ] Annotation পড়ার মতো; UI element ঢাকছে না
- [ ] শুরু থেকে শেষ অনুসরণযোগ্য; দর্শক দেখে কাজটি করতে পারবে
- [ ] Recreation/uncertainty থাকলে delivery note-এ উল্লেখ আছে

## G. Audio
- [ ] SFX peak/duration/clipping যাচাই; level match
- [ ] SFX visual-এর ২–৩f আগে; অতিরিক্ত loud নয়
- [ ] VO থাকলে কিছুই তাকে ঢাকছে না; না থাকলে "audio sync যাচাই হয়েছে" দাবি করা হয়নি
- [ ] Audio asset source/license নোট আছে

## H. Final Render QA
- [ ] ভিডিও শুরু থেকে শেষ দেখা হয়েছে
- [ ] Text clipping, বাংলা অক্ষর, broken image, transition, animation timing ঠিক
- [ ] Resolution ও fps সঠিক; শেষে blank frames নেই
- [ ] Tutorial থাকলে ধাপ সঠিক ক্রমে; গুরুত্বপূর্ণ ধাপ পড়ার মতো সময় পেয়েছে
- [ ] প্রিভিউ দেখে নয় — rendered output দেখেই যাচাই

## I. Delivery
- [ ] ZIP (node_modules ছাড়া) তৈরি; extract করে README অনুযায়ী চলবে
- [ ] README.md (PowerShell: install / studio / render / output / error handling)
- [ ] ASSETS.md (সব asset-এর source + license)
- [ ] ৩টি কমান্ড (আসল path/ID সহ — placeholder নয়)
- [ ] সব পরীক্ষা যা বাস্তবে সম্পন্ন হয়েছে তা তালিকাবদ্ধ; limitation/missing asset স্পষ্ট
- [ ] কোনো command চালানো সম্ভব না হলে সেটি জানানো হয়েছে
