# Annex C — Icon ও Symbol সিস্টেম

## ১. উৎস ও লাইসেন্স

- **Inline SVG only** — Lucide / Feather / Heroicons / Material Symbols (outline) থেকে path কপি করে প্রজেক্টে (`src/components/icons/`) রাখবে। এগুলো MIT/Apache — বাণিজ্যিক ব্যবহার যোগ্য। `ASSETS.md`-তে উৎস + লাইসেন্স নোট।
- **Emoji সম্পূর্ণ নিষিদ্ধ** — emoji platform glyph (রঙিন, প্যালেট-বহির্ভূত) hero-color নিয়ম ভাঙে এবং ব্যাকগ্রাউন্ডে অদৃশ্য হতে পারে।
- আইকন কখনো raster (png) নয় — সব vector, তাই যেকোনো সাইজে sharp।

## ২. এক আইকন ভাষা (সারা ভিডিওতে)

| টোকেন | মান |
|---|---|
| Grid | 24×24 (সব আইকন এই canvas-এ আঁকা) |
| Stroke | 2px, round cap/join (line icon) |
| Corner radius | একরকম (round) |
| Color | সবসময় `theme.colors.*` — inline hex নয় |
| Size on screen | 20–48px (UI ভেতরে 16–24px, feature lockup-এ 32–48px) |
| Filled variant | শুধু status (সফল/ত্রুটি) — বাকিতে line icon |

এক ভিডিওতে ২টির বেশি আইকন স্টাইল (যেমন line + filled + duotone) মেশাবে না।

## ৩. Icon Animation Patterns

| প্যাটার্ন | কীভাবে | কখন |
|---|---|---|
| **Stroke Draw-On** | stroke-dasharray/offset animate | লাইন আইকন এন্ট্রি, টেকনিক্যাল |
| **Icon Pop** | scale 0.6→1.1→1 (spring bouncy) + opacity, 10f | সাধারণ এন্ট্রি |
| **Icon Morph** | এক path → অন্য path (play→pause, check→check-circle) | অবস্থা পরিবর্তন |
| **Icon Grid Stagger** | ৪f offset, ছোট pop | ফিচার গ্রিড |
| **Check Burst** | টিক draw + চারপাশে ৪টি ছোট লাইন বার্স্ট (6f) | সম্পন্ন/সফল |
| **Progress Ring** | circle stroke-dashoffset + counter | অগ্রগতি |
| **Badge Pulse** | ছোট pop + ১বার pulse (12f) | notification/dot |
| **Icon+Label Lockup** | আইকন আসবে → ৬f পরে লেবেল (follow-through) | feature উপস্থাপনা |
| **Draw + Fade Exit** | exit এন্ট্রান্সের চেয়ে দ্রুত (8f) | সব আইকনে |

সব আইকন **stagger করবে** (একসঙ্গে সব নয়)। প্রতি staggered item-এ SFX নয় — শুধু গ্রুপ reveal-এ ১টি।

## ৪. ব্যবহার ম্যাট্রিক্স

| জায়গা | স্টাইল | সঙ্গে |
|---|---|---|
| Feature/তালিকা | line icon 32–40px | ছোট label |
| Status | filled + status color | সবসময় লেবেল টেক্সট সহ (শুধু রঙে নয়) |
| Dashboard/UI mockup | line icon 16–24px | UI_Text |
| Recap/Checklist | animated check | আইটেম টেক্সট |
| Step indicator | number chip (সংখ্যা) | step label |
| শুধু সাজসজ্জা | **আইকন নয়** — shape/line/particle ব্যবহার করো | — |

## ৫. Lockup ও Badge

- **Icon + Text lockup:** আইকন-লেবেল gap সবসময় pixel-এ (8–16px), এক baseline-এ, একই opacity/entrance group।
- **Badge:** icon পেছনে rounded rect (hero color 12–20% opacity) বা border pill।
- **Notification dot:** icon-এর উপরে-ডানে 8px dot + pulse।
- আইকন কখনো টেক্সটের উপর বসে পড়ে পাঠযোগ্যতা কমাবে না।
