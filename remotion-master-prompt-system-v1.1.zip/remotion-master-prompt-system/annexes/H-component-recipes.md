# Annex H — Component Recipes (কপি-পেস্ট কোড লাইব্রেরি)

> সব component `theme` import করবে (`src/theme.ts`)। `useCurrentFrame()` / `useVideoConfig()` / `interpolate` / `spring` remotion থেকে। **কোনো `interpolate()` linear নয়; সবসময় clamp।** কোডে inline hex/easing নয়।

## 1. Premium entrance (কাজের ঘোড়া)

```tsx
const Entrance: React.FC<{delay?: number; children: React.ReactNode}> =
({ delay = 0, children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
  return (
    <div style={{
      opacity: p,
      transform: `translateY(${interpolate(p, [0, 1], [40, 0])}px)
                  scale(${interpolate(p, [0, 1], [0.94, 1])})`,
    }}>{children}</div>
  );
};
```
Bezier দরকার হলে (নিয়ন্ত্রিত slide):
```tsx
const x = interpolate(frame, [0, 25], [60, 0], {
  easing: theme.ease.out,
  extrapolateLeft: "clamp", extrapolateRight: "clamp", // সবসময় দুটোই
});
```

## 2. Staggered children
```tsx
{items.map((item, i) => <Entrance key={i} delay={start + i * 4}>{item}</Entrance>)}
```
offset: শব্দ 3f · কার্ড/তালিকা 4–5f · বড় ব্লক 6f।

## 3. Word-by-word reveal (বাংলা-সেফ — space split; ছোট UI/label stagger, ৩f/শব্দ)
> ⚠️ spoken লেখায় এটি নয় — তার জন্য §22 `SyncedWords` (ভয়েসের গতিতে, ধীরে)।
```tsx
const WordReveal: React.FC<{text: string; delay?: number; per?: number;
  style?: React.CSSProperties}> = ({ text, delay = 0, per = 3, style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: "0.26em", ...style }}>
      {text.split(" ").map((word, i) => {
        const p = spring({ frame: frame - delay - i * per, fps,
          config: theme.spring.snappy });
        return (
          <span key={i} style={{
            display: "inline-block", opacity: p,
            transform: `translateY(${interpolate(p, [0, 1], [30, 0])}px)`,
          }}>{word}</span>
        );
      })}
    </div>
  );
};
```
GOTCHA: বড় টেক্সট ব্লকের পাশে flex row-তে `gap` pixel-এ (যেমন 42) — em নয় (em = parent font-size, প্রায় শূন্য gap হয়)।

## 4. Background mesh (ফ্ল্যাট নয়)
```tsx
const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50, d2 = Math.cos(frame / 70) * 40;
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div style={{ position: "absolute", width: 1200, height: 1200,
        borderRadius: "50%", top: -450, left: -300 + d1, filter: "blur(50px)",
        background: `radial-gradient(circle, ${theme.colors.primary}33, transparent 62%)` }}/>
      <div style={{ position: "absolute", width: 900, height: 900,
        borderRadius: "50%", bottom: -400, right: -250 - d2, filter: "blur(70px)",
        background: `radial-gradient(circle, ${theme.colors.accent}22, transparent 65%)` }}/>
    </AbsoluteFill>
  );
};
```

## 5. Color grade overlay (content-এর উপরে, grain-এর নিচে)
```tsx
const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.primary,
      mixBlendMode: "soft-light", opacity: 0.18 }}/>
    <AbsoluteFill style={{ background:
      "linear-gradient(180deg, rgba(0,0,0,0.10), transparent 28%, transparent 72%, rgba(0,0,0,0.2))" }}/>
  </AbsoluteFill>
);
```
Opacity: light theme 0.10–0.15, dark 0.18–0.25।

## 6. Procedural grain (asset ছাড়া)
```tsx
const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return <AbsoluteFill style={{ pointerEvents: "none",
    backgroundImage: noise, backgroundSize: "220px",
    backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
    opacity: 0.05, mixBlendMode: "multiply" }}/>; // dark theme-এ "overlay"
};
```

## 7. Vignette (সবচেয়ে উপরের layer)
```tsx
const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background:
    "radial-gradient(ellipse at center, transparent 56%, rgba(0,0,0,0.22) 100%)" }}/>
);
```

## 8. Ken Burns (প্রতিটি still-এ — ব্যতিক্রম নয়)
```tsx
const KenBurns: React.FC<{src: string; zoomTo?: number}> = ({ src, zoomTo = 1.1 }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const scale = interpolate(frame, [0, durationInFrames], [1, zoomTo],
    { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const pan = interpolate(frame, [0, durationInFrames], [0, -25],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return <Img src={staticFile(src)} style={{ width: "100%", height: "100%",
    objectFit: "cover", transform: `scale(${scale}) translateX(${pan}px)` }}/>;
};
```
পরপর শটে zoom-in/zoom-out alternate। Rounded card-এ মাস্ক: `borderRadius: 32, overflow: "hidden", border: "1px solid rgba(255,255,255,0.08)", boxShadow: "0 40px 80px -20px rgba(0,0,0,0.6)"`।

## 9. Animated counter
```tsx
const value = interpolate(
  spring({ frame: frame - delay, fps, config: { damping: 30, stiffness: 60 } }),
  [0, 1], [0, target], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
<span style={{ fontVariantNumeric: "tabular-nums" }}>{value.toFixed(1)}%</span>
```
`tabular-nums` ডিজিট বদলালে jitter রোধ করে। **সংখ্যা সবসময় স্ক্রিপ্টের — কল্পিত নয়।**

## 10. Spark / radial logo mark
```tsx
const rays = 12;
{Array.from({ length: rays }).map((_, i) => {
  const p = spring({ frame: frame - delay - i * 1.2, fps,
    config: theme.spring.snappy });
  return <div key={i} style={{ position: "absolute", left: "50%", top: "50%",
    width: size * 0.085, height: size * 0.46 * p, background: theme.colors.primary,
    borderRadius: size, transformOrigin: "50% 0%",
    transform: `translateX(-50%) rotate(${(360 / rays) * i}deg) translateY(${size * 0.07}px)` }}/>
})}
```
কনটেইনারে bouncy scale + smooth rotation (−120° থেকে) + `filter: drop-shadow(0 0 ${size*0.25}px ${theme.colors.glow})`।

## 11. Exits — এন্ট্রান্সের চেয়ে দ্রুত
```tsx
const exitY = interpolate(frame, [durationInFrames - 12, durationInFrames - 2],
  [0, -42], { easing: theme.ease.in,
  extrapolateLeft: "clamp", extrapolateRight: "clamp" });
const exitO = interpolate(frame, [durationInFrames - 12, durationInFrames - 2],
  [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
```
প্রতিটি visible element বা scene wrapper-এ প্রয়োগ।

## 12. Idle breathing (২s+ স্ক্রিনে)
```tsx
const breathe = 1 + Math.sin(frame / 22) * 0.015;
const float = Math.sin(frame / 30) * 3;
const drift = interpolate(frame, [0, 300], [0, -20],
  { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
```

## 13. Parallax depth (৩ স্তর)
```tsx
const x = interpolate(frame, [0, 90], [0, -120],
  { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
<Bg style={{ transform: `translateX(${x * 0.3}px)` }}/>
<Mid style={{ transform: `translateX(${x * 0.6}px)` }}/>
<Fg style={{ transform: `translateX(${x}px)` }}/>
```

## 14. Transitions
`@remotion/transitions`:
```tsx
import { TransitionSeries, linearTiming } from "@remotion/transitions";
import { slide } from "@remotion/transitions/slide";
<TransitionSeries>
  <TransitionSeries.Sequence durationInFrames={90}><A/></TransitionSeries.Sequence>
  <TransitionSeries.Transition presentation={slide({ direction: "from-right" })}
    timing={linearTiming({ durationInFrames: 12 })}/>
  <TransitionSeries.Sequence durationInFrames={150}><B/></TransitionSeries.Sequence>
</TransitionSeries>
```
Hand-rolled (৮–১৪f):
- **Whip pan**: bg 6f-এ 1500px + `filter: blur(8px)`; cut মাঝ-whip-এ।
- **Scale-through**: A scale 1.3 + fade, B 0.8→1 নিচে।
- **Mask wipe**: brand-color আকৃতি সুইপ; পেছনে cut।

## 15. Motion blur (>30px/frame মুভে)
```tsx
import { Trail } from "@remotion/motion-blur";
<Trail layers={4} lagInFrames={0.4}><FastThing/></Trail>
```

## 16. Audio + SFX sync
```tsx
import { Audio, Sequence, staticFile } from "remotion";
<Audio src={staticFile("sfx/music.mp3")} volume={0.25}/>
<Sequence from={entranceFrame - 3}>  {/* visual ল্যান্ডের 2-3f আগে */}
  <Audio src={staticFile("sfx/whoosh_soft_01.wav")} volume={0.7}/>
</Sequence>
```
Beat-এ cut: `framesPerBeat = fps * 60 / BPM`।

## 17. Audio ছাড়া SRT-driven phrase reveal (শুধু অ-spoken লেখা/লেবেলের জন্য)
> spoken লেখার জন্য **§21–§22 (Annex K)** ব্যবহার করো — এই §17 পদ্ধতি spoken বাক্যে নয়।
```tsx
// cue-এর সময়সীমার মধ্যে লাইন/phrase ধরে reveal — শব্দ timestamp না থাকলে word-by-word নয়
const cue = { start: 90, end: 150, lines: ["প্রথম লাইন", "দ্বিতীয় লাইন"] };
{cue.lines.map((line, i) => {
  const lineStart = cue.start + i * ((cue.end - cue.start) / cue.lines.length);
  return <LineMaskRise key={i} text={line} delay={lineStart}/>;
})}
```
spoken লেখার শব্দ-স্তর reveal: **§21–§22 / Annex K** (word timestamp থাকলে নিখুঁত; না থাকলে SRT থেকে অনুপাতিক অনুমান)।

## 18. Text Window (টেক্সটের ভেতর ছবি)
```tsx
<div style={{
  fontSize: 120, fontWeight: 800,
  backgroundImage: `url(${staticFile("images/hero.jpg")})`,
  backgroundSize: "cover", backgroundPosition: `${50 + panX}% 50%`,
  WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent",
}}>{word}</div>
```

## 19. Highlight sweep (pill/underline)
```tsx
const sweep = interpolate(frame, [delay, delay + 12], [0, 1],
  { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
<div style={{ position: "relative", display: "inline-block" }}>
  {word}
  <div style={{ position: "absolute", left: 0, bottom: 4, height: 10,
    width: `${sweep * 100}%`, background: theme.colors.primary, opacity: 0.35,
    borderRadius: 8 }}/>
</div>
```

## 20. Icon draw-on (Annex C)
```tsx
const p = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
<svg viewBox="0 0 24 24" width={40} height={40} fill="none"
  stroke={theme.colors.text} strokeWidth={2} strokeLinecap="round">
  <path d="M4 12l5 5L20 6"
    strokeDasharray={30} strokeDashoffset={30 * (1 - p)} />
</svg>
```

## 21. `buildWordTimings` — SRT cue → শব্দ-প্রতি reveal frame (Annex K)
`src/data/wordTiming.ts` — pure, deterministic। cue-র সময়কে শব্দের দৈর্ঘ্য + বিরামচিহ্ন অনুযায়ী ভাগ করে।
```ts
export type WordUnit = { text: string; startFrame: number; endFrame: number };
export type WordTimingOpts = {
  fps: number;
  leadFrames?: number;      // cue শুরুর পর প্রথম শব্দ আসতে দেরি (ডিফল্ট 2f)
  tailRatio?: number;       // cue-এর শেষ অংশ খালি (ডিফল্ট 0.08)
  minGapFrames?: number;    // দুই reveal-এর ন্যূনতম ব্যবধান; কম হলে শব্দ মিলিয়ে একক (ডিফল্ট 4f)
  maxGapSec?: number;       // দীর্ঘ cue-তে শব্দপ্রতি সর্বোচ্চ ছড়ানো (ডিফল্ট 0.9s)
  wordTimes?: { text: string; startSec: number; endSec: number }[]; // নির্ভরযোগ্য word-timestamp থাকলে এটাই
};

const seg = new Intl.Segmenter("bn", { granularity: "grapheme" });
const clusters = (w: string) => [...seg.segment(w.replace(/[।,?!:;—\-.]/g, ""))].length;
const pauseAfter = (w: string) =>
  /[।?!.]$/.test(w) ? 3 : /[,;:—]$/.test(w) ? 1.6 : 0;

export function buildWordTimings(
  text: string, cueStartSec: number, cueEndSec: number, o: WordTimingOpts
): WordUnit[] {
  const { fps } = o;
  const f = (s: number) => Math.round(s * fps);
  const words = text.trim().split(/\s+/).filter(Boolean);   // শুধু space-split — অক্ষর ভাঙা নিষিদ্ধ
  const cueStart = f(cueStartSec), cueEnd = f(cueEndSec);

  // ১) নির্ভরযোগ্য word-level timestamp থাকলে সরাসরি
  if (o.wordTimes?.length)
    return o.wordTimes.map(w => ({ text: w.text,
      startFrame: Math.max(cueStart, f(w.startSec)), endFrame: f(w.endSec) }));

  // ২) অনুপাতিক অনুমান
  const lead = o.leadFrames ?? 2;
  const tail = Math.max(4, Math.round((cueEnd - cueStart) * (o.tailRatio ?? 0.08)));
  const w = words.map(x => Math.max(2, clusters(x)));
  const gaps = words.map(x => pauseAfter(x));
  const total = w.reduce((a, b) => a + b, 0) + gaps.reduce((a, b) => a + b, 0)
    - gaps[gaps.length - 1];
  let span = cueEnd - tail - (cueStart + lead);
  span = Math.max(1, Math.min(span, Math.round((o.maxGapSec ?? 0.9) * fps * words.length)));

  const raw: number[] = [];
  let acc = 0;
  words.forEach((_, i) => {
    raw.push(cueStart + lead + Math.round((acc / total) * span));
    acc += w[i] + gaps[i];
  });

  // ৩) খুব কাছাকাছি শব্দ এক ইউনিটে
  const minGap = o.minGapFrames ?? 4;
  const units: WordUnit[] = [];
  words.forEach((t, i) => {
    const last = units[units.length - 1];
    if (last && raw[i] - last.startFrame < minGap) last.text += " " + t;
    else units.push({ text: t, startFrame: raw[i], endFrame: cueEnd });
  });
  units.forEach((u, i) => {
    u.endFrame = i + 1 < units.length ? units[i + 1].startFrame : cueEnd;
  });
  return units;
}

// দীর্ঘ cue → chunk (বিরামচিহ্নে ভাঙা, প্রতি chunk ≤ maxWords)
export function chunkUnits(units: WordUnit[], maxWords = 8): WordUnit[][] {
  const chunks: WordUnit[][] = [[]];
  units.forEach(u => {
    const cur = chunks[chunks.length - 1];
    const count = cur.reduce((n, x) => n + x.text.split(" ").length, 0);
    cur.push(u);
    const breaks = /[।?!.,;:]$/.test(u.text);
    if (count + u.text.split(" ").length >= maxWords || (breaks && count >= maxWords - 3))
      chunks.push([]);
  });
  return chunks.filter(c => c.length);
}
```
ব্যবহার (`timeline.ts`): `buildWordTimings(cue.text, cue.startSec, cue.endSec, { fps: 30 })`। Whisper/word-timestamp থাকলে `wordTimes` দাও।

## 22. `SyncedWords` — ধীর, ভয়েস-মিলানো শব্দ reveal (Annex K)
```tsx
import { useCurrentFrame, interpolate } from "remotion";
import { theme } from "../../theme";
import type { WordUnit } from "../../data/wordTiming";

// units-এর frame = ABSOLUTE ভিডিও-frame। Sequence-এর ভেতরে বসালে `from` = সেই Sequence-এর from।
export const SyncedWords: React.FC<{
  units: WordUnit[]; from?: number; gapPx?: number; revealFrames?: number;
  exitAt?: number;            // (ঐচ্ছিক) এই absolute frame-এ পুরো view exit (৬f)
  style?: React.CSSProperties;
}> = ({ units, from = 0, gapPx = 28, revealFrames = 9, exitAt, style }) => {
  const abs = useCurrentFrame() + from;
  const exit = exitAt === undefined ? 0 :
    interpolate(abs, [exitAt, exitAt + 6], [0, 1],
      { easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <div style={{ display: "flex", flexWrap: "wrap", columnGap: gapPx, rowGap: gapPx * 0.3,
      opacity: 1 - exit, transform: `translateY(${-14 * exit}px)`, wordBreak: "keep-all",
      letterSpacing: 0, ...style }}>
      {units.map((u, i) => {
        // সব শব্দ DOM-এ আছে (opacity 0 অবস্থায়) → layout স্থির, reflow নেই
        const p = interpolate(abs, [u.startFrame, u.startFrame + revealFrames], [0, 1],
          { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
        const fresh = interpolate(abs, [u.startFrame, u.startFrame + 12], [1, 0],   // ঐচ্ছিক active tint
          { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
        return (
          <span key={i} style={{
            display: "inline-block", opacity: p,
            transform: `translateY(${interpolate(p, [0, 1], [14, 0])}px)`,
            filter: `blur(${interpolate(p, [0, 1], [6, 0])}px)`,
            color: fresh > 0.01 ? theme.colors.primary : theme.colors.text,
          }}>{u.text}</span>
        );
      })}
    </div>
  );
};
```
পেজিনেশনসহ ব্যবহার (দীর্ঘ cue):
```tsx
const chunks = chunkUnits(units, 8);
{chunks.map((c, i) => {
  const first = c[0].startFrame;
  const next = chunks[i + 1]?.[0].startFrame;
  const last = c[c.length - 1].endFrame;
  return (
    <Sequence key={i} from={first} durationInFrames={(next ?? last + 24) - first + 6}>
      <SyncedWords units={c} from={first} exitAt={next ?? last + 18} style={{ fontSize: 96 }} />
    </Sequence>
  );
})}
```
GOTCHA: `<Sequence from={X}>` ভেতরে `useCurrentFrame()` 0 থেকে শুরু — তাই `from={X}` অবশ্যই পাস করো, নইলে শব্দ ভুল সময়ে আসবে।
