# Project Structure Template

```
project/
├─ src/
│  ├─ index.ts                 # registerRoot(RemotionRoot)
│  ├─ Root.tsx                  # <Composition id="Main" .../>
│  ├─ theme.ts                  # templates/theme.ts থেকে (রং/ফন্ট/easing/spring/tokens)
│  ├─ data/
│  │  ├─ timeline.ts            # SRT→frame map, scene boundaries, durationInFrames
│  │  ├─ wordTiming.ts          # buildWordTimings / chunkUnits (Annex H §21, Annex K)
│  │  └─ tutorialState.ts       # tutorial steps (Annex G §3)
│  ├─ scenes/
│  │  ├─ Scene01_Hook.tsx
│  │  ├─ Scene02_Context.tsx
│  │  └─ ...
│  └─ components/
│     ├─ text/                  # SyncedWords (Annex K), WordReveal, LineMaskRise, Counter, presets (Annex B)
│     ├─ icons/                 # inline SVG icons (Annex C)
│     ├─ ui/                    # cards, panels, charts, browser/phone mockup
│     ├─ photo/                 # KenBurns, MaskReveal, treatments (Annex D)
│     ├─ tutorial/              # Cursor, ClickRipple, StepChip, HighlightBox (Annex G)
│     ├─ transitions/           # WhipPan, MaskWipe, ScaleThrough (Annex E)
│     └─ post/                  # BgMesh, Grade, Grain, Vignette (Annex H §4–7)
├─ public/
│  ├─ images/                   # সব ছবি (stock/AI/user)
│  ├─ logos/                    # ইউজারের লোগো (আসল ফাইল, বিকৃত নয়)
│  ├─ ui-refs/                  # tutorial screenshot/reference
│  ├─ fonts/                    # offline font files (Hind Siliguri, Noto Sans Bengali...)
│  ├─ sfx/                      # whoosh_soft_01.wav, click_crisp_01.wav ... (Annex I)
│  └─ voiceover.mp3             # (ঐচ্ছিক) — থাকলে PreviewAudio বাজবে
├─ out/                         # render output (video.mp4, check_*.png)
├─ ASSETS.md                    # প্রতিটি asset-এর source + license + AI-generated না কিনা
├─ README.md                    # Windows PowerShell: install / studio / render / error handling
├─ package.json                 # "render" script সত্যিকারের Main composition-এ যুক্ত
└─ tsconfig.json
```

## Naming conventions
- Composition ID: `Main` (ইউজার ভিন্ন না বললে)
- Scene files: `Scene01_Hook.tsx`, `Scene02_...` (ক্রম সংখ্যা + ভূমিকা)
- SFX: `public/sfx/<type>_<mood>_01.wav`
- Check frames: `out/check_<frame>.png`

## package.json scripts (উদাহরণ)
```json
{
  "scripts": {
    "studio": "remotion studio",
    "render": "remotion render src/index.ts Main out/video.mp4 --codec h264 --crf 17",
    "still": "remotion still src/index.ts Main out/check.png --overwrite"
  }
}
```
entry ফাইলের আসল নাম অনুযায়ী command মিলিয়ে নেবে — placeholder রাখবে না।

## Composition config (Root.tsx)
```tsx
<Composition
  id="Main"
  component={Main}
  durationInFrames={timeline.total}   // SRT শেষ timestamp → frame (+ outro padding)
  fps={30}
  width={1920}
  height={1080}
/>
```
- রিল/শর্ট: width 1080, height 1920
- 60fps: ইউজার চাইলে বা খুব দ্রুত মোশনে — সব animation frame-based বলে স্কেল হবে
- `durationInFrames` ↔ scene content মিলবে — dead air (শেষে ফাঁকা ফ্রেম) নয়
